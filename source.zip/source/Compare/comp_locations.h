/********************************************************************************/
/*    This file is part of PaleoView.                       					*/
/*                                                                      		*/
/*    PaleoView is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoView is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoView.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#ifndef COMP_LOCATIONS_H
#define COMP_LOCATIONS_H


#include <QGraphicsScene>
#include <QPainter>
#include <QFont>
#include <QGraphicsItem>
#include "General/inventory.h"
#include <stdlib.h>
#include "General/resources.h"

class Comp_Locations : public QGraphicsItem
{

public:
    Comp_Locations(QGraphicsScene *graphScene, QImage *image);

    void setSize(int map_width,int map_height);
    void setView(float lo,float la, float z);
    void setMessage(QString s);
    void setInventory(Inventory *inv);
    void set_Plot_Info(int *red,int *green,int *blue, int *plot);
    float getMapFactor_x();
    float getMapFactor_y();
    void invertLabel();
    float getZoom();
    float getLongitude();
    float getLatitude();
    void set_Map_Mode(int n);
    QRectF boundingRect() const Q_DECL_OVERRIDE;
    QPainterPath shape() const Q_DECL_OVERRIDE;
    void paint(QPainter *painter,const QStyleOptionGraphicsItem *option, QWidget *widget) Q_DECL_OVERRIDE;
    void setRect(int x1,int x2, int y1, int y2, int mode);
    void set_selected_Core(QString c,QString p);
private:
    QGraphicsScene *graph;
    QString s;
    QImage *mapimage;
    float zoom,longitude,latitude;
    int mapsize_x;
    int mapsize_y;
    Inventory *inv;
    int label_Flag;
    int map_mode;
    QString core,proxy;
    // data for basins
    double ATL_depth_min=0;
    double ATL_depth_max=5500;
    double ATL_latt_min=-90;
    double ATL_latt_max=90;
    double PAC_depth_min=0;
    double PAC_depth_max=5500;
    double PAC_latt_min=-90;
    double PAC_latt_max=60;
    double IND_depth_min=0;
    double IND_depth_max=5500;
    double IND_latt_min=-90;
    double IND_latt_max=30;
    double MED_depth_min=0;
    double MED_depth_max=5500;
    double MED_latt_min=-5.6;
    double MED_latt_max=36.4;

    // Selection Rect
    int select_Rect=0;
    double sel_x1;
    double sel_x2;
    double sel_y1;
    double sel_y2;

    Resources resources;

    int *color_red;
    int *color_green;
    int *color_blue;
    int *plot;
};

#endif // COMP_LOCATIONS_H
