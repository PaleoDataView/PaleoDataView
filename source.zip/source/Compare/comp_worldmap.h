/********************************************************************************/
/*    This file is part of PaleoView.                       					*/
/*                                                                      		*/
/*    PaleoView is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoView is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoView.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#ifndef COMP_WORLDMAP_H
#define COMP_WORLDMAP_H



#include <QDialog>
#include <QGraphicsSceneMouseEvent>
#include <QGraphicsScene>
#include "MainWindow/map.h"
#include "MainWindow/grid.h"
#include "comp_locations.h"
#include "General/inventory.h"
#include <QToolTip>
#include <QPushButton>
#include <QKeyEvent>
#include "General/resources.h"
#include "QPainter"

class Comp_WorldMap : public QGraphicsScene
{
    Q_OBJECT

public:
    Comp_WorldMap(QDialog *dialog,QImage *image);

    void setSize(int map_width,int map_height);
    void setInventory(Inventory *i);
    void set_selected_Core(QString core,QString proxy);
    void set_Plot_Info(int *red,int *green,int *blue,int *p);

private slots:
    void invertLabel();
    void set_Map_Mode();
    void set_ATL_Mode();
    void set_PAC_Mode();
    void set_IND_Mode();
    void set_MED_Mode();

signals:
    void selectedCore();


protected:
    void mousePressEvent(QGraphicsSceneMouseEvent* mouseEvent1) Q_DECL_OVERRIDE;
    void mouseReleaseEvent(QGraphicsSceneMouseEvent* mouseEvent2) Q_DECL_OVERRIDE;
    void mouseMoveEvent(QGraphicsSceneMouseEvent* mouseEvent3) Q_DECL_OVERRIDE;
    void wheelEvent(QGraphicsSceneWheelEvent *mouseEvent4) Q_DECL_OVERRIDE;
    void mouseDoubleClickEvent(QGraphicsSceneMouseEvent *mouseEvent5) Q_DECL_OVERRIDE;

    void keyPressEvent(QKeyEvent *event) Q_DECL_OVERRIDE;
    void keyReleaseEvent(QKeyEvent *event) Q_DECL_OVERRIDE;
private:
    QDialog *diag;
    Map *map;
    Grid *grid;
    Comp_Locations *loc;
    Inventory *inv;
    QImage *mapimage;
    Resources resources;

    float zoom,longitude,latitude;
    int mapsize_x;
    int mapsize_y;
    int moveFlag=0;
    int key_flag;
    int frame_x1,frame_x2,frame_y1,frame_y2;
    int map_mode;

    // data for basins
    double ATL_depth_min=0;
    double ATL_depth_max=5500;
    double ATL_latt_min=-90;
    double ATL_latt_max=90;
    double PAC_depth_min=0;
    double PAC_depth_max=5500;
    double PAC_latt_min=-90;
    double PAC_latt_max=60;
    double IND_depth_min=0;
    double IND_depth_max=5500;
    double IND_latt_min=-90;
    double IND_latt_max=30;
    double MED_depth_min=0;
    double MED_depth_max=5500;
    double MED_latt_min=-5.6;
    double MED_latt_max=36.4;

    int *color_red;
    int *color_green;
    int *color_blue;
    int *plot;
};

#endif // COMP_WORLDMAP_H
