/********************************************************************************/
/*    This file is part of PaleoDataViewer.                       					*/
/*                                                                      		*/
/*    PaleoDataViewer is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoDataViewer is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoDataViewer.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#include "compare.h"
#include "ui_compare.h"

Compare::Compare(QMainWindow *mainWindow,Inventory *inventory,QImage *image) :
    mainW(mainWindow),inv(inventory),mapimage(image),
    ui(new Ui::Compare)
{
    resources=new Resources();
    oldcore=inv->get_currentCore();
    ui->setupUi(this);
    sp=ui->splitter->saveState();
    sp_2=ui->splitter_2->saveState();
    sp_3=ui->splitter_3->saveState();
    qApp->installEventFilter(this);

    // Prepare hydro-database
    hydro=new HydroDatabase();

    amsdata=new AMSData(inv);


    // Plot data
    color_red=new int[inv->get_Entries()];
    color_green=new int[inv->get_Entries()];
    color_blue=new int[inv->get_Entries()];
    plot=new int[inv->get_Entries()];
    for(int i=0;i<inv->get_Entries();i++){
        float v=float(i)/float(inv->get_Entries());
        int r_col=0,g_col=0,b_col=0;
        v = v * 6; // Contour color sheme
        if (v < 1) {
            r_col = (int) ((v * 255));
            g_col = (int) (0);
            b_col = (int) ((v * 255));
        }
        if (v >= 1 && v < 2) {
            r_col = (int) (255 - ((v - 1) * 255));
            g_col = (int) (0);
            b_col = (int) (255);
        }
        if (v >= 2 && v < 3) {
            r_col = (int) (0);
            g_col = (int) ((v - 2) * 255);
            b_col = (int) (255 - ((v - 2) * 255));
        }
        if (v >= 3 && v < 4) {
            r_col = (int) ((v - 3) * 255);
            g_col = (int) (255);
            b_col = (int) (0);
        }
        if (v >= 4 && v < 5) {
            r_col = (int) (255);
            g_col = (int) (255 - ((v - 4) * 255));
            b_col = (int) (0);
        }
        if (v >= 5) {
            r_col = (int) (255);
            g_col = (int) ((v - 5) * 255);
            b_col = (int) ((v - 5) * 255);
        }
        color_red[i]=r_col;
        color_blue[i]=b_col;
        color_green[i]=g_col;
        plot[i]=0;

    }


    //qDebug()<<"Reading Hydro Data Complete!";

    modelIsotopeList=new QStandardItemModel(0,0,this);
    setupIsotope();
    if (inv->get_Entries()>0) setInfo();

    data2=new float[0];
    col2=new QColor[0];
    com2=new QString[0];
    lab2=new QString[0];
    map=new Graph(this,data2,0,0);
    createMap(1);

    data1=new float[0];
    data_use1=new bool[0];
    col1=new QColor[0];
    com1=new QString[0];
    multiplot=new Graph(this,data1,0,0);
    createMultiPlot();
    //setupPlot();



    connect(ui->comboBox_2,SIGNAL(currentIndexChanged(int)),this,SLOT(applyIsotope(int)));// show all/selected cores
    connect(ui->tableView,SIGNAL(clicked(QModelIndex)),this,SLOT(isotopeSelected(QModelIndex)));// entry selected
    connect(ui->pushButton,SIGNAL(clicked(bool)),this,SLOT(selectPlot()));
    connect(ui->pushButton_2,SIGNAL(clicked(bool)),this,SLOT(colorSelect()));
    connect(ui->comboBox,SIGNAL(currentTextChanged(QString)),this,SLOT(updatePlot()));
    connect(ui->pushButton_3,SIGNAL(clicked(bool)),this,SLOT(autoColor()));
    connect(map,SIGNAL(selection(int,QList<int>,QList<int>)),this,SLOT(selection_changed(int,QList<int>,QList<int>)));
    connect(map,SIGNAL(selected(int,int,int)),this,SLOT(selected_changed(int,int,int)));

}

Compare::~Compare()
{
    delete ui;
    delete hydro;
    delete resources;
    delete amsdata;

    delete[] color_red;
    delete[] color_green;
    delete[] color_blue;
    delete[] plot;
    delete map;
    delete multiplot;
    delete[] data1;
    delete[] com1;
    delete[] col1;
    delete[] data_use1;
    delete[] data2;
    delete[] col2;
    delete[] com2;
    delete[] lab2;


    inv->set_currentCore(oldcore);

}


void Compare::setupIsotope(){
    // List of Cores
    // get number of entries that pass filter
    int sum=0;
    if (ui->comboBox_2->currentText()=="All")sum=inv->get_Entries();
    if (ui->comboBox_2->currentText()=="Only Selected") sum=inv->get_Selected_Sum();
    if (ui->comboBox_2->currentText()=="Only Displayed") for (int i=0;i<inv->get_Entries();i++) if (plot[i]) sum++;
    // create the model for Isotope list
    delete modelIsotopeList;
    modelIsotopeList = new QStandardItemModel(sum,3,this);
    modelIsotopeList->setHorizontalHeaderItem(0, new QStandardItem(QString("Index")));
    modelIsotopeList->setHorizontalHeaderItem(1, new QStandardItem(QString("Name of Core")));
    modelIsotopeList->setHorizontalHeaderItem(2, new QStandardItem(QString("Proxy")));
    modelIsotopeList->setHorizontalHeaderItem(3, new QStandardItem(QString("Color")));
    //...
    ui->tableView->setModel(modelIsotopeList);
    ui->tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
    QStandardItem *var_Index = new QStandardItem[sum];
    QStandardItem *var_Core = new QStandardItem[sum];
    QStandardItem *var_Species = new QStandardItem[sum];
    QStandardItem *var_Plot = new QStandardItem[sum];

    int pos=0;
    for (int i=0;i<inv->get_Entries();i++){
        if (ui->comboBox_2->currentText()=="All" || (ui->comboBox_2->currentText()=="Only Selected"  && inv->get_Selected(i)==1)  || (ui->comboBox_2->currentText()=="Only Displayed"  && plot[i]==1)){


            var_Index[pos].setData(i,Qt::EditRole);
            modelIsotopeList->setItem(pos,0,&var_Index[pos]);

            var_Core[pos].setText(inv->get_Core(i));
            modelIsotopeList->setItem(pos,1,&var_Core[pos]);

            var_Species[pos].setText(inv->get_Species(i));
            modelIsotopeList->setItem(pos,2,&var_Species[pos]);

            var_Plot[pos].setData("",Qt::EditRole);
            modelIsotopeList->setItem(pos,3,&var_Plot[pos]);

            for (int j=0;j<3;j++) if (plot[i]) modelIsotopeList->setData(modelIsotopeList->index(pos,j), QColor(Qt::lightGray), Qt::BackgroundRole);
            if (plot[i]) modelIsotopeList->setData(modelIsotopeList->index(pos,3), QColor(color_red[i],color_green[i],color_blue[i],255), Qt::BackgroundRole);
            for (int j=0;j<3;j++) if (i==selected) modelIsotopeList->setData(modelIsotopeList->index(pos,j), QColor(Qt::gray), Qt::BackgroundRole);
            pos++;
        }
    }
    ui->tableView->setSortingEnabled(1);
    ui->tableView->verticalHeader()->setDefaultSectionSize(ui->tableView->verticalHeader()->minimumSectionSize());
    ui->tableView->resizeColumnsToContents();
    ui->tableView->setHorizontalScrollMode(ui->tableView->ScrollPerPixel);

}

void Compare::applyIsotope(int n){
    setupIsotope();
}

void Compare::isotopeSelected(QModelIndex mi){

        int sel=mi.row();
        //qDebug() << "Clicked :"+QString::number(sel);
        QStandardItemModel* model = qobject_cast<QStandardItemModel*>(ui->tableView->model());
        QString text = model->item(sel,0)->text();
        //qDebug() << text;
        selected=text.toInt(0,10);
        inv->readData(text.toInt(0,10));
        setupIsotope();
        setInfo();
}

void Compare::setInfo(){
    QFont font;
    font.setFamily("Courier");
    font.setStyleHint(QFont::Monospace);
    font.setFixedPitch(true);
    font.setPointSize(10);

    ui->textBrowser->setFont(font);
    QString str="";
    int n=selected;
    if (n>=0){
        if (inv->get_flag_Data_OK()){
            str.append("<b>Core Name.........: </b>"+inv->get_att_Core()+
                       "<br><b>Species...........: </b>"+inv->get_att_Species()+
                       "<br><b>Longitude [dez]...: </b>"+QString::number(inv->get_att_Longitude())+
                       "°<br><b>Latitude [dez]....: </b>"+QString::number(inv->get_att_Latitude())+
                       "°<br><b>Water Depth [m]...: </b>"+QString::number(inv->get_att_Water_Depth())+
                       "m<br><b>Device............: </b>"+inv->get_att_Device()+
                       "<br><b>Record Type.......: </b>"+inv->get_att_Record_Type()+
                       "<br><b>Category..........: </b>"+inv->get_att_Category()+
                       "<br><b>Filename..........: </b>"+inv->get_Filename(n)+
                       "<br><b>Importer..........: </b>"+inv->get_att_Importer()+
                       "<br><b>Carbon Flag.......: </b>"+QString::number(inv->get_att_Carbon_Use_Flag())+
                       "<br><b>Oxygen Flag.......: </b>"+QString::number(inv->get_att_Oxygen_Use_Flag())+
                       "<br><b>C-Correction......: </b>"+QString::number(inv->get_att_C_Correction())+
                       "<br><b>C-Justification...: </b>"+inv->get_att_C_Justification()+
                       "<br><b>O-Correction......: </b>"+QString::number(inv->get_att_O_Correction())+
                       "<br><b>O-Justification...: </b>"+inv->get_att_O_Justification()+
                       "<br><b>Labratory.........: </b>"+inv->get_att_Laboratory()+
                       "<br><b>Basin.............: </b>"+QString::number(inv->get_Basin(n))+
                       "<br><b>E-Paper...........: </b>"+inv->get_att_EPaper()+
                       "<br><b>Optional Values...: </b>"+inv->get_att_Optional()
                       );
        } else {
        str.append("<b>Core Name.........: </b>"+inv->get_Core(n)+
                   "<br><b>Species...........: </b>"+inv->get_Species(n)+
                   "<br><b>Longitude [dez]...: </b>"+QString::number(inv->get_Longitude(n))+
                   "°<br><b>Latitude [dez]....: </b>"+QString::number(inv->get_Latitude(n))+
                   "°<br><b>Water Depth [m]...: </b>"+QString::number(inv->get_Water_Depth(n))+
                   "m<br><b>Basin.............: </b>"+QString::number(inv->get_Basin(n))+
                   "<br><b>Record Type.......: </b>"+inv->get_Record_Type(n)+
                   "<br><b>Filename..........: </b>"+inv->get_Filename(n)+
                   "<br><b>Carbon Flag.......: </b>"+QString::number(inv->get_Carbon_Use_Flag(n))+
                   "<br><b>Oxygen Flag.......: </b>"+QString::number(inv->get_Oxygen_Use_Flag(n)));
        }
    } else {
        str.append("Select a Core");
    }

    ui->textBrowser->setText(str);

    ui->graphicsView_3->setScene(new QGraphicsScene);

    ui->graphicsView_3->setBackgroundBrush(QColor(color_red[n],color_green[n],color_blue[n]));


}

void Compare::paintEvent(QPaintEvent *)
{

    map->setSize(ui->graphicsView->width(),ui->graphicsView->height());
    multiplot->setSize(ui->graphicsView_2->width(),ui->graphicsView_2->height());
    setupIsotope();

}

void Compare::updateList(){
    setupIsotope();
    setInfo();
    createMultiPlot();

    ui->tableView->setFocus();
}

void Compare::selectPlot(){
    if (plot[selected]){
        plot[selected]=0;
    } else {
        plot[selected]=1;
    }
    updateList();


    createMap(0);
    createMultiPlot();

    update();
}

void Compare::colorSelect(){
    QColorDialog cdiag;
    QColor col(cdiag.getColor(QColor(color_red[selected],color_green[selected],color_blue[selected]),this));
    if (col.isValid()){
        color_green[selected]=col.green();
        color_red[selected]=col.red();
        color_blue[selected]=col.blue();
        ui->graphicsView_3->setBackgroundBrush(QColor(color_red[selected],color_green[selected],color_blue[selected]));
    }

    update();
}

void Compare::updatePlot(){
    createMultiPlot();   
}



void Compare::autoColor(){
    int count_total=0;
    for (int i=0;i<inv->get_Entries();i++) if(plot[i]) count_total++;
    if (count_total){
        count_total=count_total+2;
        int count=1;
        for(int i=0;i<inv->get_Entries();i++){
            if (plot[i]){
                float v=float(count)/float(count_total);
                int r_col=0,g_col=0,b_col=0;
                v = v * 6; // Contour color sheme
                if (v < 1) {
                    r_col = (int) ((v * 255));
                    g_col = (int) (0);
                    b_col = (int) ((v * 255));
                }
                if (v >= 1 && v < 2) {
                    r_col = (int) (255 - ((v - 1) * 255));
                    g_col = (int) (0);
                    b_col = (int) (255);
                }
                if (v >= 2 && v < 3) {
                    r_col = (int) (0);
                    g_col = (int) ((v - 2) * 255);
                    b_col = (int) (255 - ((v - 2) * 255));
                }
                if (v >= 3 && v < 4) {
                    r_col = (int) ((v - 3) * 255);
                    g_col = (int) (255);
                    b_col = (int) (0);
                }
                if (v >= 4 && v < 5) {
                    r_col = (int) (255);
                    g_col = (int) (255 - ((v - 4) * 255));
                    b_col = (int) (0);
                }
                if (v >= 5) {
                    r_col = (int) (255);
                    g_col = (int) ((v - 5) * 255);
                    b_col = (int) ((v - 5) * 255);
                }
                color_red[i]=r_col;
                color_blue[i]=b_col;
                color_green[i]=g_col;
                ui->graphicsView_3->setBackgroundBrush(QColor(color_red[i],color_green[i],color_blue[i]));
                count++;
            }

        }
    }
    updateList();

    createMap(0);
    createMultiPlot();
    //setupPlot();
    update();
}

void Compare::createMultiPlot(){
    if (ui->comboBox->currentText()=="Carbon-Isotopes vs. Depth"){
        // get the max size of data
        int max_row=0;
        int max_col=0;
        for (int i=0;i<inv->get_Entries();i++) max_col=max_col+plot[i];
        for (int i=0;i<inv->get_Entries();i++) {
            if (plot[i]){
                inv->set_currentCore(i);
                inv->readData(i);
                if (max_row<inv->get_Length()) max_row=inv->get_Length();
            }
        }
        delete[] data1;
        data1=new float[max_row*max_col*2];
        delete[] data_use1;
        data_use1=new bool[max_row*max_col*2];
        delete[] col1;
        col1=new QColor[max_col*2];
        delete[] com1;
        com1=new QString[max_row*max_col*2];
        int current_column=0;
        for (int i=0;i<inv->get_Entries();i++){
            if (plot[i]){
                inv->set_currentCore(i);
                inv->readData(i);
                for (int j=0;j<inv->get_Length();j++){
                    data1[j+current_column*max_row]=inv->get_data_Isotopes(0,j);
                    data1[j+(current_column+1)*max_row]=inv->get_data_Isotopes(2,j);
                    data_use1[j+current_column*max_row]=inv->get_data_Isotopes(6,j);
                    data_use1[j+(current_column+1)*max_row]=inv->get_data_Isotopes(6,j);
                    com1[j+current_column*max_row]=inv->get_att_Core()+"\n"+inv->get_att_Species();
                    com1[j+(current_column+1)*max_row]="";
                }
                for (int j=inv->get_Length();j<max_row;j++){
                    data1[j+current_column*max_row]=NAN;
                    data1[j+(current_column+1)*max_row]=NAN;
                }
                col1[current_column]=QColor(color_red[i],color_green[i],color_blue[i]);
                current_column=current_column+2;

            }
        }
        multiplot->setData(data1,max_col*2,max_row);
        multiplot->setUse(data_use1,1);
        multiplot->setTitel("","Depth [m]","\u03b413C [\u2030 VPDB]");
        multiplot->setMultiplicator(1,1);
        multiplot->setTextSize(8,0,8);
        multiplot->setSetColor(col1,1);
        multiplot->setSetLineColor(col1,1);
        multiplot->setComment(com1,2);
        multiplot->setSize(ui->graphicsView_2->width(),ui->graphicsView_2->height());
        multiplot->setSymbol(3);
        multiplot->autoSize();
        multiplot->setSettings(resources->path_PaleoDataViewer+"/Resources/Plot/Compare_C_Depth.txt",0);
        ui->graphicsView_2->setScene(multiplot);
    }

    if (ui->comboBox->currentText()=="Carbon-Isotopes vs. Age"){
        // get the max size of data
        int max_row=0;
        int max_col=0;
        for (int i=0;i<inv->get_Entries();i++) max_col=max_col+plot[i];
        for (int i=0;i<inv->get_Entries();i++) {
            if (plot[i]){
                inv->set_currentCore(i);
                inv->readData(i);
                if (max_row<inv->get_Length()) max_row=inv->get_Length();
            }
        }
        delete[] data1;
        delete[] data1;
        data1=new float[max_row*max_col*2];
        delete[] data_use1;
        data_use1=new bool[max_row*max_col*2];
        delete[] col1;
        col1=new QColor[max_col*2];
        delete[] com1;
        com1=new QString[max_row*max_col*2];
        int current_column=0;
        for (int i=0;i<inv->get_Entries();i++){
            if (plot[i]){
                inv->set_currentCore(i);
                inv->readData(i);
                for (int j=0;j<inv->get_Length();j++){
                    data1[j+current_column*max_row]=inv->get_data_Isotopes(1,j);
                    data1[j+(current_column+1)*max_row]=inv->get_data_Isotopes(2,j);
                    data_use1[j+current_column*max_row]=inv->get_data_Isotopes(6,j);
                    data_use1[j+(current_column+1)*max_row]=inv->get_data_Isotopes(6,j);
                    com1[j+current_column*max_row]=inv->get_att_Core()+"\n"+inv->get_att_Species();
                    com1[j+(current_column+1)*max_row]="";
                }
                for (int j=inv->get_Length();j<max_row;j++){
                    data1[j+current_column*max_row]=NAN;
                    data1[j+(current_column+1)*max_row]=NAN;
                }
                col1[current_column]=QColor(color_red[i],color_green[i],color_blue[i]);
                current_column=current_column+2;

            }
        }
        multiplot->setData(data1,max_col*2,max_row);
        multiplot->setUse(data_use1,1);
        multiplot->setTitel("","Age in [kyr]","\u03b413C [\u2030 VPDB]");
        multiplot->setMultiplicator(1,1);
        multiplot->setTextSize(8,0,8);
        multiplot->setSetColor(col1,1);
        multiplot->setSetLineColor(col1,1);
        multiplot->setComment(com1,2);
        multiplot->setSize(ui->graphicsView_2->width(),ui->graphicsView_2->height());
        multiplot->setSymbol(3);
        multiplot->autoSize();
        multiplot->setSettings(resources->path_PaleoDataViewer+"/Resources/Plot/Compare_C_Age.txt",0);
        ui->graphicsView_2->setScene(multiplot);
    }

    if (ui->comboBox->currentText()=="Oxygen-Isotopes vs. Depth"){
        // get the max size of data
        int max_row=0;
        int max_col=0;
        for (int i=0;i<inv->get_Entries();i++) max_col=max_col+plot[i];
        for (int i=0;i<inv->get_Entries();i++) {
            if (plot[i]){
                inv->set_currentCore(i);
                inv->readData(i);
                if (max_row<inv->get_Length()) max_row=inv->get_Length();
            }
        }
        delete[] data1;
        data1=new float[max_row*max_col*2];
        delete[] data_use1;
        data_use1=new bool[max_row*max_col*2];
        delete[] col1;
        col1=new QColor[max_col*2];
        delete[] com1;
        com1=new QString[max_row*max_col*2];
        int current_column=0;
        for (int i=0;i<inv->get_Entries();i++){
            if (plot[i]){
                inv->set_currentCore(i);
                inv->readData(i);
                for (int j=0;j<inv->get_Length();j++){
                    data1[j+current_column*max_row]=inv->get_data_Isotopes(0,j);
                    data1[j+(current_column+1)*max_row]=inv->get_data_Isotopes(3,j);
                    data_use1[j+current_column*max_row]=inv->get_data_Isotopes(6,j);
                    data_use1[j+(current_column+1)*max_row]=inv->get_data_Isotopes(6,j);
                    com1[j+current_column*max_row]=inv->get_att_Core()+"\n"+inv->get_att_Species();
                    com1[j+(current_column+1)*max_row]="";
                }
                for (int j=inv->get_Length();j<max_row;j++){
                    data1[j+current_column*max_row]=NAN;
                    data1[j+(current_column+1)*max_row]=NAN;
                }
                col1[current_column]=QColor(color_red[i],color_green[i],color_blue[i]);
                current_column=current_column+2;

            }
        }
        multiplot->setData(data1,max_col*2,max_row);
        multiplot->setUse(data_use1,1);
        multiplot->setTitel("","Depth [m]","\u03b418O [\u2030 VPDB]");
        multiplot->setMultiplicator(1,-1);
        multiplot->setTextSize(8,0,8);
        multiplot->setSetColor(col1,1);
        multiplot->setSetLineColor(col1,1);
        multiplot->setComment(com1,2);
        multiplot->setSize(ui->graphicsView_2->width(),ui->graphicsView_2->height());
        multiplot->setSymbol(3);
        multiplot->autoSize();
        multiplot->setSettings(resources->path_PaleoDataViewer+"/Resources/Plot/Compare_O_Depth.txt",0);
        ui->graphicsView_2->setScene(multiplot);
    }

    if (ui->comboBox->currentText()=="Oxygen-Isotopes vs. Age"){
        // get the max size of data
        int max_row=0;
        int max_col=0;
        for (int i=0;i<inv->get_Entries();i++) max_col=max_col+plot[i];
        for (int i=0;i<inv->get_Entries();i++) {
            if (plot[i]){
                inv->set_currentCore(i);
                inv->readData(i);
                if (max_row<inv->get_Length()) max_row=inv->get_Length();
            }
        }
        delete[] data1;
        data1=new float[max_row*max_col*2];
        delete[] data_use1;
        data_use1=new bool[max_row*max_col*2];
        delete[] col1;
        col1=new QColor[max_col*2];
        delete[] com1;
        com1=new QString[max_row*max_col*2];
        int current_column=0;
        for (int i=0;i<inv->get_Entries();i++){
            if (plot[i]){
                inv->set_currentCore(i);
                inv->readData(i);
                for (int j=0;j<inv->get_Length();j++){
                    data1[j+current_column*max_row]=inv->get_data_Isotopes(1,j);
                    data1[j+(current_column+1)*max_row]=inv->get_data_Isotopes(3,j);
                    data_use1[j+current_column*max_row]=inv->get_data_Isotopes(6,j);
                    data_use1[j+(current_column+1)*max_row]=inv->get_data_Isotopes(6,j);
                    com1[j+current_column*max_row]=inv->get_att_Core()+"\n"+inv->get_att_Species();
                    com1[j+(current_column+1)*max_row]="";
                }
                for (int j=inv->get_Length();j<max_row;j++){
                    data1[j+current_column*max_row]=NAN;
                    data1[j+(current_column+1)*max_row]=NAN;
                }
                col1[current_column]=QColor(color_red[i],color_green[i],color_blue[i]);
                current_column=current_column+2;

            }
        }
        multiplot->setData(data1,max_col*2,max_row);
        multiplot->setUse(data_use1,1);
        multiplot->setTitel("","Age in [kyr]","\u03b418O [\u2030 VPDB]");
        multiplot->setMultiplicator(1,-1);
        multiplot->setTextSize(8,0,8);
        multiplot->setSetColor(col1,1);
        multiplot->setSetLineColor(col1,1);
        multiplot->setComment(com1,2);
        multiplot->setSize(ui->graphicsView_2->width(),ui->graphicsView_2->height());
        multiplot->setSymbol(3);
        multiplot->autoSize();
        multiplot->setSettings(resources->path_PaleoDataViewer+"/Resources/Plot/Compare_O_Age.txt",0);
        ui->graphicsView_2->setScene(multiplot);
    }

    if (ui->comboBox->currentText()=="Age Model"){
        // get the max size of data
        int max_row=0;
        int max_col=0;
        for (int i=0;i<inv->get_Entries();i++) max_col=max_col+plot[i];
        for (int i=0;i<inv->get_Entries();i++) {
            if (plot[i]){
                inv->set_currentCore(i);

                amsdata->AMSRead();
                if (max_row<amsdata->get_Length()) max_row=amsdata->get_Length();
            }
        }
        delete[] data1;
        data1=new float[max_row*max_col*2];
        delete[] data_use1;
        data_use1=new bool[max_row*max_col*2];
        delete[] col1;
        col1=new QColor[max_col*2];
        delete[] com1;
        com1=new QString[max_row*max_col*2];
        int current_column=0;
        for (int i=0;i<inv->get_Entries();i++){
            if (plot[i]){
                inv->set_currentCore(i);

                amsdata->AMSRead();
                for (int j=0;j<amsdata->get_Length();j++){
                    data1[j+current_column*max_row]=amsdata->get_Depth(j);
                    data1[j+(current_column+1)*max_row]=amsdata->get_Data(4,j);
                    data_use1[j+current_column*max_row]=amsdata->get_Data(7,j);
                    data_use1[j+(current_column+1)*max_row]=amsdata->get_Data(7,j);
                    com1[j+current_column*max_row]=inv->get_Core(inv->get_currentCore())+"\n"+inv->get_Species(inv->get_currentCore());
                    com1[j+(current_column+1)*max_row]="";
                }
                for (int j=amsdata->get_Length();j<max_row;j++){
                    data1[j+current_column*max_row]=NAN;
                    data1[j+(current_column+1)*max_row]=NAN;
                }
                col1[current_column]=QColor(color_red[i],color_green[i],color_blue[i]);
                current_column=current_column+2;

            }
        }
        multiplot->setData(data1,max_col*2,max_row);
        multiplot->setUse(data_use1,1);
        multiplot->setTitel("","Depth in [m]","Age in [kyr]");
        multiplot->setMultiplicator(1,1);
        multiplot->setTextSize(8,0,8);
        multiplot->setSetColor(col1,1);
        multiplot->setSetLineColor(col1,1);
        multiplot->setComment(com1,2);
        multiplot->setSize(ui->graphicsView_2->width(),ui->graphicsView_2->height());
        multiplot->setSymbol(3);
        multiplot->autoSize();
        multiplot->setSettings(resources->path_PaleoDataViewer+"/Resources/Plot/Compare_AgeModel.txt",0);
        ui->graphicsView_2->setScene(multiplot);
    }

    if (ui->comboBox->currentText()=="Temperature"){
        // get the max size of data
        int max_row=hydro->get_t_Depth_Size();
        int max_col=0;
        for (int i=0;i<inv->get_Entries();i++) max_col=max_col+plot[i];
        delete[] data1;
        data1=new float[max_row*max_col*2];

        delete[] col1;
        col1=new QColor[max_col*2];
        delete[] com1;
        com1=new QString[max_row*max_col*2];
        int current_column=0;
        for (int i=0;i<inv->get_Entries();i++){
            if (plot[i]){
                inv->set_currentCore(i);

                for (int j=0;j<hydro->get_t_Depth_Size();j++){
                    data1[j+(current_column+1)*max_row]=hydro->get_t_Depth(j);
                    float t=hydro->getTemperature(inv->get_Longitude(i),inv->get_Latitude(i),hydro->get_t_Depth(j));
                    if (t>-1000 && t<1000){
                        data1[j+(current_column)*max_row]=t;
                    }else{
                        data1[j+(current_column)*max_row]=NAN;
                    }
                    com1[j+current_column*max_row]=inv->get_Core(i)+"\n"+inv->get_Species(i);
                    com1[j+(current_column+1)*max_row]="";
                }

                col1[current_column]=QColor(color_red[i],color_green[i],color_blue[i]);
                current_column=current_column+2;

            }
        }
        multiplot->setData(data1,max_col*2,max_row);
        multiplot->setUse(data_use1,0);
        multiplot->setTitel("","Temperature in [°C]","Depth in [m]");
        multiplot->setMultiplicator(1,-1);
        multiplot->setTextSize(8,0,8);
        multiplot->setSetColor(col1,1);
        multiplot->setSetLineColor(col1,1);
        multiplot->setComment(com1,2);
        multiplot->setSize(ui->graphicsView_2->width(),ui->graphicsView_2->height());
        multiplot->setSymbol(3);
        multiplot->autoSize();
        multiplot->setSettings(resources->path_PaleoDataViewer+"/Resources/Plot/Compare_Temp.txt",0);
        ui->graphicsView_2->setScene(multiplot);
    }

    if (ui->comboBox->currentText()=="Salinity"){
        // get the max size of data
        int max_row=hydro->get_s_Depth_Size();
        int max_col=0;
        for (int i=0;i<inv->get_Entries();i++) max_col=max_col+plot[i];

        delete[] data1;
        data1=new float[max_row*max_col*2];

        delete[] col1;
        col1=new QColor[max_col*2];
        delete[] com1;
        com1=new QString[max_row*max_col*2];
        int current_column=0;
        for (int i=0;i<inv->get_Entries();i++){
            if (plot[i]){
                inv->set_currentCore(i);

                for (int j=0;j<hydro->get_s_Depth_Size();j++){
                    data1[j+(current_column+1)*max_row]=hydro->get_s_Depth(j);
                    float t=hydro->getSalinity(inv->get_Longitude(i),inv->get_Latitude(i),hydro->get_s_Depth(j));
                    if (t>-1000 && t<1000){
                        data1[j+(current_column)*max_row]=t;
                    }else{
                        data1[j+(current_column)*max_row]=NAN;
                    }
                    com1[j+current_column*max_row]=inv->get_Core(i)+"\n"+inv->get_Species(i);
                    com1[j+(current_column+1)*max_row]="";
                }

                col1[current_column]=QColor(color_red[i],color_green[i],color_blue[i]);
                current_column=current_column+2;

            }
        }
        multiplot->setData(data1,max_col*2,max_row);
        multiplot->setUse(data_use1,0);
        multiplot->setTitel("","Salinity in [psu]","Depth in [m]");
        multiplot->setMultiplicator(1,-1);
        multiplot->setTextSize(8,0,8);
        multiplot->setSetColor(col1,1);
        multiplot->setSetLineColor(col1,1);
        multiplot->setComment(com1,2);
        multiplot->setSize(ui->graphicsView_2->width(),ui->graphicsView_2->height());
        multiplot->setSymbol(3);
        multiplot->autoSize();
        multiplot->setSettings(resources->path_PaleoDataViewer+"/Resources/Plot/Compare_Salt.txt",0);
        ui->graphicsView_2->setScene(multiplot);
    }

    if (ui->comboBox->currentText()=="d18o Seawater"){
        // get the max size of data
        int max_row=hydro->get_d18o_Depth_Size();
        int max_col=0;
        for (int i=0;i<inv->get_Entries();i++) max_col=max_col+plot[i];
        delete[] data1;
        data1=new float[max_row*max_col*2];

        delete[] col1;
        col1=new QColor[max_col*2];
        delete[] com1;
        com1=new QString[max_row*max_col*2];
        int current_column=0;
        for (int i=0;i<inv->get_Entries();i++){
            if (plot[i]){
                inv->set_currentCore(i);

                for (int j=0;j<hydro->get_d18o_Depth_Size();j++){
                    data1[j+(current_column+1)*max_row]=hydro->get_d18o_Depth(j);
                    float t=hydro->getd18o(inv->get_Longitude(i),inv->get_Latitude(i),hydro->get_d18o_Depth(j));
                    if (t>-1000 && t<1000){
                        data1[j+(current_column)*max_row]=t;
                    }else{
                        data1[j+(current_column)*max_row]=NAN;
                    }
                    com1[j+current_column*max_row]=inv->get_Core(i)+"\n"+inv->get_Species(i);
                    com1[j+(current_column+1)*max_row]="";
                }

                col1[current_column]=QColor(color_red[i],color_green[i],color_blue[i]);
                current_column=current_column+2;

            }
        }
        multiplot->setData(data1,max_col*2,max_row);
        multiplot->setUse(data_use1,0);
        multiplot->setTitel("","d18O Seawater (o/oo SMOW)","Depth in [m]");
        multiplot->setMultiplicator(1,-1);
        multiplot->setTextSize(8,0,8);
        multiplot->setSetColor(col1,1);
        multiplot->setSetLineColor(col1,1);
        multiplot->setComment(com1,2);
        multiplot->setSize(ui->graphicsView_2->width(),ui->graphicsView_2->height());
        multiplot->setSymbol(3);
        multiplot->autoSize();
        multiplot->setSettings(resources->path_PaleoDataViewer+"/Resources/Plot/Compare_Seawater.txt",0);
        ui->graphicsView_2->setScene(multiplot);
    }
}

bool Compare::eventFilter(QObject *obj, QEvent *event)
{
    if (event->type() == QEvent::KeyPress)
    {
        if (obj==this||obj==ui->graphicsView||obj==ui->tableView||obj==ui->graphicsView_2||obj==ui->graphicsView_3||obj==ui->textBrowser){
            QKeyEvent *keyEvent = static_cast<QKeyEvent *>(event);
            if (keyEvent->key()==Qt::Key_F1){
                ui->splitter->restoreState(sp);
                ui->splitter_2->restoreState(sp_2);
                ui->splitter_3->restoreState(sp_3);
                return true;
            }
        }
    }
    return QObject::eventFilter(obj, event);
}

void Compare::createMap(int first){
    delete[] data2;
    data2=new float[inv->get_Entries()*2];
    delete[] com2;
    com2=new QString[inv->get_Entries()*2];
    delete[] lab2;
    lab2=new QString[inv->get_Entries()*2];
    delete[] col2;
    col2=new QColor[inv->get_Entries()*2];
    for (int i=0;i<inv->get_Entries();i++){
        data2[i+0*inv->get_Entries()]=inv->get_Longitude(i);
        data2[i+1*inv->get_Entries()]=inv->get_Latitude(i);
        com2[i+0*inv->get_Entries()]=inv->get_Core(i)+"\n"+inv->get_Species(i);
        lab2[i+0*inv->get_Entries()]=inv->get_Core(i);
        col2[i+0*inv->get_Entries()]=Qt::black;
        col2[i+1*inv->get_Entries()]=Qt::white;
        if(plot[i]) col2[i+1*inv->get_Entries()]=QColor(color_red[i],color_green[i],color_blue[i]);


    }
    map->setData(data2,2,inv->get_Entries());
    map->setMultiplicator(1,1);
    map->setColor(col2,true);
    map->setTitel("","Longitude","Latitude");
    map->setAxisType(3,3);
    map->setTextSize(8,8,0);
    map->setComment(com2,2);
    map->setLabel(lab2,label_flag);
    map->setLockAspect(1);

    map->setRepeat(2,-180,180,0,-90,90);
    map->setLimit(-900,900,-90,90);
    if (first) map->setBackground(mapimage,-180,180,-90,90,1);
    map->setFolding(1,0);
    map->setLineStyle(Qt::NoPen);
    map->setSettings(resources->path_PaleoDataViewer+"/Resources/Plot/Comp_Map.txt");
    if (first) map->autoSize();
    ui->graphicsView->setScene(map);
}
void Compare::selection_changed(int p,QList<int> x,QList<int> y){
    //qDebug()<<"Plot send:"+QString::number(plot);
    for (int i=0;i<x.length();i++){
        //qDebug()<<QString::number(x.at(i))+" : "+QString::number(y.at(i));
        if (plot[y.at(i)]) {
            plot[y.at(i)]=0;
        }else{
            plot[y.at(i)]=1;
        }
        selected=y.at(i);


    }
    map->setSelected_X(-1);
    map->setSelected_Y(-1);
    setInfo();
    createMap(0);

    updateList();
}

void Compare::selected_changed(int p,int x,int y){
    if(y>-1){
    selected=y;
    map->setSelected_X(-1);
    map->setSelected_Y(-1);
    setInfo();
    }

}
