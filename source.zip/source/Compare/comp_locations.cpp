/********************************************************************************/
/*    This file is part of PaleoView.                       					*/
/*                                                                      		*/
/*    PaleoView is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoView is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoView.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#include "comp_locations.h"


Comp_Locations::Comp_Locations(QGraphicsScene *graphScene,QImage *image)
    : graph(graphScene),mapimage(image)
{

    s="Init";
    map_mode=0;

    mapsize_x=1;
    mapsize_y=1;

    zoom=1.0f;
    longitude=10.0f;
    latitude=53.0f;
    label_Flag=0;
    //color_red=new int[0];
    //color_green=new int[0];
    //color_blue=new int[0];
    //plot=new int[0];
}

void Comp_Locations::setSize(int x,int y)
{
    mapsize_x=x;
    mapsize_y=y;
}

void Comp_Locations::set_Map_Mode(int n)
{
    map_mode=n;
}

void Comp_Locations::setView(float lo, float la, float z){
    longitude=lo;
    latitude=la;
    zoom=z;
}
void Comp_Locations::setMessage(QString msg){
    s=msg;
}

float Comp_Locations::getMapFactor_x(){
    return mapimage->width()/360.0f*zoom;
}

float Comp_Locations::getMapFactor_y(){
    return mapimage->height()/180.0f*zoom;
}

float Comp_Locations::getZoom(){
    return zoom;
}

float Comp_Locations::getLatitude(){
    return latitude;
}

float Comp_Locations::getLongitude(){
    return longitude;
}

void Comp_Locations::setInventory(Inventory *i){
    inv=i;
}

void Comp_Locations::invertLabel(){
    if (label_Flag) {
        label_Flag=0;
    } else {
        label_Flag=1;
    }
    //qDebug()<<QString::number(label_Flag);
}

void Comp_Locations::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget){

    if (map_mode==0){
        if (longitude>180.0f) longitude=longitude-360.0f;
        if (longitude<-180.0f) longitude=longitude+360.0f;

        // calculate x and y in bitmap
        int x=(longitude+180.0f)*((float)(mapimage->width())/360.0f);
        int y=-(latitude-90.0f)*((float)(mapimage->height())/180.0f);

        // check/correct zoom level
        if (zoom<((float)(mapsize_y)/(float)(mapimage->height()))) zoom=((float)(mapsize_y)/(float)(mapimage->height()));

        // check/correct lattitude

        if ( y-(mapsize_y/zoom)/2.0f<0 ){
            y=(mapsize_y/zoom)/2.0f;
            latitude=90.0f-(180.0f/mapimage->height()*y);
        }
        if ( y+(mapsize_y/zoom)/2.0f>mapimage->height()){
            y=mapimage->height()-(mapsize_y/zoom)/2.0f;
            latitude=90.0f-(180.0f/mapimage->height()*y);
        }



        // set Font for labels
        QFont font=painter->font() ;
        font.setPointSize ( 8 );
        font.setWeight(QFont::Normal);
        painter->setFont(font);


        // estimate View in Lo and La
        float mapFactor_x=mapimage->width()/360.0f*zoom;
        float min_Longitude=longitude-(mapsize_x/2.0f/mapFactor_x);
        float max_Longitude=longitude+(mapsize_x/2.0f/mapFactor_x);
        float mapFactor_y=mapimage->height()/180.0f*zoom;
        float min_Latitude=latitude-(mapsize_y/2.0f/mapFactor_y);
        float max_Latitude=latitude+(mapsize_y/2.0f/mapFactor_y);
        //printf("%i",inv->get_Length());
        // draw Comp_Locations
        for(unsigned int i=0;i<inv->get_Entries();i++){
            // Check if Core inside View of centre map
            if(inv->get_Latitude(i)>min_Latitude && inv->get_Latitude(i)<max_Latitude){
                if (inv->get_Longitude(i)>min_Longitude && inv->get_Longitude(i)<max_Longitude){
                    // draw a Marker at Location
                    int sx=(inv->get_Longitude(i)-longitude)*mapFactor_x;
                    int sy=(latitude-inv->get_Latitude(i))*mapFactor_y;
                    painter->setBrush(QColor(color_red[i],color_green[i],color_blue[i],255));
                    //if (inv->get_Selected(i)) painter->setBrush(QColor(Qt::red));
                    if (inv->get_Core(i)==core && inv->get_Species(i)==proxy){
                        painter->setBrush(QColor(Qt::green));
                        painter->drawRect(QRect(sx-4,sy-4,8,8));
                    } else {
                        if (plot[i]) {
                            painter->drawRect(QRect(sx-4,sy-4,8,8));
                        } else {
                            painter->setBrush(QColor(255,255,255,255));
                            painter->drawRect(QRect(sx-2,sy-2,4,4));
                        }
                    }
                    if (label_Flag) painter->drawText(sx+4,sy+4,inv->get_Core(i));
                }
                // Check if Core inside View of right map
                if (inv->get_Longitude(i)-360>min_Longitude && inv->get_Longitude(i)-360<max_Longitude){
                    // draw a Marker at Location
                    int sx=(inv->get_Longitude(i)-longitude-360)*mapFactor_x;
                    int sy=(latitude-inv->get_Latitude(i))*mapFactor_y;
                    painter->setBrush(QColor(color_red[i],color_green[i],color_blue[i],255));
                    //if (inv->get_Selected(i)) painter->setBrush(QColor(Qt::red));
                    if (inv->get_Core(i)==core && inv->get_Species(i)==proxy){
                        painter->setBrush(QColor(Qt::green));
                        painter->drawRect(QRect(sx-4,sy-4,8,8));
                    } else {
                        if (plot[i]) {
                            painter->drawRect(QRect(sx-4,sy-4,8,8));
                        } else {
                            painter->setBrush(QColor(255,255,255,255));
                            painter->drawRect(QRect(sx-2,sy-2,4,4));
                        }
                    }
                    if (label_Flag) painter->drawText(sx+4,sy+4,inv->get_Core(i));
                }
                // Check if Core inside View of left map
                if (inv->get_Longitude(i)+360>min_Longitude && inv->get_Longitude(i)+360<max_Longitude){

                    // draw a Marker at Location
                 int sx=(inv->get_Longitude(i)+360-longitude)*mapFactor_x;
                    int sy=(latitude-inv->get_Latitude(i))*mapFactor_y;
                    painter->setBrush(QColor(color_red[i],color_green[i],color_blue[i],255));
                    //if (inv->get_Selected(i)) painter->setBrush(QColor(Qt::red));
                    if (inv->get_Core(i)==core && inv->get_Species(i)==proxy){
                        painter->setBrush(QColor(Qt::green));
                        painter->drawRect(QRect(sx-4,sy-4,8,8));
                    } else {
                        if (plot[i]) {
                            painter->drawRect(QRect(sx-4,sy-4,8,8));
                        } else {
                            painter->setBrush(QColor(255,255,255,255));
                            painter->drawRect(QRect(sx-2,sy-2,4,4));
                        }
                    }
                    if (label_Flag) painter->drawText(sx+4,sy+4,inv->get_Core(i));
                }
            }
        }
        if (select_Rect==1){

        }

        // Draw message
        //painter->drawText(0,20,QString("Position (%1,%2)").arg(start).arg(end));
    }

    // Atlantic mode
    if (map_mode==1){

        for (int i=0;i<inv->get_Entries();i++){
            if (inv->get_Basin(i)==1){
                // draw a Marker at Location
                int sx=(int)(-mapsize_x/2+(inv->get_Latitude(i)-ATL_latt_min)*(float)((float)mapsize_x)/(ATL_latt_max-ATL_latt_min));
                int sy=(int)(-mapsize_y/2+inv->get_Water_Depth(i)*(float)((float)mapsize_y)/(ATL_depth_max-ATL_depth_min));
                painter->setBrush(QColor(Qt::blue));
                if (inv->get_Selected(i)) painter->setBrush(QColor(Qt::red));
                painter->drawRect(QRect(sx-2,sy-2,4,4));

                if (label_Flag) painter->drawText(sx+4,sy+4,inv->get_Core(i));
            }
        }
    }
    // Pacific Mode
    if (map_mode==2){
        for (int i=0;i<inv->get_Entries();i++){
            if (inv->get_Basin(i)==2){
                // draw a Marker at Location
                int sx=(int)(-mapsize_x/2+(inv->get_Latitude(i)-PAC_latt_min)*(float)((float)mapsize_x)/(PAC_latt_max-PAC_latt_min));
                int sy=(int)(-mapsize_y/2+inv->get_Water_Depth(i)*(float)((float)mapsize_y)/(PAC_depth_max-PAC_depth_min));
                painter->setBrush(QColor(Qt::blue));
                if (inv->get_Selected(i)) painter->setBrush(QColor(Qt::red));
                painter->drawRect(QRect(sx-2,sy-2,4,4));

                if (label_Flag) painter->drawText(sx+4,sy+4,inv->get_Core(i));
            }
        }

    }
    // Indic Mode
    if (map_mode==3){
        for (int i=0;i<inv->get_Entries();i++){
            if (inv->get_Basin(i)==3){
                // draw a Marker at Location
                int sx=(int)(-mapsize_x/2+(inv->get_Latitude(i)-IND_latt_min)*(float)((float)mapsize_x)/(IND_latt_max-IND_latt_min));
                int sy=(int)(-mapsize_y/2+inv->get_Water_Depth(i)*(float)((float)mapsize_y)/(IND_depth_max-IND_depth_min));
                painter->setBrush(QColor(Qt::blue));
                if (inv->get_Selected(i)) painter->setBrush(QColor(Qt::red));
                painter->drawRect(QRect(sx-2,sy-2,4,4));

                if (label_Flag) painter->drawText(sx+4,sy+4,inv->get_Core(i));
            }
        }

    }
    // Med Mode
    if (map_mode==4){
        for (int i=0;i<inv->get_Entries();i++){
            if (inv->get_Basin(i)==4){
                // draw a Marker at Location
                int sx=(int)(-mapsize_x/2+(inv->get_Latitude(i)-MED_latt_min)*(float)((float)mapsize_x)/(MED_latt_max-MED_latt_min));
                int sy=(int)(-mapsize_y/2+inv->get_Water_Depth(i)*(float)((float)mapsize_y)/(MED_depth_max-MED_depth_min));
                painter->setBrush(QColor(Qt::blue));
                if (inv->get_Selected(i)) painter->setBrush(QColor(Qt::red));
                painter->drawRect(QRect(sx-2,sy-2,4,4));

                if (label_Flag) painter->drawText(sx+4,sy+4,inv->get_Core(i));
            }
        }
    }
    if (select_Rect==1){
        QPen pen;
        pen.setWidth(1);
        pen.setColor(Qt::red);
        painter->setBrush(Qt::NoBrush);
        painter->setPen(pen);
        painter->drawRect(QRect(sel_x1,sel_y1,(sel_x2-sel_x1),(sel_y2-sel_y1)));
    }


}

QRectF Comp_Locations::boundingRect() const
{
}

QPainterPath Comp_Locations::shape() const
{
}

void Comp_Locations::setRect(int x1,int x2, int y1, int y2, int mode){
    select_Rect=mode;
    sel_x1=x1;
    sel_x2=x2;
    sel_y1=y1;
    sel_y2=y2;
}

void Comp_Locations::set_selected_Core(QString c,QString p){
    core=c;
    proxy=p;
}

void Comp_Locations::set_Plot_Info(int *red,int *green,int *blue,int *p){
    color_red=red;
    color_green=green;
    color_blue=blue;
    plot=p;
}
