/********************************************************************************/
/*    This file is part of PaleoView.                       					*/
/*                                                                      		*/
/*    PaleoView is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoView is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoView.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#include "map.h"

Map::Map(QGraphicsScene *graphScene,QImage *image)
    : graph(graphScene),mapimage(image)
{
    s="Init";
    map_mode=0;

    mapATL.load(resources.filename_ATL);
    mapPAC.load(resources.filename_PAC);
    mapIND.load(resources.filename_IND);
    mapMED.load(resources.filename_MED);
    mapsize_x=1;
    mapsize_y=1;

    zoom=1.0f;
    longitude=10.0f;
    latitude=53.0f;
}

void Map::setSize(int x,int y)
{
    mapsize_x=x;
    mapsize_y=y;
}

void Map::set_Map_Mode(int n)
{
    map_mode=n;
}

void Map::setView(float lo, float la, float z){
    longitude=lo;
    latitude=la;
    zoom=z;
}
void Map::setMessage(QString msg){
    s=msg;
}

float Map::getMapFactor_x(){
    return mapimage->width()/360.0f*zoom;
}

float Map::getMapFactor_y(){
    return mapimage->height()/180.0f*zoom;
}

float Map::getZoom(){
    return zoom;
}

float Map::getLatitude(){
    return latitude;
}

float Map::getLongitude(){
    return longitude;
}

void Map::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget){

    if (map_mode==0){
        // calculate lattitude and longitude
        //float longitude=(360/mapimage->width()*x)-180;
        //float lattitude=90-(180/mapimage->height()*y);
        if (longitude>180.0f) longitude=longitude-360.0f;
        if (longitude<-180.0f) longitude=longitude+360.0f;

        // calculate x and y in bitmap
        int x=(longitude+180.0f)*((float)(mapimage->width())/360.0f);
        int y=-(latitude-90.0f)*((float)(mapimage->height())/180.0f);

        // check/correct zoom level
        if (zoom<((float)(mapsize_y)/(float)(mapimage->height()))) zoom=((float)(mapsize_y)/(float)(mapimage->height()));

        // check/correct lattitude

        if ( y-(mapsize_y/zoom)/2.0f<0 ){
            y=(mapsize_y/zoom)/2.0f;
            latitude=90.0f-(180.0f/mapimage->height()*y);
        }
        if ( y+(mapsize_y/zoom)/2.0f>mapimage->height()){
            y=mapimage->height()-(mapsize_y/zoom)/2.0f;
            latitude=90.0f-(180.0f/mapimage->height()*y);
        }
        // Create centre Picture
        QImage mapsection(mapimage->copy(x-(mapsize_x/zoom)/2,y-(mapsize_y/zoom)/2,(mapsize_x/zoom),(mapsize_y/zoom)));

        // add left copy to picture
        int x1=mapimage->width()-((x-(mapsize_x/zoom)/2.0f)*(-1));
        int x2=mapimage->width();
        if (x2-x1<=0) x1=x2;
        QImage mapsection_left(mapimage->copy(x1,y-(mapsize_y/zoom)/2,(x2-x1),(mapsize_y/zoom)));

        // add right copy to picture
        int x3=0;
        int x4=x+(mapsize_x/zoom)/2.0f-mapimage->width();
        if (x4-x3<=0) x3=x4;
        QImage mapsection_right(mapimage->copy(x3,y-(mapsize_y/zoom)/2,(x4-x3),(mapsize_y/zoom)));

        // apply zoom
        if (zoom>1.0f){
            mapsection=mapsection.scaled(mapsize_x,mapsize_y,Qt::IgnoreAspectRatio,Qt::FastTransformation);
            if (!mapsection_left.isNull()) mapsection_left=mapsection_left.scaled((x2-x1)*zoom,mapsize_y,Qt::IgnoreAspectRatio,Qt::SmoothTransformation);
            if (!mapsection_right.isNull()) mapsection_right=mapsection_right.scaled((x4-x3)*zoom,mapsize_y,Qt::IgnoreAspectRatio,Qt::SmoothTransformation);
        } else {
            mapsection=mapsection.scaled(mapsize_x,mapsize_y,Qt::IgnoreAspectRatio,Qt::FastTransformation);
            if (!mapsection_left.isNull()) mapsection_left=mapsection_left.scaled((x2-x1)*zoom,mapsize_y,Qt::IgnoreAspectRatio,Qt::FastTransformation);
            if (!mapsection_right.isNull()) mapsection_right=mapsection_right.scaled((x4-x3)*zoom,mapsize_y,Qt::IgnoreAspectRatio,Qt::FastTransformation);
        }

        // draw map
        painter->drawImage(-mapsection.width()/2,-mapsection.height()/2,mapsection);
        painter->drawImage(-mapsection.width()/2,-mapsection.height()/2,mapsection_left);
        painter->drawImage(mapsection.width()/2-mapsection_right.width(),-mapsection.height()/2,mapsection_right);

        // Draw message
        //painter->drawText(0,0,QString("Position (%1,%2)").arg(longitude).arg(lattitude));
    }
    // Atlantic mode
    if (map_mode==1){
        QImage map=mapATL.scaled(mapsize_x,mapsize_y,Qt::IgnoreAspectRatio,Qt::FastTransformation);
        painter->drawImage(-mapsize_x/2,-mapsize_y/2,map);
        painter->drawText(-mapsize_x/2+5,-mapsize_y/2+10,"ATL");
    }
    // Pacific Mode
    if (map_mode==2){
        QImage map=mapPAC.scaled(mapsize_x,mapsize_y,Qt::IgnoreAspectRatio,Qt::FastTransformation);
        painter->drawImage(-mapsize_x/2,-mapsize_y/2,map);
        painter->drawText(-mapsize_x/2+5,-mapsize_y/2+10,"PAC");
    }
    // Indic Mode
    if (map_mode==3){
        QImage map=mapIND.scaled(mapsize_x,mapsize_y,Qt::IgnoreAspectRatio,Qt::FastTransformation);
        painter->drawImage(-mapsize_x/2,-mapsize_y/2,map);
        painter->drawText(-mapsize_x/2+5,-mapsize_y/2+10,"IND");
    }
    // Med Mode
    if (map_mode==4){
        QImage map=mapMED.scaled(mapsize_x,mapsize_y,Qt::IgnoreAspectRatio,Qt::FastTransformation);
        painter->drawImage(-mapsize_x/2,-mapsize_y/2,map);
        painter->drawText(-mapsize_x/2+5,-mapsize_y/2+10,"MED");
    }


}

QRectF Map::boundingRect() const
{
}

QPainterPath Map::shape() const
{ 
}


