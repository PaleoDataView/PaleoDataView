/********************************************************************************/
/*    This file is part of PaleoView.                       					*/
/*                                                                      		*/
/*    PaleoView is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoView is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoView.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#ifndef MAP_H
#define MAP_H

#include <QImage>
#include <QGraphicsPixmapItem>
#include <QGraphicsScene>
#include <QGraphicsSceneMouseEvent>
#include <QPainter>
#include "General/resources.h"

QT_BEGIN_NAMESPACE
class QGraphicsSceneMouseEvent;
QT_END_NAMESPACE

class Map : public QGraphicsItem
{
public:
    Map(QGraphicsScene *graphScene,QImage *image);

    void setSize(int map_width,int map_height);
    void setView(float lo,float la, float z);
    void setMessage(QString s);
    float getMapFactor_x();
    float getMapFactor_y();

    float getZoom();
    float getLongitude();
    float getLatitude();
    void set_Map_Mode(int n);
    QRectF boundingRect() const Q_DECL_OVERRIDE;
    QPainterPath shape() const Q_DECL_OVERRIDE;
    void paint(QPainter *painter,const QStyleOptionGraphicsItem *option, QWidget *widget) Q_DECL_OVERRIDE;

private:
    QGraphicsScene *graph;
    QString s;
    QImage *mapimage;
    QImage mapATL;
    QImage mapPAC;
    QImage mapIND;
    QImage mapMED;
    float zoom,longitude,latitude;
    int mapsize_x;
    int mapsize_y;
    int map_mode;

    Resources resources;
};

#endif // MAP_H
