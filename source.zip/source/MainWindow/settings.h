/********************************************************************************/
/*    This file is part of PaleoView.                       					*/
/*                                                                      		*/
/*    PaleoView is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoView is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoView.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#ifndef SETTINGS_H
#define SETTINGS_H

#include <QDialog>
#include <QDebug>
#include <QString>
#include <QFileDialog>
#include <QFile>
#include "General/resources.h"
#include <QDesktopServices>

namespace Ui {
class Settings;
}

class Settings : public QDialog
{
    Q_OBJECT

public:
    explicit Settings(QWidget *parent = 0);
    ~Settings();

private slots:
    void Browse_filename_global();
    void Browse_filename_ATL();
    void Browse_filename_PAC();
    void Browse_filename_IND();
    void Browse_filename_MED();
    void Browse_filename_inventory();
    void Browse_path_data();
    void Browse_path_age();
    void Browse_path_target();
    void Browse_filename_C14_Cal();
    void Browse_path_hydro();
    void Browse_filename_config();
    void Accept();

private:
    Ui::Settings *ui;
    Resources *resources;
};

#endif // SETTINGS_H
