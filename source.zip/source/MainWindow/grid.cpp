/********************************************************************************/
/*    This file is part of PaleoView.                       					*/
/*                                                                      		*/
/*    PaleoView is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoView is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoView.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#include "grid.h"

Grid::Grid(QGraphicsScene *graphScene,QImage *image)
    : graph(graphScene),mapimage(image)
{

    s="Init";
    map_mode=0;

    mapsize_x=1;
    mapsize_y=1;

    zoom=1.0f;
    longitude=10.0f;
    latitude=53.0f;
}

void Grid::setSize(int x,int y)
{
    mapsize_x=x;
    mapsize_y=y;
}

void Grid::set_Map_Mode(int n)
{
    map_mode=n;
}

void Grid::setView(float lo, float la, float z){
    longitude=lo;
    latitude=la;
    zoom=z;
}
void Grid::setMessage(QString msg){
    s=msg;
}

float Grid::getMapFactor_x(){
    return mapimage->width()/360.0f*zoom;
}

float Grid::getMapFactor_y(){
    return mapimage->height()/180.0f*zoom;
}

float Grid::getZoom(){
    return zoom;
}

float Grid::getLatitude(){
    return latitude;
}

float Grid::getLongitude(){
    return longitude;
}

void Grid::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget){

    if (map_mode==0){
        if (longitude>180.0f) longitude=longitude-360.0f;
        if (longitude<-180.0f) longitude=longitude+360.0f;

        // calculate x and y in bitmap
        int x=(longitude+180.0f)*((float)(mapimage->width())/360.0f);
        int y=-(latitude-90.0f)*((float)(mapimage->height())/180.0f);

        // check/correct zoom level
        if (zoom<((float)(mapsize_y)/(float)(mapimage->height()))) zoom=((float)(mapsize_y)/(float)(mapimage->height()));

        // check/correct lattitude

        if ( y-(mapsize_y/zoom)/2.0f<0 ){
            y=(mapsize_y/zoom)/2.0f;
            latitude=90.0f-(180.0f/mapimage->height()*y);
        }
        if ( y+(mapsize_y/zoom)/2.0f>mapimage->height()){
            y=mapimage->height()-(mapsize_y/zoom)/2.0f;
            latitude=90.0f-(180.0f/mapimage->height()*y);
        }


        // draw Grid
        // set Font
        QFont font=painter->font() ;
        font.setPointSize ( 8 );
        font.setWeight(QFont::DemiBold);
        painter->setFont(font);

        // longitude
        float mapFactor_x=mapimage->width()/360.0f*zoom;
        float step=1.0f;
        if (mapsize_x/mapFactor_x>10.0f) step=5.0f;
        if (mapsize_x/mapFactor_x>20.0f) step=10.0f;
        if (mapsize_x/mapFactor_x>60.0f) step=30.0f;
        float start=((int)(longitude-(mapsize_x/2.0f/mapFactor_x))/(int)step)*step;
        float end=((int)(longitude+(mapsize_x/2.0f/mapFactor_x))/(int)step)*step;

        for (float sx=start;sx<=end;sx=sx+step){
            int x1=(sx-longitude)*mapFactor_x;
            painter->drawLine(x1,-mapsize_y,x1,mapsize_y);
            int x_scale=sx;
            if (sx>180.0f) x_scale=sx-360.0f;
            if (sx<-180.0f) x_scale=sx+360.0f;
            painter->drawText(x1,0,QString("%1°").arg(x_scale));
        }

        // lattitude
        float mapFactor_y=mapimage->height()/180.0f*zoom;
        step=1.0f;
        if (mapsize_x/mapFactor_x>10.0f) step=5.0f;
        if (mapsize_y/mapFactor_y>20.0f) step=10.0f;
        if (mapsize_y/mapFactor_y>60.0f) step=30.0f;
        start=((int)(latitude-(mapsize_x/2.0f/mapFactor_y))/(int)step)*step;
        end=((int)(latitude+(mapsize_x/2.0f/mapFactor_y))/(int)step)*step;

        for (float sy=start;sy<=end;sy=sy+step){
            int y1=(latitude-sy)*mapFactor_y;
            painter->drawLine(-mapsize_x,y1,mapsize_x,y1);
            painter->drawText(0,y1,QString("%1°").arg(sy));
        }

        // Draw message
        //painter->drawText(0,20,QString("Position (%1,%2)").arg(start).arg(end));
    }
    // Atlantic mode
    if (map_mode==1){
        QFont font=painter->font() ;
        font.setPointSize ( 8 );
        font.setWeight(QFont::DemiBold);
        painter->setFont(font);

        // longitude
        double start=ATL_latt_min;
        double ende=ATL_latt_max;
        double step=10;
        double count=0;
        for (int i=start;i<=ende;i=i+step){
            int x=(int)(-mapsize_x/2+count*(float)((float)mapsize_x)/(ende-start));
            painter->drawLine(x,-mapsize_y/2,x,mapsize_y/2);
            painter->drawText(x,mapsize_y/2-2,QString::number(i));
            count+=step;
        }
        // Depth
        start=ATL_depth_min;
        ende=ATL_depth_max;
        step=1000;
        count=0;
        for (int i=start;i<=ende;i=i+step){
            int y=(int)(-mapsize_y/2+count*(float)((float)mapsize_y)/(ende-start));
            painter->drawLine(-mapsize_x/2,y,mapsize_x/2,y);
            painter->drawText(-mapsize_x/2,y,QString::number(i));
            count+=step;
        }
    }
    // Pacific Mode
    if (map_mode==2){
        QFont font=painter->font() ;
        font.setPointSize ( 8 );
        font.setWeight(QFont::DemiBold);
        painter->setFont(font);

        // longitude
        double start=PAC_latt_min;
        double ende=PAC_latt_max;
        double step=10;
        double count=0;
        for (int i=start;i<=ende;i=i+step){
            int x=(int)(-mapsize_x/2+count*(float)((float)mapsize_x)/(ende-start));
            painter->drawLine(x,-mapsize_y/2,x,mapsize_y/2);
            int j=i;
            if (i>180)j=i-360;
            painter->drawText(x,mapsize_y/2-2,QString::number(j));
            count+=step;
        }
        // Depth
        start=PAC_depth_min;
        ende=PAC_depth_max;
        step=1000;
        count=0;
        for (int i=start;i<=ende;i=i+step){
            int y=(int)(-mapsize_y/2+count*(float)((float)mapsize_y)/(ende-start));
            painter->drawLine(-mapsize_x/2,y,mapsize_x/2,y);

            painter->drawText(-mapsize_x/2,y,QString::number(i));
            count+=step;
        }
    }
    // Indic Mode
    if (map_mode==3){
        QFont font=painter->font() ;
        font.setPointSize ( 8 );
        font.setWeight(QFont::DemiBold);
        painter->setFont(font);

        // longitude
        double start=IND_latt_min;
        double ende=IND_latt_max;
        double step=10;
        double count=0;
        for (int i=start;i<=ende;i=i+step){
            int x=(int)(-mapsize_x/2+count*(float)((float)mapsize_x)/(ende-start));
            painter->drawLine(x,-mapsize_y/2,x,mapsize_y/2);
            painter->drawText(x,mapsize_y/2-2,QString::number(i));
            count+=step;
        }
        // Depth
        start=IND_depth_min;
        ende=IND_depth_max;
        step=1000;
        count=0;
        for (int i=start;i<=ende;i=i+step){
            int y=(int)(-mapsize_y/2+count*(float)((float)mapsize_y)/(ende-start));
            painter->drawLine(-mapsize_x/2,y,mapsize_x/2,y);
            painter->drawText(-mapsize_x/2,y,QString::number(i));
            count+=step;
        }
    }
    // Med Mode
    if (map_mode==4){
        QFont font=painter->font() ;
        font.setPointSize ( 8 );
        font.setWeight(QFont::DemiBold);
        painter->setFont(font);

        // longitude
        double start=MED_latt_min;
        double ende=MED_latt_max;
        double step=10;
        double count=0;
        for (int i=start;i<=ende;i=i+step){
            int x=(int)(-mapsize_x/2+count*(float)((float)mapsize_x)/(ende-start));
            painter->drawLine(x,-mapsize_y/2,x,mapsize_y/2);
            painter->drawText(x,mapsize_y/2-2,QString::number(i));
            count+=step;
        }
        // Depth
        start=MED_depth_min;
        ende=MED_depth_max;
        step=1000;
        count=0;
        for (int i=start;i<=ende;i=i+step){
            int y=(int)(-mapsize_y/2+count*(float)((float)mapsize_y)/(ende-start));
            painter->drawLine(-mapsize_x/2,y,mapsize_x/2,y);
            painter->drawText(-mapsize_x/2,y,QString::number(i));
            count+=step;
        }
    }

}

QRectF Grid::boundingRect() const
{
}

QPainterPath Grid::shape() const
{
}

