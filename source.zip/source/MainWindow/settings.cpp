/********************************************************************************/
/*    This file is part of PaleoView.                       					*/
/*                                                                      		*/
/*    PaleoView is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoView is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoView.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#include "settings.h"
#include "ui_settings.h"

Settings::Settings(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Settings)
{
    ui->setupUi(this);
    resources=new Resources();
    ui->lineEdit->setText(resources->get_filename_global());
    ui->lineEdit_2->setText(resources->get_filename_ATL());
    ui->lineEdit_3->setText(resources->get_filename_PAC());
    ui->lineEdit_4->setText(resources->get_filename_IND());
    ui->lineEdit_5->setText(resources->get_filename_MED());
    ui->lineEdit_6->setText(resources->get_filename_inventory());
    ui->lineEdit_7->setText(resources->get_path_data());
    ui->lineEdit_8->setText(resources->get_path_age());
    ui->lineEdit_9->setText(resources->get_path_target());
    ui->lineEdit_10->setText(resources->get_filename_C14_Cal());
    ui->lineEdit_11->setText(resources->get_path_paleoview());
    ui->lineEdit_12->setText(resources->get_path_hydro());
    connect(ui->pushButton_2,SIGNAL(clicked()),this,SLOT(Browse_filename_global()));
    connect(ui->pushButton_3,SIGNAL(clicked()),this,SLOT(Browse_filename_ATL()));
    connect(ui->pushButton_4,SIGNAL(clicked()),this,SLOT(Browse_filename_PAC()));
    connect(ui->pushButton_5,SIGNAL(clicked()),this,SLOT(Browse_filename_IND()));
    connect(ui->pushButton_6,SIGNAL(clicked()),this,SLOT(Browse_filename_MED()));
    connect(ui->pushButton_7,SIGNAL(clicked()),this,SLOT(Browse_filename_inventory()));
    connect(ui->pushButton_8,SIGNAL(clicked()),this,SLOT(Browse_path_data()));
    connect(ui->pushButton_9,SIGNAL(clicked()),this,SLOT(Browse_path_age()));
    connect(ui->pushButton_10,SIGNAL(clicked()),this,SLOT(Browse_path_target()));
    connect(ui->pushButton_11,SIGNAL(clicked()),this,SLOT(Browse_filename_C14_Cal()));
    connect(ui->pushButton_12,SIGNAL(clicked()),this,SLOT(Browse_filename_config()));
    connect(ui->pushButton_13,SIGNAL(clicked()),this,SLOT(Browse_path_hydro()));
    connect(ui->pushButton,SIGNAL(clicked()),this,SLOT(Accept()));
}

Settings::~Settings()
{
    delete ui;
    delete resources;
}

void Settings::Browse_filename_global(){
    QString file = QFileDialog::getOpenFileName(this, tr("Select File"),
                                             "",
                                             tr("PNG File (*.png)"));
    //qDebug() << file;
    if (file!="") ui->lineEdit->setText(file);
}

void Settings::Browse_filename_ATL(){
    QString file = QFileDialog::getOpenFileName(this, tr("Select File"),
                                             "",
                                             tr("PNG File (*.png)"));
    //qDebug() << file;
    if (file!="") ui->lineEdit_2->setText(file);
}

void Settings::Browse_filename_PAC(){
    QString file = QFileDialog::getOpenFileName(this, tr("Select File"),
                                             "",
                                             tr("PNG File (*.png)"));
    //qDebug() << file;
    if (file!="")ui->lineEdit_3->setText(file);
}

void Settings::Browse_filename_IND(){
    QString file = QFileDialog::getOpenFileName(this, tr("Select File"),
                                             "",
                                             tr("PNG File (*.png)"));
    //qDebug() << file;
    if (file!="")ui->lineEdit_4->setText(file);
}

void Settings::Browse_filename_MED(){
    QString file = QFileDialog::getOpenFileName(this, tr("Select File"),
                                             "",
                                             tr("PNG File (*.png)"));
    //qDebug() << file;
    ui->lineEdit_5->setText(file);
}

void Settings::Browse_filename_inventory(){
    QString file = QFileDialog::getOpenFileName(this, tr("Select File"),
                                             "",
                                             tr("Inventory File (*.txt)"));
    //qDebug() << file;
    if (file!="")ui->lineEdit_6->setText(file);
}

void Settings::Browse_path_data(){
    QString file = QFileDialog::getExistingDirectory(this, tr("Select Folder"),
                                             "",
                                             QFileDialog::ShowDirsOnly);
    //qDebug() << file;
    ui->lineEdit_7->setText(file);
}

void Settings::Browse_path_age(){
    QString file = QFileDialog::getExistingDirectory(this, tr("Select Folder"),
                                             "",
                                             QFileDialog::ShowDirsOnly);
    //qDebug() << file;
    if (file!="")ui->lineEdit_8->setText(file);
}

void Settings::Browse_path_target(){
    QString file = QFileDialog::getExistingDirectory(this, tr("Select Folder"),
                                             "",
                                             QFileDialog::ShowDirsOnly);
    //qDebug() << file;
    if (file!="")ui->lineEdit_9->setText(file);
}

void Settings::Browse_filename_C14_Cal(){
    QString file = QFileDialog::getOpenFileName(this, tr("Select File"),
                                             "",
                                             tr("C14 File (*.c14)"));
    //qDebug() << file;
    if (file!="")ui->lineEdit_10->setText(file);
}

void Settings::Browse_filename_config(){
    QString file = QFileDialog::getOpenFileName(this, tr("Select File"),
                                             "",
                                             tr("Config File (*.txt)"));
    //qDebug() << file;
    if (file!="")ui->lineEdit_11->setText(file);
}

void Settings::Browse_path_hydro(){
    QString file = QFileDialog::getExistingDirectory(this, tr("Select Folder"),
                                             "",
                                             QFileDialog::ShowDirsOnly);
    //qDebug() << file;
    ui->lineEdit_12->setText(file);
}

void Settings::Accept(){
    // Save Everything
    resources->set_filename_global(ui->lineEdit->text());
    resources->set_filename_ATL(ui->lineEdit_2->text());
    resources->set_filename_PAC(ui->lineEdit_3->text());
    resources->set_filename_IND(ui->lineEdit_4->text());
    resources->set_filename_MED(ui->lineEdit_5->text());
    resources->set_filename_inventory(ui->lineEdit_6->text());
    resources->set_path_data(ui->lineEdit_7->text());
    resources->set_path_age(ui->lineEdit_8->text());
    resources->set_path_target(ui->lineEdit_9->text());
    resources->set_filename_C14_Cal(ui->lineEdit_10->text());
    resources->set_path_paleoview(ui->lineEdit_11->text());
    resources->set_path_hydro(ui->lineEdit_12->text());
    resources->save();
    QDesktopServices::openUrl(QUrl("file:///"+ui->lineEdit_11->text(), QUrl::TolerantMode));
    emit(this->close());
}
