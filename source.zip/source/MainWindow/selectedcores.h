/********************************************************************************/
/*    This file is part of PaleoView.                       					*/
/*                                                                      		*/
/*    PaleoView is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoView is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoView.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#ifndef SELECTEDCORES_H
#define SELECTEDCORES_H

#include <QListWidget>
#include <QTextBrowser>
#include <QLineEdit>
#include <QMainWindow>
#include <General/inventory.h>
#include "Editor/graph.h"
#include <QFileDialog>
#include <QDesktopServices>
#include "Editor/graph.h"
class selectedCores : public QWidget
{
    Q_OBJECT

public:
    selectedCores(QMainWindow *mainWindow,QListWidget *list,QListWidget *list2,Inventory *i,QTextBrowser *information,QTextBrowser *reference,QTextBrowser *comment,QLineEdit *line,Graph *plot1,Graph *plot2);
    void createCores();
    int getInventory();
    void setInfo();
    QString get_selected_Core();
    QString get_selected_Proxy();
    void setCore(QString core);
    void remove();
    void removeall();

private slots:
    void coreClicked(QListWidgetItem *item);
    void proxyClicked(QListWidgetItem *item);
    void set_EPaper();
    void view_EPaper();

    void invert_O_Flag();
    void invert_C_Flag();

signals:
    void selectionChanged();

private:
    QMainWindow *mainW;
    QListWidget *Itemlist;
    QListWidget *Proxylist;
    QTextBrowser *info;
    QTextBrowser *ref;
    QTextBrowser *com;
    QLineEdit *path;
    Inventory *inv;
    Graph *pl1;
    Graph *pl2;

};

#endif // SELECTEDCORES_H
