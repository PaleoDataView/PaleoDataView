/********************************************************************************/
/*    This file is part of PaleoDataViewer.                       					*/
/*                                                                      		*/
/*    PaleoDataViewer is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoDataViewer is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoDataViewer.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#include "mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{

    // genrate gui
    ui->setupUi(this);

    sp=ui->splitter->saveState();
    sp_2=ui->splitter_2->saveState();
    sp_3=ui->splitter_3->saveState();
    sp_4=ui->splitter_4->saveState();
    sp_5=ui->splitter_5->saveState();
    qApp->installEventFilter(this);

    //init resources
    resources=new Resources();


    // read config from current location


    //this->setWindowIcon(QIcon(resources->get_path_PaleoDataViewer()+"PV_icon.ico"));
    ui->toolBar->setIconSize(QSize(32,32));
    ui->actionEdit->setIcon(QIcon(resources->get_path_PaleoDataViewer()+"/Resources/Icons/ISO.ico"));
    ui->actionCorrelation->setIcon(QIcon(resources->get_path_PaleoDataViewer()+"/Resources/Icons/Cor.ico"));
    ui->actionAMS->setIcon(QIcon(resources->get_path_PaleoDataViewer()+"/Resources/Icons/AMS.ico"));
    ui->actionBacon->setIcon(QIcon(resources->get_path_PaleoDataViewer()+"/Resources/Icons/Bacon.ico"));
    ui->actionDTW->setIcon(QIcon(resources->get_path_PaleoDataViewer()+"/Resources/Icons/DTW.ico"));
    ui->actionCompare->setIcon(QIcon(resources->get_path_PaleoDataViewer()+"/Resources/Icons/Comp.ico"));
    ui->actionModern_Hydrography->setIcon(QIcon(resources->get_path_PaleoDataViewer()+"/Resources/Icons/Hydro.ico"));
    ui->actionAbout->setIcon(QIcon(resources->get_path_PaleoDataViewer()+"/Resources/Icons/PDV_icon.ico"));
    ui->actionCredits->setIcon(QIcon(resources->get_path_PaleoDataViewer()+"/Resources/Icons/PDV_icon.ico"));
    ui->actionImport->setIcon(QIcon(resources->get_path_PaleoDataViewer()+"/Resources/Icons/Import.ico"));
    ui->actionExport->setIcon(QIcon(resources->get_path_PaleoDataViewer()+"/Resources/Icons/Export.ico"));
    ui->actionExtract_Time_Slice->setIcon(QIcon(resources->get_path_PaleoDataViewer()+"/Resources/Icons/Extract.ico"));



    // Show Logo
    About *a=new About(this);

    a->setWindowFlags(Qt::Dialog | Qt::CustomizeWindowHint );
    QScreen *screen = QGuiApplication::primaryScreen();
    QRect  screenGeometry = screen->geometry();
    int height = screenGeometry.height();
    int width = screenGeometry.width();
    a->setGeometry(width/2-500,height/2-300,500,300);


    a->show();
    QTime dieTime= QTime::currentTime().addSecs(3);

    // get an inventory file
    inv=new Inventory();
    inv->read_Basin();
    //inv->read();

    inv->generate();

    worldmap=new QImage();
    worldmap->load(resources->filename_global);
    amsdata=new AMSData(inv);

    while (QTime::currentTime() < dieTime) QCoreApplication::processEvents(QEventLoop::AllEvents, 100);
    a->close();
    delete a;

    // create plots 1&2
    data1=new float[0];
    com1=new QString[0];
    use1=new bool[0];
    col1=new QColor[0];
    style=new Qt::PenStyle[0];
    stype=new int[0];
    pl1=new Graph(this,data1,0,0);

    pl1->comHide(0);

    data2=new float[0];
    com2=new QString[0];
    use2=new bool[0];
    col2=new QColor[0];
    pl2=new Graph(this,data2,0,0);

    pl2->comHide(0);

    createEmptyPlots();






    data=new float[0];
    com=new QString[0];
    lab=new QString[0];
    col=new QColor[0];
    map=new Graph(this,data,0,0);

    createMap(1);

    // all the buttons ...
    connect(ui->pushButton_10,SIGNAL(clicked()),this,SLOT(invertLabel()));
    connect(ui->pushButton_15,SIGNAL(clicked()),this,SLOT(MapToWorld()));
    connect(ui->pushButton_14,SIGNAL(clicked()),this,SLOT(MapToATL()));
    connect(ui->pushButton_13,SIGNAL(clicked()),this,SLOT(MapToPAC()));
    connect(ui->pushButton_12,SIGNAL(clicked()),this,SLOT(MapToIND()));
    connect(ui->pushButton_11,SIGNAL(clicked()),this,SLOT(MapToMED()));
    connect(ui->pushButton_17,SIGNAL(clicked()),this,SLOT(set_EPaper()));
    connect(ui->pushButton_16,SIGNAL(clicked()),this,SLOT(view_EPaper()));
    connect(ui->pushButton_9,SIGNAL(clicked()),this,SLOT(remove()));

    ui->textBrowser_4->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(ui->textBrowser_4,SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(commentContextMenu(QPoint)));
    ui->textBrowser_3->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(ui->textBrowser_3,SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(referenceContextMenu(QPoint)));

    connect(ui->pushButton_19,SIGNAL(clicked()),this,SLOT(removeall()));

    connect(ui->treeWidget,SIGNAL(itemClicked(QTreeWidgetItem*,int)),this,SLOT(proxyClicked()));


    connect(ui->actionAMS,SIGNAL(triggered(bool)),this,SLOT(AMSCall()));
    connect(ui->actionAMS_All,SIGNAL(triggered(bool)),this,SLOT(AMSAllCall()));
    connect(ui->actionDTW,SIGNAL(triggered(bool)),this,SLOT(DTWCall()));
    connect(ui->actionCorrelation,SIGNAL(triggered(bool)),this,SLOT(CorrelateCall()));
    connect(ui->actionCompare,SIGNAL(triggered(bool)),this,SLOT(Comp()));
    connect(ui->actionModern_Hydrography,SIGNAL(triggered(bool)),this,SLOT(HydroCall()));
    connect(ui->actionEdit,SIGNAL(triggered(bool)),this,SLOT(DataViewCall()));
    connect(ui->actionBacon,SIGNAL(triggered(bool)),this,SLOT(RunBacon()));
    connect(ui->actionExtract_Time_Slice,SIGNAL(triggered(bool)),this,SLOT(Ext()));
    connect(ui->actionAbout,SIGNAL(triggered(bool)),this,SLOT(AboutCall()));
    connect(ui->actionCredits,SIGNAL(triggered(bool)),this,SLOT(credits()));
    connect(ui->actionExport,SIGNAL(triggered(bool)),this,SLOT(Xport()));
    connect(ui->actionImport,SIGNAL(triggered(bool)),this,SLOT(Iport()));
    connect(ui->actionImport_Folder,SIGNAL(triggered(bool)),this,SLOT(IportAll()));

    connect(ui->actionConvert,SIGNAL(triggered(bool)),this,SLOT(Conv()));
    connect(map,SIGNAL(selection(int,QList<int>,QList<int>)),this,SLOT(selection_changed(int,QList<int>,QList<int>)));
    connect(map,SIGNAL(selected(int,int,int)),this,SLOT(selected_changed(int,int,int)));
    connect(ui->actionChange_PV_Folder_2,SIGNAL(triggered(bool)),this,SLOT(Change_PV_Folder()));
    connect(ui->actionCreate_New_Working_Directory,SIGNAL(triggered(bool)),this,SLOT(New_Working_Directory()));
    connect(ui->actionChange_Working_Directory,SIGNAL(triggered(bool)),this,SLOT(Change_Working_Directory()));

}

MainWindow::~MainWindow()
{
    delete ui;
    delete resources;
    delete inv;
    delete worldmap;
    delete amsdata;
    delete map;
    delete pl1;
    delete pl2;



    delete[] data1;
    delete[] com1;
    delete[] use1;
    delete[] col1;
    delete[] style;
    delete[] stype;

    delete[] data2;
    delete[] com2;
    delete[] use2;
    delete[] col2;

    delete[] data;
    delete[] com;
    delete[] lab;
    delete[] col;
}

/*******************************/
void MainWindow::paintEvent(QPaintEvent *)
{

    map->setSize(ui->graphicsView_3->width(),ui->graphicsView_3->height());
    pl1->setSize(ui->graphicsView->width(),ui->graphicsView->height());
    pl2->setSize(ui->graphicsView_2->width(),ui->graphicsView_2->height());

}

void MainWindow::mousePressEvent(QMouseEvent* mouseEvent1)
{
    update();
}

void MainWindow::mouseReleaseEvent(QMouseEvent* mouseEvent2)
{
}

void MainWindow::mouseMoveEvent(QMouseEvent* mouseEvent3)
{
}



void MainWindow::redraw(){
    if (inv->get_Entries()>0&&inv->get_currentCore()!=-1){
    if (inv->get_att_Carbon_Use_Flag()){
        ui->groupBox_11->setTitle("Carbon Isotope (use)");
    } else {
        ui->groupBox_11->setTitle("Carbon Isotope (no use)");
    }
    if (inv->get_att_Oxygen_Use_Flag()){
        ui->groupBox_10->setTitle("Oxygen Isotope (use)");
    } else {
        ui->groupBox_10->setTitle("Oxygen Isotope (no use)");
    }
    createMap(0);
    createPlots();

    update();
    } else {

        ui->groupBox_10->setTitle("Oxygen Isotope");

        ui->groupBox_11->setTitle("Carbon Isotope");


        createEmptyPlots();
        update();
    }
}




void MainWindow::redraw_score(){

    createTree();
    if (inv->get_Entries()>0&&inv->get_currentCore()!=-1){
    if(inv->get_currentCore()!=-1){
        if (inv->get_att_Carbon_Use_Flag()){
            ui->groupBox_11->setTitle("Carbon Isotope (use)");
        } else {
            ui->groupBox_11->setTitle("Carbon Isotope (no use)");
        }
        if (inv->get_att_Oxygen_Use_Flag()){
            ui->groupBox_10->setTitle("Oxygen Isotope (use)");
        } else {
            ui->groupBox_10->setTitle("Oxygen Isotope (no use)");
        }
        map->setSelected_X(0);
        map->setSelected_Y(inv->get_currentCore());
        createMap(0);
        createPlots();
    } else {

        ui->groupBox_10->setTitle("Oxygen Isotope");

        ui->groupBox_11->setTitle("Carbon Isotope");


        createEmptyPlots();
    }
    update();
    } else {

        ui->groupBox_10->setTitle("Oxygen Isotope");

        ui->groupBox_11->setTitle("Carbon Isotope");


        createEmptyPlots();
        update();
    }
}

void MainWindow::commentContextMenu(QPoint pos){

        QPoint globalPos = ui->textBrowser_4->mapToGlobal(pos);

        QMenu commentMenu;
        commentMenu.addAction("Edit");


        QAction* selectedItem = commentMenu.exec(globalPos);
        if (selectedItem)
        {
            if (selectedItem->iconText()=="Edit"){
                inputDialog *indi=new inputDialog(this,ui->textBrowser_4->toPlainText(),"Comment");
                indi->setModal(true);
                indi->setAttribute( Qt::WA_DeleteOnClose );
                indi->show();

            }
        }

}

void MainWindow::referenceContextMenu(QPoint pos){

        QPoint globalPos = ui->textBrowser_3->mapToGlobal(pos);

        QMenu referenceMenu;
        referenceMenu.addAction("Edit");


        QAction* selectedItem = referenceMenu.exec(globalPos);
        if (selectedItem)
        {
            if (selectedItem->iconText()=="Edit"){

                inputDialog *indi=new inputDialog(this,ui->textBrowser_3->toPlainText(),"Reference");
                indi->setModal(true);
                indi->setAttribute( Qt::WA_DeleteOnClose );
                indi->show();
            }
        }

}
void MainWindow::plot1ContextMenu(QPoint pos){

        QPoint globalPos = ui->graphicsView->mapToGlobal(pos);

        QMenu plot1Menu;
        plot1Menu.addAction("Edit Comment");


        QAction* selectedItem = plot1Menu.exec(globalPos);
        if (selectedItem)
        {
            if (selectedItem->iconText()=="Edit Comment"&& pl1->getSelected_Y()!=-1){

                inputDialog *indi=new inputDialog(this,inv->get_data_Comments(pl1->getSelected_Y()),"Comment on Dot in Plot1");
                indi->setModal(true);
                indi->setAttribute( Qt::WA_DeleteOnClose );
                indi->show();
            }

        }

}
void MainWindow::plot2ContextMenu(QPoint pos){

        QPoint globalPos = ui->graphicsView_2->mapToGlobal(pos);

        QMenu plot2Menu;
        plot2Menu.addAction("Edit Comment");


        QAction* selectedItem = plot2Menu.exec(globalPos);
        if (selectedItem)
        {
            if (selectedItem->iconText()=="Edit Comment" && pl2->getSelected_Y()!=-1){

                inputDialog *indi=new inputDialog(this,inv->get_data_Comments(pl2->getSelected_Y()),"Comment on Dot in Plot2");
                indi->setModal(true);
                indi->setAttribute( Qt::WA_DeleteOnClose );
                indi->show();
            }
        }

}

void MainWindow::DataViewCall(){
    if (inv->get_Entries()>0){

    DataView *iso=new DataView(this,inv);
        iso->setModal(true);
        iso->setWindowFlags(Qt::Dialog | Qt::WindowTitleHint | Qt::WindowMaximizeButtonHint | Qt::WindowCloseButtonHint | Qt::CustomizeWindowHint);
        iso->setAttribute( Qt::WA_DeleteOnClose );
        iso->show();
    }
}

void MainWindow::CorrelateCall(){

    if (inv->get_currentCore()>-1){

        Correlate *cor=new Correlate(this,inv);
        cor->setModal(true);
        cor->setWindowFlags(Qt::Dialog | Qt::WindowTitleHint | Qt::WindowMaximizeButtonHint | Qt::WindowCloseButtonHint | Qt::CustomizeWindowHint);
        cor->setAttribute( Qt::WA_DeleteOnClose );
        cor->show();
    } else {
        //ui->textBrowser_2->setText("No Core/Proxy selected.");
    }
}

void MainWindow::HydroCall(){
    if (inv->get_currentCore()>-1){

        Hydro *hy=new Hydro(this,inv,worldmap);
        hy->setModal(true);
        hy->setWindowFlags(Qt::Dialog | Qt::WindowTitleHint | Qt::WindowMaximizeButtonHint | Qt::WindowCloseButtonHint | Qt::CustomizeWindowHint);
        hy->setAttribute( Qt::WA_DeleteOnClose );
        hy->show();
    } else {
        //ui->textBrowser_2->setText("No Core/Proxy selected.");
    }
}

void MainWindow::AMSCall(){
    if (inv->get_currentCore()>-1){

        AMS *ams=new AMS(this,inv);
        ams->setModal(true);
        ams->setWindowFlags(Qt::Dialog | Qt::WindowTitleHint | Qt::WindowMaximizeButtonHint | Qt::WindowCloseButtonHint | Qt::CustomizeWindowHint);
        ams->setAttribute( Qt::WA_DeleteOnClose );
        ams->show();
    } else {
        //ui->textBrowser_2->setText("No Core/Proxy selected.");
    }
}

void MainWindow::AMSAllCall(){

        AMSAll *amsall=new AMSAll(this,inv);
        amsall->setModal(true);
        amsall->setWindowFlags(Qt::Dialog | Qt::WindowTitleHint | Qt::WindowMaximizeButtonHint | Qt::WindowCloseButtonHint | Qt::CustomizeWindowHint);
        amsall->setAttribute( Qt::WA_DeleteOnClose );
        amsall->show();
}

void MainWindow::DTWCall(){
    /*if (inv->get_currentCore()>-1){
        DTW *dtw=new DTW(this,inv);
        dtw->setModal(true);
        dtw->setWindowFlags(Qt::Dialog | Qt::WindowTitleHint | Qt::WindowMaximizeButtonHint | Qt::WindowCloseButtonHint | Qt::CustomizeWindowHint);
        dtw->setAttribute( Qt::WA_DeleteOnClose );
        dtw->show();
    } else {
        //ui->textBrowser_2->setText("No Core/Proxy selected.");
    }*/
}

void MainWindow::textChanged(QString text,QString origin){
    if (origin=="Comment"&&inv->get_Entries()>0){
        //qDebug() << "Text:"+text;
        inv->set_att_Comment(text);
        inv->saveData();
        ui->textBrowser_4->setText(text);
        update();
    }
    if (origin=="Reference"&&inv->get_Entries()>0){
        //qDebug() << "Text:"+text;
        inv->set_att_Reference(text);
        inv->saveData();
        ui->textBrowser_3->setText(text);
        update();
    }
    if (origin=="Comment on Dot in Plot1"&&inv->get_Entries()>0){
        //qDebug() << "Text:"+text;
        inv->set_data_Comment(text,pl1->getSelected_Y());
        inv->saveData();
    }
    if (origin=="Comment on Dot in Plot2"&&inv->get_Entries()>0){
        //qDebug() << "Text:"+text;
        inv->set_data_Comment(text,pl2->getSelected_Y());
        inv->saveData();
    }


}

void MainWindow::AboutCall(){

    About *about=new About(this);
    about->setModal(true);
    about->setWindowFlags(Qt::Dialog | Qt::WindowTitleHint | Qt::WindowMaximizeButtonHint | Qt::WindowCloseButtonHint | Qt::CustomizeWindowHint);
    about->setAttribute( Qt::WA_DeleteOnClose );
    about->show();
}

void MainWindow::credits(){

    Credits* credit=new Credits(this);
    credit->setModal(true);
    credit->setWindowFlags(Qt::Dialog | Qt::WindowTitleHint | Qt::WindowMaximizeButtonHint | Qt::WindowCloseButtonHint | Qt::CustomizeWindowHint);
    credit->setAttribute( Qt::WA_DeleteOnClose );
    credit->show();
}

void MainWindow::Xport(){
    if (inv->get_currentCore()>-1){

        Export *xport=new Export(this,inv);
        xport->setModal(true);
        xport->setWindowFlags(Qt::Dialog | Qt::WindowTitleHint | Qt::WindowMaximizeButtonHint | Qt::WindowCloseButtonHint | Qt::CustomizeWindowHint);
        xport->setAttribute( Qt::WA_DeleteOnClose );
        xport->show();
    } else {
        //ui->textBrowser_2->setText("No Core/Proxy selected.");
    }

}

void MainWindow::Iport(){

    Import *import=new Import(this,inv);
    import->setModal(true);
    import->setWindowFlags(Qt::Dialog | Qt::WindowTitleHint | Qt::WindowMaximizeButtonHint | Qt::WindowCloseButtonHint | Qt::CustomizeWindowHint);
    import->setAttribute( Qt::WA_DeleteOnClose );
    import->show();
}

void MainWindow::IportAll(){

    ImportAll *importall=new ImportAll(this,inv);
    importall->setModal(true);
    importall->setWindowFlags(Qt::Dialog | Qt::WindowTitleHint | Qt::WindowMaximizeButtonHint | Qt::WindowCloseButtonHint | Qt::CustomizeWindowHint);
    importall->setAttribute( Qt::WA_DeleteOnClose );
    importall->show();
}

void MainWindow::Conv(){

    Convert *conv=new Convert(this);
    conv->setModal(true);
    conv->setWindowFlags(Qt::Dialog | Qt::WindowTitleHint | Qt::WindowMaximizeButtonHint | Qt::WindowCloseButtonHint | Qt::CustomizeWindowHint);
    conv->setAttribute( Qt::WA_DeleteOnClose );
    conv->show();
}

void MainWindow::Comp(){
    if (inv->get_Entries()>0){

        Compare *comp=new Compare(this,inv,worldmap);
        comp->setModal(true);
        comp->setWindowFlags(Qt::Dialog | Qt::WindowTitleHint | Qt::WindowMaximizeButtonHint | Qt::WindowCloseButtonHint | Qt::CustomizeWindowHint);
        comp->setAttribute( Qt::WA_DeleteOnClose );
        comp->show();
    }
}

void MainWindow::Ext(){
    if(inv->get_Entries()>0){

        Extract *extract=new Extract(this,inv);
        extract->setModal(true);
        extract->setWindowFlags(Qt::Dialog | Qt::WindowTitleHint | Qt::WindowMaximizeButtonHint | Qt::WindowCloseButtonHint | Qt::CustomizeWindowHint);
        extract->setAttribute( Qt::WA_DeleteOnClose );
        extract->show();
    }
}


void MainWindow::Edit(){
    /*float *data=new float[20*100];
    float *data_err=new float[20*100];
    for (int j=0;j<20;j++) for (int i=0;i<100;i++) {
        data[i+j*100]=i-(j*i);
        data_err[i+j*100]=(i-(j*i)+(j*i*i))*0.1;
    }
    Editor *c=new Editor(this,data,data_err,20,100);
    c->setModal(true);
    c->setWindowFlags(Qt::Dialog | Qt::WindowTitleHint | Qt::WindowMaximizeButtonHint | Qt::WindowCloseButtonHint | Qt::CustomizeWindowHint);
    c->show();*/
}

void MainWindow::remove(){
    inv->set_Selected(inv->get_currentCore(),0);
    inv->set_currentCore(-1);
    redraw();
    createTree();
    createEmptyPlots();
}

void MainWindow::removeall(){
    for (int i=0;i<inv->get_Entries();i++) inv->set_Selected(i,0);
    inv->set_currentCore(-1);
    redraw();
    createTree();
    createEmptyPlots();
}

void MainWindow::set_EPaper(){
    if (inv->get_currentCore()>-1&&inv->get_Entries()>0){
        QString file = QFileDialog::getOpenFileName(this, tr("Select File"),
                                                QDir::homePath(),
                                                 tr("PDF (*.pdf)"));


        //qDebug() << file;
        if(file!=""){
            inv->set_att_EPaper(file);
            inv->saveData();
            proxyClicked();
        }
    } else {
        //ui->textBrowser_2->setText("No Core/Proxy selected.");
    }
}

void MainWindow::view_EPaper(){
    if (inv->get_currentCore()>-1&&inv->get_Entries()>0){
        QDesktopServices::openUrl(QUrl("file:///"+inv->get_att_EPaper(), QUrl::TolerantMode));
    } else {
        //ui->textBrowser_2->setText("No Core/Proxy selected.");
    }
}



void MainWindow::ResetLayout(){
    ui->splitter->restoreState(sp);
    ui->splitter_2->restoreState(sp_2);
    ui->splitter_3->restoreState(sp_3);
    ui->splitter_4->restoreState(sp_4);
    ui->splitter_5->restoreState(sp_5);
}

bool MainWindow::eventFilter(QObject *obj, QEvent *event)
{
    if (event->type() == QEvent::KeyPress)
    {
        if (obj==ui->graphicsView||obj==ui->graphicsView_2||obj==ui->graphicsView_3||obj==ui->treeWidget){
            QKeyEvent *keyEvent = static_cast<QKeyEvent *>(event);
            if (keyEvent->key()==Qt::Key_F1){
                ResetLayout();
                return true;
            }
        }
    }
    return QObject::eventFilter(obj, event);
}

void MainWindow::RunBacon(){
    if (inv->get_currentCore()>-1){

        Bacon *bacon=new Bacon(this,inv);
        bacon->setModal(true);
        bacon->setWindowFlags(Qt::Dialog | Qt::WindowTitleHint | Qt::WindowMaximizeButtonHint | Qt::WindowCloseButtonHint | Qt::CustomizeWindowHint);
        bacon->setAttribute( Qt::WA_DeleteOnClose );
        bacon->show();
    } else {
        //ui->textBrowser_2->setText("No Core/Proxy selected.");
    }
}

void MainWindow::closeEvent (QCloseEvent *event)
{
    QMessageBox::StandardButton resBtn = QMessageBox::question( this, "PaleoDataViewer",
                                                                tr("Do you want to quit PaleoDataViewer?\n"),
                                                                QMessageBox::Cancel | QMessageBox::Yes,
                                                                QMessageBox::Yes);
    if (resBtn != QMessageBox::Yes) {
        event->ignore();
    } else {
        event->accept();
    }
}

void MainWindow::createEmptyPlots(){
    // fill first plot with data
    delete[] data1;
    data1=new float[1*2];
    delete[] com1;
    com1=new QString[1*2];
    for (int i=0;i<1;i++){
        data1[i+0*1]=NAN;
        data1[i+1*1]=NAN;
        com1[i+1*1]="";
    }
    pl1->setData(data1,0,0);
    pl1->setComment(com1,2);
    pl1->setSettings(resources->path_PaleoDataViewer+"/Plot/Main_C_Isotope.txt");
    pl1->autoSize();
    ui->graphicsView->setScene(pl1);

    delete[] data2;
    data2=new float[1*2];
    delete[] com2;
    com2=new QString[1*2];
    for (int i=0;i<1;i++){
        data2[i+0*1]=NAN;
        data2[i+1*1]=NAN;
        com2[i+1*1]="";
    }
    pl2->setData(data2,0,0);
    pl2->setComment(com2,2);
    pl2->setSettings(resources->path_PaleoDataViewer+"/Plot/Main_O_Isotope.txt");
    pl2->autoSize();
    ui->graphicsView_2->setScene(pl2);
}

void MainWindow::createPlots(){
    //get age model
    amsdata->AMSRead();

    // get length
    int length=inv->get_Length();
    if(amsdata->get_Length()>length) length=amsdata->get_Length();


    // fill first plot with data
    delete[] data1;
    data1=new float[length*4];
    for (int i=0;i<length*4;i++) data1[i]=NAN;
    delete[] use1;
    use1=new bool[length*4];
    for (int i=0;i<length*4;i++) use1[i]=0;
    delete[] com1;
    com1=new QString[length*4];
    for (int i=0;i<length*4;i++) com1[i]="";
    delete[] col1;
    col1=new QColor[length*4];
    for (int i=0;i<length*4;i++) col1[i]=Qt::blue;

    float low=INFINITY;
    float high=-INFINITY;
    for (int i=0;i<inv->get_Length();i++){
        data1[i+0*length]=inv->get_data_Isotopes(0,i);
        data1[i+1*length]=inv->get_data_Isotopes(2,i);
        if (low>inv->get_data_Isotopes(2,i)) low=inv->get_data_Isotopes(2,i);
        if (high<inv->get_data_Isotopes(2,i)) high=inv->get_data_Isotopes(2,i);
        use1[i+0*length]=inv->get_data_Isotopes(6,i);
        use1[i+1*length]=inv->get_data_Isotopes(6,i);
        if (inv->get_data_Comments(i).simplified()!="NaN")com1[i+1*length]=inv->get_data_Comments(i);
        col1[i+0*length]=Qt::black;
    }

    for (int i=0;i<amsdata->get_Length();i++){
        data1[i+2*length]=amsdata->get_Depth(i);
        data1[i+3*length]=low-(high-low)*0.2;
        use1[i+2*length]=amsdata->get_Data(7,i);
        use1[i+3*length]=amsdata->get_Data(7,i);
        com1[i+2*length]=amsdata->get_Type(i);
        com1[i+3*length]="Age [kyr]:"+QString::number(amsdata->get_Data(4,i));
        if (amsdata->get_Type(i)=="AMS") {
            col1[i+3*length]=Qt::gray;
        }else{
            col1[i+3*length]=Qt::darkGray;
        }
        col1[i+2*length]=Qt::black;
    }


    pl1->setData(data1,4,length);
    pl1->setUse(use1,1);
    pl1->setTitel("","Depth [m]","\u03b413C permil");
    pl1->setMultiplicator(1,1);
    pl1->setTextSize(8,0,8);
    pl1->setSize(ui->graphicsView->width(),ui->graphicsView->height());
    delete[] style;
    style=new Qt::PenStyle[4];
    style[0]=Qt::SolidLine;
    style[1]=Qt::SolidLine;
    style[2]=Qt::NoPen;
    style[3]=Qt::NoPen;

    delete[] stype;
    stype=new int[4];
    stype[0]=0;
    stype[1]=0;
    stype[2]=1;
    stype[3]=1;
    pl1->setSetLineStyle(style,1);
    pl1->setColor(col1,1);
    pl1->setSetSymboltype(stype,1);
    pl1->setComment(com1,2);
    pl1->setSettings(resources->path_PaleoDataViewer+"/Plot/Main_C_Isotope.txt");
    pl1->autoSize();
    ui->graphicsView->setScene(pl1);


    // fill first plot with data
    delete[] data2;
    data2=new float[length*4];
    for (int i=0;i<length*4;i++) data2[i]=NAN;
    delete[] use2;
    use2=new bool[length*4];
    for (int i=0;i<length*4;i++) use2[i]=0;
    delete[] com2;
    com2=new QString[length*4];
    for (int i=0;i<length*4;i++) com2[i]="";
    delete[] col2;
    col2=new QColor[length*4];
    for (int i=0;i<length*4;i++) col2[i]=Qt::blue;

    low=INFINITY;
    high=-INFINITY;
    for (int i=0;i<length;i++){
        data2[i+0*length]=inv->get_data_Isotopes(0,i);
        data2[i+1*length]=inv->get_data_Isotopes(3,i);
        use2[i+0*length]=inv->get_data_Isotopes(6,i);
        use2[i+1*length]=inv->get_data_Isotopes(6,i);
        if (low>inv->get_data_Isotopes(3,i)) low=inv->get_data_Isotopes(3,i);
        if (high<inv->get_data_Isotopes(3,i)) high=inv->get_data_Isotopes(3,i);
        if (inv->get_data_Comments(i).simplified()!="NaN")com2[i+1*length]=inv->get_data_Comments(i);
        col2[i+0*length]=Qt::black;
    }

    for (int i=0;i<amsdata->get_Length();i++){
        data2[i+2*length]=amsdata->get_Depth(i);
        data2[i+3*length]=high+(high-low)*0.2;
        use2[i+2*length]=amsdata->get_Data(7,i);
        use2[i+3*length]=amsdata->get_Data(7,i);
        com2[i+2*length]=amsdata->get_Type(i);
        com2[i+3*length]="Age [kyr]:"+QString::number(amsdata->get_Data(4,i));
        if (amsdata->get_Type(i)=="AMS") {
            col2[i+3*length]=Qt::gray;
        }else{
            col2[i+3*length]=Qt::darkGray;
        }

        col2[i+2*length]=Qt::black;
    }

    pl2->setData(data2,4,length);
    pl2->setUse(use2,1);
    pl2->setTitel("","Depth [m]","\u03b418O permil");
    pl2->setMultiplicator(1,-1);
    pl2->setTextSize(8,0,8);
    pl2->setSize(ui->graphicsView->width(),ui->graphicsView->height());

    pl2->setSetLineStyle(style,1);
    pl2->setColor(col2,1);
    pl2->setSetSymboltype(stype,1);
    pl2->setComment(com2,2);
    pl2->setSettings(resources->path_PaleoDataViewer+"/Plot/Main_O_Isotope.txt");
    pl2->autoSize();
    ui->graphicsView_2->setScene(pl2);
}

void MainWindow::createTree(){
    //create tree for variable names
    ui->treeWidget->clear();
    QList<QTreeWidgetItem *> cores;

    for (int i=0;i<inv->get_Entries();i++){

        if (inv->get_Selected(i)){
            //Check if already in list
            int index=-1;
            for (int j=0;j<cores.size();j++){
                if (cores.at(j)->text(0)==inv->get_Core(i)) index=j;
            }

            if (index==-1){
                // add new Core
                QStringList str;
                str<<inv->get_Core(i);
                cores.append(new QTreeWidgetItem((QTreeWidget*)0,str));
                // find new entry
                int index=-1;
                for (int j=0;j<cores.size();j++){
                    if (cores.at(j)->text(0)==inv->get_Core(i)) index=j;
                }
                // add proxy to core
                QTreeWidgetItem *proxy = new QTreeWidgetItem();
                proxy->setText(0, inv->get_Species(i));

                cores.at(index)->addChild(proxy);
            } else {
                // add proxy to core
                QTreeWidgetItem *proxy = new QTreeWidgetItem();
                proxy->setText(0, inv->get_Species(i));

                cores.at(index)->addChild(proxy);
            }
        }
    }
    ui->treeWidget->insertTopLevelItems(0,cores);
    ui->treeWidget->expandAll();
    if (inv->get_currentCore()!=-1){
        // mark current core
        for (int i=0;i<ui->treeWidget->topLevelItemCount();i++){
            if (ui->treeWidget->topLevelItem(i)->text(0)==inv->get_Core(inv->get_currentCore())){
                for(int j=0;j<ui->treeWidget->topLevelItem(i)->childCount();j++){
                    if (ui->treeWidget->topLevelItem(i)->child(j)->text(0)==inv->get_Species(inv->get_currentCore())) ui->treeWidget->setCurrentItem(ui->treeWidget->topLevelItem(i)->child(j));
                }
            }
        }
    }
    proxyClicked();
}

void MainWindow::proxyClicked(){
    int r_parent=ui->treeWidget->currentIndex().parent().row();
    int r_child=ui->treeWidget->currentIndex().row();
    if (r_parent==-1) {//clicked top level item
        r_parent=ui->treeWidget->currentIndex().row();
        r_child=-1;
    }
    if (r_child!=-1 && r_parent!=-1){
        QString core=ui->treeWidget->currentItem()->parent()->text(0);
        QString proxy=ui->treeWidget->currentItem()->text(0);
        // find in inventory
        int index=-1;
        for(int i=0;i<inv->get_Entries();i++){
            if (core==inv->get_Core(i) && proxy==inv->get_Species(i)) index=i;
        }
        if (index!=-1) {
            inv->readData(index);
            inv->set_currentCore(index);
            QFont font;
            font.setFamily("Courier");
            font.setStyleHint(QFont::Monospace);
            font.setFixedPitch(true);
            font.setPointSize(8);

            ui->textBrowser_3->setFont(font);
            ui->textBrowser_4->setFont(font);
            ui->textBrowser->setFont(font);

            QString str="";

            if (index>=0){
                if (inv->get_flag_Data_OK()){
                    str.append("<b>Core Name.........: </b>"+inv->get_att_Core()+
                               "<br><b>Species...........: </b>"+inv->get_att_Species()+
                               "<br><b>Longitude [dez]...: </b>"+QString::number(inv->get_att_Longitude())+
                               "°<br><b>Latitude [dez]....: </b>"+QString::number(inv->get_att_Latitude())+
                               "°<br><b>Water Depth [m]...: </b>"+QString::number(inv->get_att_Water_Depth())+
                               "m<br><b>Device............: </b>"+inv->get_att_Device()+
                               "<br><b>Record Type.......: </b>"+inv->get_att_Record_Type()+
                               "<br><b>Category..........: </b>"+inv->get_att_Category()+
                               "<br><b>Filename..........: </b>"+inv->get_Filename(index)+
                               "<br><b>Importer..........: </b>"+inv->get_att_Importer()+
                               "<br><b>Carbon Flag.......: </b>"+QString::number(inv->get_att_Carbon_Use_Flag())+
                               "<br><b>Oxygen Flag.......: </b>"+QString::number(inv->get_att_Oxygen_Use_Flag())+
                               "<br><b>C-Correction......: </b>"+QString::number(inv->get_att_C_Correction())+
                               "<br><b>C-Justification...: </b>"+inv->get_att_C_Justification()+
                               "<br><b>O-Correction......: </b>"+QString::number(inv->get_att_O_Correction())+
                               "<br><b>O-Justification...: </b>"+inv->get_att_O_Justification()+
                               "<br><b>Labratory.........: </b>"+inv->get_att_Laboratory()+
                               "<br><b>Basin.............: </b>"+QString::number(inv->get_Basin(index))+
                               "<br><b>E-Paper...........: </b>"+inv->get_att_EPaper()+
                               "<br><b>Optional Values...: </b>"+inv->get_att_Optional()
                               );
                    ui->textBrowser_3->setText(inv->get_att_Reference());
                    ui->textBrowser_4->setText(inv->get_att_Comment());
                    ui->lineEdit->setText(inv->get_att_EPaper());
                } else {
                str.append("<b>Core Name.........: </b>"+inv->get_Core(index)+
                           "<br><b>Species...........: </b>"+inv->get_Species(index)+
                           "<br><b>Longitude [dez]...: </b>"+QString::number(inv->get_Longitude(index))+
                           "°<br><b>Latitude [dez]....: </b>"+QString::number(inv->get_Latitude(index))+
                           "°<br><b>Water Depth [m]...: </b>"+QString::number(inv->get_Water_Depth(index))+
                           "m<br><b>Basin.............: </b>"+QString::number(inv->get_Basin(index))+
                           "<br><b>Record Type.......: </b>"+inv->get_Record_Type(index)+
                           "<br><b>Filename..........: </b>"+inv->get_Filename(index)+
                           "<br><b>Carbon Flag.......: </b>"+QString::number(inv->get_Carbon_Use_Flag(index))+
                           "<br><b>Oxygen Flag.......: </b>"+QString::number(inv->get_Oxygen_Use_Flag(index)));
                }
                createPlots();
            } else {
                str.append("Select a Core");
                ui->textBrowser_3->setText("Select a Core");
                ui->textBrowser_4->setText("Select a Core");
                createEmptyPlots();
            }
            ui->textBrowser->setText(str);

        }
    }
    map->setSelected_Y(inv->get_currentCore());
    redraw();
}

void MainWindow::createMap(int first){

    if (mapmode==0){
        delete[] data;
        delete[] com;
        delete[] lab;
        delete[] col;
        data=new float[inv->get_Entries()*2];
        com=new QString[inv->get_Entries()*2];
        lab=new QString[inv->get_Entries()*2];
        col=new QColor[inv->get_Entries()*2];
        for (int i=0;i<inv->get_Entries();i++){
            data[i+0*inv->get_Entries()]=inv->get_Longitude(i);
            data[i+1*inv->get_Entries()]=inv->get_Latitude(i);
            com[i+0*inv->get_Entries()]=inv->get_Core(i)+"\n"+inv->get_Species(i);
            lab[i+0*inv->get_Entries()]=inv->get_Core(i);
            col[i+0*inv->get_Entries()]=Qt::black;
            col[i+1*inv->get_Entries()]=Qt::blue;
            if (inv->get_Selected(i)==1) col[i+1*inv->get_Entries()]=Qt::green;

        }
        map->setData(data,2,inv->get_Entries());
        map->setMultiplicator(1,1);
        map->setColor(col,true);
        map->setTitel("","Longitude","Latitude");
        map->setAxisType(3,3);
        map->setTextSize(8,8,0);
        map->setComment(com,2);
        map->setLabel(lab,label_flag);
        map->setLockAspect(1);

        map->setRepeat(2,-180,180,0,-90,90);
        map->setLimit(-900,900,-90,90);

        if (first) map->setBackground(worldmap,-180,180,-90,90,1);
        map->setFolding(1,0);
        if (first) map->setView(-180,180,-90,90);
        map->setLineStyle(Qt::NoPen);
        map->setSettings(resources->path_PaleoDataViewer+"/Plot/Main_Map0.txt");

        ui->graphicsView_3->setScene(map);
    }
    // data for basins
    double ATL_depth_min=-5500;
    double ATL_depth_max=0;
    double ATL_latt_min=-90;
    double ATL_latt_max=90;
    double PAC_depth_min=-5500;
    double PAC_depth_max=0;
    double PAC_latt_min=-90;
    double PAC_latt_max=60;
    double IND_depth_min=-5500;
    double IND_depth_max=0;
    double IND_latt_min=-90;
    double IND_latt_max=30;
    double MED_depth_min=-5500;
    double MED_depth_max=0;
    double MED_latt_min=-5.6;
    double MED_latt_max=36.4;

    if (mapmode==1){

        delete[] data;
        delete[] com;
        delete[] lab;
        delete[] col;
        data=new float[inv->get_Entries()*2];
        com=new QString[inv->get_Entries()*2];
        lab=new QString[inv->get_Entries()*2];
        col=new QColor[inv->get_Entries()*2];
        for (int i=0;i<inv->get_Entries();i++){
            if (inv->get_Basin(i)==1){
                data[i+0*inv->get_Entries()]=inv->get_Latitude(i);
                data[i+1*inv->get_Entries()]=-inv->get_Water_Depth(i);
            } else {
                data[i+0*inv->get_Entries()]=NAN;
                data[i+1*inv->get_Entries()]=NAN;
            }
            com[i+0*inv->get_Entries()]=inv->get_Core(i)+"\n"+inv->get_Species(i);
            lab[i+0*inv->get_Entries()]=inv->get_Core(i);
            col[i+0*inv->get_Entries()]=Qt::black;
            col[i+1*inv->get_Entries()]=Qt::blue;
            if (inv->get_Selected(i)==1) col[i+1*inv->get_Entries()]=Qt::green;

        }
        map->setData(data,2,inv->get_Entries());
        map->setMultiplicator(1,1);
        map->setColor(col,true);
        map->setTitel("Atlantic Ocean","Lattitude","Depth [m]");
        map->setAxisType(3,3);
        map->setTextSize(8,16,0);
        map->setComment(com,2);
        map->setLabel(lab,label_flag);
        map->setLockAspect(0);

        map->setRepeat(0,ATL_latt_min,ATL_latt_max,0,ATL_depth_min,ATL_depth_max);
        map->setLimit(ATL_latt_min,ATL_latt_max,ATL_depth_min,ATL_depth_max);
        if (first) map->setBackground(resources->filename_ATL,ATL_latt_min,ATL_latt_max,ATL_depth_min,ATL_depth_max,1);
        map->setFolding(0,0);
        map->setLineStyle(Qt::NoPen);
        map->setSettings(resources->path_PaleoDataViewer+"/Plot/Main_Map1.txt");
        if (first) map->setView(ATL_latt_min,ATL_latt_max,ATL_depth_min,ATL_depth_max);
        ui->graphicsView_3->setScene(map);
    }
    if (mapmode==2){

        delete[] data;
        delete[] com;
        delete[] lab;
        delete[] col;
        data=new float[inv->get_Entries()*2];
        com=new QString[inv->get_Entries()*2];
        lab=new QString[inv->get_Entries()*2];
        col=new QColor[inv->get_Entries()*2];
        for (int i=0;i<inv->get_Entries();i++){
            if (inv->get_Basin(i)==2){
                data[i+0*inv->get_Entries()]=inv->get_Latitude(i);
                data[i+1*inv->get_Entries()]=-inv->get_Water_Depth(i);
            } else {
                data[i+0*inv->get_Entries()]=NAN;
                data[i+1*inv->get_Entries()]=NAN;
            }
            com[i+0*inv->get_Entries()]=inv->get_Core(i)+"\n"+inv->get_Species(i);
            lab[i+0*inv->get_Entries()]=inv->get_Core(i);
            col[i+0*inv->get_Entries()]=Qt::black;
            col[i+1*inv->get_Entries()]=Qt::blue;
            if (inv->get_Selected(i)==1) col[i+1*inv->get_Entries()]=Qt::green;

        }
        map->setData(data,2,inv->get_Entries());
        map->setMultiplicator(1,1);
        map->setColor(col,true);
        map->setTitel("Pacific Ocean","Lattitude","Depth [m]");
        map->setAxisType(3,3);
        map->setTextSize(8,16,0);
        map->setComment(com,2);
        map->setLabel(lab,label_flag);
        map->setLockAspect(0);

        map->setRepeat(0,PAC_latt_min,PAC_latt_max,0,PAC_depth_min,PAC_depth_max);
        map->setLimit(PAC_latt_min,PAC_latt_max,PAC_depth_min,PAC_depth_max);
        if (first) map->setBackground(resources->filename_PAC,PAC_latt_min,PAC_latt_max,PAC_depth_min,PAC_depth_max,1);
        map->setFolding(0,0);
        map->setLineStyle(Qt::NoPen);
        map->setSettings(resources->path_PaleoDataViewer+"/Plot/Main_Map2.txt");
        if (first) map->setView(PAC_latt_min,PAC_latt_max,PAC_depth_min,PAC_depth_max);
        ui->graphicsView_3->setScene(map);
    }
    if (mapmode==3){
        delete[] data;
        delete[] com;
        delete[] lab;
        delete[] col;
        data=new float[inv->get_Entries()*2];
        com=new QString[inv->get_Entries()*2];
        lab=new QString[inv->get_Entries()*2];
        col=new QColor[inv->get_Entries()*2];
        for (int i=0;i<inv->get_Entries();i++){
            if (inv->get_Basin(i)==3){
                data[i+0*inv->get_Entries()]=inv->get_Latitude(i);
                data[i+1*inv->get_Entries()]=-inv->get_Water_Depth(i);
            } else {
                data[i+0*inv->get_Entries()]=NAN;
                data[i+1*inv->get_Entries()]=NAN;
            }
            com[i+0*inv->get_Entries()]=inv->get_Core(i)+"\n"+inv->get_Species(i);
            lab[i+0*inv->get_Entries()]=inv->get_Core(i);
            col[i+0*inv->get_Entries()]=Qt::black;
            col[i+1*inv->get_Entries()]=Qt::blue;
            if (inv->get_Selected(i)==1) col[i+1*inv->get_Entries()]=Qt::green;

        }
        map->setData(data,2,inv->get_Entries());
        map->setMultiplicator(1,1);
        map->setColor(col,true);
        map->setTitel("Indic Ocean","Lattitude","Depth [m]");
        map->setAxisType(3,3);
        map->setTextSize(8,16,0);
        map->setComment(com,2);
        map->setLabel(lab,label_flag);
        map->setLockAspect(0);

        map->setRepeat(0,IND_latt_min,IND_latt_max,0,IND_depth_min,IND_depth_max);
        map->setLimit(IND_latt_min,IND_latt_max,IND_depth_min,IND_depth_max);
        if (first) map->setBackground(resources->filename_IND,IND_latt_min,IND_latt_max,IND_depth_min,IND_depth_max,1);
        map->setFolding(0,0);
        map->setLineStyle(Qt::NoPen);
        map->setSettings(resources->path_PaleoDataViewer+"/Plot/Main_Map3.txt");
        if (first) map->setView(IND_latt_min,IND_latt_max,IND_depth_min,IND_depth_max);
        ui->graphicsView_3->setScene(map);
    }
    if (mapmode==4){
        delete[] data;
        delete[] com;
        delete[] lab;
        delete[] col;
        data=new float[inv->get_Entries()*2];
        com=new QString[inv->get_Entries()*2];
        lab=new QString[inv->get_Entries()*2];
        col=new QColor[inv->get_Entries()*2];
        for (int i=0;i<inv->get_Entries();i++){
            if (inv->get_Basin(i)==4){
                data[i+0*inv->get_Entries()]=inv->get_Longitude(i);
                data[i+1*inv->get_Entries()]=-inv->get_Water_Depth(i);
            } else {
                data[i+0*inv->get_Entries()]=NAN;
                data[i+1*inv->get_Entries()]=NAN;
            }
            com[i+0*inv->get_Entries()]=inv->get_Core(i)+"\n"+inv->get_Species(i);
            lab[i+0*inv->get_Entries()]=inv->get_Core(i);
            col[i+0*inv->get_Entries()]=Qt::black;
            col[i+1*inv->get_Entries()]=Qt::blue;
            if (inv->get_Selected(i)==1) col[i+1*inv->get_Entries()]=Qt::green;

        }
        map->setData(data,2,inv->get_Entries());
        map->setMultiplicator(1,1);
        map->setColor(col,true);
        map->setTitel("Mediterranian Sea","Longitude","Depth [m]");
        map->setAxisType(3,3);
        map->setTextSize(8,16,0);
        map->setComment(com,2);
        map->setLabel(lab,label_flag);
        map->setLockAspect(0);

        map->setRepeat(0,MED_latt_min,MED_latt_max,0,MED_depth_min,MED_depth_max);
        map->setLimit(MED_latt_min,MED_latt_max,MED_depth_min,MED_depth_max);
        if (first) map->setBackground(resources->filename_MED,MED_latt_min,MED_latt_max,MED_depth_min,MED_depth_max,1);
        map->setFolding(0,0);
        map->setLineStyle(Qt::NoPen);
        map->setSettings(resources->path_PaleoDataViewer+"/Plot/Main_Map4.txt");
        if (first) map->setView(MED_latt_min,MED_latt_max,MED_depth_min,MED_depth_max);
        ui->graphicsView_3->setScene(map);
    }
}

void MainWindow::selection_changed(int plot,QList<int> x,QList<int> y){
    //qDebug()<<"Plot send:"+QString::number(plot);
    for (int i=0;i<x.length();i++){
        //qDebug()<<QString::number(x.at(i))+" : "+QString::number(y.at(i));
        if (inv->get_Selected(y.at(i))==1) {
            inv->set_Selected(y.at(i),0);
        }else{
            inv->set_Selected(y.at(i),1);
        }
        map->setSelected_X(x.at(i));
        map->setSelected_Y(y.at(i));
        inv->set_currentCore(y.at(i));
    }

    createMap(0);
    redraw_score();
    update();
}

void MainWindow::selected_changed(int plot,int x,int y){
    //qDebug()<<QString::number(plot)+":"+QString::number(x)+" "+QString::number(y);



        int index=y;

        if (index!=-1) {
            inv->readData(index);
            inv->set_currentCore(index);
            QFont font;
            font.setFamily("Courier");
            font.setStyleHint(QFont::Monospace);
            font.setFixedPitch(true);
            font.setPointSize(8);

            ui->textBrowser_3->setFont(font);
            ui->textBrowser_4->setFont(font);
            ui->textBrowser->setFont(font);

            QString str="";

            if (index>=0){
                if (inv->get_flag_Data_OK()){
                    str.append("<b>Core Name.........: </b>"+inv->get_att_Core()+
                               "<br><b>Species...........: </b>"+inv->get_att_Species()+
                               "<br><b>Longitude [dez]...: </b>"+QString::number(inv->get_att_Longitude())+
                               "°<br><b>Latitude [dez]....: </b>"+QString::number(inv->get_att_Latitude())+
                               "°<br><b>Water Depth [m]...: </b>"+QString::number(inv->get_att_Water_Depth())+
                               "m<br><b>Device............: </b>"+inv->get_att_Device()+
                               "<br><b>Record Type.......: </b>"+inv->get_att_Record_Type()+
                               "<br><b>Category..........: </b>"+inv->get_att_Category()+
                               "<br><b>Filename..........: </b>"+inv->get_Filename(index)+
                               "<br><b>Importer..........: </b>"+inv->get_att_Importer()+
                               "<br><b>Carbon Flag.......: </b>"+QString::number(inv->get_att_Carbon_Use_Flag())+
                               "<br><b>Oxygen Flag.......: </b>"+QString::number(inv->get_att_Oxygen_Use_Flag())+
                               "<br><b>C-Correction......: </b>"+QString::number(inv->get_att_C_Correction())+
                               "<br><b>C-Justification...: </b>"+inv->get_att_C_Justification()+
                               "<br><b>O-Correction......: </b>"+QString::number(inv->get_att_O_Correction())+
                               "<br><b>O-Justification...: </b>"+inv->get_att_O_Justification()+
                               "<br><b>Labratory.........: </b>"+inv->get_att_Laboratory()+
                               "<br><b>Basin.............: </b>"+QString::number(inv->get_Basin(index))+
                               "<br><b>E-Paper...........: </b>"+inv->get_att_EPaper()+
                               "<br><b>Optional Values...: </b>"+inv->get_att_Optional()
                               );
                    ui->textBrowser_3->setText(inv->get_att_Reference());
                    ui->textBrowser_4->setText(inv->get_att_Comment());
                    ui->lineEdit->setText(inv->get_att_EPaper());
                } else {
                str.append("<b>Core Name.........: </b>"+inv->get_Core(index)+
                           "<br><b>Species...........: </b>"+inv->get_Species(index)+
                           "<br><b>Longitude [dez]...: </b>"+QString::number(inv->get_Longitude(index))+
                           "°<br><b>Latitude [dez]....: </b>"+QString::number(inv->get_Latitude(index))+
                           "°<br><b>Water Depth [m]...: </b>"+QString::number(inv->get_Water_Depth(index))+
                           "m<br><b>Basin.............: </b>"+QString::number(inv->get_Basin(index))+
                           "<br><b>Record Type.......: </b>"+inv->get_Record_Type(index)+
                           "<br><b>Filename..........: </b>"+inv->get_Filename(index)+
                           "<br><b>Carbon Flag.......: </b>"+QString::number(inv->get_Carbon_Use_Flag(index))+
                           "<br><b>Oxygen Flag.......: </b>"+QString::number(inv->get_Oxygen_Use_Flag(index)));
                }
                createPlots();
            } else {
                str.append("Select a Core");
                ui->textBrowser_3->setText("Select a Core");
                ui->textBrowser_4->setText("Select a Core");
                createEmptyPlots();
            }
            ui->textBrowser->setText(str);

        }

    redraw_score();
    update();
}

void MainWindow::invertLabel(){
    if (label_flag==1) {
        label_flag=0;
    } else {
        label_flag=1;
    }
    createMap(0);
    update();
}

void MainWindow::MapToWorld(){
    mapmode=0;
    createMap(1);
    update();
}

void MainWindow::MapToATL(){
    mapmode=1;
    createMap(1);
    update();
}

void MainWindow::MapToPAC(){
    mapmode=2;
    createMap(1);
    update();
}

void MainWindow::MapToIND(){
    mapmode=3;
    createMap(1);
    update();
}

void MainWindow::MapToMED(){
    mapmode=4;
    createMap(1);
    update();
}

void MainWindow::Change_PV_Folder(){
    QString old=resources->get_path_PaleoDataViewer();
    QString file = QFileDialog::getExistingDirectory(this, tr("Select Folder"),
                                             resources->get_path_PaleoDataViewer(),
                                             QFileDialog::ShowDirsOnly);
    if (old!=file&&file!=""){
        QDir dir;
        if (dir.exists(file+"/Resources") &&
                dir.exists(file+"/Default")){
            resources->set_workdir("Default");
            resources->set_path_PaleoDataViewer(file);

            resources->save();
            QMessageBox msgBox;
                    msgBox.setText("The path has been changed.");
                    msgBox.setInformativeText("This requires a restart of PaleoDataViewer");
                    msgBox.setIcon(QMessageBox::Warning);

                    msgBox.exec();
            // Reset Programm
            qApp->exit( -123456789);
        } else {
            QMessageBox msgBox;
                    msgBox.setText("This folder is not a valid PaleoDataViewer folder.");
                    msgBox.setInformativeText("You can create a proper folder by copying the original installation folder in 'Documents'.");
                    msgBox.setIcon(QMessageBox::Warning);

                    msgBox.exec();
        }
    } else {
        QMessageBox msgBox;
                msgBox.setText("The path has NOT been changed.");
                msgBox.setInformativeText("Returning to PaleoDataViewer.");
                msgBox.setIcon(QMessageBox::Warning);

                msgBox.exec();
    }
}

void MainWindow::New_Working_Directory(){
    QString Qfilename = QFileDialog::getSaveFileName(this, tr("Select Name For New Working Directory"),
                                             resources->path_PaleoDataViewer,
                                             tr(""));
    if (Qfilename!=""){
        QDir dir;
        if (dir.mkpath(Qfilename) &&
        dir.mkpath(Qfilename+"/Age") &&
        dir.mkpath(Qfilename+"/Isotopes") &&
        dir.mkpath(Qfilename+"/Derived Data") &&
        dir.mkpath(Qfilename+"/Import")) {
            QMessageBox msgBox;
                    msgBox.setText("Creation of a new working directory succesful");
                    msgBox.setInformativeText("It can now be selected.");
                    msgBox.setIcon(QMessageBox::Warning);

                    msgBox.exec();
        } else {
            QMessageBox msgBox;
                    msgBox.setText("Was not able to create directory.");
                    msgBox.setInformativeText("Please check!");
                    msgBox.setIcon(QMessageBox::Warning);

                    msgBox.exec();
        }
    }
}

void MainWindow::Change_Working_Directory(){
    QString old=resources->get_workdir();
    QString file = QFileDialog::getExistingDirectory(this, tr("Select Working Directory"),
                                             resources->get_path_PaleoDataViewer(),
                                             QFileDialog::ShowDirsOnly);
    if (old!=file&&file!=""){
        // check if proper working directory
        QDir dir;
        if (dir.exists(file+"/Age") &&
                dir.exists(file+"/Isotopes") &&
                dir.exists(file+"/Derived Data") &&
                dir.exists(file+"/Import")){

            QStringList filelist=file.split('/');
            file=filelist.last();


            resources->set_workdir(file);

            resources->save();
            QMessageBox msgBox;
                    msgBox.setText("The working directory has been changed.");
                    msgBox.setInformativeText("This requires a restart of PaleoDataViewer");
                    msgBox.setIcon(QMessageBox::Warning);

                    msgBox.exec();
            // Reset Programm
            qApp->exit( -123456789);
        } else {
            QMessageBox msgBox;
                    msgBox.setText("This folder is not a valid working directory.");
                    msgBox.setInformativeText("Use 'New Working Directory' to create a new one.");
                    msgBox.setIcon(QMessageBox::Warning);

                    msgBox.exec();
        }
    } else {
        QMessageBox msgBox;
                msgBox.setText("The path has NOT been changed.");
                msgBox.setInformativeText("Returning to PaleoDataViewer.");
                msgBox.setIcon(QMessageBox::Warning);

                msgBox.exec();
    }
}
