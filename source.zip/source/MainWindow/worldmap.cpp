/********************************************************************************/
/*    This file is part of PaleoView.                       					*/
/*                                                                      		*/
/*    PaleoView is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoView is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoView.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#include "worldmap.h"
#include <QDebug>
WorldMap::WorldMap(QMainWindow *mainWindow,QImage *image)
                   : mainW(mainWindow), mapimage(image)
{
    connect(this,SIGNAL(selectedCore()),mainW,SLOT(redraw_score()));

    zoom=0.1f;
    longitude=0.0f;
    latitude=0.0f;
    map_mode=0;
    mapsize_x=100;
    mapsize_y=100;
    key_flag=0;
    frame_x1=0;
    frame_x2=0;
    frame_y1=0;
    frame_y2=0;
    this->setSceneRect(-mapsize_x/2+1,-mapsize_y/2+1,mapsize_x-2,mapsize_y-2);
    // Generate Map
    map=new Map(this,mapimage);
    map->setView(longitude,latitude,zoom);
    this->addItem(map);

    // Generate Grid
    grid=new Grid(this,mapimage);
    grid->setView(map->getLongitude(),map->getLatitude(),map->getZoom());
    this->addItem(grid);

    // Generate Locations
    loc=new Locations(this,mapimage);
    loc->setView(map->getLongitude(),map->getLatitude(),map->getZoom());
    this->addItem(loc);
}

void WorldMap::setSize(int x,int y)
{
    mapsize_x=x;
    mapsize_y=y;
    this->setSceneRect(-mapsize_x/2+1,-mapsize_y/2+1,mapsize_x-2,mapsize_y-2);
    map->setSize(x,y);
    grid->setSize(x,y);
    loc->setSize(x,y);
}

void WorldMap::setInventory(Inventory *i){
    inv=i;
    loc->setInventory(inv);
}

void WorldMap::mousePressEvent(QGraphicsSceneMouseEvent* mouseEvent1)
{
    if (key_flag==1){
        frame_x1=mouseEvent1->scenePos().x();
        frame_y1=mouseEvent1->scenePos().y();
    }

    moveFlag=0;
    longitude=map->getLongitude();
    latitude=map->getLatitude();
    zoom=map->getZoom();
    update();
}

void WorldMap::mouseReleaseEvent(QGraphicsSceneMouseEvent* mouseEvent2)
{
    if (!moveFlag && map_mode==0 && key_flag==0){
        // estimate closest Core and select it. make list of cores in vicinity
        float pos_lo=map->getLongitude()+(mouseEvent2->scenePos().x()/map->getMapFactor_x()) ;
        float pos_la=map->getLatitude()-(mouseEvent2->scenePos().y()/map->getMapFactor_y());
        if (pos_lo>180.0f) pos_lo=pos_lo-360.0f;
        if (pos_lo<-180.0f) pos_lo=pos_lo+360.0f;
        float dr=2.0f/zoom/map->getMapFactor_x();
        int id=-1;
        int multi[inv->get_Entries()];
        for (int i=0;i<inv->get_Entries();i++) multi[i]=0;

        int count=0;
        for (int unsigned i=0;i<inv->get_Entries();i++){
            float dr_temp=(pos_lo-inv->get_Longitude(i))*(pos_lo-inv->get_Longitude(i))+(pos_la-inv->get_Latitude(i))*(pos_la-inv->get_Latitude(i));
            if (dr_temp<dr){
                dr=dr_temp;
                id=i;
            }
            if (dr_temp<2.0f/zoom/map->getMapFactor_x()){
                count++;
                multi[i]=1;
            }
        }
        if (id>=0&&count==1){
        // show core information
        QString str="Core Name : "+inv->get_Core(id)+
                "\nSpecies : "+inv->get_Species(id)+
                "\nLongitude : "+QString::number(inv->get_Longitude(id))+
                "°\nLatitude : "+QString::number(inv->get_Latitude(id))+
                "°\nWater Depth : "+QString::number(inv->get_Water_Depth(id))+" m";

        QPoint pos;
        pos.setX(mouseEvent2->screenPos().x());
        pos.setY(mouseEvent2->screenPos().y());
        QToolTip::showText(pos,str,0);


        }
        if (count>1){
            // show core list
            QString str="Warning: "+QString::number(count)+" Cores in vicinity.\nCore Names/Species:";
            for (int i=0;i<inv->get_Entries();i++) if (multi[i]) str.append("\n"+inv->get_Core(i)+" : "+inv->get_Species(i)+"");

            QPoint pos;
            pos.setX(mouseEvent2->screenPos().x());
            pos.setY(mouseEvent2->screenPos().y());
            QToolTip::showText(pos,str,0);


        }

    }
    // Basins
    double start_x=0,start_y=0,ende_x=0,ende_y=0;
    if (map_mode==1){
        start_x=ATL_latt_min;
        ende_x=ATL_latt_max;
        start_y=ATL_depth_min;
        ende_y=ATL_depth_max;
    }
    if (map_mode==2){
        start_x=PAC_latt_min;
        ende_x=PAC_latt_max;
        start_y=PAC_depth_min;
        ende_y=PAC_depth_max;
    }
    if (map_mode==3){
        start_x=IND_latt_min;
        ende_x=IND_latt_max;
        start_y=IND_depth_min;
        ende_y=IND_depth_max;
    }
    if (map_mode==4){
        start_x=MED_latt_min;
        ende_x=MED_latt_max;
        start_y=MED_depth_min;
        ende_y=MED_depth_max;
    }
    if (map_mode>0 && key_flag==0){
        // estimate closest Core and select it. make list of cores in vicinity
        float dr=25.0f;
        int id=-1;
        int multi[inv->get_Entries()];
        for (int i=0;i<inv->get_Entries();i++) multi[i]=0;

        int count=0;
        for (int unsigned i=0;i<inv->get_Entries();i++){
            double lo=inv->get_Latitude(i);
            if (map_mode==2&&lo<0) lo+=360;
            int x1=(lo-start_x)*(float)((float)mapsize_x/(ende_x-start_x));
            int y1=(inv->get_Water_Depth(i)-start_y)*(float)((float)mapsize_y/(ende_y-start_y));
            int x2=mouseEvent2->scenePos().x()+mapsize_x/2;
            int y2=mouseEvent2->scenePos().y()+mapsize_y/2;
            //qDebug() << "Click: "+QString::number(x1)+":"+QString::number(y1);
            float dr_temp=(x1-x2)*(x1-x2)+(y1-y2)*(y1-y2);
            if (dr_temp<dr){
                dr=dr_temp;
                id=i;
            }
            if (dr_temp<25.0f){
                count++;
                multi[i]=1;
            }
        }
        if (id>=0&&count==1){
        // show core information
        QString str="Core Name : "+inv->get_Core(id)+
                "\nSpecies : "+inv->get_Species(id)+
                "\nLongitude : "+QString::number(inv->get_Longitude(id))+
                "°\nLatitude : "+QString::number(inv->get_Latitude(id))+
                "°\nWater Depth : "+QString::number(inv->get_Water_Depth(id))+" m";

        QPoint pos;
        pos.setX(mouseEvent2->screenPos().x());
        pos.setY(mouseEvent2->screenPos().y());
        QToolTip::showText(pos,str,0);


        }
        if (count>1){
            // show core list
            QString str="Warning: "+QString::number(count)+" Cores in vicinity.\nCore Names/Species:";
            for (int i=0;i<inv->get_Entries();i++) if (multi[i]) str.append("\n"+inv->get_Core(i)+" : "+inv->get_Species(i)+"");

            QPoint pos;
            pos.setX(mouseEvent2->screenPos().x());
            pos.setY(mouseEvent2->screenPos().y());
            QToolTip::showText(pos,str,0);
        }
    }

    if (key_flag==1){
        frame_x2=mouseEvent2->scenePos().x();
        frame_y2=mouseEvent2->scenePos().y();
        // zoom
        if (frame_x1>frame_x2){
            int temp=frame_x1;
            frame_x1=frame_x2;
            frame_x2=temp;
        }
        if (frame_y1>frame_y2){
            int temp=frame_y1;
            frame_y1=frame_y2;
            frame_y2=temp;
        }
        // select all cores in frame

        if (map_mode==0){
            float pos_x1=map->getLongitude()+(frame_x1/map->getMapFactor_x());
            float pos_y1=map->getLatitude()-(frame_y1/map->getMapFactor_y());
            float pos_x2=map->getLongitude()+(frame_x2/map->getMapFactor_x());
            float pos_y2=map->getLatitude()-(frame_y2/map->getMapFactor_y());

            for (int i=0;i<inv->get_Entries();i++){
                float x=inv->get_Longitude(i);
                float y=inv->get_Latitude(i);
                if ((x>pos_x1 && x<pos_x2 && y>pos_y2 && y<pos_y1) ||
                        (x+360>pos_x1 && x+360<pos_x2 && y>pos_y2 && y<pos_y1) ||
                        (x-360>pos_x1 && x-360<pos_x2 && y>pos_y2 && y<pos_y1)){
                    inv->invert_Selected(i);
                    last_core=inv->get_Core(i);
                    last_proxy=inv->get_Species(i);
                }
            }

            emit selectedCore();
        }
        // Basins
        double start_x=0,start_y=0,ende_x=0,ende_y=0;
        if (map_mode==1){
            start_x=ATL_latt_min;
            ende_x=ATL_latt_max;
            start_y=ATL_depth_min;
            ende_y=ATL_depth_max;
        }
        if (map_mode==2){
            start_x=PAC_latt_min;
            ende_x=PAC_latt_max;
            start_y=PAC_depth_min;
            ende_y=PAC_depth_max;
        }
        if (map_mode==3){
            start_x=IND_latt_min;
            ende_x=IND_latt_max;
            start_y=IND_depth_min;
            ende_y=IND_depth_max;
        }
        if (map_mode==4){
            start_x=MED_latt_min;
            ende_x=MED_latt_max;
            start_y=MED_depth_min;
            ende_y=MED_depth_max;
        }
        if (map_mode>0 && key_flag==1){
            float pos_x1=start_x+((frame_x1+mapsize_x/2)/(float)(mapsize_x))*(ende_x-start_x);
            float pos_y1=start_y+((frame_y1+mapsize_y/2)/(float)(mapsize_y))*(ende_y-start_y);
            float pos_x2=start_x+((frame_x2+mapsize_x/2)/(float)(mapsize_x))*(ende_x-start_x);
            float pos_y2=start_y+((frame_y2+mapsize_y/2)/(float)(mapsize_y))*(ende_y-start_y);
            //qDebug() << "Frame: "+QString::number(pos_x1)+" : "+QString::number(pos_x2)+" : "+QString::number(pos_y1)+" : "+QString::number(pos_y2);
            for (int i=0;i<inv->get_Entries();i++){
                float x=inv->get_Latitude(i);
                float y=inv->get_Water_Depth(i);
                float z=inv->get_Basin(i);
                if ((x>pos_x1 && x<pos_x2 && y>pos_y1 && y<pos_y2)){
                    if (z==map_mode) {
                        inv->invert_Selected(i);
                        last_core=inv->get_Core(i);
                        last_proxy=inv->get_Species(i);
                    }
                }
            }

            emit selectedCore();
        }
        key_flag=0;
    }
    loc->setRect(0,0,0,0,0);
    longitude=map->getLongitude();
    latitude=map->getLatitude();
    zoom=map->getZoom();


    update();
}

void WorldMap::mouseMoveEvent(QGraphicsSceneMouseEvent* mouseEvent3)
{
    if (map_mode==0 && key_flag==0){
    float pos_lo=map->getLongitude()+(mouseEvent3->scenePos().x()/map->getMapFactor_x()) ;
    float pos_la=map->getLatitude()-(mouseEvent3->scenePos().y()/map->getMapFactor_y());
    if (pos_lo>180.0f) pos_lo=pos_lo-360.0f;
    if (pos_lo<-180.0f) pos_lo=pos_lo+360.0f;
    QString str=QString::number( pos_lo ) + ", " + QString::number(pos_la)+"\nBasin :"+QString::number(inv->get_Basin(pos_lo,pos_la))+" "+inv->get_Basinname(pos_lo,pos_la);
    QPoint pos;
    pos.setX(mouseEvent3->screenPos().x());
    pos.setY(mouseEvent3->screenPos().y());
    QToolTip::showText(pos,str,0);

    if (mouseEvent3->buttons()==Qt::LeftButton){

        moveFlag=1;

        longitude=map->getLongitude();
        latitude=map->getLatitude();
        zoom=map->getZoom();
        if (mouseEvent3->lastScreenPos().x() != mouseEvent3->screenPos().x()) longitude=longitude+(1/map->getMapFactor_x())*(mouseEvent3->lastScreenPos().x()-mouseEvent3->screenPos().x());
        if (mouseEvent3->lastScreenPos().y() != mouseEvent3->screenPos().y()) latitude=latitude-(1/map->getMapFactor_y())*(mouseEvent3->lastScreenPos().y()-mouseEvent3->screenPos().y());

        map->setView(longitude,latitude,zoom);
        grid->setView(map->getLongitude(),map->getLatitude(),map->getZoom());
        loc->setView(map->getLongitude(),map->getLatitude(),map->getZoom());
        update();
    }
    }
    if (mouseEvent3->buttons()==Qt::LeftButton && key_flag==1){
        // draw Frame
        loc->setRect(frame_x1,mouseEvent3->scenePos().x(),frame_y1,mouseEvent3->scenePos().y(),1);
        update();
    }
}

void WorldMap::wheelEvent(QGraphicsSceneWheelEvent *mouseEvent4){
    if(map_mode==0){
    longitude=map->getLongitude();
    latitude=map->getLatitude();
    zoom=map->getZoom();

    zoom=zoom+(mouseEvent4->delta()/120)*zoom/10;

    map->setMessage(QString("Mouse wheel (%1,%2)").arg(mouseEvent4->delta()).arg(zoom));

    map->setView(longitude,latitude,zoom);
    grid->setView(longitude,latitude,zoom);
    loc->setView(longitude,latitude,zoom);
    update();
    }
}

void WorldMap::mouseDoubleClickEvent(QGraphicsSceneMouseEvent *mouseEvent5){
    if (map_mode==0&&inv->get_Entries()>0){
    longitude=map->getLongitude();
    latitude=map->getLatitude();
    zoom=map->getZoom();

    // estimate closest Cores and select/deselect them. make list of cores in vicinity
    float pos_lo=map->getLongitude()+(mouseEvent5->scenePos().x()/map->getMapFactor_x()) ;
    float pos_la=map->getLatitude()-(mouseEvent5->scenePos().y()/map->getMapFactor_y());
    if (pos_lo>180.0f) pos_lo=pos_lo-360.0f;
    if (pos_lo<-180.0f) pos_lo=pos_lo+360.0f;
    float dr=2.0f/zoom/map->getMapFactor_x();
    for (int unsigned i=0;i<inv->get_Entries();i++){
        float dr_temp=(pos_lo-inv->get_Longitude(i))*(pos_lo-inv->get_Longitude(i))+(pos_la-inv->get_Latitude(i))*(pos_la-inv->get_Latitude(i));
        if (dr_temp<2.0f/zoom/map->getMapFactor_x()){
            inv->invert_Selected(i);
            last_core=inv->get_Core(i);
            last_proxy=inv->get_Species(i);
        }
    }


    map->setView(longitude,latitude,zoom);
    grid->setView(longitude,latitude,zoom);
    loc->setView(longitude,latitude,zoom);

    }

    // Basins
    double start_x=0,start_y=0,ende_x=0,ende_y=0;
    if (map_mode==1){
        start_x=ATL_latt_min;
        ende_x=ATL_latt_max;
        start_y=ATL_depth_min;
        ende_y=ATL_depth_max;
    }
    if (map_mode==2){
        start_x=PAC_latt_min;
        ende_x=PAC_latt_max;
        start_y=PAC_depth_min;
        ende_y=PAC_depth_max;
    }
    if (map_mode==3){
        start_x=IND_latt_min;
        ende_x=IND_latt_max;
        start_y=IND_depth_min;
        ende_y=IND_depth_max;
    }
    if (map_mode==4){
        start_x=MED_latt_min;
        ende_x=MED_latt_max;
        start_y=MED_depth_min;
        ende_y=MED_depth_max;
    }
    if (map_mode>0&&inv->get_Entries()>0){
        // estimate closest Core and select it. make list of cores in vicinity
        float dr=25.0f;

        for (int unsigned i=0;i<inv->get_Entries();i++){
            double lo=inv->get_Latitude(i);
            if (map_mode==2&&lo<0) lo+=360;
            int x1=(lo-start_x)*(float)((float)mapsize_x/(ende_x-start_x));
            int y1=(inv->get_Water_Depth(i)-start_y)*(float)((float)mapsize_y/(ende_y-start_y));
            int x2=mouseEvent5->scenePos().x()+mapsize_x/2;
            int y2=mouseEvent5->scenePos().y()+mapsize_y/2;

            float dr_temp=(x1-x2)*(x1-x2)+(y1-y2)*(y1-y2);
            if (dr_temp<25.0f){
                inv->invert_Selected(i);
                last_core=inv->get_Core(i);
                last_proxy=inv->get_Species(i);
                inv->set_currentCore(i);
            }
        }
    }

    emit selectedCore();
    update();
}

void WorldMap::invertLabel(){
    loc->invertLabel();
    loc->setView(longitude,latitude,zoom);
    update();
}

void WorldMap::set_Map_Mode(){
    map_mode=0;
    //qDebug() << "Map Mode : 0";
    map->set_Map_Mode(map_mode);
    grid->set_Map_Mode(map_mode);
    loc->set_Map_Mode(map_mode);
    update();
}

void WorldMap::set_ATL_Mode(){
    map_mode=1;
    map->set_Map_Mode(map_mode);
    grid->set_Map_Mode(map_mode);
    loc->set_Map_Mode(map_mode);
    //qDebug() << "Map Mode : 1";
    update();
}

void WorldMap::set_PAC_Mode(){
    map_mode=2;
    map->set_Map_Mode(map_mode);
    grid->set_Map_Mode(map_mode);
    loc->set_Map_Mode(map_mode);
    //qDebug() << "Map Mode : 2";
    update();
}

void WorldMap::set_IND_Mode(){
    map_mode=3;
    map->set_Map_Mode(map_mode);
    grid->set_Map_Mode(map_mode);
    loc->set_Map_Mode(map_mode);
    //qDebug() << "Map Mode : 3";
    update();
}

void WorldMap::set_MED_Mode(){
    map_mode=4;
    map->set_Map_Mode(map_mode);
    grid->set_Map_Mode(map_mode);
    loc->set_Map_Mode(map_mode);
    //qDebug() << "Map Mode : 4";
    update();
}

void WorldMap::keyPressEvent(QKeyEvent *event){
    //qDebug() << "Pressed :"+QString::number(event->key());
    if (event->key()==Qt::Key_Control){
        //qDebug() << "Control";
        key_flag=1;
    }
}
void WorldMap::keyReleaseEvent(QKeyEvent *event){
    //qDebug() << "Released :"+QString::number(event->key());
    if (event->key()==Qt::Key_Control){
        //qDebug() << "Control";
        key_flag=0;
    }
}

void WorldMap::set_selected_Core(QString core,QString proxy){
    loc->set_selected_Core(core,proxy);
}

QString WorldMap::get_last_core(){
    return last_core;
}
QString WorldMap::get_last_proxy(){
    return last_proxy;
}

