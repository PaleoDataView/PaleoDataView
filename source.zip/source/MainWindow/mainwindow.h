/********************************************************************************/
/*    This file is part of PaleoDataViewer.                       					*/
/*                                                                      		*/
/*    PaleoDataViewer is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoDataViewer is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoDataViewer.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QMouseEvent>
#include <QListWidgetItem>
#include <QPushButton>
#include <QImage>
#include "ui_mainwindow.h"
#include "worldmap.h"
#include "General/inventory.h"


#include "General/resources.h"
#include "Hydro/hydrodatabase.h"
#include "Dialog/inputdialog.h"
#include "ISO/dataview.h"
#include "COR/correlate.h"
#include "Hydro/hydro.h"
#include "AMS/ams.h"
#include "AMS/amsall.h"
#include "Dialog/about.h"
#include "Dialog/credits.h"
#include "Export/export.h"
#include "Import/import.h"
#include "Import/importall.h"
#include "Compare/compare.h"
#include "Extract/extract.h"

#include "Editor/editor.h"
#include "Editor/graph.h"
#include <QApplication>
#include "Convert/convert.h"
#include <QCloseEvent>
#include "DTW/dtw.h"
#include <QScreen>
#include "COR/amdata.h"
#include <QTreeWidgetItem>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    void closeEvent (QCloseEvent *event);
    void createPlots();
    void createEmptyPlots();
    void createTree();
    void createMap(int first);


private slots:
    void redraw();
    void redraw_score();
    void commentContextMenu(QPoint pos);
    void referenceContextMenu(QPoint pos);
    void plot1ContextMenu(QPoint pos);
    void plot2ContextMenu(QPoint pos);
    void textChanged(QString text,QString origin);
    void DataViewCall();
    void CorrelateCall();
    void HydroCall();
    void AMSCall();
    void AMSAllCall();
    void DTWCall();
    void AboutCall();
    void credits();
    void Xport();
    void Iport();
    void IportAll();
    void Comp();
    void Ext();


    void Edit();
    void remove();
    void removeall();
    void set_EPaper();
    void view_EPaper();
    void proxyClicked();
    void ResetLayout();
    void RunBacon();
    void Conv();
    void selection_changed(int plot,QList<int> x,QList<int> y);
    void selected_changed(int plot,int x,int y);
    void invertLabel();
    void MapToATL();
    void MapToPAC();
    void MapToIND();
    void MapToMED();
    void MapToWorld();
    void Change_PV_Folder();
    void New_Working_Directory();
    void Change_Working_Directory();
protected:
    bool eventFilter(QObject *obj, QEvent *event);

private:
    Ui::MainWindow *ui;

    void mousePressEvent(QMouseEvent* mouseEvent1);
    void mouseReleaseEvent(QMouseEvent* mouseEvent2);
    void mouseMoveEvent(QMouseEvent* mouseEvent3);


    void paintEvent(QPaintEvent*);


    Inventory *inv;

    Graph *pl1;
    float *data1;
    QString *com1;
    bool *use1;
    QColor *col1;
    Qt::PenStyle *style;
    int *stype;

    Graph *pl2;
    float *data2;
    QString *com2;
    bool *use2;
    QColor *col2;

    Resources *resources;
    QImage *mapimage;

    QByteArray sp,sp_2,sp_3,sp_4,sp_5;
    AMSData *amsdata;
    Graph *map;
    float *data;
    QString *com;
    QString *lab;
    QColor *col;
    int mapmode=0;
    int label_flag=0;
    QImage *worldmap;




};

#endif // MAINWINDOW_H
