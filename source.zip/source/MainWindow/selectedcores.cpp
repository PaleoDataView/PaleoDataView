/********************************************************************************/
/*    This file is part of PaleoView.                       					*/
/*                                                                      		*/
/*    PaleoView is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoView is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoView.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#include "selectedcores.h"
#include <QDebug>

selectedCores::selectedCores(QMainWindow *mainWindow,
                             QListWidget *list,
                             QListWidget *list2,
                             Inventory *inventory,
                             QTextBrowser *information,
                             QTextBrowser *reference,
                             QTextBrowser *comment,
                             QLineEdit *line,
                             Graph *plot1,
                             Graph *plot2)
    : mainW(mainWindow),
      Itemlist(list),
      Proxylist(list2),
      inv(inventory),
      info(information),
      ref(reference),
      com(comment),
      path(line),
      pl1(plot1),
      pl2(plot2)

{
    connect(Itemlist,SIGNAL(itemClicked(QListWidgetItem*)),this,SLOT(coreClicked(QListWidgetItem*)));
    connect(Proxylist,SIGNAL(itemClicked(QListWidgetItem*)),this,SLOT(proxyClicked(QListWidgetItem*)));
    connect(this,SIGNAL(selectionChanged()),mainW,SLOT(redraw()));

}

void selectedCores::createCores(){

    int old=Itemlist->currentRow();
    Itemlist->clear();
    for (int i=0;i<inv->get_Entries();i++){
        if (inv->get_Selected(i)){
            int multi=0;
            for (int j=0;j<i;j++) if (inv->get_Core(i)==inv->get_Core(j) && inv->get_Selected(j)==1) multi=1;
            if (multi==0) Itemlist->addItem(inv->get_Core(i));
        }
    }



    if (Itemlist->count()>0){
        Itemlist->setCurrentRow(0);
        if (Itemlist->count()>old && old>=0) Itemlist->setCurrentRow(old);
        emit coreClicked(Itemlist->currentItem());
        setInfo();
    } else {
        Itemlist->addItem("Select a Core");
        Itemlist->setCurrentRow(0);
        Proxylist->clear();
        Proxylist->addItem("Select a Core");
        Proxylist->setCurrentRow(0);
        inv->set_flag_Data_OK(0);
        emit coreClicked(Itemlist->currentItem());
        setInfo();

    }


}

void selectedCores::coreClicked(QListWidgetItem *item){
    if (Itemlist->currentItem()->text()!="Select a Core"){
    Itemlist->setCurrentItem(item);
    //qDebug() << "Core Clicked:"+Itemlist->currentItem()->text();

    // create list of proxys
    int old=Proxylist->currentRow();
    Proxylist->clear();
    for (int i=0;i<inv->get_Entries();i++){
        if (inv->get_Core(i)==Itemlist->currentItem()->text() && inv->get_Selected(i)==1){
            Proxylist->addItem(inv->get_Species(i));
        }
    }
    Proxylist->setCurrentRow(0);
    if (Proxylist->count()>old && old>=0) Proxylist->setCurrentRow(old);
    if (Proxylist->count()>=0) emit proxyClicked(Proxylist->currentItem());
    setInfo();
    }

}

void selectedCores::proxyClicked(QListWidgetItem *item){
    if (Proxylist->currentItem()->text()!="Select a Core"){
    Proxylist->setCurrentItem(item);


    //qDebug() << "Proxy Clicked:"+Proxylist->currentItem()->text();

    inv->readData(this->getInventory());
    // fill first plot with data
    float *data1=new float[inv->get_Length()*2];
    QString *com1=new QString[inv->get_Length()*2];
    for (int i=0;i<inv->get_Length();i++){
        data1[i+0*inv->get_Length()]=inv->get_data_Isotopes(0,i);
        data1[i+1*inv->get_Length()]=inv->get_data_Isotopes(2,i);
        if (inv->get_data_Comments(i).simplified()!="NaN")com1[i+1*inv->get_Length()]=inv->get_data_Comments(i);
    }
    pl1->setData(data1,2,inv->get_Length());
    pl1->setComment(com1,2);
    float *data2=new float[inv->get_Length()*2];
    QString *com2=new QString[inv->get_Length()*2];
    for (int i=0;i<inv->get_Length();i++){
        data2[i+0*inv->get_Length()]=inv->get_data_Isotopes(0,i);
        data2[i+1*inv->get_Length()]=inv->get_data_Isotopes(3,i);
        if (inv->get_data_Comments(i).simplified()!="NaN")com2[i+1*inv->get_Length()]=inv->get_data_Comments(i);
    }
    pl2->setData(data2,2,inv->get_Length());
    pl2->setComment(com2,2);
    setInfo();
    emit(selectionChanged());
    }
}

int selectedCores::getInventory(){
    int j=-1;
    if (Itemlist->currentRow()>=0 && Proxylist->currentRow()>=0){
        for (int i=0;i<inv->get_Entries();i++){
            if((inv->get_Core(i)==Itemlist->currentItem()->text()) && (inv->get_Species(i)==Proxylist->currentItem()->text())) j=i;
        }
    }
    return j;
}

void selectedCores::setInfo(){
    QFont font;
    font.setFamily("Courier");
    font.setStyleHint(QFont::Monospace);
    font.setFixedPitch(true);
    font.setPointSize(8);

    ref->setFont(font);
    com->setFont(font);
    info->setFont(font);

    QString str="";
    int n=this->getInventory();
    if (n>=0){
        if (inv->get_flag_Data_OK()){
            str.append("<b>Core Name.........: </b>"+inv->get_att_Core()+
                       "<br><b>Species...........: </b>"+inv->get_att_Species()+
                       "<br><b>Longitude [dez]...: </b>"+QString::number(inv->get_att_Longitude())+
                       "°<br><b>Latitude [dez]....: </b>"+QString::number(inv->get_att_Latitude())+
                       "°<br><b>Water Depth [m]...: </b>"+QString::number(inv->get_att_Water_Depth())+
                       "m<br><b>Device............: </b>"+inv->get_att_Device()+
                       "<br><b>Record Type.......: </b>"+inv->get_att_Record_Type()+
                       "<br><b>Filename..........: </b>"+inv->get_Filename(n)+
                       "<br><b>Carbon Flag.......: </b>"+QString::number(inv->get_att_Carbon_Use_Flag())+
                       "<br><b>Oxygen Flag.......: </b>"+QString::number(inv->get_att_Oxygen_Use_Flag())+
                       "<br><b>C-Correction......: </b>"+QString::number(inv->get_att_C_Correction())+
                       "<br><b>C-Justification...: </b>"+inv->get_att_C_Justification()+
                       "<br><b>O-Correction......: </b>"+QString::number(inv->get_att_O_Correction())+
                       "<br><b>O-Justification...: </b>"+inv->get_att_O_Justification()+
                       "<br><b>Labratory.........: </b>"+inv->get_att_Laboratory()+
                       "<br><b>Basin.............: </b>"+QString::number(inv->get_Basin(n))+
                       "<br><b>E-Paper...........: </b>"+inv->get_att_EPaper()
                       );
            ref->setText(inv->get_att_Reference());
            com->setText(inv->get_att_Comment());
            path->setText(inv->get_att_EPaper());
        } else {
        str.append("<b>Core Name.........: </b>"+inv->get_Core(n)+
                   "<br><b>Species...........: </b>"+inv->get_Species(n)+
                   "<br><b>Longitude [dez]...: </b>"+QString::number(inv->get_Longitude(n))+
                   "°<br><b>Latitude [dez]....: </b>"+QString::number(inv->get_Latitude(n))+
                   "°<br><b>Water Depth [m]...: </b>"+QString::number(inv->get_Water_Depth(n))+
                   "m<br><b>Basin.............: </b>"+QString::number(inv->get_Basin(n))+
                   "<br><b>Record Type.......: </b>"+inv->get_Record_Type(n)+
                   "<br><b>Filename..........: </b>"+inv->get_Filename(n)+
                   "<br><b>Carbon Flag.......: </b>"+QString::number(inv->get_Carbon_Use_Flag(n))+
                   "<br><b>Oxygen Flag.......: </b>"+QString::number(inv->get_Oxygen_Use_Flag(n)));
        }
    } else {
        str.append("Select a Core");
        ref->setText("Select a Core");
        com->setText("Select a Core");
    }
    info->setText(str);


}

void selectedCores::set_EPaper(){
    QString file = QFileDialog::getOpenFileName(this, tr("Select File"),
                                             QDir::homePath(),
                                             tr("PDF (*.pdf)"));


    //qDebug() << file;
    inv->set_att_EPaper(file);
    inv->saveData();
    setInfo();
}

void selectedCores::view_EPaper(){
    //qDebug() << "Open: "+inv->get_att_EPaper();
    QDesktopServices::openUrl(QUrl("file:///"+inv->get_att_EPaper(), QUrl::TolerantMode));
}

void selectedCores::remove() {

        if (Itemlist->currentRow()>=0 && Proxylist->currentRow()>=0) {
            for (int i=0;i<inv->get_Entries();i++) {
                if((inv->get_Core(i)==Itemlist->currentItem()->text() && inv->get_Species(i)==Proxylist->currentItem()->text())) {
                    inv->invert_Selected(i);
                }
            }
        }
        inv->set_currentCore(-1);
        createCores();
        // fill first plot with data
        float *data1=new float[inv->get_Length()*2];
        QString *com1=new QString[inv->get_Length()*2];
        for (int i=0;i<inv->get_Length();i++){
            data1[i+0*inv->get_Length()]=inv->get_data_Isotopes(0,i);
            data1[i+1*inv->get_Length()]=inv->get_data_Isotopes(2,i);
            if (inv->get_data_Comments(i).simplified()!="NaN")com1[i+1*inv->get_Length()]=inv->get_data_Comments(i);
        }
        pl1->setData(data1,2,inv->get_Length());
        pl1->setComment(com1,2);
        float *data2=new float[inv->get_Length()*2];
        QString *com2=new QString[inv->get_Length()*2];
        for (int i=0;i<inv->get_Length();i++){
            data2[i+0*inv->get_Length()]=inv->get_data_Isotopes(0,i);
            data2[i+1*inv->get_Length()]=inv->get_data_Isotopes(3,i);
            if (inv->get_data_Comments(i).simplified()!="NaN")com2[i+1*inv->get_Length()]=inv->get_data_Comments(i);
        }
        pl2->setData(data2,2,inv->get_Length());
        pl2->setComment(com2,2);

        emit (selectionChanged());


}

void selectedCores::removeall() {

        for (int i=0;i<inv->get_Entries();i++) {
                inv->set_Selected(i,0);
        }
        createCores();
        inv->set_currentCore(-1);
        // fill first plot with data
        float *data1=new float[inv->get_Length()*2];
        QString *com1=new QString[inv->get_Length()*2];
        for (int i=0;i<inv->get_Length();i++){
            data1[i+0*inv->get_Length()]=inv->get_data_Isotopes(0,i);
            data1[i+1*inv->get_Length()]=inv->get_data_Isotopes(2,i);
            if (inv->get_data_Comments(i).simplified()!="NaN")com1[i+1*inv->get_Length()]=inv->get_data_Comments(i);
        }
        pl1->setData(data1,2,inv->get_Length());
        pl1->setComment(com1,2);

        float *data2=new float[inv->get_Length()*2];
        QString *com2=new QString[inv->get_Length()*2];
        for (int i=0;i<inv->get_Length();i++){
            data2[i+0*inv->get_Length()]=inv->get_data_Isotopes(0,i);
            data2[i+1*inv->get_Length()]=inv->get_data_Isotopes(3,i);
            if (inv->get_data_Comments(i).simplified()!="NaN")com2[i+1*inv->get_Length()]=inv->get_data_Comments(i);
        }
        pl2->setData(data2,2,inv->get_Length());
        pl2->setComment(com2,2);

        emit (selectionChanged());
}

void selectedCores::invert_O_Flag(){
    if (Itemlist->currentItem()->text()!="Select a Core"){
        int n=this->getInventory();
        inv->invert_O_Flag(n);
        inv->save();
        inv->saveData();
        setInfo();
        emit (selectionChanged());
    } else {
        //qDebug()<<"no Core";
    }
}

void selectedCores::invert_C_Flag(){
    if (Itemlist->currentItem()->text()!="Select a Core"){
        int n=this->getInventory();
        inv->invert_C_Flag(n);
        inv->save();
        inv->saveData();
        setInfo();
        emit (selectionChanged());
    } else {
        //qDebug()<<"no Core";
    }

}

QString selectedCores::get_selected_Core(){
    return Itemlist->currentItem()->text();
}

QString selectedCores::get_selected_Proxy(){
    return Proxylist->currentItem()->text();
}


void selectedCores::setCore(QString core){
    for (int i=0;i<Itemlist->count();i++){
        if (Itemlist->item(i)->text()==core){
            Itemlist->setCurrentRow(i);
            emit coreClicked(Itemlist->currentItem());
        }
        //qDebug()<<QString::number(i)+" : "+Itemlist->item(i)->text()+" : "+core;
    }
}




