/********************************************************************************/
/*    This file is part of PaleoDataViewer.                       					*/
/*                                                                      		*/
/*    PaleoDataViewer is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoDataViewer is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoDataViewer.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#include "about.h"
#include "ui_about.h"

About::About(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::About)
{
    ui->setupUi(this);
    this->setStyleSheet("background-color:white;");

    resources=new Resources();
    QImageReader reader(resources->get_path_PaleoDataViewer()+"/Resources/Icons/PV_Icon.png");
    reader.setAutoTransform(true);
    PVLogo = reader.read();
    ui->label_4->setPixmap(QPixmap::fromImage(PVLogo));

    QImageReader reader_2(resources->get_path_PaleoDataViewer()+"/Resources/Icons/MARUM.png");
    reader_2.setAutoTransform(true);
    MARUM = reader_2.read();
    ui->label_6->setPixmap(QPixmap::fromImage(MARUM));

    QImageReader reader_3(resources->get_path_PaleoDataViewer()+"/Resources/Icons/Palmod.png");
    reader_3.setAutoTransform(true);
    Palmod = reader_3.read();
    ui->label_8->setPixmap(QPixmap::fromImage(Palmod));



}

About::~About()
{
    delete ui;
    delete resources;
}

