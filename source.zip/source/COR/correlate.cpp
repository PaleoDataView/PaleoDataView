/********************************************************************************/
/*    This file is part of PaleoDataViewer.                       					*/
/*                                                                      		*/
/*    PaleoDataViewer is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoDataViewer is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoDataViewer.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#include "correlate.h"
#include "ui_correlate.h"

Correlate::Correlate(QMainWindow *mainWindow,Inventory *inventory) :
    mainW(mainWindow),inv(inventory),
    ui(new Ui::Correlate)
{
    resources=new Resources();
    ui->setupUi(this);
    sp=ui->splitter->saveState();
    sp_2=ui->splitter_2->saveState();
    sp_3=ui->splitter_3->saveState();
    qApp->installEventFilter(this);

    amdata=new AMSData(inv);
    amdata->AMSRead();

    //inv->new_Age_Model();
    //inv->read_Age_Model();
    inv->readTarget();
    ui->comboBox->clear();
    for(int i=0;i<inv->get_Target_Vari();i++) ui->comboBox->addItem(inv->get_Target_Name(i));
    // check if already a stack is present in the agemodel
    for (int i=0;i<amdata->get_Length();i++){
        if (amdata->get_Type(i)=="INA") ui->comboBox->setCurrentText("Intermediate North Atlantic");
        if (amdata->get_Type(i)=="DNA") ui->comboBox->setCurrentText("Deep North Atlantic");
        if (amdata->get_Type(i)=="ISA") ui->comboBox->setCurrentText("Intermediate South Atlantic");
        if (amdata->get_Type(i)=="DSA") ui->comboBox->setCurrentText("Deep South Atlantic");
        if (amdata->get_Type(i)=="IP") ui->comboBox->setCurrentText("Intermediate Pacific");
        if (amdata->get_Type(i)=="DP") ui->comboBox->setCurrentText("Deep Pacific");
        if (amdata->get_Type(i)=="II") ui->comboBox->setCurrentText("Intermediate Indian");
        if (amdata->get_Type(i)=="DI") ui->comboBox->setCurrentText("Deep Indian");
    }
    select=amdata->getSelect();


    // create Age model plot
    data1=new float[0];
    data_use1=new bool[0];
    data_error1=new float[0];
    data_error21=new float[0];
    col1=new QColor[0];
    mark1=new int[0];
    am_plot=new Graph(this,data1,0,0);
    createAMPlot();

    // create result of tuning plot
    data2=new float[0];
    use2=new bool[0];
    comment2=new QString[0];
    result_plot=new Graph(this,data2,0,0);
    createResultPlot();

    // create sedimentation rate plot
    data3=new float[0];
    col3=new QColor[0];
    sr_plot=new Graph(this,data3,0,0);
    createSRPlot();

    // create correlation plot
    data4=new float[0];
    use4=new bool[0];

    data5=new float[0];
    data_error5=new float[0];
    use5=new bool[0];
    c5=new QColor[0];
    lw5=new int[0];
    ss5=new int[0];
    ps5=new Qt::PenStyle[0];

    cor_plot=new Graph(this,data4,0,0);
    cor_plot->setNumber(2);
    createCorPlot(1);




    modelData=new QStandardItemModel(0,0,this);
    setupTable();

    edit=new AMEdit(this,amdata,select);
    attd=new attDialog(this,amdata->get_Age_Comment(0),QString::number(0));
    connect(ui->pushButton_3,SIGNAL(clicked(bool)),this,SLOT(addPoint()));
    connect(ui->pushButton_4,SIGNAL(clicked(bool)),this,SLOT(removePoint()));
    connect(ui->pushButton_5,SIGNAL(clicked(bool)),this,SLOT(editPoint()));
    connect(ui->tableView,SIGNAL(clicked(QModelIndex)),this,SLOT(tableSelected(QModelIndex)));
    //connect(ui->comboBox_2,SIGNAL(currentTextChanged(QString)),this,SLOT(int_Style_Selected(QString)));
    connect(ui->pushButton,SIGNAL(clicked(bool)),this,SLOT(apply()));
    //connect(ui->comboBox_3,SIGNAL(currentTextChanged(QString)),this,SLOT(data_Selected(QString)));
    connect(ui->comboBox,SIGNAL(currentTextChanged(QString)),this,SLOT(target_Selected(QString)));
    connect(ui->pushButton_6,SIGNAL(clicked(bool)),this,SLOT(applyAM()));
    //connect(cor_plot,SIGNAL(selectSignal()),this,SLOT(createLines()));

    changes=false;
}

Correlate::~Correlate()
{
    delete ui;
    delete resources;
    delete amdata;
    delete modelData;
    delete edit;
    delete attd;

    delete[] data1;
    delete[] data_use1;
    delete[] data_error1;
    delete[] data_error21;
    delete[] col1;
    delete[] mark1;

    delete[] data2;
    delete[] use2;
    delete[] comment2;

    delete[] data3;
    delete[] col3;

    delete[] data4;
    delete[] use4;

    delete[] data5;
    delete[] data_error5;
    delete[] use5;
    delete[] c5;
    delete[] lw5;
    delete[] ss5;
    delete[] ps5;
}

void Correlate::paintEvent(QPaintEvent *)
{
    if (am_plot->getSelected_Y()>=0 && am_plot->getSelected_Y()<amdata->get_Length()){
        QStandardItemModel* model = qobject_cast<QStandardItemModel*>(ui->tableView->model());
        for (int i=0;i<amdata->get_Length();i++){
            if (model->item(i,0)->text().toInt()==am_plot->getSelected_Y()){
                select=i;
                break;
            }
        }
        if (select>=0&&select<=amdata->get_Length()) {
            amdata->setSelect(select);
            setupTable();
        }
        am_plot->setSelected_Y(-1);
        createAMPlot();
    }
    if (cor_plot->getSelectLine()!=-1 && cor_plot->getSelectLine()<amdata->get_Length()){
        QStandardItemModel* model = qobject_cast<QStandardItemModel*>(ui->tableView->model());
        for (int i=0;i<amdata->get_Length();i++){
            if (model->item(i,0)->text().toInt()==cor_plot->getSelectLine()){
                select=i;
                break;
            }
        }
        if (select>=0&&select<=amdata->get_Length()) {
            amdata->setSelect(select);
            setupTable();
        }
    }
    createLines();
    cor_plot->setSize(ui->graphicsView->width(),ui->graphicsView->height());
    am_plot->setSize(ui->graphicsView_3->width(),ui->graphicsView_3->height());
    sr_plot->setSize(ui->graphicsView_2->width(),ui->graphicsView_2->height());
    result_plot->setSize(ui->graphicsView_4->width(),ui->graphicsView_4->height());
}

void Correlate::setupTable(){

    // create the model for AMData
    delete modelData;
    modelData = new QStandardItemModel(amdata->get_Length(),14,this);
    modelData->setHorizontalHeaderItem(0, new QStandardItem(QString("Index")));
    modelData->setHorizontalHeaderItem(1, new QStandardItem(QString("Depth")));
    modelData->setHorizontalHeaderItem(2, new QStandardItem(QString("Sample\nThickness")));
    modelData->setHorizontalHeaderItem(3, new QStandardItem(QString("Label")));
    modelData->setHorizontalHeaderItem(4, new QStandardItem(QString("Type")));
    modelData->setHorizontalHeaderItem(5, new QStandardItem(QString("Age dated\n[ka]")));
    modelData->setHorizontalHeaderItem(6, new QStandardItem(QString("Age UCL\n[ka+]")));
    modelData->setHorizontalHeaderItem(7, new QStandardItem(QString("Age LCL\n[ka-]")));
    modelData->setHorizontalHeaderItem(8, new QStandardItem(QString("Res. Age\n[ka]")));
    modelData->setHorizontalHeaderItem(9, new QStandardItem(QString("Res. Age\n Error\n[ka]")));
    modelData->setHorizontalHeaderItem(10, new QStandardItem(QString("Cal yrs\n[wm ka BP]")));
    modelData->setHorizontalHeaderItem(11, new QStandardItem(QString("Cal yrs min\n[95%]")));
    modelData->setHorizontalHeaderItem(12, new QStandardItem(QString("Cal yrs max\n[95%]")));
    modelData->setHorizontalHeaderItem(13, new QStandardItem(QString("Use Flag")));
    modelData->setHorizontalHeaderItem(14, new QStandardItem(QString("Comments")));

    ui->tableView->setModel(modelData);
    ui->tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
    QStandardItem *var_Index = new QStandardItem[amdata->get_Length()];
    QStandardItem *var_Depth = new QStandardItem[amdata->get_Length()];
    QStandardItem *var_Sample = new QStandardItem[amdata->get_Length()];
    QStandardItem *var_Label = new QStandardItem[amdata->get_Length()];
    QStandardItem *var_Type = new QStandardItem[amdata->get_Length()];
    QStandardItem *var_Age_dated = new QStandardItem[amdata->get_Length()];
    QStandardItem *var_Age_UCL = new QStandardItem[amdata->get_Length()];
    QStandardItem *var_Age_LCL = new QStandardItem[amdata->get_Length()];
    QStandardItem *var_Age_Res = new QStandardItem[amdata->get_Length()];
    QStandardItem *var_Age_Res_Err = new QStandardItem[amdata->get_Length()];
    QStandardItem *var_Cal = new QStandardItem[amdata->get_Length()];
    QStandardItem *var_Cal_Min = new QStandardItem[amdata->get_Length()];
    QStandardItem *var_Cal_Max = new QStandardItem[amdata->get_Length()];
    QStandardItem *var_Use_Flag = new QStandardItem[amdata->get_Length()];
    QStandardItem *var_Comment = new QStandardItem[amdata->get_Length()];

    for (int i=0;i<amdata->get_Length();i++){
            var_Index[i].setData(i,Qt::EditRole);
            modelData->setItem(i,0,&var_Index[i]);

            var_Depth[i].setData(amdata->get_Depth(i),Qt::EditRole);
            modelData->setItem(i,1,&var_Depth[i]);

            var_Sample[i].setData(amdata->get_Sample_Thickness(i),Qt::EditRole);
            modelData->setItem(i,2,&var_Sample[i]);

            var_Label[i].setText(amdata->get_LabID(i));
            modelData->setItem(i,3,&var_Label[i]);

            var_Type[i].setText(amdata->get_Type(i));
            modelData->setItem(i,4,&var_Type[i]);

            var_Age_dated[i].setData(amdata->get_Data(0,i),Qt::EditRole);
            modelData->setItem(i,5,&var_Age_dated[i]);

            var_Age_UCL[i].setData(amdata->get_Data(1,i),Qt::EditRole);
            modelData->setItem(i,6,&var_Age_UCL[i]);

            var_Age_LCL[i].setData(amdata->get_Data(2,i),Qt::EditRole);
            modelData->setItem(i,7,&var_Age_LCL[i]);

            var_Age_Res[i].setData(amdata->get_Data(3,i),Qt::EditRole);
            modelData->setItem(i,8,&var_Age_Res[i]);

            var_Age_Res_Err[i].setData(amdata->get_Reservoir_Error(i),Qt::EditRole);
            modelData->setItem(i,9,&var_Age_Res_Err[i]);

            var_Cal[i].setData(amdata->get_Data(4,i),Qt::EditRole);
            modelData->setItem(i,10,&var_Cal[i]);

            var_Cal_Min[i].setData(amdata->get_Data(5,i),Qt::EditRole);
            modelData->setItem(i,11,&var_Cal_Min[i]);

            var_Cal_Max[i].setData(amdata->get_Data(6,i),Qt::EditRole);
            modelData->setItem(i,12,&var_Cal_Max[i]);

            var_Use_Flag[i].setData(amdata->get_Data(7,i),Qt::EditRole);
            var_Use_Flag[i].setCheckable(true);
            var_Use_Flag[i].setText(QString::number(amdata->get_Data(7,i)));
            if (amdata->get_Data(7,i)) var_Use_Flag[i].setCheckState(Qt::Checked);
            modelData->setItem(i,13,&var_Use_Flag[i]);
            modelData->setData(modelData->index(i, 13), Qt::AlignCenter,Qt::TextAlignmentRole);

            var_Comment[i].setText(amdata->get_Age_Comment(i));
            modelData->setItem(i,14,&var_Comment[i]);




            // coloring
            if (amdata->get_Data(7,i)){
                modelData->setData(modelData->index(i, 13), QColor(Qt::green), Qt::BackgroundRole);
            } else {
                modelData->setData(modelData->index(i, 13), QColor(Qt::red), Qt::BackgroundRole);
            }


    }
    ui->tableView->setSortingEnabled(1);
    ui->tableView->horizontalHeader()->setSortIndicator(0,Qt::AscendingOrder);
    ui->tableView->verticalHeader()->setDefaultSectionSize(ui->tableView->verticalHeader()->minimumSectionSize());
    ui->tableView->resizeColumnsToContents();
    ui->tableView->setHorizontalScrollMode(ui->tableView->ScrollPerPixel);
    ui->tableView->setSelectionMode(QAbstractItemView::NoSelection);
    for (int i=0;i<15;i++)if (i!=13)modelData->setData(modelData->index(amdata->getSelect(),i), QColor(Qt::gray), Qt::BackgroundRole);
    ui->tableView->scrollTo(modelData->index(amdata->getSelect(),0));
}

void Correlate::addPoint(){
    if ((cor_plot->getSelected_Y(0)>=0 && cor_plot->getSelected_Y(0)<inv->get_Length()) && (cor_plot->getSelected_Y(1)>=0 && cor_plot->getSelected_Y(1)<inv->get_Target_Length(ui->comboBox->currentIndex()))){
        // get selected points
        double depth=inv->get_data_Isotopes(0,cor_plot->getSelected_Y(0));
        double age=inv->get_Target_Age(cor_plot->getSelected_Y(1),ui->comboBox->currentIndex());


        // check if valid
        int ok=1;
        /*
        int pos =0;
        for (int i=0;i<amdata->get_Length();i++){
            if (amdata->get_Data(4,i)<age){
                pos++;
            } else {
                break;
            }
        }


        if (amdata->get_Length()==0) ok=1; // first element always ok

        if (pos>0){//if not first element
            // check previous element
            if ((amdata->get_Data(4,pos-1)<age && amdata->get_Depth(pos-1)<depth)){
                // check next element
                if (pos<amdata->get_Length()){// if not last element
                    if (amdata->get_Data(4,pos)>age && amdata->get_Depth(pos)>depth) ok=1;
                } else { // if last element
                    ok=1;
                }
            }
        } else {// if first element
            // check next element
            if (pos<amdata->get_Length()){// if not last element
                if (amdata->get_Data(4,pos)>age && amdata->get_Depth(pos)>depth) ok=1;
            } else { // if last element
                ok=1;
            }
        }*/
        // check if it will be a reversal
        for (int i=0;i<amdata->get_Length();i++){
            float depth_2=amdata->get_Depth(i);
            float age_2=amdata->get_Data(4,i);
            if (age<age_2 && depth>depth_2) ok=0;
            if (age>age_2 && depth<depth_2) ok=0;
            if (age==age_2 || depth==depth_2) ok=0;

        }

        if (ok){

            amdata->addEntry();

            if (cor_plot->getSelected_Y(0)>=0) {
                amdata->set_Depth(0,inv->get_data_Isotopes(0,cor_plot->getSelected_Y(0)));
            } else {
                amdata->set_Depth(0,0);
            }
            amdata->set_Type(0,"COR");
            if (ui->comboBox->currentText()=="Intermediate North Atlantic") amdata->set_Type(0,"INA");
            if (ui->comboBox->currentText()=="Deep North Atlantic") amdata->set_Type(0,"DNA");
            if (ui->comboBox->currentText()=="Intermediate South Atlantic") amdata->set_Type(0,"ISA");
            if (ui->comboBox->currentText()=="Deep South Atlantic") amdata->set_Type(0,"DSA");
            if (ui->comboBox->currentText()=="Intermediate Pacific") amdata->set_Type(0,"IP");
            if (ui->comboBox->currentText()=="Deep Pacific") amdata->set_Type(0,"DP");
            if (ui->comboBox->currentText()=="Intermediate Indian") amdata->set_Type(0,"II");
            if (ui->comboBox->currentText()=="Deep Indian") amdata->set_Type(0,"DI");

            amdata->set_LabID(0,"User");
            amdata->set_Age_Comment("Manually tuned with :"+ui->comboBox->currentText(),0);
            if (cor_plot->getSelected_Y(1)>=0) {
                amdata->set_Data(0,0,NAN);
                amdata->set_Data(1,0,NAN);
                amdata->set_Data(2,0,NAN);
                amdata->set_Data(3,0,NAN);
                amdata->set_Data(4,0,inv->get_Target_Age(cor_plot->getSelected_Y(1),ui->comboBox->currentIndex()));
                amdata->set_Data(5,0,inv->get_Target_Age(cor_plot->getSelected_Y(1),ui->comboBox->currentIndex())-inv->get_Target_Age_Error(cor_plot->getSelected_Y(1),ui->comboBox->currentIndex()));
                amdata->set_Data(6,0,inv->get_Target_Age(cor_plot->getSelected_Y(1),ui->comboBox->currentIndex())+inv->get_Target_Age_Error(cor_plot->getSelected_Y(1),ui->comboBox->currentIndex()));
                amdata->set_Data(7,0,1);
                amdata->set_Sample_Thickness(0,NAN);
                amdata->set_Reservoir_Error(0,NAN);
            } else {
                amdata->set_Data(4,0,0);
            }
            amdata->sort(0,amdata->get_Length()-1);

            createLines();


            createAMPlot();
            createSRPlot();
            createResultPlot();
            createCorPlot(0);
            setupTable();
            update();

        }
        changes=true;
    }
}

void Correlate::removePoint(){
    if (select>=0 && amdata->get_Length()==1){
        amdata->set_Depth(select,NAN);
        amdata->set_LabID(select,"Unknown");
        amdata->set_Type(select,"Unknown");
        amdata->set_Age_Comment("default Entry: Please Edit",select);
        for (int i=0;i<7;i++) amdata->set_Data(i,select,NAN);
        amdata->set_Data(7,select,0);
        amdata->set_Sample_Thickness(0,NAN);
        amdata->set_Reservoir_Error(0,NAN);
    }
    if (select>=0 && amdata->get_Length()>1){
        //qDebug() << "remove"+QString::number(amdata->get_Length());

        amdata->deleteEntry(select);
    }

    if (select>=amdata->get_Length()) select--;
        amdata->setSelect(select);
        createLines();

        createAMPlot();
        createSRPlot();
        createResultPlot();
        createCorPlot(0);
        setupTable();
        update();

    changes=true;
}

void Correlate::editPoint(){

    if (select>=0&&amdata->get_Length()>select){
    delete edit;
    edit=new AMEdit(this,amdata,select);
    edit->setModal(true);
    edit->show();
    }
    amdata->sort(0,amdata->get_Length()-1);

    createLines();

    createAMPlot();
    createSRPlot();
    createResultPlot();
    createCorPlot(0);
    setupTable();
    update();
    changes=true;
}

void Correlate::tableSelected(QModelIndex mi){
    /*int sel=mi.row();
    //qDebug() << "Clicked :"+QString::number(sel);
    QStandardItemModel* model = qobject_cast<QStandardItemModel*>(ui->tableView->model());
    QString text = model->item(sel,0)->text();
    selected=text.toInt(0,10);*/

    int sel=mi.row();
    //qDebug() << "Clicked :"+QString::number(sel)+":"+QString::number(mi.column());
    QStandardItemModel* model = qobject_cast<QStandardItemModel*>(ui->tableView->model());
    QString text = model->item(sel,mi.column())->text();
    //qDebug() << text;
    int index=model->item(sel,0)->text().toInt();

    if (mi.column()==13){
        if (amdata->get_Data(7,sel)==1){
            amdata->set_Data(7,sel,0);
        } else {
            if (!isnan(amdata->get_Data(4,sel))) amdata->set_Data(7,sel,1);
        }
    }
    if (mi.column()==14){
        delete attd;
        attd=new attDialog(this,amdata->get_Age_Comment(index),QString::number(index));
        attd->setModal(true);
        attd->show();
    }
    select=index;

    amdata->setSelect(index);
    setupTable();



    // recreate Age model plot
    createAMPlot();

    // recreate Sedimentation Rate Plot
    createSRPlot();

    // create result of tuning plot
    createResultPlot();

    // create interactive plots for Data and Traget tuning

    createCorPlot(1);





    update();

}

void Correlate::int_Style_Selected(QString str){/*
    am_plot->setPlot(0,1,"Age Model","Depth in [m]","Age in [kyr]",1,1,str);
    am_plot->setSize(ui->graphicsView_3->width(),ui->graphicsView_3->height());
    am_plot->autoSize();
    cor_plot->setSize(ui->graphicsView->width(),ui->graphicsView->height());
    am_plot->setSize(ui->graphicsView_3->width(),ui->graphicsView_3->height());
    sr_plot->setSize(ui->graphicsView_2->width(),ui->graphicsView_2->height());
    result_plot->setPlot(0,3,"Result ("+ui->comboBox_3->currentText()+")","Age in [kyr]","d13C [o/oo VPDB]",1,-1,"linear");
    result_plot->setSize(ui->graphicsView_4->width(),ui->graphicsView_4->height());
    result_plot->autoSize();
    str=ui->comboBox_3->currentText();
    if (str=="C Isotopes"){
        source_axis=4;
        cor_plot->setPlot_1(0,source_axis,"Raw Time Series ("+ui->comboBox_3->currentText()+")","Depth [m]","d13C [o/oo VPDB]",1,1);
        result_plot->setPlot(0,source_axis,"Result ("+ui->comboBox_3->currentText()+")","Age in [kyr]","d13C [o/oo VPDB]",1,1,"linear");
    }
    if (str=="O Isotopes") {
        source_axis=3;
        cor_plot->setPlot_1(0,source_axis,"Raw Time Series ("+ui->comboBox_3->currentText()+")","Depth [m]","d13O [o/oo VPDB]",1,-1);
        result_plot->setPlot(0,source_axis,"Result ("+ui->comboBox_3->currentText()+")","Age in [kyr]","d13O [o/oo VPDB]",1,-1,"linear");
    }
    update();*/
}

void Correlate::apply(){
    /*
    //qDebug()<<"Apply Model";
    //inv->apply_Age_Model("linear");
    for (int i=0;i<inv->get_Length();i++){
        double v=get_Int_Value_Age(get_data_Isotopes(0,i),str);
        set_data_Isotopes(1,i,v);
    }
    inv->saveData();
    //save_Age_Model();
*/

    amdata->AMSSave();
    changes=false;
}

void Correlate::applyAM(){
    //qDebug()<<"Apply Model";
    //amdata->apply_Age_Model("linear");
    for (int i=0;i<inv->get_Length();i++){
        double v=amdata->get_Int_Value_Age(inv->get_data_Isotopes(0,i),"linear");
        inv->set_data_Age(v,i);
    }
    inv->saveData();
}


void Correlate::target_Selected(QString str){
    if (str=="Govin")
        target_axis=3;
    if (str=="LH4") target_axis=4;
    //target=str;
    createCorPlot(1);
    cor_plot->setSize(ui->graphicsView->width(),ui->graphicsView->height());

    update();
}

void Correlate::data_Selected(QString str){
    createCorPlot(1);
    createResultPlot();
    cor_plot->setSize(ui->graphicsView->width(),ui->graphicsView->height());
    result_plot->setSize(ui->graphicsView_4->width(),ui->graphicsView_4->height());

    update();
}

void Correlate::attChanged(QString text,QString origin){
        int sel=origin.toInt(0,10);
        //qDebug() << "Text:"+text;
        amdata->set_Age_Comment(text,sel);

        setupTable();
        changes=true;
}

void Correlate::redraw(){
    setupTable();
}

void Correlate::createAMPlot(){
    delete[] data1;
    data1=new float[amdata->get_Length()*2];
    delete[] data_use1;
    data_use1=new bool[amdata->get_Length()*2];
    delete [] data_error1;
    data_error1=new float[amdata->get_Length()*2];
    delete[] data_error21;
    data_error21=new float[amdata->get_Length()*2];
    delete[] col1;
    col1=new QColor[amdata->get_Length()*2];
    delete[] mark1;
    mark1=new int[amdata->get_Length()*2];

    for (int i=0;i<amdata->get_Length();i++){
        //data1[i+0*amdata->get_Length()]=amdata->get_Depth(i);
        //data1[i+1*amdata->get_Length()]=amdata->get_Data(0,i);
        data1[i+0*amdata->get_Length()]=amdata->get_Depth(i);
        data1[i+1*amdata->get_Length()]=amdata->get_Data(4,i);
        //data_use[i+0*amdata->get_Length()]=amdata->get_Data(7,i);
        //data_use[i+1*amdata->get_Length()]=amdata->get_Data(7,i);
        data_use1[i+0*amdata->get_Length()]=amdata->get_Data(7,i);
        data_use1[i+1*amdata->get_Length()]=amdata->get_Data(7,i);
        //data_error[i+0*amdata->get_Length()]=NAN;
        //data_error[i+1*amdata->get_Length()]=amdata->get_Data(2,i);
        data_error1[i+0*amdata->get_Length()]=NAN;
        if (amdata->get_Data(5,i)!=0) data_error1[i+1*amdata->get_Length()]=abs(amdata->get_Data(4,i)-amdata->get_Data(5,i)); else data_error1[i+1*amdata->get_Length()]=NAN;
        //data_error2[i+0*amdata->get_Length()]=NAN;
        //data_error2[i+1*amdata->get_Length()]=amdata->get_Data(1,i);
        data_error21[i+0*amdata->get_Length()]=NAN;
        if (amdata->get_Data(6,i)!=0) data_error21[i+1*amdata->get_Length()]=abs(amdata->get_Data(4,i)-amdata->get_Data(6,i)); else data_error21[i+1*amdata->get_Length()]=NAN;
        //col_r[i+0*amdata->get_Length()]=255;
        //col_r[i+1*amdata->get_Length()]=255;
        col1[i+0*amdata->get_Length()]=QColor(0,0,0);
        col1[i+1*amdata->get_Length()]=QColor(0,0,255);

        //if (amdata->get_Age_Comment(i).simplified()!="NaN") comment[i+2*amdata->get_Length()]=amdata->get_Age_Comment(i);
        //mark[i+0*amdata->get_Length()]=0;
        //mark[i+1*amdata->get_Length()]=0;
        mark1[i+0*amdata->get_Length()]=0;
        mark1[i+1*amdata->get_Length()]=0;
    }
    //mark[select+0*amdata->get_Length()]=1;
    //mark[select+1*amdata->get_Length()]=1;
    mark1[select+0*amdata->get_Length()]=1;
    mark1[select+1*amdata->get_Length()]=1;
    am_plot->setData(data1,2,amdata->get_Length());
    am_plot->setUse(data_use1,1);
    am_plot->setError(data_error1,2);
    am_plot->setError2(data_error21,2);
    am_plot->setColor(col1,1);
    am_plot->setMark(mark1,1);
    //am_plot->setComment(comment,1);
    am_plot->setTitel("","Depth [m]","Age in [kyr]");
    am_plot->setMultiplicator(1,1);
    am_plot->setTextSize(8,0,8);
    am_plot->setSize(ui->graphicsView_3->width(),ui->graphicsView_3->height());
    am_plot->setSymbol(3);

    am_plot->autoSize();
    am_plot->setSettings(resources->path_PaleoDataViewer+"/Resources/Plot/Correlate_AgeModel.txt",0);
    ui->graphicsView_3->setScene(am_plot);
}

void Correlate::createResultPlot(){
    delete[] data2;
    data2=new float[inv->get_Length()*2];
    delete[] use2;
    use2=new bool[inv->get_Length()*2];
    delete[] comment2;
    comment2=new QString[inv->get_Length()*2];
    for (int i=0;i<inv->get_Length();i++){
            data2[i+0*inv->get_Length()]=amdata->get_Int_Value_Age(inv->get_data_Isotopes(0,i),"linear");
            data2[i+1*inv->get_Length()]=inv->get_data_Isotopes(5,i);
            use2[i+0*inv->get_Length()]=inv->get_data_Isotopes(6,i);
            use2[i+1*inv->get_Length()]=inv->get_data_Isotopes(6,i);
            result_plot->setMultiplicator(1,-1);
            result_plot->setTitel("","Age in [kyr]","\u03b418O [\u2030 VPDB]");

        if (inv->get_data_Comments(i).simplified()!="NaN") comment2[i+1*inv->get_Length()]=inv->get_data_Comments(i);
    }
    if (amdata->get_Length()>1)  {
        result_plot->setData(data2,2,inv->get_Length());
        result_plot->setUse(use2,1);
        result_plot->setComment(comment2,1);
        result_plot->setTextSize(8,0,8);
        result_plot->setSize(ui->graphicsView_4->width(),ui->graphicsView_4->height());
        result_plot->setSymbol(3);
        result_plot->autoSize();
    }
    result_plot->setSettings(resources->path_PaleoDataViewer+"/Resources/Plot/Correlate_Result.txt",0);
    ui->graphicsView_4->setScene(result_plot);
}

void Correlate::createSRPlot(){
    // Calculate sedimentation rate
    // create subset of active Flag only
    // get length
    int active_count=0;
    for (int i=0;i<amdata->get_Length();i++) if (amdata->get_Data(7,i)==1) active_count++;
    double *temp_age;
    double *temp_depth;
    temp_age=new double[active_count];
    temp_depth=new double[active_count];
    int n=0;
    for (int i=0;i<amdata->get_Length();i++){
        if (amdata->get_Data(7,i)==1){
            temp_age[n]=amdata->get_Data(4,i);
            temp_depth[n]=amdata->get_Depth(i);
            n++;
        }
    }

    // calculate derivertive
    if (active_count>1){
        float *age=new float[active_count-1];
        float *sr=new float[active_count-1];
        float *age_area=new float[active_count-1];
        for (int i=0;i<active_count-1;i++){
            age[i]=temp_age[i]+(temp_age[i+1]-temp_age[i])/2;
            age_area[i]=(temp_age[i+1]-temp_age[i])/2;
            sr[i]=(temp_depth[i+1]-temp_depth[i])/(temp_age[i+1]-temp_age[i]);
        }
        // create Plot
        delete[] data3;
        data3=new float[(active_count-1)*2*2];
        delete[] col3;
        col3=new QColor[(active_count-1)*2*2];

        for (int i=0;i<active_count-1;i++){
            data3[i*2+0*(active_count-1)*2]=age[i]-age_area[i];
            data3[i*2+1*(active_count-1)*2]=sr[i];
            data3[(i*2+1)+0*(active_count-1)*2]=age[i]+age_area[i];
            data3[(i*2+1)+1*(active_count-1)*2]=sr[i];
            col3[i*2+0*(active_count-1)*2].QColor::red();
            col3[i*2+1*(active_count-1)*2].QColor::red();
            col3[(i*2+1)+0*(active_count-1)*2].QColor::red();
            col3[(i*2+1)+1*(active_count-1)*2].QColor::red();

        }
        sr_plot->setData(data3,2,(active_count-1)*2);
        sr_plot->setTitel("","Age in [kyr]","Rate [m/kyr]");
        sr_plot->setMultiplicator(1,1);
        sr_plot->setTextSize(8,0,8);
        sr_plot->setSize(ui->graphicsView_2->width(),ui->graphicsView_2->height());
        sr_plot->setSymbol(1);
        sr_plot->setColor(col3,1);
        sr_plot->setLineWidth(3);
        sr_plot->setLineStyle(Qt::SolidLine);
        sr_plot->setLineColor(Qt::red);
        sr_plot->autoSize();
        ui->graphicsView_2->setScene(sr_plot);

        delete[] age;
        delete[] sr;
        delete[] age_area;
    } else {
        delete[] data3;
        data3=new float[0];
        sr_plot->setData(data3,0,0);
        sr_plot->setSettings(resources->path_PaleoDataViewer+"/Resources/Plot/Correlation_Sedimentation.txt",0);
        ui->graphicsView_2->setScene(sr_plot);
    }
    delete[] temp_age;
    delete[] temp_depth;

}

bool Correlate::eventFilter(QObject *obj, QEvent *event)
{
    if (event->type() == QEvent::KeyPress)
    {
        if (obj==ui->graphicsView||obj==ui->tableView||obj==ui->graphicsView_2||ui->graphicsView_3||obj==ui->graphicsView_4){
            QKeyEvent *keyEvent = static_cast<QKeyEvent *>(event);
            if (keyEvent->key()==Qt::Key_F1){
                ui->splitter->restoreState(sp);
                ui->splitter_2->restoreState(sp_2);
                ui->splitter_3->restoreState(sp_3);
                return true;
            }
        }
    }
    return QObject::eventFilter(obj, event);
}

void Correlate::createCorPlot(int autosize){

    // Get Isotope data
    int y_axis=0;
    //cor_plot->setNumber(2);
    delete[] data4;
    data4=new float[inv->get_Length()*2];
    delete[] use4;
    use4=new bool[inv->get_Length()*2];
    for (int i=0;i<inv->get_Length();i++){
        data4[i+0*inv->get_Length()]=inv->get_data_Isotopes(0,i);
        data4[i+1*inv->get_Length()]=inv->get_data_Isotopes(5,i);
        use4[i+0*inv->get_Length()]=inv->get_data_Isotopes(6,i);
        use4[i+1*inv->get_Length()]=inv->get_data_Isotopes(6,i);
        cor_plot->setMultiplicator(1,-1,0);
        cor_plot->setTitel("","Depth [m]","d18O permil",0);
        y_axis=3;

    }
    cor_plot->setData(data4,2,inv->get_Length(),0);
    cor_plot->setUse(use4,1,0);
    cor_plot->setTextSize(8,0,0,0);
    cor_plot->setSize(ui->graphicsView->width(),ui->graphicsView->height());
    cor_plot->setSymbol(3,0);
    cor_plot->fixRange(0,1,0);

    if (autosize) cor_plot->autoSize(0);

    // Target Plot
    int length=inv->get_Target_Length(ui->comboBox->currentIndex());
    if (inv->get_Target_Length(ui->comboBox->currentIndex())<inv->get_Length()) length=inv->get_Length();

    delete[] data5;
    delete[] data_error5;
    delete[] use5;
    delete[] c5;
    delete[] lw5;
    delete[] ss5;
    delete[] ps5;
    data5=new float[length*4];
    data_error5=new float[length*4];
    use5=new bool[length*4];
    c5=new QColor[4];
    lw5=new int[4];
    ss5=new int[4];
    ps5=new Qt::PenStyle[4];

    for (int i=0;i<length*4;i++) data5[i]=NAN;
    for (int i=0;i<length*4;i++) data_error5[i]=NAN;
    for (int i=0;i<length*4;i++) use5[i]=true;
    // Calc Offsets
    double offset_1=0;
    double offset_2=0;
    for (int i=0;i<inv->get_Length();i++) offset_1+=inv->get_data_Isotopes(y_axis,i);
    offset_1/=inv->get_Length();
    int count=0;
    for (int i=0;i<inv->get_Target_Length(ui->comboBox->currentIndex());i++) {
        if (!isnan(inv->get_Target_Value(i,ui->comboBox->currentIndex()))){
            count++;
            offset_2+=inv->get_Target_Value(i,ui->comboBox->currentIndex());
        }
    }
    offset_2/=count;

    for (int i=0;i<inv->get_Length();i++){
        // Result Data
        data5[i+0*length]=amdata->get_Int_Value_Age(inv->get_data_Isotopes(0,i),"linear");
        data5[i+1*length]=inv->get_data_Isotopes(5,i)-offset_1+offset_2;
        use5[i+0*length]=inv->get_data_Isotopes(6,i);
        use5[i+1*length]=inv->get_data_Isotopes(6,i);
    }

    for (int i=0;i<inv->get_Target_Length(ui->comboBox->currentIndex());i++){
        // Target Data
        data5[i+2*length]=inv->get_Target_Age(i,ui->comboBox->currentIndex());
        data5[i+3*length]=inv->get_Target_Value(i,ui->comboBox->currentIndex());
        data_error5[i+2*length]=inv->get_Target_Age_Error(i,ui->comboBox->currentIndex());
        data_error5[i+3*length]=inv->get_Target_Error(i,ui->comboBox->currentIndex());

        cor_plot->setMultiplicator(1,-1,1);
        cor_plot->setTitel("","Age in [kyr]","Target",1);

    }
    cor_plot->setData(data5,4,length,1);
    cor_plot->setUse(use5,2,1);
    cor_plot->setError(data_error5,1,1);

    cor_plot->setTextSize(8,0,0,1);
    cor_plot->setSize(ui->graphicsView->width(),ui->graphicsView->height());
    cor_plot->setSymbol(3,1);
    cor_plot->fixRange(0,1,1);

    c5[0]=Qt::red;
    c5[1]=Qt::red;
    c5[2]=Qt::black;
    c5[3]=Qt::black;
    cor_plot->setSetLineColor(c5,1,1);

    lw5[0]=3;
    lw5[1]=3;
    lw5[2]=1;
    lw5[3]=1;
    cor_plot->setSetLineWidth(lw5,1,1);

    ss5[0]=0;
    ss5[1]=0;
    ss5[2]=3;
    ss5[3]=3;
    cor_plot->setSetSymbolsize(ss5,1,1);

    ps5[0]=Qt::SolidLine;
    ps5[1]=Qt::SolidLine;
    ps5[2]=Qt::DashDotLine;
    ps5[3]=Qt::DashDotLine;
    cor_plot->setSetLineStyle(ps5,1,1);
    if (autosize) cor_plot->autoSize(1);
    cor_plot->setAxisType(1,0,0);
    createLines();

    ss5[0]=0;
    ss5[1]=0;
    ss5[2]=cor_plot->getSymbol(1);
    ss5[3]=cor_plot->getSymbol(1);
    cor_plot->setSetSymbolsize(ss5,1,1);
    cor_plot->setSettings(resources->path_PaleoDataViewer+"/Resources/Plot/Correlate_Isotope.txt",0);
    cor_plot->setSettings(resources->path_PaleoDataViewer+"/Resources/Plot/Correlate_Target.txt",1);
    ui->graphicsView->setScene(cor_plot);
}

void Correlate::createLines(){
    int y_axis=0;


        y_axis=3;

    cor_plot->addLineClear();
    for(int i=0;i<amdata->get_Length();i++){
        // get index in data 1
        int i_1=-1;
        for (int j=0;j<inv->get_Length();j++){
             if (inv->get_data_Isotopes(0,j)>=amdata->get_Depth(i)){
                 i_1=j;
                 break;
             }
             i_1=j;
        }
        float v1=inv->get_data_Isotopes(y_axis,i_1);
        if (i_1>0 && i_1<inv->get_Length())
            v1=inv->get_data_Isotopes(y_axis,i_1-1)+(inv->get_data_Isotopes(y_axis,i_1)-inv->get_data_Isotopes(y_axis,i_1-1))/(inv->get_data_Isotopes(0,i_1)-inv->get_data_Isotopes(0,i_1-1))*(amdata->get_Depth(i)-inv->get_data_Isotopes(0,i_1-1));

        int i_2=-1;
        for (int j=0;j<inv->get_Target_Length(ui->comboBox->currentIndex());j++){
             if (inv->get_Target_Age(j,ui->comboBox->currentIndex())>=amdata->get_Data(4,i)){
                 i_2=j;
                 break;
             }
             i_2=j;
        }
        float v2=inv->get_Target_Value(i_2,ui->comboBox->currentIndex());
        if (i_2>0 && i_2<inv->get_Target_Length(ui->comboBox->currentIndex()))
            v2=inv->get_Target_Value(i_2-1,ui->comboBox->currentIndex())+(inv->get_Target_Value(i_2,ui->comboBox->currentIndex())-inv->get_Target_Value(i_2-1,ui->comboBox->currentIndex()))/(inv->get_Target_Age(i_2,ui->comboBox->currentIndex())-inv->get_Target_Age(i_2-1,ui->comboBox->currentIndex()))*(amdata->get_Data(4,i)-inv->get_Target_Age(i_2-1,ui->comboBox->currentIndex()));

        QColor c=Qt::darkGreen;
        if (amdata->get_Type(i)=="AMS") c=Qt::lightGray;
        if (amdata->get_Data(7,i)==0) c=Qt::red;
        int w=2;
        if (i==select) w=3;
        Qt::PenStyle p=Qt::SolidLine;
        if (amdata->get_Type(i)=="AMS") p=Qt::DashLine;
        cor_plot->addLine(amdata->get_Depth(i),v1,0,amdata->get_Data(4,i),v2,1,c,w,p);
    }
    if (cor_plot->getSelected_Y(0)!=-1 && cor_plot->getSelected_Y(1)!=-1){
        cor_plot->addLine(inv->get_data_Isotopes(0,cor_plot->getSelected_Y(0)),inv->get_data_Isotopes(y_axis,cor_plot->getSelected_Y(0)),0,inv->get_Target_Age(cor_plot->getSelected_Y(1),ui->comboBox->currentIndex()),inv->get_Target_Value(cor_plot->getSelected_Y(1),ui->comboBox->currentIndex()),1,Qt::black,1,Qt::DashLine);
    }
    cor_plot->setAddMode(1);
    cor_plot->update();
}

void Correlate::reject()
{
    QMessageBox::StandardButton resBtn = QMessageBox::Yes;
    if (changes) {
        resBtn = QMessageBox::question( this,"PaleoDataViewer - Correleate",
                                        tr("There are unsaved changes.\nAre you sure?\n"),
                                        QMessageBox::Cancel | QMessageBox::Yes,
                                        QMessageBox::Yes);
    }
    if (resBtn == QMessageBox::Yes) {
        QDialog::reject();
    }
}
