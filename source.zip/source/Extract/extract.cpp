/********************************************************************************/
/*    This file is part of PaleoDataViewer.                       					*/
/*                                                                      		*/
/*    PaleoDataViewer is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoDataViewer is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoDataViewer.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#include "extract.h"
#include "ui_extract.h"

Extract::Extract(QMainWindow *mainWindow,Inventory *inventory) :
    mainW(mainWindow),inv(inventory),
    ui(new Ui::Extract)
{
    ui->setupUi(this);
    sp=ui->splitter->saveState();
    sp_2=ui->splitter_2->saveState();

    qApp->installEventFilter(this);
    ui->pushButton->setFocusPolicy(Qt::NoFocus);
    resources=new Resources();
    data=new float[0];
    coll=new QColor[0];
    lstyle=new Qt::PenStyle[0];
    pl1=new Graph(this,data,0,0);



    this->setWindowTitle("Extract Time Slice");


    result_Q05_O.clear();
    result_Q50_O.clear();
    result_Q95_O.clear();
    result_age_O.clear();
    result_Q05_C.clear();
    result_Q50_C.clear();
    result_Q95_C.clear();
    result_age_C.clear();

    size=0;
    start=ui->doubleSpinBox->value();
    inc=ui->doubleSpinBox_4->value();
    end=ui->doubleSpinBox_2->value();

    for (int j=0;j<size*inv->get_Entries();j++){
        result_age_C.push_back(NAN);
        result_Q05_C.push_back(NAN);
        result_Q50_C.push_back(NAN);
        result_Q95_C.push_back(NAN);
        result_age_O.push_back(NAN);
        result_Q05_O.push_back(NAN);
        result_Q50_O.push_back(NAN);
        result_Q95_O.push_back(NAN);

    }


    modelInventory = new QStandardItemModel(1,1,this);
    setupInventory();

    connect(ui->tableView,SIGNAL(clicked(QModelIndex)),this,SLOT(invSelected(QModelIndex)));
    connect(ui->comboBox,SIGNAL(currentIndexChanged(int)),this,SLOT(setup()));
    connect(ui->comboBox_2,SIGNAL(currentIndexChanged(int)),this,SLOT(setup()));
    connect(ui->comboBox_3,SIGNAL(currentIndexChanged(int)),this,SLOT(setup()));
    connect(ui->doubleSpinBox,SIGNAL(editingFinished()),this,SLOT(setup()));
    connect(ui->doubleSpinBox_2,SIGNAL(editingFinished()),this,SLOT(setup()));
    connect(ui->doubleSpinBox_4,SIGNAL(editingFinished()),this,SLOT(setup()));
    connect(ui->pushButton,SIGNAL(clicked(bool)),this,SLOT(calc()));
    connect(ui->radioButton,SIGNAL(clicked(bool)),this,SLOT(setup()));
    connect(this,SIGNAL(selectionChanged()),mainW,SLOT(redraw_score()));// refresh main window
    connect(ui->pushButton_2,SIGNAL(clicked(bool)),this,SLOT(read()));
    connect(ui->pushButton_3,SIGNAL(clicked(bool)),this,SLOT(save()));
}

Extract::~Extract()
{
    delete ui;
    delete resources;
    delete modelInventory;
    delete[] data;
    delete[] coll;
    delete[] lstyle;
}

void Extract::setupInventory(){

    // get number of entries that pass filter
    bool filter[inv->get_Entries()];
    int sum=0;
    for (int i=0;i<inv->get_Entries();i++){
        if (checkFilter(i)){
            filter[i]=true;
            sum++;
        } else {
            filter[i]=false;
        }
    }

    // create the model for Inventory
    delete modelInventory;
    modelInventory = new QStandardItemModel(sum,15,this);
    modelInventory->setHorizontalHeaderItem(0, new QStandardItem(QString("Index")));
    modelInventory->setHorizontalHeaderItem(1, new QStandardItem(QString("Selected")));
    modelInventory->setHorizontalHeaderItem(2, new QStandardItem(QString("Name of Core")));
    modelInventory->setHorizontalHeaderItem(3, new QStandardItem(QString("Proxy")));
    modelInventory->setHorizontalHeaderItem(4, new QStandardItem(QString("Longitude")));
    modelInventory->setHorizontalHeaderItem(5, new QStandardItem(QString("Latitude")));
    modelInventory->setHorizontalHeaderItem(6, new QStandardItem(QString("Water\nDepth")));
    modelInventory->setHorizontalHeaderItem(7, new QStandardItem(QString("Basin")));
    modelInventory->setHorizontalHeaderItem(8, new QStandardItem(QString("Record\nType")));
    modelInventory->setHorizontalHeaderItem(9, new QStandardItem(QString("Oxygen\nUse Flag")));
    modelInventory->setHorizontalHeaderItem(10, new QStandardItem(QString("Carbon\nUse Flag")));
    modelInventory->setHorizontalHeaderItem(11, new QStandardItem(QString("Filename")));
    modelInventory->setHorizontalHeaderItem(12, new QStandardItem(QString("Age Min")));
    modelInventory->setHorizontalHeaderItem(13, new QStandardItem(QString("Age Max")));
    modelInventory->setHorizontalHeaderItem(14, new QStandardItem(QString("Bacon")));


    //...
    ui->tableView->setModel(modelInventory);
    ui->tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
    //qDebug()<<"set Variables";
    QStandardItem *var_Index = new QStandardItem[sum];
    QStandardItem *var_Selected = new QStandardItem[sum];
    QStandardItem *var_Core = new QStandardItem[sum];
    QStandardItem *var_Species = new QStandardItem[sum];
    QStandardItem *var_Longitude = new QStandardItem[sum];
    QStandardItem *var_Latitude = new QStandardItem[sum];
    QStandardItem *var_Water_Depth = new QStandardItem[sum];
    QStandardItem *var_Basin = new QStandardItem[sum];
    QStandardItem *var_Record_Type = new QStandardItem[sum];
    QStandardItem *var_Oxygen_Use_Flag = new QStandardItem[sum];
    QStandardItem *var_Carbon_Use_flag = new QStandardItem[sum];
    QStandardItem *var_Filename = new QStandardItem[sum];
    QStandardItem *var_AgeMin = new QStandardItem[sum];
    QStandardItem *var_AgeMax = new QStandardItem[sum];   
    QStandardItem *var_Bacon = new QStandardItem[sum];


    int pos=0;

    AMSData* ams=new AMSData(inv);

    for (int i=0;i<inv->get_Entries();i++){
        if (filter[i]){


            var_Index[pos].setData(i,Qt::EditRole);
            modelInventory->setItem(pos,0,&var_Index[pos]);


            var_Selected[pos].setText("");
            var_Selected[pos].setCheckable(true);

            if (inv->get_Selected(i)==1) {
                var_Selected[pos].setCheckState(Qt::Checked);
            }
            modelInventory->setItem(pos,1,&var_Selected[pos]);
            modelInventory->setData(modelInventory->index(pos, 1), Qt::AlignCenter,Qt::TextAlignmentRole);

            var_Core[pos].setText(inv->get_Core(i));
            modelInventory->setItem(pos,2,&var_Core[pos]);

            var_Species[pos].setText(inv->get_Species(i));
            modelInventory->setItem(pos,3,&var_Species[pos]);

            var_Longitude[pos].setData(inv->get_Longitude(i),Qt::EditRole);
            modelInventory->setItem(pos,4,&var_Longitude[pos]);

            var_Latitude[pos].setData(inv->get_Latitude(i),Qt::EditRole);
            modelInventory->setItem(pos,5,&var_Latitude[pos]);

            var_Water_Depth[pos].setData(inv->get_Water_Depth(i),Qt::EditRole);
            modelInventory->setItem(pos,6,&var_Water_Depth[pos]);

            var_Basin[pos].setText(inv->get_Basinname(inv->get_Basin(i)));
            modelInventory->setItem(pos,7,&var_Basin[pos]);

            var_Record_Type[pos].setText(inv->get_Record_Type(i));
            modelInventory->setItem(pos,8,&var_Record_Type[pos]);

            var_Oxygen_Use_Flag[pos].setData(inv->get_Oxygen_Use_Flag(i),Qt::EditRole);
            var_Oxygen_Use_Flag[pos].setText(QString::number(inv->get_Oxygen_Use_Flag(i)));
            modelInventory->setItem(pos,9,&var_Oxygen_Use_Flag[pos]);
            modelInventory->setData(modelInventory->index(pos, 9), Qt::AlignCenter,Qt::TextAlignmentRole);


            var_Carbon_Use_flag[pos].setData(inv->get_Carbon_Use_Flag(i),Qt::EditRole);
            var_Carbon_Use_flag[pos].setText(QString::number(inv->get_Carbon_Use_Flag(i)));
            modelInventory->setItem(pos,10,&var_Carbon_Use_flag[pos]);
            modelInventory->setData(modelInventory->index(pos, 10), Qt::AlignCenter,Qt::TextAlignmentRole);


            var_Filename[pos].setText(inv->get_Filename(i));
            modelInventory->setItem(pos,11,&var_Filename[pos]);

            inv->set_currentCore(i);
            ams->AMSRead();
            double min=INFINITY;
            double max=-INFINITY;
            for (int ii=0;ii<ams->get_Length();ii++) {
                if (ams->get_Data(7,ii)==1){
                    if (ams->get_Data(4,ii)<min) min=ams->get_Data(4,ii);
                    if (ams->get_Data(4,ii)>max) max=ams->get_Data(4,ii);
                }
            }
            if (min==INFINITY) min=NAN;
            if (max==-INFINITY) max=NAN;



            var_AgeMin[pos].setText(QString::number(min));
            modelInventory->setItem(pos,12,&var_AgeMin[pos]);
            var_AgeMax[pos].setText(QString::number(max));
            modelInventory->setItem(pos,13,&var_AgeMax[pos]);

            var_Bacon[pos].setText(QString::number(ams->get_bacon_out_nrow()-ams->get_bacon_burnin()));
            modelInventory->setItem(pos,14,&var_Bacon[pos]);





            // coloring
            if (inv->get_Selected(i)){
                for (int j=0;j<15;j++) modelInventory->setData(modelInventory->index(pos, j), QColor(Qt::lightGray), Qt::BackgroundRole);
            }
            if (inv->get_Selected(i)){
                for (int j=0;j<15;j++) {
                    if (ui->doubleSpinBox->value()>=min && ui->doubleSpinBox_2->value()<=max){
                        if ((inv->get_Oxygen_Use_Flag(i)==1 && inv->get_Carbon_Use_Flag(i)==1)||ui->radioButton->isChecked()) modelInventory->setData(modelInventory->index(pos, j), QColor(Qt::green), Qt::BackgroundRole);
                    }
                    if (ui->doubleSpinBox_2->value()<min || ui->doubleSpinBox->value()>max){
                        modelInventory->setData(modelInventory->index(pos, j), QColor(Qt::red), Qt::BackgroundRole);
                    }
                    if ((ui->doubleSpinBox->value()<min && ui->doubleSpinBox_2->value()>min) || (ui->doubleSpinBox->value()<max && ui->doubleSpinBox_2->value()>max) ){
                        if ((inv->get_Oxygen_Use_Flag(i)==1 && inv->get_Carbon_Use_Flag(i)==1)||ui->radioButton->isChecked()) modelInventory->setData(modelInventory->index(pos, j), QColor(Qt::yellow), Qt::BackgroundRole);
                    }
                }
            }
            if (inv->get_Carbon_Use_Flag(i)){
                modelInventory->setData(modelInventory->index(pos, 10), QColor(Qt::green), Qt::BackgroundRole);
            } else {
                modelInventory->setData(modelInventory->index(pos, 10), QColor(Qt::red), Qt::BackgroundRole);
            }
            if (inv->get_Oxygen_Use_Flag(i)){
                modelInventory->setData(modelInventory->index(pos, 9), QColor(Qt::green), Qt::BackgroundRole);
            } else {
                modelInventory->setData(modelInventory->index(pos, 9), QColor(Qt::red), Qt::BackgroundRole);
            }
            pos++;
        }
    }

    // deleting causes crahes, why?
    delete ams;
    delete[] filter;

    ui->tableView->setSortingEnabled(1);
    ui->tableView->verticalHeader()->setDefaultSectionSize(ui->tableView->verticalHeader()->minimumSectionSize());
    ui->tableView->resizeColumnsToContents();
    ui->tableView->setHorizontalScrollMode(ui->tableView->ScrollPerPixel);

}

void Extract::invSelected(QModelIndex mi){

    int sel=mi.row();
    //qDebug() << "Clicked :"+QString::number(sel)+":"+QString::number(mi.column());
    QStandardItemModel* model = qobject_cast<QStandardItemModel*>(ui->tableView->model());
    QString text = model->item(sel,mi.column())->text();
    //qDebug() << text;
    int index=model->item(sel,0)->text().toInt();

    if (mi.column()==1){
        if (inv->get_Selected(index)==1){
            inv->set_Selected(index,0);
        } else {
            inv->set_Selected(index,1);
        }
        emit(selectionChanged());
    }
    inv->set_currentCore(index);
    plot();
    setupInventory();

}

bool Extract::checkFilter(int i){
    bool ok=true;

    // check Ocean
    if (inv->get_Basin(i)!=1 && ui->comboBox_2->currentText()=="Atlantic Ocean") ok=false;
    if (inv->get_Basin(i)!=2 && ui->comboBox_2->currentText()=="Pacific Ocean") ok=false;
    if (inv->get_Basin(i)!=3 && ui->comboBox_2->currentText()=="Indian Ocean") ok=false;
    if (inv->get_Basin(i)!=4 && ui->comboBox_2->currentText()=="Mediteranian Ocean") ok=false;
    if (inv->get_Basin(i)!=10 && ui->comboBox_2->currentText()=="Antarctic Ocean") ok=false;
    if (inv->get_Basin(i)!=11 && ui->comboBox_2->currentText()=="Arctic Ocean") ok=false;
    // Selected
    if (inv->get_Selected(i)==0 && ui->comboBox->currentText()=="Selected Only") ok=false;


    return ok;
}

void Extract::setup(){

    setupInventory();
}

void Extract::calc(){
    // setup results(again)

    start=ui->doubleSpinBox->value();
    inc=ui->doubleSpinBox_4->value();
    end=ui->doubleSpinBox_2->value();
    int count=(end-start)/inc;

        result_Q05_C.clear();
        result_Q50_C.clear();
        result_Q95_C.clear();
        result_age_C.clear();
        for (int j=0;j<count;j++) result_age_C.push_back(ui->doubleSpinBox->value()+j*ui->doubleSpinBox_4->value());
        for (int j=0;j<count*inv->get_Entries();j++){
            result_Q05_C.push_back(NAN);
            result_Q50_C.push_back(NAN);
            result_Q95_C.push_back(NAN);
        }


        result_Q05_O.clear();
        result_Q50_O.clear();
        result_Q95_O.clear();
        result_age_O.clear();
        for (int j=0;j<count;j++) result_age_O.push_back(ui->doubleSpinBox->value()+j*ui->doubleSpinBox_4->value());
        for (int j=0;j<count*inv->get_Entries();j++){
            result_Q05_O.push_back(NAN);
            result_Q50_O.push_back(NAN);
            result_Q95_O.push_back(NAN);
        }





    // Go through all inventory
    for (int i=0;i<inv->get_Entries();i++){
        inv->set_currentCore(i);
        inv->readData(inv->get_currentCore());
        if (inv->get_Selected(i)){
            ui->plainTextEdit->appendPlainText("Name :"+inv->get_Core(i)+" : "+inv->get_Species(i));
            if (inv->get_AgeModel(i)==1){
                // Read Agemodel
                ui->plainTextEdit->appendPlainText("    Reading Agemodel Data...");
                repaint();
                AMSData* ams=new AMSData(inv);
                ams->AMSRead();
                ui->plainTextEdit->appendPlainText("    OK. ");
                repaint();
                if (ams->get_bacon_out_ncol()!=0){
                    ui->plainTextEdit->appendPlainText("    Bacon data found("+QString::number(ams->get_bacon_out_nrow()-ams->get_bacon_burnin())+" Iterations).");
                    // (1)+++++ Using Bacon Agedata ++++++

                    // Calculation age models
                    ui->plainTextEdit->appendPlainText("    Calculating results...");
                    repaint();
                    // get original out_nrow

                    int out_nrow=ams->get_bacon_out_nrow();


                    // analyse out and transform it to data
                    // Calc hist with own routine
                    int burnin=ams->get_bacon_burnin();
                    if (burnin>out_nrow) burnin=out_nrow;

                    // transfer out to array for analysis and apply burnin
                    out_nrow=out_nrow-burnin;
                    int out_ncol=ams->get_bacon_out_ncol();
                    float *outdata=new float [out_nrow*out_ncol];
                    float *out=ams->get_bacon_out();
                    for (int q=0;q<out_ncol;q++){
                        for (int j=burnin;j<out_nrow+burnin;j++){
                            outdata[q*out_nrow+(j-burnin)]=out[q*(out_nrow+burnin)+j];
                        }
                    }





                    // calculate ages
                    float section_size=(ams->get_bacon_d_max()-ams->get_bacon_d_min())/ams->get_bacon_K();
                    for (int j=1;j<out_ncol-2;j++){
                        for (int i=0;i<out_nrow;i++) outdata[j*out_nrow+i]=outdata[(j-1)*out_nrow+i]+outdata[(j)*out_nrow+i]*section_size;
                    }

                    // Now agemodels are ready in ages
/*
                    Editor *cc=new Editor(this,ages,ages,depth_n,out_nrow);// This takes a lot of time!!!!
                    cc->setWindowFlags(Qt::Dialog | Qt::WindowTitleHint | Qt::WindowMaximizeButtonHint | Qt::WindowCloseButtonHint | Qt::CustomizeWindowHint);
                    cc->show();
*/


                    // (2) ++++++ define age array ++++++++
                    // already done. see result_age array

                    // (3) ++++++ prepare isotope data +++++++
                    // create array with noisy isotope data

                    ui->plainTextEdit->appendPlainText("    Adding some noise to Isotope-Data...");
                    repaint();
                    float* noisy=new float[inv->get_Length()*out_nrow];
                    for (int iter=0;iter<out_nrow;iter++){
                        for (int j=0;j<inv->get_Length();j++) {
                            if (ui->comboBox_3->currentText()=="18O") noisy[j+iter*inv->get_Length()]=inv->get_data_d18O_Corr(j)+gauss(0,1)*(ui->doubleSpinBox_6->value());
                            if (ui->comboBox_3->currentText()=="13C") noisy[j+iter*inv->get_Length()]=inv->get_data_d13C_Corr(j)+gauss(0,1)*(ui->doubleSpinBox_6->value());

                        }
                    }
/*
                    Editor *c=new Editor(this,noisy,noisy,ui->spinBox->value(),inv->get_Length());// This takes a lot of time!!!!
                    c->setWindowFlags(Qt::Dialog | Qt::WindowTitleHint | Qt::WindowMaximizeButtonHint | Qt::WindowCloseButtonHint | Qt::CustomizeWindowHint);
                    c->show();
*/
                    // (4) ++++++ Interpolate bacon agemodels(ages) to have same depths(inv->get_Depth()) as isodata ++++++++++++++++++++
                    ui->plainTextEdit->appendPlainText("    Interpolating...");
                    repaint();
                    float* newages=new float[inv->get_Length()*out_nrow];
                    for (int j=0;j<inv->get_Length()*out_nrow;j++) newages[j]=NAN;
                    for (int j=0;j<inv->get_Length();j++){
                        // get value for depth
                        float depth=inv->get_data_Depth(j)*100;// turn m to cm
                        //qDebug()<<QString::number(depth);
                        // find neihbors in ages(analytically because its equidistant)
                        float res=(ams->get_bacon_d_max()-ams->get_bacon_d_min())/ams->get_bacon_K();
                        int row=(depth-ams->get_bacon_d_min())/res;
                        double depth0=ams->get_bacon_d_min()+(row)*res;// get depth for r
                        double depth1=ams->get_bacon_d_min()+(row+1)*res;// get depth for r+1
                        //qDebug()<<QString::number(depth0)+"-"+QString::number(depth1);

                        if (depth>=ams->get_bacon_d_min() && depth<ams->get_bacon_d_max() && row<ams->get_bacon_K()-1){

                            for (int q=0;q<out_nrow;q++){
                                // interpolate for all agemodels of this depth

                                newages[j+q*inv->get_Length()]=outdata[q+row*out_nrow]
                                        +(outdata[q+(row+1)*out_nrow]
                                        -outdata[q+row*out_nrow])
                                        /(depth1-depth0)*(depth-depth0);
                            }
                        }
                    }
                    delete[] outdata;
/*
                    Editor *cc=new Editor(this,newages,newages,out_nrow,inv->get_Length());// This takes a lot of time!!!!
                    cc->setWindowFlags(Qt::Dialog | Qt::WindowTitleHint | Qt::WindowMaximizeButtonHint | Qt::WindowCloseButtonHint | Qt::CustomizeWindowHint);
                    cc->show();
*/
                    // (5) Interpolation Fit noisy and newages to new ageintervalls and interpolate new 18O values
                    ui->plainTextEdit->appendPlainText("    Aligning Bacon and Isotopes...");
                    repaint();

                    float* multi_d18O=new float[count*out_nrow];
                    for (int j=0;j<count*out_nrow;j++)multi_d18O[j]=NAN;
                    for (int j=0;j<count;j++){// fill for all new ages
                        float age=ui->doubleSpinBox->value()+j*ui->doubleSpinBox_4->value();
                        age=age*1000;
                        for (int q=0;q<out_nrow;q++){// do it for all iterations
                            // since not equidistant search necessary
                            // search for first valid bigger age
                            int age1=NAN;
                            for (int r=0;r<inv->get_Length();r++){//search ages iteration q
                                if (inv->get_data_Use_Flag(r)==1 && isnan(newages[r+q*inv->get_Length()])==false){ // accept only if use flag is set. This time we interpolate also the d18O, thats why it matters.
                                    if (newages[r+q*inv->get_Length()]>=age){
                                        age1=r;
                                        break;
                                    }
                                }
                            }
                            // search for biggest smaler age
                            int age0=NAN;
                            for (int r=age1;r>=0;r--){//search ages iteration q
                                if (inv->get_data_Use_Flag(r)==1 && isnan(newages[r+q*inv->get_Length()])==false){ // accept only if use flag is set. This time we interpolate also the d18O, thats why it matters.
                                    if (newages[r+q*inv->get_Length()]<=age){
                                        age0=r;
                                        break;
                                    }
                                }
                            }
                            //qDebug()<<QString::number(age0)+":"+QString::number(age1);
                            // if 2 points were found->start interpolation for d18O in iteration q
                            if (isnan(age0)==false && isnan(age1)==false ){
                                float lage=newages[age0+q*inv->get_Length()];
                                float uage=newages[age1+q*inv->get_Length()];
                                float l18O=noisy[age0+q*inv->get_Length()];
                                float u18O=noisy[age1+q*inv->get_Length()];
                                multi_d18O[j+count*q]=l18O+(u18O-l18O)/(uage-lage)*(age-lage);
                            }
                        }
                    }
                    delete[] newages;
          /*
                        Editor *c=new Editor(this,multi_d18O,multi_d18O,out_nrow,count);// This takes a lot of time!!!!
                        c->setWindowFlags(Qt::Dialog | Qt::WindowTitleHint | Qt::WindowMaximizeButtonHint | Qt::WindowCloseButtonHint | Qt::CustomizeWindowHint);
                        c->show();
*/

                    // (6) calculate 5 50 95 Quantile for all ages
                    // sort values in Iteration and estimate Quantiles
                    // set nans to 999999 and count elements
                    ui->plainTextEdit->appendPlainText("    Estimating Quantiles...");
                    repaint();
                    int* c=new int[count];
                    for (int j=0;j<count;j++) c[j]=0;
                    for (int j=0;j<count;j++){
                        for (int q=0;q<out_nrow;q++){
                            if (multi_d18O[j+count*q]>0 && multi_d18O[j+count*q]<50) {
                                c[j]=c[j]+1;
                            } else {
                                multi_d18O[j+count*q]=9999;
                            }
                        }
                    }



                    for (int j=0;j<count;j++){
                        sort(multi_d18O,j,count,0, out_nrow-1);
                        // get Quantiles
                        float v=multi_d18O[j+count*((int)(c[j]*0.05))];
                        if (ui->comboBox_3->currentText()=="18O") if (v!=9999 && c[j]/count>0.5) result_Q05_O[j+count*i]=v;
                        if (ui->comboBox_3->currentText()=="13C") if (v!=9999 && c[j]/count>0.5) result_Q05_C[j+count*i]=v;
                        v=multi_d18O[j+count*((int)(c[j]*0.5))];
                        if (ui->comboBox_3->currentText()=="18O") if (v!=9999 && c[j]/count>0.5) result_Q50_O[j+count*i]=v;
                        if (ui->comboBox_3->currentText()=="13C") if (v!=9999&& c[j]/count>0.5) result_Q50_C[j+count*i]=v;
                        v=multi_d18O[j+count*((int)(c[j]*0.95))];
                        if (ui->comboBox_3->currentText()=="18O") if (v!=9999&& c[j]/count>0.5) result_Q95_O[j+count*i]=v;
                        if (ui->comboBox_3->currentText()=="13C") if (v!=9999&& c[j]/count>0.5) result_Q95_C[j+count*i]=v;
                    }

                    delete[] c;
                    delete[] multi_d18O;

                    delete[] out;
                    delete[] noisy;

/*
                    Editor *c=new Editor(this,multi_d18O,multi_d18O,out_nrow,count);// This takes a lot of time!!!!
                    c->setWindowFlags(Qt::Dialog | Qt::WindowTitleHint | Qt::WindowMaximizeButtonHint | Qt::WindowCloseButtonHint | Qt::CustomizeWindowHint);
                    c->show();
*/



                    /* global values not necessary
                    // create histogramm
                    ui->plainTextEdit->appendPlainText("Creating pdf for core...");
                    repaint();

                    float* pdf=new float[count*size];
                    for (int j=0;j<count*size;j++) pdf[j]=0;
                    // default values for histogramm

                    for(int j=0;j<count;j++){
                        for(int q=0;q<out_nrow;q++){
                            int index=(multi_d18O[j+count*q]-start)/delta;
                            if (index<size && multi_d18O[j+count*q]>0 ) {
                                pdf[j*size+index]=pdf[j*size+index]+1;
                            }
                        }
                    }
                    delete[] multi_d18O;
/*
                    Editor *c=new Editor(this,pdf,pdf,count,size);// This takes a lot of time!!!!
                    c->setWindowFlags(Qt::Dialog | Qt::WindowTitleHint | Qt::WindowMaximizeButtonHint | Qt::WindowCloseButtonHint | Qt::CustomizeWindowHint);
                    c->show();
*/
/*
                    // Add core specific data to global results
                    ui->plainTextEdit->appendPlainText("Adding core pdf to global pdf...");
                    repaint();
                    for (int j=0;j<count*size;j++) result_pdf[j]=result_pdf[j]+pdf[j];
                    delete[] pdf;
*/


                } else {
                    // What to do if no bacon data found?
                    ui->plainTextEdit->appendPlainText("    NO BACON AGE-MODEL FOUND!!!");
                    repaint();
                }
                delete ams;


            } else {
                // No Agemodel found

            }

        }

    }


/*
    // Analyse global pdf and calculate Quantile
    ui->plainTextEdit->appendPlainText("Calculating Quantiles from global pdf...");
    repaint();
    for (int i=0;i<count;i++){//do it for all ages
        // estimate total content of hist
        int total=0;
        for(int j=0;j<size;j++){
            total=total+result_pdf[i*size+j];
        }
        float cum=0;
        for(int j=0;j<size;j++){
            if (total>0){
                cum=cum+result_pdf[i*size+j]/total;
                if (cum>0.05&&isnan(result_Q05[i])==true) result_Q05[i]=start+j*delta;
                if (cum>0.50&&isnan(result_Q50[i])==true) result_Q50[i]=start+j*delta;
                if (cum>0.95&&isnan(result_Q95[i])==true) result_Q95[i]=start+j*delta;
            }
        }
    }
*/
    size=count;
    ui->plainTextEdit->appendPlainText("finished!!!");
    plot();
    repaint();



}

void Extract::sort(float* data,int j,int count,int left,int right){
    // sort values using QuickSort
    int ii = left, jj = right;
    double tmp;

    double pivot = data[j+count*((left + right) / 2)];
    while (ii <= jj) {
        while (data[j+count*ii] < pivot) ii++;
        while (data[j+count*jj] > pivot) jj--;
        if (ii <= jj) {
            // exchange everything
            tmp = data[j+count*ii];
            data[j+count*ii] = data[j+count*jj];
            data[j+count*jj] = tmp;

            ii++;
            jj--;
        }
    };
    if (left < jj) sort(data,j,count,left, jj);
    if (ii < right) sort(data,j,count,ii, right);
}

// Generate Gauss according Box-Mueller method
double Extract::gauss(double mu, double sigma)
{
    const double epsilon = std::numeric_limits<double>::min();
    const double two_pi = 2.0*3.14159265358979323846;

    static double z0, z1;
    static bool generate;
    generate = !generate;

    if (!generate)
       return z1 * sigma + mu;

    double u1, u2;
    do
     {
       u1 = qrand() * (1.0 / RAND_MAX);
       u2 = qrand() * (1.0 / RAND_MAX);

     }
    while ( u1 <= epsilon );

    z0 = sqrt(-2.0 * log(u1)) * cos(two_pi * u2);
    z1 = sqrt(-2.0 * log(u1)) * sin(two_pi * u2);
    return z0 * sigma + mu;
}

void Extract::plot(){
    int index=inv->get_currentCore();
    if (index>=0&&index<=inv->get_Entries()){

        delete[] data;
        data=new float[6*size];
        for(int i=0;i<6*size;i++) data[i]=NAN;
        delete[] coll;
        coll=new QColor[6];
        for (int i=0;i<6;i++) coll[i]=QColor(0,0,0);
        delete[] lstyle;
        lstyle=new Qt::PenStyle[6];
        for (int i=0;i<6;i++) lstyle[i]=Qt::DashLine;
        for(int i=0;i<size;i++){

            if (ui->comboBox_3->currentText()=="18O"){
                data[0*size+i]=result_age_O[i];
                data[1*size+i]=result_Q05_O[i+size*index];

                data[2*size+i]=result_age_O[i];
                data[3*size+i]=result_Q50_O[i+size*index];

                data[4*size+i]=result_age_O[i];
                data[5*size+i]=result_Q95_O[i+size*index];
            }
            if (ui->comboBox_3->currentText()=="13C"){
                data[0*size+i]=result_age_C[i];
                data[1*size+i]=result_Q05_C[i+size*index];

                data[2*size+i]=result_age_C[i];
                data[3*size+i]=result_Q50_C[i+size*index];

                data[4*size+i]=result_age_C[i];
                data[5*size+i]=result_Q95_C[i+size*index];
            }
        }



        coll[0]=QColor(128,128,128);
        coll[1]=QColor(128,128,128);
        coll[2]=QColor(255,0,0);
        coll[3]=QColor(255,0,0);
        coll[4]=QColor(128,128,128);
        coll[5]=QColor(128,128,128);
        lstyle[0]=Qt::DotLine;
        lstyle[1]=Qt::DotLine;
        lstyle[2]=Qt::SolidLine;
        lstyle[3]=Qt::SolidLine;
        lstyle[4]=Qt::DotLine;
        lstyle[5]=Qt::DotLine;
        pl1->setLineWidth(3);
        if (ui->comboBox_3->currentText()=="18O") {
            pl1->setData(data,6,size);
            pl1->setTitel(QString::number(index)+" : "+inv->get_Core(index)+" : "+inv->get_Species(index),"Age [kyr]","\u03b418O permil");
            pl1->setMultiplicator(1,-1);
            pl1->setTextSize(8,16,8);

            pl1->setSetLineColor(coll,1);
            pl1->setSetLineStyle(lstyle,1);
            pl1->setSize(ui->graphicsView->width(),ui->graphicsView->height());
            pl1->setSymbol(0);
            pl1->setSettings(resources->path_PaleoDataViewer+"/Plot/Extract_O.txt");
            pl1->autoSize();
            ui->graphicsView->setScene(pl1);
        }
        if (ui->comboBox_3->currentText()=="13C") {
            pl1->setData(data,6,size);
            pl1->setTitel(QString::number(index)+" : "+inv->get_Core(index)+" : "+inv->get_Species(index),"Age [kyr]","\u03b413C permil");
            pl1->setMultiplicator(1,1);
            pl1->setTextSize(8,16,8);
            pl1->setSetLineColor(coll,1);
            pl1->setSetLineStyle(lstyle,1);
            pl1->setSize(ui->graphicsView->width(),ui->graphicsView->height());
            pl1->setSymbol(0);
            pl1->setSettings(resources->path_PaleoDataViewer+"/Plot/Extract_C.txt");
            pl1->autoSize();
            ui->graphicsView->setScene(pl1);
        }
    }
}

void Extract::paintEvent(QPaintEvent *)
{
    pl1->setSize(ui->graphicsView->width(),ui->graphicsView->height());
}

void Extract::save(){
    if (ui->comboBox_3->currentText()=="18O") save_O();
    if (ui->comboBox_3->currentText()=="13C") save_C();
}

void Extract::read(){
    if (ui->comboBox_3->currentText()=="18O") read_O();
    if (ui->comboBox_3->currentText()=="13C") read_C();
}

void Extract::save_O(){
    QString Qfilename = QFileDialog::getSaveFileName(this, tr("Select Save File"),
                                             resources->path_PaleoDataViewer+"/Derived Data/data",
                                             tr("18O Compilation (*.O18)"));
    ui->plainTextEdit->appendPlainText("Saving to File : "+Qfilename);
    repaint();
    // get number of datasets
    int length=0;
    for (int i=0;i<inv->get_Entries();i++){
        int ok=0;
        for (int j=0;j<size;j++) {
            if (isnan(result_Q50_O[j+size*i])==false) {
                ok=1;
                break;
            }
        }
        if (ok==1) length++;
    }
    // +++++++++ Preparing data
    // Meta attributes
    // -starting age
    // -increment
    // -ending age
    // Core Meta
    QString* core_name=new QString[length];
    QString* species_name=new QString[length];
    float* core_latt=new float[length];
    float* core_long=new float[length];
    float* core_depth=new float[length];
    float* Q05=new float[length*size];
    float* Q50=new float[length*size];
    float* Q95=new float[length*size];
    int count=0;
    for (int i=0;i<inv->get_Entries();i++){
        int ok=0;
        for (int j=0;j<size;j++) {
            if (isnan(result_Q50_O[j+size*i])==false) {
                ok=1;
                break;
            }
        }
        if (ok==1) {
            core_name[count]=inv->get_Core(i);
            species_name[count]=inv->get_Species(i);
            core_depth[count]=inv->get_Water_Depth(i);
            for (int j=0;j<size;j++){
                Q05[j+count*size]=result_Q05_O[j+size*i];
                Q50[j+count*size]=result_Q50_O[j+size*i];
                Q95[j+count*size]=result_Q95_O[j+size*i];
            }
            count++;
        }
    }



    char* filename;
    string fname=Qfilename.toStdString();
    filename=new char[fname.size()+1];
    strcpy(filename,fname.c_str());

   qDebug()<<"saving...";

    // Initialize ids and meta
    int ncid;
    int retval;// for Errors

    // Open the file
    if (!(retval = nc_create(filename, NC_WRITE, &ncid))){
        // Define variables

        // Float list length
        int length_dim;
        int dim[1];
        if ((retval = nc_def_dim(ncid,"Length",length,&length_dim)))
           ERR(retval);
        dim[0]=length_dim;

        // Character Strings for identification
        // Corename
        int corename_length=0;
        for (int i=0;i<length;i++) if (corename_length<core_name[i].length()) corename_length=core_name[i].length();
        int corename_label_dim;
        if ((retval = nc_def_dim(ncid,"Core_Length",corename_length,&corename_label_dim)))
           ERR(retval);
        int dimm[2];
        dimm[0]=corename_label_dim;
        dimm[1]=length_dim;
        int corename_id;
        if ((retval = nc_def_var(ncid,"Core",NC_CHAR,2,dimm,&corename_id)))
            ERR(retval);

        // Species
        int species_length=0;
        for (int i=0;i<length;i++) if (species_length<species_name[i].length()) species_length=species_name[i].length();
        int species_label_dim;
        if ((retval = nc_def_dim(ncid,"Species_Length",species_length,&species_label_dim)))
           ERR(retval);
        int dimm2[2];
        dimm2[0]=species_label_dim;
        dimm2[1]=length_dim;
        int species_id;
        if ((retval = nc_def_var(ncid,"Species",NC_CHAR,2,dimm2,&species_id)))
            ERR(retval);

        // Float lists for location
        // long
        int long_id;
        if ((retval = nc_def_var(ncid,"Longitude",NC_FLOAT,1,dim,&long_id)))
            ERR(retval);
        // latt
        int latt_id;
        if ((retval = nc_def_var(ncid,"Lattitude",NC_FLOAT,1,dim,&latt_id)))
            ERR(retval);
        // depth
        int depth_id;
        if ((retval = nc_def_var(ncid,"Depth",NC_FLOAT,1,dim,&depth_id)))
            ERR(retval);



        // set size of Q matrix
        int size_dim;
        int Q05_id;
        int Q50_id;
        int Q95_id;
        if ((retval = nc_def_dim(ncid,"Size",size,&size_dim)))
           ERR(retval);
        dimm[0]=length_dim;
        dimm[1]=size_dim;
       //qDebug()<<dim[0];
       //qDebug()<<dim[1];
        if ((retval = nc_def_var(ncid,"Quantile_05",NC_FLOAT,2,dimm,&Q05_id)))
            ERR(retval);
        if ((retval = nc_def_var(ncid,"Quantile_50",NC_FLOAT,2,dimm,&Q50_id)))
            ERR(retval);
        if ((retval = nc_def_var(ncid,"Quantile_95",NC_FLOAT,2,dimm,&Q95_id)))
            ERR(retval);

        //**********************************************

        // end definition mode
        if ((retval = nc_enddef(ncid)))
            ERR(retval);

        // ******* write Core
        {
        unsigned char text[corename_length][length];
        for(int i=0;i<corename_length;i++) for(int ii=0;ii<length;ii++) text[i][ii]=' ';
        for (int i=0;i<length;i++){
            for (int j=0;j<core_name[i].length();j++) text[j][i]=core_name[i].at(j).toLatin1();
        }
        if ((retval = nc_put_var(ncid,corename_id,&text[0][0])))
            ERR(retval);
        }

        // ******* write Species
        {
        unsigned char text[species_length][length];
        for(int i=0;i<species_length;i++) for(int ii=0;ii<length;ii++) text[i][ii]=' ';
        for (int i=0;i<length;i++){
            for (int j=0;j<species_name[i].length();j++) text[j][i]=species_name[i].at(j).toLatin1();
        }
        if ((retval = nc_put_var(ncid,species_id,&text[0][0])))
            ERR(retval);
        }

        // ******** save latt
        if ((retval = nc_put_var(ncid,latt_id,&core_latt[0])))
            ERR(retval);
        // ******** save long
        if ((retval = nc_put_var(ncid,long_id,&core_long[0])))
            ERR(retval);
        // ******** save depth
        if ((retval = nc_put_var(ncid,depth_id,&core_depth[0])))
            ERR(retval);

        // ******** save Q05
        if ((retval = nc_put_var(ncid,Q05_id,&Q05[0])))
            ERR(retval);
        // ******** save Q50
        if ((retval = nc_put_var(ncid,Q50_id,&Q50[0])))
            ERR(retval);
        // ******** save Q95
        if ((retval = nc_put_var(ncid,Q95_id,&Q95[0])))
            ERR(retval);

        // activate defMode
        if ((retval = nc_redef(ncid)))
            ERR(retval);

        // write attributes
        // 1:start
        if ((retval = nc_put_att_float(ncid,NC_GLOBAL,"Start_Age",NC_FLOAT,1,&start)))
            ERR(retval);
        // 2:increment
        if ((retval = nc_put_att_float(ncid,NC_GLOBAL,"Increment_Age",NC_FLOAT,1,&inc)))
            ERR(retval);
        // 3:end
        if ((retval = nc_put_att_float(ncid,NC_GLOBAL,"End_Age",NC_FLOAT,1,&end)))
            ERR(retval);



        // *******************************************************

       //qDebug()<<"data written";

        // Close the file, freeing all resources.
        if ((retval = nc_close(ncid)))
           ERR(retval);

    } else {
        if (nc_strerror(retval)=="No such file or directory") {
           //qDebug() << "Start generating new File...";
        } else {

            //ERR(retval);
        }
    }
    delete filename;
    delete[] core_name;
    delete[] species_name;
    delete[] core_latt;
    delete[] core_long;
    delete[] core_depth;
    delete[] Q05;
    delete[] Q50;
    delete[] Q95;
}

void Extract::read_O(){
    QString Qfilename = QFileDialog::getOpenFileName(this, tr("Select File"),
                                             resources->path_PaleoDataViewer+"/Derived Data/",
                                             tr("18O (*.O18)"));
    ui->plainTextEdit->appendPlainText("Reading from File : "+Qfilename);
    repaint();

    char* filename;
    string fname=Qfilename.toStdString();
    filename=new char[fname.size()+1];
    strcpy(filename,fname.c_str());
    //qDebug() << QFilename;


    // Initialize ids and meta
    int ncid;
    int varid;
    size_t dimlen[2]={0};
    int retval;// for Errors

    // Open the file
    if (!(retval = nc_open(filename, NC_NOWRITE, &ncid))){




        // ******* read Corename
        std::vector<QString*> core;
        {
        // get length
        if ((retval = nc_inq_dimid(ncid, "Length", &varid)))
           ERR(retval);
        if ((retval = nc_inq_dimlen(ncid, varid, &dimlen[0])))
           ERR(retval);

        // number of cores and character length
        if ((retval = nc_inq_dimid(ncid, "Core_Length", &varid)))
           ERR(retval);
        if ((retval = nc_inq_dimlen(ncid, varid, &dimlen[1])))
           ERR(retval);



        if ((retval = nc_inq_varid(ncid, "Core", &varid)))
           ERR(retval);
        unsigned char text[dimlen[0]*dimlen[1]];
        if ((retval = nc_get_var(ncid,varid,&text[0]))) ERR(retval);
        core.clear();
        core.reserve(dimlen[0]);
        for (int i=0;i<dimlen[0];i++){
            core.push_back(new QString(""));
            for (int j=0;j<dimlen[1];j++){
                if (text[j*dimlen[0]+i]!=0){
                    core[i]->append(text[j*dimlen[0]+i]);
                }
            }
        }
        }

        // ******* read Species
        std::vector<QString*> species;
        {
        // get length
        if ((retval = nc_inq_dimid(ncid, "Species_Length", &varid)))
           ERR(retval);
        if ((retval = nc_inq_dimlen(ncid, varid, &dimlen[1])))
           ERR(retval);

        if ((retval = nc_inq_varid(ncid, "Species", &varid)))
           ERR(retval);
        unsigned char text[dimlen[0]*dimlen[1]];
        if ((retval = nc_get_var(ncid,varid,&text[0]))) ERR(retval);
        species.clear();

        for (int i=0;i<dimlen[0];i++){
            species.push_back(new QString(""));
            for (int j=0;j<dimlen[1];j++){
                if (text[j*dimlen[0]+i]!=0){
                    species[i]->append(text[j*dimlen[0]+i]);
                }
            }
        }
        }

        // read Q

        if ((retval = nc_inq_dimid(ncid, "Size", &varid)))
           ERR(retval);
        // get size
        if ((retval = nc_inq_dimlen(ncid, varid, &dimlen[1])))
           ERR(retval);

        int nrow=dimlen[1];
        int ncol=dimlen[0];
        if ((retval = nc_inq_varid(ncid, "Quantile_05", &varid)))
           ERR(retval);
        float* Q05=new float[ncol*nrow];
        if ((retval = nc_get_var_float(ncid,varid,&Q05[0]))) ERR(retval);

        // read Q50
        if ((retval = nc_inq_varid(ncid, "Quantile_50", &varid)))
           ERR(retval);
        float* Q50=new float[ncol*nrow];
        if ((retval = nc_get_var_float(ncid,varid,&Q50[0]))) ERR(retval);

        // read Q95
        if ((retval = nc_inq_varid(ncid, "Quantile_95", &varid)))
           ERR(retval);
        float* Q95=new float[ncol*nrow];
        if ((retval = nc_get_var_float(ncid,varid,&Q95[0]))) ERR(retval);

        // 1:start
        float start_age;
        if ((retval = nc_get_att_float(ncid,NC_GLOBAL,"Start_Age",&start_age)))
            ERR(retval);
        // 2:increment
        float inc_age;
        if ((retval = nc_get_att_float(ncid,NC_GLOBAL,"Increment_Age",&inc_age)))
            ERR(retval);

        // Close the file, freeing all resources.
        if ((retval = nc_close(ncid)))
           ERR(retval);

        // put data into shape
        start=start_age;
        ui->doubleSpinBox->setValue(start);
        inc=inc_age;
        ui->doubleSpinBox_4->setValue(inc);
        end=start_age+inc_age*dimlen[1];
        ui->doubleSpinBox_2->setValue(end);
        size=dimlen[1];
        result_Q05_O.clear();
        result_Q50_O.clear();
        result_Q95_O.clear();
        result_age_O.clear();
        int count=(int)((ui->doubleSpinBox_2->value()-ui->doubleSpinBox->value())/(ui->doubleSpinBox_4->value()));
        for (int j=0;j<count;j++) result_age_O.push_back(ui->doubleSpinBox->value()+j*ui->doubleSpinBox_4->value());
        for (int j=0;j<count*inv->get_Entries();j++){
            result_Q05_O.push_back(NAN);
            result_Q50_O.push_back(NAN);
            result_Q95_O.push_back(NAN);
        }
        result_Q05_C.clear();
        result_Q50_C.clear();
        result_Q95_C.clear();
        result_age_C.clear();

        for (int j=0;j<count;j++) result_age_C.push_back(ui->doubleSpinBox->value()+j*ui->doubleSpinBox_4->value());
        for (int j=0;j<count*inv->get_Entries();j++){
            result_Q05_C.push_back(NAN);
            result_Q50_C.push_back(NAN);
            result_Q95_C.push_back(NAN);
        }
        // copy to results
        for (int i=0;i<inv->get_Entries();i++) inv->set_Selected(i,0);
        for (int i=0;i<dimlen[0];i++){
            // find index
            int found=0;
            for (int j=0;j<inv->get_Entries();j++){
                if (inv->get_Core(j).simplified()==core[i]->toLatin1().simplified() && inv->get_Species(j).simplified()==species[i]->toLatin1().simplified()){
                    inv->set_Selected(j,1);
                    for (int q=0;q<dimlen[1];q++) result_Q05_O[j*size+q]=Q05[i*dimlen[1]+q];
                    for (int q=0;q<dimlen[1];q++) result_Q50_O[j*size+q]=Q50[i*dimlen[1]+q];
                    for (int q=0;q<dimlen[1];q++) result_Q95_O[j*size+q]=Q95[i*dimlen[1]+q];
                    found=1;
                    break;
                }
            }
            if (found==0){
                QString Core=core[i]->toLatin1();
                QString Species=species[i]->toLatin1();
                ui->plainTextEdit->appendPlainText("Core not found : "+Core+" : "+Species);
                repaint();
            }
        }


        delete[] Q05;
        delete[] Q50;
        delete[] Q95;
        setupInventory();
        plot();
    } else {

        if (nc_strerror(retval)=="No such file or directory") {
            //qDebug() << "Start generating new File...";
        } else {
            //qDebug() << "File Error";
           // ERR(retval);
        }


    }

    delete filename;




}

void Extract::save_C(){
    QString Qfilename = QFileDialog::getSaveFileName(this, tr("Select Save File"),
                                             resources->path_PaleoDataViewer+"/Derived Data/data",
                                             tr("C13 Compilation (*.C13)"));
    ui->plainTextEdit->appendPlainText("Saving to File : "+Qfilename);
    repaint();
    // get number of datasets
    int length=0;
    for (int i=0;i<inv->get_Entries();i++){
        int ok=0;
        for (int j=0;j<size;j++) {
            if (isnan(result_Q50_C[j+size*i])==false) {
                ok=1;
                break;
            }
        }
        if (ok==1) length++;
    }
    // +++++++++ Preparing data
    // Meta attributes
    // -starting age
    // -increment
    // -ending age
    // Core Meta
    QString* core_name=new QString[length];
    QString* species_name=new QString[length];
    float* core_latt=new float[length];
    float* core_long=new float[length];
    float* core_depth=new float[length];
    float* Q05=new float[length*size];
    float* Q50=new float[length*size];
    float* Q95=new float[length*size];
    int count=0;
    for (int i=0;i<inv->get_Entries();i++){
        int ok=0;
        for (int j=0;j<size;j++) {
            if (isnan(result_Q50_C[j+size*i])==false) {
                ok=1;
                break;
            }
        }
        if (ok==1) {
            core_name[count]=inv->get_Core(i);
            species_name[count]=inv->get_Species(i);
            core_depth[count]=inv->get_Water_Depth(i);
            for (int j=0;j<size;j++){
                Q05[j+count*size]=result_Q05_C[j+size*i];
                Q50[j+count*size]=result_Q50_C[j+size*i];
                Q95[j+count*size]=result_Q95_C[j+size*i];
            }
            count++;
        }
    }



    char* filename;
    string fname=Qfilename.toStdString();
    filename=new char[fname.size()+1];
    strcpy(filename,fname.c_str());

   qDebug()<<"saving...";

    // Initialize ids and meta
    int ncid;
    int retval;// for Errors

    // Open the file
    if (!(retval = nc_create(filename, NC_WRITE, &ncid))){
        // Define variables

        // Float list length
        int length_dim;
        int dim[1];
        if ((retval = nc_def_dim(ncid,"Length",length,&length_dim)))
           ERR(retval);
        dim[0]=length_dim;

        // Character Strings for identification
        // Corename
        int corename_length=0;
        for (int i=0;i<length;i++) if (corename_length<core_name[i].length()) corename_length=core_name[i].length();
        int corename_label_dim;
        if ((retval = nc_def_dim(ncid,"Core_Length",corename_length,&corename_label_dim)))
           ERR(retval);
        int dimm[2];
        dimm[0]=corename_label_dim;
        dimm[1]=length_dim;
        int corename_id;
        if ((retval = nc_def_var(ncid,"Core",NC_CHAR,2,dimm,&corename_id)))
            ERR(retval);

        // Species
        int species_length=0;
        for (int i=0;i<length;i++) if (species_length<species_name[i].length()) species_length=species_name[i].length();
        int species_label_dim;
        if ((retval = nc_def_dim(ncid,"Species_Length",species_length,&species_label_dim)))
           ERR(retval);
        int dimm2[2];
        dimm2[0]=species_label_dim;
        dimm2[1]=length_dim;
        int species_id;
        if ((retval = nc_def_var(ncid,"Species",NC_CHAR,2,dimm2,&species_id)))
            ERR(retval);

        // Float lists for location
        // long
        int long_id;
        if ((retval = nc_def_var(ncid,"Longitude",NC_FLOAT,1,dim,&long_id)))
            ERR(retval);
        // latt
        int latt_id;
        if ((retval = nc_def_var(ncid,"Lattitude",NC_FLOAT,1,dim,&latt_id)))
            ERR(retval);
        // depth
        int depth_id;
        if ((retval = nc_def_var(ncid,"Depth",NC_FLOAT,1,dim,&depth_id)))
            ERR(retval);



        // set size of Q matrix
        int size_dim;
        int Q05_id;
        int Q50_id;
        int Q95_id;
        if ((retval = nc_def_dim(ncid,"Size",size,&size_dim)))
           ERR(retval);
        dimm[0]=length_dim;
        dimm[1]=size_dim;
       //qDebug()<<dim[0];
       //qDebug()<<dim[1];
        if ((retval = nc_def_var(ncid,"Quantile_05",NC_FLOAT,2,dimm,&Q05_id)))
            ERR(retval);
        if ((retval = nc_def_var(ncid,"Quantile_50",NC_FLOAT,2,dimm,&Q50_id)))
            ERR(retval);
        if ((retval = nc_def_var(ncid,"Quantile_95",NC_FLOAT,2,dimm,&Q95_id)))
            ERR(retval);

        //**********************************************

        // end definition mode
        if ((retval = nc_enddef(ncid)))
            ERR(retval);

        // ******* write Core
        {
        unsigned char text[corename_length][length];
        for(int i=0;i<corename_length;i++) for(int ii=0;ii<length;ii++) text[i][ii]=' ';
        for (int i=0;i<length;i++){
            for (int j=0;j<core_name[i].length();j++) text[j][i]=core_name[i].at(j).toLatin1();
        }
        if ((retval = nc_put_var(ncid,corename_id,&text[0][0])))
            ERR(retval);
        }

        // ******* write Species
        {
        unsigned char text[species_length][length];
        for(int i=0;i<species_length;i++) for(int ii=0;ii<length;ii++) text[i][ii]=' ';
        for (int i=0;i<length;i++){
            for (int j=0;j<species_name[i].length();j++) text[j][i]=species_name[i].at(j).toLatin1();
        }
        if ((retval = nc_put_var(ncid,species_id,&text[0][0])))
            ERR(retval);
        }

        // ******** save latt
        if ((retval = nc_put_var(ncid,latt_id,&core_latt[0])))
            ERR(retval);
        // ******** save long
        if ((retval = nc_put_var(ncid,long_id,&core_long[0])))
            ERR(retval);
        // ******** save depth
        if ((retval = nc_put_var(ncid,depth_id,&core_depth[0])))
            ERR(retval);

        // ******** save Q05
        if ((retval = nc_put_var(ncid,Q05_id,&Q05[0])))
            ERR(retval);
        // ******** save Q50
        if ((retval = nc_put_var(ncid,Q50_id,&Q50[0])))
            ERR(retval);
        // ******** save Q95
        if ((retval = nc_put_var(ncid,Q95_id,&Q95[0])))
            ERR(retval);

        // activate defMode
        if ((retval = nc_redef(ncid)))
            ERR(retval);

        // write attributes
        // 1:start
        if ((retval = nc_put_att_float(ncid,NC_GLOBAL,"Start_Age",NC_FLOAT,1,&start)))
            ERR(retval);
        // 2:increment
        if ((retval = nc_put_att_float(ncid,NC_GLOBAL,"Increment_Age",NC_FLOAT,1,&inc)))
            ERR(retval);
        // 3:end
        if ((retval = nc_put_att_float(ncid,NC_GLOBAL,"End_Age",NC_FLOAT,1,&end)))
            ERR(retval);



        // *******************************************************

       //qDebug()<<"data written";

        // Close the file, freeing all resources.
        if ((retval = nc_close(ncid)))
           ERR(retval);

    } else {
        if (nc_strerror(retval)=="No such file or directory") {
           //qDebug() << "Start generating new File...";
        } else {

            //ERR(retval);
        }
    }
    delete filename;
    delete[] core_name;
    delete[] species_name;
    delete[] core_latt;
    delete[] core_long;
    delete[] core_depth;
    delete[] Q05;
    delete[] Q50;
    delete[] Q95;
}

void Extract::read_C(){
    QString Qfilename = QFileDialog::getOpenFileName(this, tr("Select File"),
                                             resources->path_PaleoDataViewer+"/Derived Data/",
                                             tr("C13 Compilation (*.C13)"));
    ui->plainTextEdit->appendPlainText("Reading from File : "+Qfilename);
    repaint();

    char* filename;
    string fname=Qfilename.toStdString();
    filename=new char[fname.size()+1];
    strcpy(filename,fname.c_str());
    //qDebug() << QFilename;


    // Initialize ids and meta
    int ncid;
    int varid;
    size_t dimlen[2]={0};
    int retval;// for Errors

    // Open the file
    if (!(retval = nc_open(filename, NC_NOWRITE, &ncid))){




        // ******* read Corename
        std::vector<QString*> core;
        {
        // get length
        if ((retval = nc_inq_dimid(ncid, "Length", &varid)))
           ERR(retval);
        if ((retval = nc_inq_dimlen(ncid, varid, &dimlen[0])))
           ERR(retval);

        // number of cores and character length
        if ((retval = nc_inq_dimid(ncid, "Core_Length", &varid)))
           ERR(retval);
        if ((retval = nc_inq_dimlen(ncid, varid, &dimlen[1])))
           ERR(retval);



        if ((retval = nc_inq_varid(ncid, "Core", &varid)))
           ERR(retval);
        unsigned char text[dimlen[0]*dimlen[1]];
        if ((retval = nc_get_var(ncid,varid,&text[0]))) ERR(retval);
        core.clear();
        core.reserve(dimlen[0]);
        for (int i=0;i<dimlen[0];i++){
            core.push_back(new QString(""));
            for (int j=0;j<dimlen[1];j++){
                if (text[j*dimlen[0]+i]!=0){
                    core[i]->append(text[j*dimlen[0]+i]);
                }
            }
        }
        }

        // ******* read Species
        std::vector<QString*> species;
        {
        // get length
        if ((retval = nc_inq_dimid(ncid, "Species_Length", &varid)))
           ERR(retval);
        if ((retval = nc_inq_dimlen(ncid, varid, &dimlen[1])))
           ERR(retval);

        if ((retval = nc_inq_varid(ncid, "Species", &varid)))
           ERR(retval);
        unsigned char text[dimlen[0]*dimlen[1]];
        if ((retval = nc_get_var(ncid,varid,&text[0]))) ERR(retval);
        species.clear();

        for (int i=0;i<dimlen[0];i++){
            species.push_back(new QString(""));
            for (int j=0;j<dimlen[1];j++){
                if (text[j*dimlen[0]+i]!=0){
                    species[i]->append(text[j*dimlen[0]+i]);
                }
            }
        }
        }

        // read Q

        if ((retval = nc_inq_dimid(ncid, "Size", &varid)))
           ERR(retval);
        // get size
        if ((retval = nc_inq_dimlen(ncid, varid, &dimlen[1])))
           ERR(retval);

        int nrow=dimlen[1];
        int ncol=dimlen[0];
        if ((retval = nc_inq_varid(ncid, "Quantile_05", &varid)))
           ERR(retval);
        float* Q05=new float[ncol*nrow];
        if ((retval = nc_get_var_float(ncid,varid,&Q05[0]))) ERR(retval);

        // read Q50
        if ((retval = nc_inq_varid(ncid, "Quantile_50", &varid)))
           ERR(retval);
        float* Q50=new float[ncol*nrow];
        if ((retval = nc_get_var_float(ncid,varid,&Q50[0]))) ERR(retval);

        // read Q95
        if ((retval = nc_inq_varid(ncid, "Quantile_95", &varid)))
           ERR(retval);
        float* Q95=new float[ncol*nrow];
        if ((retval = nc_get_var_float(ncid,varid,&Q95[0]))) ERR(retval);

        // 1:start
        float start_age;
        if ((retval = nc_get_att_float(ncid,NC_GLOBAL,"Start_Age",&start_age)))
            ERR(retval);
        // 2:increment
        float inc_age;
        if ((retval = nc_get_att_float(ncid,NC_GLOBAL,"Increment_Age",&inc_age)))
            ERR(retval);

        // Close the file, freeing all resources.
        if ((retval = nc_close(ncid)))
           ERR(retval);

        // put data into shape
        start=start_age;
        ui->doubleSpinBox->setValue(start);
        inc=inc_age;
        ui->doubleSpinBox_4->setValue(inc);
        end=start_age+inc_age*dimlen[1];
        ui->doubleSpinBox_2->setValue(end);
        size=dimlen[1];
        result_Q05_C.clear();
        result_Q50_C.clear();
        result_Q95_C.clear();
        result_age_C.clear();
        int count=(int)((ui->doubleSpinBox_2->value()-ui->doubleSpinBox->value())/(ui->doubleSpinBox_4->value()));
        for (int j=0;j<count;j++) result_age_C.push_back(ui->doubleSpinBox->value()+j*ui->doubleSpinBox_4->value());
        for (int j=0;j<count*inv->get_Entries();j++){
            result_Q05_C.push_back(NAN);
            result_Q50_C.push_back(NAN);
            result_Q95_C.push_back(NAN);
        }
        result_Q05_O.clear();
        result_Q50_O.clear();
        result_Q95_O.clear();
        result_age_O.clear();
        for (int j=0;j<count;j++) result_age_O.push_back(ui->doubleSpinBox->value()+j*ui->doubleSpinBox_4->value());
        for (int j=0;j<count*inv->get_Entries();j++){
            result_Q05_O.push_back(NAN);
            result_Q50_O.push_back(NAN);
            result_Q95_O.push_back(NAN);
        }
        // copy to results
        for (int i=0;i<inv->get_Entries();i++) inv->set_Selected(i,0);
        for (int i=0;i<dimlen[0];i++){
            // find index
            int found=0;
            for (int j=0;j<inv->get_Entries();j++){
                if (inv->get_Core(j).simplified()==core[i]->toLatin1().simplified() && inv->get_Species(j).simplified()==species[i]->toLatin1().simplified()){
                    inv->set_Selected(j,1);
                    for (int q=0;q<dimlen[1];q++) result_Q05_C[j*size+q]=Q05[i*dimlen[1]+q];
                    for (int q=0;q<dimlen[1];q++) result_Q50_C[j*size+q]=Q50[i*dimlen[1]+q];
                    for (int q=0;q<dimlen[1];q++) result_Q95_C[j*size+q]=Q95[i*dimlen[1]+q];
                    found=1;
                    break;
                }
            }
            if (found==0){
                QString Core=core[i]->toLatin1();
                QString Species=species[i]->toLatin1();
                ui->plainTextEdit->appendPlainText("Core not found : "+Core+" : "+Species);
                repaint();
            }
        }


        delete[] Q05;
        delete[] Q50;
        delete[] Q95;
        setupInventory();
        plot();
    } else {

        if (nc_strerror(retval)=="No such file or directory") {
            //qDebug() << "Start generating new File...";
        } else {
            //qDebug() << "File Error";
           // ERR(retval);
        }


    }

    delete filename;




}

bool Extract::eventFilter(QObject *obj, QEvent *event)
{
    if (event->type() == QEvent::KeyPress)
    {
        if (obj==ui->graphicsView||obj==ui->tableView){
            QKeyEvent *keyEvent = static_cast<QKeyEvent *>(event);
            if (keyEvent->key()==Qt::Key_F1){
                ui->splitter->restoreState(sp);
                ui->splitter_2->restoreState(sp_2);

                return true;
            }
        }
    }
    return QObject::eventFilter(obj, event);
}
