/********************************************************************************/
/*    This file is part of PaleoDataViewer.                       					*/
/*                                                                      		*/
/*    PaleoDataViewer is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoDataViewer is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoDataViewer.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#ifndef EXTRACT_H
#define EXTRACT_H

#include <QDialog>
#include <QStandardItemModel>
#include <QDebug>
#include <QMainWindow>
#include "General/inventory.h"
#include "AMS/amsdata.h"
#include <cstdlib>
#include <cmath>
#include <limits>
#include "Editor/editor.h"
#include "Editor/graph.h"
#include "General/resources.h"
#include "QFileDialog"

namespace Ui {
class Extract;
}

class Extract : public QDialog
{
    Q_OBJECT

public:
    explicit Extract(QMainWindow *mainWindow,Inventory *inventory);
    ~Extract();



private:
    void setupInventory();
    bool checkFilter(int i);
    void plot();
    void sort(float* data,int j,int count,int left,int right);

private slots:
    void setup();
    void calc();
    void read();
    void save();
    void read_O();
    void save_O();
    void read_C();
    void save_C();

    double gauss(double mu, double sigma);
    void invSelected(QModelIndex mi);
signals:
    void selectionChanged();
protected:
    bool eventFilter(QObject *obj, QEvent *event);
private:
    Ui::Extract *ui;
    QMainWindow *mainW;
    Inventory *inv;
    QStandardItemModel *modelInventory;
    AMSData *amsdata;

    Graph* pl1;
    float *data;
    QColor *coll;
    Qt::PenStyle *lstyle;

    Resources *resources;

    std::vector<float> result_Q05_O;
    std::vector<float> result_Q50_O;
    std::vector<float> result_Q95_O;
    std::vector<float> result_age_O;
    std::vector<float> result_Q05_C;
    std::vector<float> result_Q50_C;
    std::vector<float> result_Q95_C;
    std::vector<float> result_age_C;
    void paintEvent(QPaintEvent*);
    int size;
    float start,inc,end;
    QByteArray sp,sp_2;
};

#endif // EXTRACT_H
