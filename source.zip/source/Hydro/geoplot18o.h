/********************************************************************************/
/*    This file is part of PaleoView.                       					*/
/*                                                                      		*/
/*    PaleoView is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoView is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoView.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#ifndef GeoPlot18O_H
#define GeoPlot18O_H


#include <QGraphicsScene>
#include <QPainter>
#include <QFont>
#include <QGraphicsItem>
#include "General/inventory.h"
#include <stdlib.h>
#include "General/resources.h"
#include "hydrodatabase.h"

class GeoPlot18O : public QGraphicsItem
{

public:
    GeoPlot18O(QGraphicsScene *graphScene,QImage *image);

    void setSize(int map_width,int map_height);
    void setView(float lo,float la, float z);
    void setMessage(QString s);
    void setInventory(Inventory *i,HydroDatabase *h);
    float getMapFactor_x();
    float getMapFactor_y();
    void invertLabel();
    float getZoom();
    float getLongitude();
    float getLatitude();
    void eval_Color(float v);
    void set_Map_Mode(int n);
    QRectF boundingRect() const Q_DECL_OVERRIDE;
    QPainterPath shape() const Q_DECL_OVERRIDE;
    void paint(QPainter *painter,const QStyleOptionGraphicsItem *option, QWidget *widget) Q_DECL_OVERRIDE;
    void setRect(int x1,int x2, int y1, int y2, int mode);
    void set_selected_Core(QString c,QString p);
    void set_Depth(float i);
private:
    QGraphicsScene *graph;
    QString s;
    QImage *mapimage;
    float zoom,longitude,latitude,depth;
    int mapsize_x;
    int mapsize_y;
    Inventory *inv;
    HydroDatabase *hydro;
    int label_Flag;
    int map_mode;
    QString core,proxy;

    // Color
    int r_col,g_col,b_col;

    // Selection Rect
    int select_Rect=0;
    double sel_x1;
    double sel_x2;
    double sel_y1;
    double sel_y2;

    Resources resources;
};

#endif // GeoPlot18O_H
