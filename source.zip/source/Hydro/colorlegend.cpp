/********************************************************************************/
/*    This file is part of PaleoDataViewer.                       					*/
/*                                                                      		*/
/*    PaleoDataViewer is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoDataViewer is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoDataViewer.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#include "colorlegend.h"
#include <QDebug>

ColorLegend::ColorLegend(QDialog *dialogWindow,int size_x, int size_y,int text,float minimum,float maximum)
    : diagW(dialogWindow)
{
    plot_Size_X=size_x;
    plot_Size_Y=size_y;
    this->setSceneRect(-plot_Size_X/2+1,-plot_Size_Y/2+1,plot_Size_X-2,plot_Size_Y-2);
    textsize=text;
    min=minimum;
    max=maximum;
    cp=new ColorPaint(this,plot_Size_X,plot_Size_Y,textsize,min,max);
    this->addItem(cp);
}

ColorLegend::~ColorLegend(){
    delete cp;
}

void ColorLegend::setSize(int size_x, int size_y,int text,float minimum,float maximum){
    plot_Size_X=size_x;
    plot_Size_Y=size_y;
    this->setSceneRect(-plot_Size_X/2+1,-plot_Size_Y/2+1,plot_Size_X-2,plot_Size_Y-2);
    textsize=text;
    min=minimum;
    max=maximum;
    cp->setSize(plot_Size_X,plot_Size_Y,textsize,min,max);
    update();
}




