/********************************************************************************/
/*    This file is part of PaleoView.                       					*/
/*                                                                      		*/
/*    PaleoView is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoView is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoView.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#include "geoplotdc.h"

GeoPlotDC::GeoPlotDC(QGraphicsScene *graphScene,QImage *image)
    : graph(graphScene),mapimage(image)
{

    s="Init";
    map_mode=0;

    mapsize_x=1;
    mapsize_y=1;

    zoom=1.0f;
    longitude=10.0f;
    latitude=53.0f;
    label_Flag=0;

}

void GeoPlotDC::setSize(int x,int y)
{
    mapsize_x=x;
    mapsize_y=y;

}

void GeoPlotDC::set_Map_Mode(int n)
{
    map_mode=n;
}

void GeoPlotDC::setView(float lo, float la, float z){
    longitude=lo;
    latitude=la;
    zoom=z;
}
void GeoPlotDC::setMessage(QString msg){
    s=msg;
}

float GeoPlotDC::getMapFactor_x(){
    return mapimage->width()/360.0f*zoom;
}

float GeoPlotDC::getMapFactor_y(){
    return mapimage->height()/180.0f*zoom;
}

float GeoPlotDC::getZoom(){
    return zoom;
}

float GeoPlotDC::getLatitude(){
    return latitude;
}

float GeoPlotDC::getLongitude(){
    return longitude;
}

void GeoPlotDC::setInventory(Inventory *i,HydroDatabase *h){
    inv=i;
    hydro=h;
}

void GeoPlotDC::invertLabel(){
    if (label_Flag) {
        label_Flag=0;
    } else {
        label_Flag=1;
    }
    //qDebug()<<QString::number(label_Flag);
}

void GeoPlotDC::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget){

    if (map_mode==0){
        if (longitude>180.0f) longitude=longitude-360.0f;
        if (longitude<-180.0f) longitude=longitude+360.0f;

        // calculate x and y in bitmap
        int x=(longitude+180.0f)*((float)(mapimage->width())/360.0f);
        int y=-(latitude-90.0f)*((float)(mapimage->height())/180.0f);

        // check/correct zoom level
        if (zoom<((float)(mapsize_y)/(float)(mapimage->height()))) zoom=((float)(mapsize_y)/(float)(mapimage->height()));

        // check/correct lattitude

        if ( y-(mapsize_y/zoom)/2.0f<0 ){
            y=(mapsize_y/zoom)/2.0f;
            latitude=90.0f-(180.0f/mapimage->height()*y);
        }
        if ( y+(mapsize_y/zoom)/2.0f>mapimage->height()){
            y=mapimage->height()-(mapsize_y/zoom)/2.0f;
            latitude=90.0f-(180.0f/mapimage->height()*y);
        }



        // set Font for labels
        QFont font=painter->font() ;
        font.setPointSize ( 8 );
        font.setWeight(QFont::Normal);
        painter->setFont(font);


        // estimate View in Lo and La
        float mapFactor_x=mapimage->width()/360.0f*zoom;
        float min_Longitude=longitude-(mapsize_x/2.0f/mapFactor_x);
        float max_Longitude=longitude+(mapsize_x/2.0f/mapFactor_x);
        float mapFactor_y=mapimage->height()/180.0f*zoom;
        float min_Latitude=latitude-(mapsize_y/2.0f/mapFactor_y);
        float max_Latitude=latitude+(mapsize_y/2.0f/mapFactor_y);
        //printf("%i",inv.get_Length());
        QPen pen;
        pen.setWidth(1);
        pen.setStyle(Qt::NoPen);
        pen.setColor(Qt::black);
        painter->setPen(pen);

        // draw GeoPlotDC

        int size_x=mapFactor_x+1;
        int size_y=mapFactor_y+1;

        for (int lat_i=0;lat_i<hydro->get_d18o_Lat_Size();lat_i++){
            for (int lon_i=0;lon_i<hydro->get_d18o_Lon_Size();lon_i++){
                float lat=hydro->get_t_Lat(lat_i);
                float lon=hydro->get_t_Lon(lon_i);


                // Check if Core inside View of centre map
                if(lat>min_Latitude-1 && lat<max_Latitude+1){

                    if (lon>min_Longitude-1 && lon<max_Longitude+1){
                        // draw a Marker at Location
                        int sx=(lon-longitude)*mapFactor_x;
                        int sy=(latitude-lat)*mapFactor_y;
                        float value=hydro->getdc(lon,lat,depth);
                        if (value>-100&&value<100){
                            eval_Color(value);
                            painter->setBrush(QColor(r_col,g_col,b_col,255));
                            painter->drawRect(QRect(sx-size_x/2,sy-size_y/2,size_x,size_y));
                        }
                    }
                    // Check if Core inside View of right map
                    if (lon-360>min_Longitude-1 && lon-360<max_Longitude+1){
                        // draw a Marker at Location
                        int sx=(lon-longitude-360)*mapFactor_x;
                        int sy=(latitude-lat)*mapFactor_y;
                        float value=hydro->getdc(lon,lat,depth);
                        if (value>-100&&value<100){
                            eval_Color(value);
                            painter->setBrush(QColor(r_col,g_col,b_col,255));
                            painter->drawRect(QRect(sx-size_x/2,sy-size_y/2,size_x,size_y));
                        }
                    }
                    // Check if Core inside View of left map
                    if (lon+360>min_Longitude-1 && lon+360<max_Longitude+1){
                        // draw a Marker at Location
                        int sx=(lon+360-longitude)*mapFactor_x;
                        int sy=(latitude-lat)*mapFactor_y;
                        float value=hydro->getdc(lon,lat,depth);
                        if (value>-100&&value<100){
                            eval_Color(value);
                            painter->setBrush(QColor(r_col,g_col,b_col,255));
                            painter->drawRect(QRect(sx-(size_x/2),sy-(size_y/2),size_x,size_y));
                        }
                    }
                }
            }
        }


    }


    if (select_Rect==1){
        QPen pen;
        pen.setWidth(1);
        pen.setColor(Qt::red);
        painter->setBrush(Qt::NoBrush);
        painter->setPen(pen);
        painter->drawRect(QRect(sel_x1,sel_y1,(sel_x2-sel_x1),(sel_y2-sel_y1)));
    }


}

QRectF GeoPlotDC::boundingRect() const
{
}

QPainterPath GeoPlotDC::shape() const
{
}

void GeoPlotDC::setRect(int x1,int x2, int y1, int y2, int mode){
    select_Rect=mode;
    sel_x1=x1;
    sel_x2=x2;
    sel_y1=y1;
    sel_y2=y2;
}

void GeoPlotDC::set_selected_Core(QString c,QString p){
    core=c;
    proxy=p;
}

void GeoPlotDC::eval_Color(float v){
    v=(v-hydro->get_dc_min())/(hydro->get_dc_max()-hydro->get_dc_min());
    v = v * 6; // Contour color sheme
    if (v < 1) {
        r_col = (int) ((v * 255));
        g_col = (int) (0);
        b_col = (int) ((v * 255));
    }
    if (v >= 1 && v < 2) {
        r_col = (int) (255 - ((v - 1) * 255));
        g_col = (int) (0);
        b_col = (int) (255);
    }
    if (v >= 2 && v < 3) {
        r_col = (int) (0);
        g_col = (int) ((v - 2) * 255);
        b_col = (int) (255 - ((v - 2) * 255));
    }
    if (v >= 3 && v < 4) {
        r_col = (int) ((v - 3) * 255);
        g_col = (int) (255);
        b_col = (int) (0);
    }
    if (v >= 4 && v < 5) {
        r_col = (int) (255);
        g_col = (int) (255 - ((v - 4) * 255));
        b_col = (int) (0);
    }
    if (v >= 5) {
        r_col = (int) (255);
        g_col = (int) ((v - 5) * 255);
        b_col = (int) ((v - 5) * 255);
    }
}

void GeoPlotDC::set_Depth(float i){
    depth=i;
    update();
}


