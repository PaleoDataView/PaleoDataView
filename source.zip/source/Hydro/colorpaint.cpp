/********************************************************************************/
/*    This file is part of PaleoDataViewer.                       					*/
/*                                                                      		*/
/*    PaleoDataViewer is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoDataViewer is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoDataViewer.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#include "colorpaint.h"
#include <QDebug>

ColorPaint::ColorPaint(QGraphicsScene *graphScene,int size_x,int size_y, int text, float minimum,float maximum)
    : graph(graphScene)
{
    plot_Size_X=size_x;
    plot_Size_Y=size_y;
    textsize=text;
    min=minimum;
    max=maximum;
}
void ColorPaint::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget){
    if (max-min>0){
    // fill with colors
    for (int i=0;i<plot_Size_Y;i++){
        float v=1-(float)(i)/(float)(plot_Size_Y);

        unsigned int r_col=0,g_col=0,b_col=0;
        v = v * 6; // Contour color sheme
        if (v < 1) {
            r_col = (int) ((v * 255));
            g_col = (int) (0);
            b_col = (int) ((v * 255));
        }
        if (v >= 1 && v < 2) {
            r_col = (int) (255 - ((v - 1) * 255));
            g_col = (int) (0);
            b_col = (int) (255);
        }
        if (v >= 2 && v < 3) {
            r_col = (int) (0);
            g_col = (int) ((v - 2) * 255);
            b_col = (int) (255 - ((v - 2) * 255));
        }
        if (v >= 3 && v < 4) {
            r_col = (int) ((v - 3) * 255);
            g_col = (int) (255);
            b_col = (int) (0);
        }
        if (v >= 4 && v < 5) {
            r_col = (int) (255);
            g_col = (int) (255 - ((v - 4) * 255));
            b_col = (int) (0);
        }
        if (v >= 5) {
            r_col = (int) (255);
            g_col = (int) ((v - 5) * 255);
            b_col = (int) ((v - 5) * 255);
        }
        if (r_col>255) r_col=255;
        if (g_col>255) g_col=255;
        if (b_col>255) b_col=255;

        painter->setPen(QColor(r_col,g_col,b_col,255));
        painter->drawLine(-plot_Size_X/2,i-plot_Size_Y/2,plot_Size_X/2,i-plot_Size_Y/2);


    }
    painter->setPen(QColor(0,0,0,255));
    float inc=1;

    inc=((max-min)/(plot_Size_Y/(textsize*4)));
    inc=(int)(inc*10)/10.0;
    if (inc<0.1) inc=0.1;
    min=((int)(min*10))/10.0;
    max=((int)(max*10))/10.0;

    for (float v=min+inc;v<=max-inc;v=v+inc){

        int i=plot_Size_Y/2-plot_Size_Y*((v-min)/(max-min));
        painter->drawLine(-plot_Size_X/2,i,-plot_Size_X/2+2,i);
        painter->drawLine(plot_Size_X/2,i,plot_Size_X/2-2,i);
        float w=v;//(int)((v*10+0.5))/10.0;
        if (w<0.01&&w>-0.01) w=0;
        QFont font_text("times", textsize,QFont::Bold);
        QFontMetrics fm_text(font_text);
        int str_len=fm_text.width(QString::number(w));
        painter->setFont(font_text);
        painter->drawText(-str_len/2,i+textsize/2,QString::number(w));
    }



}




}

void ColorPaint::setSize(int x,int y,int text,float minimum, float maximum){
    plot_Size_X=x;
    plot_Size_Y=y;
    textsize=text;
    min=minimum;
    max=maximum;
}


QRectF ColorPaint::boundingRect() const
{
}

QPainterPath ColorPaint::shape() const
{
}
