/********************************************************************************/
/*    This file is part of PaleoView.                       					*/
/*                                                                      		*/
/*    PaleoView is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoView is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoView.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#include "plotdatats.h"

PlotDataTS::PlotDataTS(QGraphicsScene *graphScene)
    : graph(graphScene)
{
    plot_Size_X=100;
    plot_Size_Y=100;
    textsize=10;
    titelsize=0;
    margin=5;
    x_min=-1;
    x_max=1;
    y_min=-1;
    y_max=1;
    x_axis=0;
    y_axis=1;
    selected=-1;
    select_Rect=0;
    sel_x1=0;
    sel_x2=0;
    sel_y1=0;
    sel_y2=0;
    factor_x=1;
    factor_y=-1;
}
void PlotDataTS::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget){
if (inv.get_flag_Data_OK()){

    // draw data
    int oldx = 0, oldy = 0;
    double linex = 0, liney = 0, oldlinex = 0, oldliney = 0;

    for (int i=0;i<hydro->get_t_Depth_Size();i++){
        // get x and y cooridinates
       float t=hydro->getPTemperature(inv.get_Longitude(inv.get_currentCore()),inv.get_Latitude(inv.get_currentCore()),hydro->get_t_Depth(i));
       float s=hydro->getSalinity(inv.get_Longitude(inv.get_currentCore()),inv.get_Latitude(inv.get_currentCore()),hydro->get_t_Depth(i));
       if (t<1000&&t>-1000){
       int x = (int) (-plot_Size_X/2+4*textsize+margin + (double) (plot_Size_X-2*margin-4*textsize) * (double) (((s*factor_x) - x_min) / (x_max - x_min)));
       int y = (int) (-plot_Size_Y/2+titelsize+margin + (double) (plot_Size_Y-2*margin-4*textsize-titelsize) * (double) ((y_max - (t*factor_y)) / (y_max - y_min)));

       // draw line
           if (i > 0) {
                   linex = x;
                   liney = y;
                   oldlinex = oldx;
                   oldliney = oldy;
                   double slope = 0;
                   if (linex - oldlinex != 0 && liney - oldliney != 0) {
                       slope = (liney - oldliney) / (linex - oldlinex);
                   } else {
                       if (linex - oldlinex == 0) {
                           slope = 999999999;
                       }
                       if (liney - oldliney == 0) {
                           slope = 0;
                       }
                   }
                   double offset = (liney - (linex * slope));

                   int c = 0;
                   while ((((linex < -plot_Size_X/2+4*textsize+margin)
                           || (liney < -plot_Size_Y/2+titelsize+margin)
                           || (linex > plot_Size_X/2-margin)
                           || (liney > plot_Size_Y/2-margin-4*textsize))
                           || ((oldlinex < -plot_Size_X/2+4*textsize+margin)
                           || (oldliney < -plot_Size_Y/2+titelsize+margin)
                           || (oldlinex > plot_Size_X/2-margin)
                           || (oldliney > plot_Size_Y/2-margin-4*textsize)))
                           && c < 3) {
                       if (linex < -plot_Size_X/2+4*textsize+margin) {
                           linex = -plot_Size_X/2+4*textsize+margin + 1;
                           liney = ((linex * slope) + offset);
                       }
                       if (linex >  plot_Size_X/2-margin) {
                           linex = plot_Size_X/2-margin - 1;
                           liney = ((linex * slope) + offset);
                       }
                       if (liney < -plot_Size_Y/2+titelsize+margin) {
                           liney = -plot_Size_Y/2+titelsize+margin + 1;
                           linex = ((liney - offset) / slope);
                       }
                       if (liney > plot_Size_Y/2-margin-4*textsize) {
                           liney = plot_Size_Y/2-margin-4*textsize - 1;
                           linex = ((liney - offset) / slope);
                       }
                       if (oldlinex < -plot_Size_X/2+4*textsize+margin) {
                           oldlinex = -plot_Size_X/2+4*textsize+margin + 1;
                           oldliney = ((oldlinex * slope) + offset);
                       }
                       if (oldlinex > plot_Size_X/2-margin) {
                           oldlinex = plot_Size_X/2-margin - 1;
                           oldliney = ((oldlinex * slope) + offset);
                       }
                       if (oldliney < -plot_Size_Y/2+titelsize+margin) {
                           oldliney = -plot_Size_Y/2+titelsize+margin + 1;
                           oldlinex = ((oldliney - offset) / slope);
                       }
                       if (oldliney > plot_Size_Y/2-margin-4*textsize) {
                           oldliney = plot_Size_Y/2-margin-4*textsize - 1;
                           oldlinex = ((oldliney - offset) / slope);
                       }
                       c++;
                   }
                   if (linex != oldlinex || liney != oldliney) {
                       if ((linex >= -plot_Size_X/2+4*textsize+margin)
                               && (liney >= -plot_Size_Y/2+titelsize+margin)
                               && (linex <= plot_Size_X/2-margin)
                               && (liney <= plot_Size_Y/2-4*textsize-margin)
                               && (oldlinex >= -plot_Size_X/2+4*textsize+margin)
                               && (oldliney >= -plot_Size_Y/2+titelsize+margin)
                               && (oldlinex <= plot_Size_X/2-margin)
                               && (oldliney <= plot_Size_Y/2-4*textsize-margin)) {

                           QPen pen;
                           pen.setWidth(1);
                           pen.setColor(Qt::black);
                           pen.setStyle(Qt::DashDotLine);
                           painter->setPen(pen);
                           painter->setRenderHint(QPainter::Antialiasing,true);
                           painter->drawLine((int) linex, (int) liney, (int) oldlinex, (int) oldliney);
                           painter->setRenderHint(QPainter::Antialiasing,false);
                       }
                   }
           }
       oldx = x;
       oldy = y;
    }

    for (int i=0;i<hydro->get_t_Depth_Size();i++){
        // get x and y cooridinates
        float t=hydro->getPTemperature(inv.get_Longitude(inv.get_currentCore()),inv.get_Latitude(inv.get_currentCore()),hydro->get_t_Depth(i));
        float s=hydro->getSalinity(inv.get_Longitude(inv.get_currentCore()),inv.get_Latitude(inv.get_currentCore()),hydro->get_t_Depth(i));
        int x = (int) (-plot_Size_X/2+4*textsize+margin + (double) (plot_Size_X-2*margin-4*textsize) * (double) (((s*factor_x) - x_min) / (x_max - x_min)));
        int y = (int) (-plot_Size_Y/2+titelsize+margin + (double) (plot_Size_Y-2*margin-4*textsize-titelsize) * (double) ((y_max - (t*factor_y)) / (y_max - y_min)));
       if (x>=-plot_Size_X/2+4*textsize+margin && x<=plot_Size_X/2-margin && y<=plot_Size_Y/2-4*textsize-margin && y>=-plot_Size_Y/2+titelsize+margin){
       // draw Datapoints
       painter->setBrush(QColor(Qt::blue));
       QPen pen;
       pen.setWidth(1);
       pen.setColor(Qt::black);
       if (selected==i) painter->setBrush(QColor(Qt::red));
       painter->setPen(pen);
       painter->drawRect(QRect(x-3,y-3,6,6));
       }
    }

    // plot core position
    {
        float t=hydro->getPTemperature(inv.get_Longitude(inv.get_currentCore()),inv.get_Latitude(inv.get_currentCore()),inv.get_Water_Depth(inv.get_currentCore()));
        float s=hydro->getSalinity(inv.get_Longitude(inv.get_currentCore()),inv.get_Latitude(inv.get_currentCore()),inv.get_Water_Depth(inv.get_currentCore()));
        int x = (int) (-plot_Size_X/2+4*textsize+margin + (double) (plot_Size_X-2*margin-4*textsize) * (double) (((s*factor_x) - x_min) / (x_max - x_min)));
        int y = (int) (-plot_Size_Y/2+titelsize+margin + (double) (plot_Size_Y-2*margin-4*textsize-titelsize) * (double) ((y_max - (t*factor_y)) / (y_max - y_min)));
        painter->setBrush(QColor(Qt::red));
        QPen pen;
        pen.setWidth(2);
        pen.setColor(Qt::red);
        if (selected==i) painter->setBrush(QColor(Qt::black));
        painter->setPen(pen);
        if (x>=-plot_Size_X/2+4*textsize+margin && x<=plot_Size_X/2-margin && y<=plot_Size_Y/2-4*textsize-margin && y>=-plot_Size_Y/2+titelsize+margin){
            painter->drawRect(QRect(x-3,y-3,6,6));
        }
        if (x>=-plot_Size_X/2+4*textsize+margin && x<=plot_Size_X/2-margin) painter->drawLine(x,-plot_Size_Y/2+titelsize+margin,x,plot_Size_Y/2-4*textsize-margin);
        if (y<=plot_Size_Y/2-4*textsize-margin && y>=-plot_Size_Y/2+titelsize+margin) painter->drawLine(-plot_Size_X/2+4*textsize+margin,y,plot_Size_X/2-margin,y);
    }

    //Plot Isopycnals
    // After : Millero et al. (1976) and Poisson et al. (1980)
    // draw data
    // estimate minimum and maximum p and resolution
    float p_min=(int)(hydro->get_press_min(y_max,x_min));
    float p_max=hydro->get_press_max(y_min,x_max);

    double dp = (p_max - p_min) / 3;
    if (dp == 0) {
         dp = p_max;
    }

    if (fabs(dp) > 1) {
        dp = (int) (dp / pow(10, (int) ((1 / log(10)) * log(dp)))) * pow(10, (int) ((1 / log(10)) * log(dp)));
    } else {
        int i = 0;
        while ((int) dp == 0) {
            dp = dp * 10;
            i = i + 1;
        }
        dp = (int) dp;
        dp = dp / (pow(10, i));
    }
    if (dp == 0) {
        dp = (p_max - p_min) / 3;
    }

    //qDebug() << QString::number(p_min)+" : "+QString::number(p_max)+" : "+QString::number(dp);

    for (float p=p_min;p<p_max;p=p+dp){

        int oldx=0;
        int oldy=0;
        float linex = 0;
        float liney = 0;
        float oldlinex = 0;
        float oldliney = 0;
        float t_inc=(y_max-y_min)/10.0;
        for (float t=y_min;t<y_max+t_inc;t=t+t_inc){

            float s=hydro->getp(inv.get_Longitude(inv.get_currentCore()),inv.get_Latitude(inv.get_currentCore()),inv.get_Water_Depth(inv.get_currentCore()),p,t);
            if (s>hydro->get_s_min()&&s<hydro->get_s_max()){
                int x = (int) (-plot_Size_X/2+4*textsize+margin + (double) (plot_Size_X-2*margin-4*textsize) * (double) (((s*factor_x) - x_min) / (x_max - x_min)));
                int y = (int) (-plot_Size_Y/2+titelsize+margin + (double) (plot_Size_Y-2*margin-4*textsize-titelsize) * (double) ((y_max - (t*factor_y)) / (y_max - y_min)));



                // draw line
                    if (t>hydro->get_t_min()) {
                            linex = x;
                            liney = y;
                            oldlinex = oldx;
                            oldliney = oldy;
                            double slope = 0;
                            if (linex - oldlinex != 0 && liney - oldliney != 0) {
                                slope = (liney - oldliney) / (linex - oldlinex);
                            } else {
                                if (linex - oldlinex == 0) {
                                    slope = 999999999;
                                }
                                if (liney - oldliney == 0) {
                                    slope = 0;
                                }
                            }
                            double offset = (liney - (linex * slope));

                            int c = 0;
                            while ((((linex < -plot_Size_X/2+4*textsize+margin)
                                    || (liney < -plot_Size_Y/2+titelsize+margin)
                                    || (linex > plot_Size_X/2-margin)
                                    || (liney > plot_Size_Y/2-margin-4*textsize))
                                    || ((oldlinex < -plot_Size_X/2+4*textsize+margin)
                                    || (oldliney < -plot_Size_Y/2+titelsize+margin)
                                    || (oldlinex > plot_Size_X/2-margin)
                                    || (oldliney > plot_Size_Y/2-margin-4*textsize)))
                                    && c < 3) {
                                if (linex < -plot_Size_X/2+4*textsize+margin) {
                                    linex = -plot_Size_X/2+4*textsize+margin + 1;
                                    liney = ((linex * slope) + offset);
                                }
                                if (linex >  plot_Size_X/2-margin) {
                                    linex = plot_Size_X/2-margin - 1;
                                    liney = ((linex * slope) + offset);
                                }
                                if (liney < -plot_Size_Y/2+titelsize+margin) {
                                    liney = -plot_Size_Y/2+titelsize+margin + 1;
                                    linex = ((liney - offset) / slope);
                                }
                                if (liney > plot_Size_Y/2-margin-4*textsize) {
                                    liney = plot_Size_Y/2-margin-4*textsize - 1;
                                    linex = ((liney - offset) / slope);
                                }
                                if (oldlinex < -plot_Size_X/2+4*textsize+margin) {
                                    oldlinex = -plot_Size_X/2+4*textsize+margin + 1;
                                    oldliney = ((oldlinex * slope) + offset);
                                }
                                if (oldlinex > plot_Size_X/2-margin) {
                                    oldlinex = plot_Size_X/2-margin - 1;
                                    oldliney = ((oldlinex * slope) + offset);
                                }
                                if (oldliney < -plot_Size_Y/2+titelsize+margin) {
                                    oldliney = -plot_Size_Y/2+titelsize+margin + 1;
                                    oldlinex = ((oldliney - offset) / slope);
                                }
                                if (oldliney > plot_Size_Y/2-margin-4*textsize) {
                                    oldliney = plot_Size_Y/2-margin-4*textsize - 1;
                                    oldlinex = ((oldliney - offset) / slope);
                                }
                                c++;
                            }
                            if (linex != oldlinex || liney != oldliney ) {
                                if ((linex >= -plot_Size_X/2+4*textsize+margin)
                                        && (liney >= -plot_Size_Y/2+titelsize+margin)
                                        && (linex <= plot_Size_X/2-margin)
                                        && (liney <= plot_Size_Y/2-4*textsize-margin)
                                        && (oldlinex >= -plot_Size_X/2+4*textsize+margin)
                                        && (oldliney >= -plot_Size_Y/2+titelsize+margin)
                                        && (oldlinex <= plot_Size_X/2-margin)
                                        && (oldliney <= plot_Size_Y/2-4*textsize-margin)
                                        && oldx!=0 && oldy!=0) {

                                    QPen pen;
                                    pen.setWidth(1);
                                    pen.setColor(Qt::darkGray);
                                    pen.setStyle(Qt::DashDotLine);
                                    painter->setPen(pen);
                                    painter->setRenderHint(QPainter::Antialiasing,true);
                                    painter->drawLine((int) linex, (int) liney, (int) oldlinex, (int) oldliney);
                                    painter->setRenderHint(QPainter::Antialiasing,false);
                                    // paint contour value
                                    QFont font_titel_xy("times", textsize,QFont::Normal);
                                    QFontMetrics fm_titel_xy(font_titel_xy);
                                    int str_len=fm_titel_xy.width(" "+QString::number(p)+" ");
                                    if (str_len<sqrt((liney-oldliney)*(liney-oldliney)+(linex-oldlinex)*(linex-oldlinex))){
                                        painter->setFont(font_titel_xy);
                                        pen.setColor(Qt::black);
                                        painter->setPen(pen);
                                        float ang=atan((liney-oldliney)/(linex-oldlinex));
                                        int xx=linex*cos(ang)+liney*sin(ang);
                                        int yy=liney*cos(ang)-linex*sin(ang);
                                        painter->rotate((ang)/(2*3.141)*360);

                                        painter->drawText(xx-str_len,yy,QString::number(p));
                                        painter->rotate(-(ang)/(2*3.141)*360);
                                    }
                                }
                            }
                    }
                oldx = x;
                oldy = y;
                }

            }
        }






    if (select_Rect==1){
        QPen pen;
        pen.setWidth(1);
        pen.setColor(Qt::red);
        painter->setBrush(Qt::NoBrush);
        painter->setPen(pen);
        painter->drawRect(QRect(sel_x1,sel_y1,(sel_x2-sel_x1),(sel_y2-sel_y1)));
    }}


}

    // Draw message
    if (inv.get_Length()==0 || inv.get_flag_Data_OK()==0) painter->drawText(0,0,"Please Select a Core");



}

void PlotDataTS::setSize(int x,int y){
    plot_Size_X=x;
    plot_Size_Y=y;

}

void PlotDataTS::setInventory(Inventory i){
    inv=i;
}
void PlotDataTS::setHydro(HydroDatabase *h){
    hydro=h;
}

void PlotDataTS::setPlot(int fx,int fy){

    factor_x=fx;
    factor_y=fy;
}

QRectF PlotDataTS::boundingRect() const
{
}

QPainterPath PlotDataTS::shape() const
{
}

double PlotDataTS::get_x_max(){
    return x_max;
}

double PlotDataTS::get_x_min(){
    return x_min;
}
double PlotDataTS::get_y_min(){
    return y_min;
}

double PlotDataTS::get_y_max(){
    return y_max;
}

void PlotDataTS::setSelected(int n){
    selected=n;
}

void PlotDataTS::setView(double x1,double x2,double y1,double y2){
    x_min=x1;
    x_max=x2;
    y_min=y1;
    y_max=y2;
}

void PlotDataTS::setRect(int x1,int x2, int y1, int y2, int mode){
    select_Rect=mode;
    sel_x1=x1;
    sel_x2=x2;
    sel_y1=y1;
    sel_y2=y2;
}

 int PlotDataTS::getSelected(){
     if (selected>hydro->get_t_Depth_Size()) selected=-1;
     return selected;
 }
