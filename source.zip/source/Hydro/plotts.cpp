/********************************************************************************/
/*    This file is part of PaleoView.                       					*/
/*                                                                      		*/
/*    PaleoView is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoView is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoView.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#include "plotts.h"
#include <QDebug>

PlotTS::PlotTS(QDialog *dialogWindow)
    : dialogW(dialogWindow)
{
    titel="Plot";
    titel_x="X(Y)";
    titel_y="Y(X)";
    plot_Size_X=100;
    plot_Size_Y=100;
    this->setSceneRect(-plot_Size_X/2+1,-plot_Size_Y/2+1,plot_Size_X-2,plot_Size_Y-2);
    textsize=10;

    titelsize=0;
    margin=5;
    x_min=-1;
    x_max=1;
    y_min=-1;
    y_max=1;
    ticks_x=10;
    ticks_y=5;
    grid_flag=1;
    x_axis=0;
    y_axis=1;
    moveFlag=0;
    // Generate Axes
    axis=new AxisTS(this);
    this->addItem(axis);
    pdata=new PlotDataTS(this);
    this->addItem(pdata);
    key_flag=0;
    frame_x1=0;
    frame_x2=0;
    frame_y1=0;
    frame_y2=0;
    factor_x=1;
    factor_y=-1;

}

PlotTS::~PlotTS(){
    delete axis;
    delete pdata;
}

void PlotTS::setInventory(Inventory i){
    inv=i;
    axis->setInventory(inv);
    pdata->setInventory(inv);
    update();
}
void PlotTS::setHydro(HydroDatabase *h){
    hydro=h;
    axis->setHydro(hydro);
    pdata->setHydro(hydro);
    update();
}

void PlotTS::setSize(int x,int y){
    plot_Size_X=x;
    plot_Size_Y=y;
    this->setSceneRect(-plot_Size_X/2+1,-plot_Size_Y/2+1,plot_Size_X-2,plot_Size_Y-2);
    axis->setSize(x,y);
    pdata->setSize(x,y);
}

void PlotTS::setPlot(QString t,QString tx,QString ty,int fx,int fy){
    axis->setPlot(t,tx,ty,fx,fy);
    pdata->setPlot(fx,fy);
    titel=t;
    titel_x=tx;
    titel_y=ty;
    factor_x=fx;
    factor_y=fy;
}

void PlotTS::autoSize(){
    x_min=9e999;
    x_max=-9e999;
    y_min=9e999;
    y_max=-9e999;
    for (int i=0;i<hydro->get_t_Depth_Size();i++){
        float t=hydro->getPTemperature(inv.get_Longitude(inv.get_currentCore()),inv.get_Latitude(inv.get_currentCore()),hydro->get_t_Depth(i));
        float s=hydro->getSalinity(inv.get_Longitude(inv.get_currentCore()),inv.get_Latitude(inv.get_currentCore()),hydro->get_t_Depth(i));
        if (t<1000 && t>-1000){
            if (x_min>s*factor_x) x_min=s*factor_x;
            if (x_max<s*factor_x) x_max=s*factor_x;
            if (y_min>t*factor_y) y_min=t*factor_y;
            if (y_max<t*factor_y) y_max=t*factor_y;
    }}
    x_min-=(x_max-x_min)*0.01;
    x_max+=(x_max-x_min)*0.01;
    y_min-=(y_max-y_min)*0.01;
    y_max+=(y_max-y_min)*0.01;
    axis->setView(x_min,x_max,y_min,y_max);
    pdata->setView(x_min,x_max,y_min,y_max);
    update();
}

void PlotTS::mousePressEvent(QGraphicsSceneMouseEvent* mouseEvent1){
    if (key_flag==1){
        frame_x1=mouseEvent1->scenePos().x();
        frame_y1=mouseEvent1->scenePos().y();
    }

}

void PlotTS::mouseReleaseEvent(QGraphicsSceneMouseEvent* mouseEvent2){
    if(moveFlag==0 && key_flag==0){
    x_min=pdata->get_x_min();
    x_max=pdata->get_x_max();
    y_min=pdata->get_y_min();
    y_max=pdata->get_y_max();

    double x=(double)mouseEvent2->scenePos().x();
    double y=(double)mouseEvent2->scenePos().y();
    x=x_min+(x+plot_Size_X/2-margin-4*textsize)*(float)((x_max-x_min)/(float)(plot_Size_X-2*margin-4*textsize));
    y=y_max-(y+plot_Size_Y/2-margin-titelsize)*(float)((y_max-y_min)/(float)(plot_Size_Y-2*margin-4*textsize-titelsize));

    // find closest dot
    double rx=999999e999;
    int count=-1;
    for (int i=0;i<hydro->get_t_Depth_Size();i++){
        float y1=hydro->getPTemperature(inv.get_Longitude(inv.get_currentCore()),inv.get_Latitude(inv.get_currentCore()),hydro->get_t_Depth(i));
        float x1=hydro->getSalinity(inv.get_Longitude(inv.get_currentCore()),inv.get_Latitude(inv.get_currentCore()),hydro->get_t_Depth(i));
        double r=(x-x1*factor_x)*(x-x1*factor_x)+(y-y1*factor_y)*(y-y1*factor_y);
        if (r<rx){
           count=i;
           rx=r;
        }
    }
    if (rx/4>(float)((x_max-x_min)/(float)(plot_Size_X-2*margin-4*textsize))*(float)((x_max-x_min)/(float)(plot_Size_X-2*margin-4*textsize))+
            (float)((y_max-y_min)/(float)(plot_Size_Y-2*margin-4*textsize-titelsize))*(float)((y_max-y_min)/(float)(plot_Size_Y-2*margin-4*textsize-titelsize))) count=-1;
    int i=pdata->getSelected();
    if (i>=-1 && count==-1) count=i;
    pdata->setSelected(count);


    // Give dot details
    if (count>-1){
    QString str=titel_y+" : "+QString::number(hydro->getPTemperature(inv.get_Longitude(inv.get_currentCore()),inv.get_Latitude(inv.get_currentCore()),hydro->get_t_Depth(count)))+"\n"+titel_x+" : "+QString::number(hydro->getSalinity(inv.get_Longitude(inv.get_currentCore()),inv.get_Latitude(inv.get_currentCore()),hydro->get_t_Depth(count)));
    QPoint pos;
    pos.setX(mouseEvent2->screenPos().x());
    pos.setY(mouseEvent2->screenPos().y());
    QToolTip::showText(pos,str,0);
    }
    update();

    }
    moveFlag=0;

    if (key_flag==1){
        frame_x2=mouseEvent2->scenePos().x();
        frame_y2=mouseEvent2->scenePos().y();
        // zoom
        if (frame_x1>frame_x2){
            int temp=frame_x1;
            frame_x1=frame_x2;
            frame_x2=temp;
        }
        if (frame_y1>frame_y2){
            int temp=frame_y1;
            frame_y1=frame_y2;
            frame_y2=temp;
        }
        double new_x_min=0,new_y_min=0,new_x_max=0,new_y_max=0;

        x_min=pdata->get_x_min();
        x_max=pdata->get_x_max();
        y_min=pdata->get_y_min();
        y_max=pdata->get_y_max();
            double fx=(plot_Size_X-2*margin-4*textsize)/(x_max-x_min);
            new_x_min=x_min+(1.0/fx)*(frame_x1-(-plot_Size_X/2+margin+4*textsize));
            new_x_max=x_min+(1.0/fx)*(frame_x2-(-plot_Size_X/2+margin+4*textsize));
            double fy=(plot_Size_Y-2*margin-4*textsize-titelsize)/(y_max-y_min);
            new_y_min=y_max-(1.0/fy)*(frame_y2-(-plot_Size_Y/2+margin+titelsize));
            new_y_max=y_max-(1.0/fy)*(frame_y1-(-plot_Size_Y/2+margin+titelsize));

        axis->setView(new_x_min,new_x_max,new_y_min,new_y_max);
        pdata->setView(new_x_min,new_x_max,new_y_min,new_y_max);
        x_min=pdata->get_x_min();
        x_max=pdata->get_x_max();
        y_min=pdata->get_y_min();
        y_max=pdata->get_y_max();

        key_flag=0;
    }

    pdata->setRect(frame_x1,frame_x2,frame_y1,frame_y2,0);
    update();
}

void PlotTS::mouseMoveEvent(QGraphicsSceneMouseEvent* mouseEvent3){
    if (mouseEvent3->buttons()==Qt::LeftButton && key_flag==0){

        moveFlag=1;

        x_min=pdata->get_x_min();
        x_max=pdata->get_x_max();
        y_min=pdata->get_y_min();
        y_max=pdata->get_y_max();

        double new_x_min=0,new_y_min=0,new_x_max=0,new_y_max=0;


            double fx=(plot_Size_X-2*margin-4*textsize)/(x_max-x_min);
            new_x_min=x_min+(1.0/fx)*(mouseEvent3->lastScreenPos().x()-mouseEvent3->screenPos().x());
            new_x_max=x_max+(1.0/fx)*(mouseEvent3->lastScreenPos().x()-mouseEvent3->screenPos().x());
            double fy=(plot_Size_Y-2*margin-4*textsize-titelsize)/(y_max-y_min);
            new_y_min=y_min-(1.0/fy)*(mouseEvent3->lastScreenPos().y()-mouseEvent3->screenPos().y());
            new_y_max=y_max-(1.0/fy)*(mouseEvent3->lastScreenPos().y()-mouseEvent3->screenPos().y());

        //qDebug() << QString::number(new_x_min)+":"+QString::number(new_x_max);
        //qDebug() << QString::number(new_y_min)+":"+QString::number(new_y_max);
        axis->setView(new_x_min,new_x_max,new_y_min,new_y_max);
        pdata->setView(new_x_min,new_x_max,new_y_min,new_y_max);
        x_min=pdata->get_x_min();
        x_max=pdata->get_x_max();
        y_min=pdata->get_y_min();
        y_max=pdata->get_y_max();
        update();
    }
    if (mouseEvent3->buttons()==Qt::LeftButton && key_flag==0){

        moveFlag=1;

        x_min=pdata->get_x_min();
        x_max=pdata->get_x_max();
        y_min=pdata->get_y_min();
        y_max=pdata->get_y_max();

        double new_x_min=0,new_y_min=0,new_x_max=0,new_y_max=0;


            double fx=(plot_Size_X-2*margin-4*textsize)/(x_max-x_min);
            new_x_min=x_min+(1.0/fx)*(mouseEvent3->lastScreenPos().x()-mouseEvent3->screenPos().x());
            new_x_max=x_max+(1.0/fx)*(mouseEvent3->lastScreenPos().x()-mouseEvent3->screenPos().x());
            double fy=(plot_Size_Y-2*margin-4*textsize-titelsize)/(y_max-y_min);
            new_y_min=y_min-(1.0/fy)*(mouseEvent3->lastScreenPos().y()-mouseEvent3->screenPos().y());
            new_y_max=y_max-(1.0/fy)*(mouseEvent3->lastScreenPos().y()-mouseEvent3->screenPos().y());

        //qDebug() << QString::number(new_x_min)+":"+QString::number(new_x_max);
        //qDebug() << QString::number(new_y_min)+":"+QString::number(new_y_max);
        axis->setView(new_x_min,new_x_max,new_y_min,new_y_max);
        pdata->setView(new_x_min,new_x_max,new_y_min,new_y_max);
        x_min=pdata->get_x_min();
        x_max=pdata->get_x_max();
        y_min=pdata->get_y_min();
        y_max=pdata->get_y_max();
        update();
    }
    if (mouseEvent3->buttons()==Qt::LeftButton && key_flag==1){
        // draw Frame
        pdata->setRect(frame_x1,mouseEvent3->scenePos().x(),frame_y1,mouseEvent3->scenePos().y(),1);
        update();
    }

}

int PlotTS::getSelected(){
    return pdata->getSelected();
}

void PlotTS::wheelEvent(QGraphicsSceneWheelEvent *mouseEvent4){
    x_min=pdata->get_x_min();
    x_max=pdata->get_x_max();
    y_min=pdata->get_y_min();
    y_max=pdata->get_y_max();

    double new_x_min=0,new_y_min=0,new_x_max=0,new_y_max=0;

    if (mouseEvent4->delta()/120>0) {
        new_x_min=x_min+(x_max-x_min)*0.1;
        new_x_max=x_max-(x_max-x_min)*0.1;
        new_y_min=y_min+(y_max-y_min)*0.1;
        new_y_max=y_max-(y_max-y_min)*0.1;
    }
    if (mouseEvent4->delta()/120<0) {
        new_x_min=x_min-(x_max-x_min)*0.1;
        new_x_max=x_max+(x_max-x_min)*0.1;
        new_y_min=y_min-(y_max-y_min)*0.1;
        new_y_max=y_max+(y_max-y_min)*0.1;
    }
    axis->setView(new_x_min,new_x_max,new_y_min,new_y_max);
    pdata->setView(new_x_min,new_x_max,new_y_min,new_y_max);
    x_min=pdata->get_x_min();
    x_max=pdata->get_x_max();
    y_min=pdata->get_y_min();
    y_max=pdata->get_y_max();
    update();

}

void PlotTS::mouseDoubleClickEvent(QGraphicsSceneMouseEvent *mouseEvent5){

}

void PlotTS::keyPressEvent(QKeyEvent *event){
    //qDebug() << "Pressed :"+QString::number(event->key());
    if (event->key()==Qt::Key_Control){
        //qDebug() << "Control";
        key_flag=1;
    }
}
void PlotTS::keyReleaseEvent(QKeyEvent *event){
    //qDebug() << "Released :"+QString::number(event->key());
    if (event->key()==Qt::Key_Control){
        //qDebug() << "Control";
        key_flag=0;
    }
}




