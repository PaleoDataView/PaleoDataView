/********************************************************************************/
/*    This file is part of PaleoDataViewer.                       					*/
/*                                                                      		*/
/*    PaleoDataViewer is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoDataViewer is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoDataViewer.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#ifndef EXPORT_H
#define EXPORT_H

#include <QDialog>
#include <QStandardItemModel>
#include "General/inventory.h"
#include <QDebug>
#include <QMainWindow>
#include "AMS/amsdata.h"
#include <QFileDialog>
#include <QMessageBox>
#include "General/resources.h"
#include <QDesktopServices>
#include "QtXlsx/src/xlsx/xlsxdocument.h"
#include <QApplication>
using namespace QXlsx;

namespace Ui {
class Export;
}

class Export : public QDialog
{
    Q_OBJECT

public:
    explicit Export(QMainWindow *mainWindow,Inventory *inventory);
    ~Export();

    void setupTable();
    void setupASCII();
    void save(QString file);
    void savexls(QString file);
private slots:
    void metaTableSelected(QModelIndex mi);
    void bacon_metaTableSelected(QModelIndex mi);
    void delimiterChanged();
    void browse();

protected:
    bool eventFilter(QObject *obj, QEvent *event);

private:
    Ui::Export *ui;
    QMainWindow *mainW;
    Resources resources;

    int meta_length;
    QStandardItemModel *metaData;
    int *meta_Flag;
    int bacon_meta_length;
    QStandardItemModel *bacon_metaData;
    int *bacon_meta_Flag;
    QStandardItemModel *modelIsotope;
    Inventory *inv;
    QStandardItemModel *ageData;
    QStandardItemModel *baconAge;
    QStandardItemModel *baconOut;
    AMSData *amsdata;
    QString txt;

    QString *str1;
    QString *str2;
    QString *bacon_str1;
    QString *bacon_str2;
    QString dlm;
    QByteArray sp,sp_2;
};

#endif // EXPORT_H
