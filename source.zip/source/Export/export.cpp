/********************************************************************************/
/*    This file is part of PaleoDataViewer.                       					*/
/*                                                                      		*/
/*    PaleoDataViewer is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoDataViewer is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoDataViewer.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#include "export.h"
#include "ui_export.h"

Export::Export(QMainWindow *mainWindow,Inventory *inventory) :
    mainW(mainWindow),inv(inventory),
    ui(new Ui::Export)
{
    ui->setupUi(this);
    sp=ui->splitter->saveState();
    sp_2=ui->splitter_2->saveState();
    //sp_3=ui->splitter_3->saveState();
    qApp->installEventFilter(this);
    amsdata=new AMSData(inv);
    amsdata->AMSRead();

    // List of Meta-Data
    meta_length=21;
    str1=new QString[meta_length];
    str2=new QString[meta_length];
    str1[0]="Core";
    str2[0]=inv->get_att_Core();
    str1[1]="Species";
    str2[1]=inv->get_att_Species();
    str1[2]="Longitude [dez]";
    str2[2]=QString::number(inv->get_att_Longitude());
    str1[3]="Latitude [dez]";
    str2[3]=QString::number(inv->get_att_Latitude());
    str1[4]="Water Depth [m]";
    str2[4]=QString::number(inv->get_att_Water_Depth());
    str1[5]="Device";
    str2[5]=inv->get_att_Device();
    str1[6]="Type";
    str2[6]=inv->get_att_Record_Type();
    str1[7]="Laboratory";
    str2[7]=inv->get_att_Laboratory();
    str1[8]="Electronic Paper";
    str2[8]=inv->get_att_EPaper();
    str1[9]="Comments";
    str2[9]=inv->get_att_Comment();
    str1[10]="Data Source";
    str2[10]=inv->get_att_Data_Source();
    str1[11]="Reference";
    str2[11]=inv->get_att_Reference();
    str1[12]="O-Use Flag";
    str2[12]=QString::number(inv->get_att_Oxygen_Use_Flag());
    str1[13]="C-Use Flag";
    str2[13]=QString::number(inv->get_att_Carbon_Use_Flag());
    str1[14]="O-Correction";
    str2[14]=QString::number(inv->get_att_O_Correction());
    str1[15]="C-Correction";
    str2[15]=QString::number(inv->get_att_C_Correction());
    str1[16]="O-Justification";
    str2[16]=inv->get_att_O_Justification();
    str1[17]="C-Justification";
    str2[17]=inv->get_att_C_Justification();
    str1[18]="Category";
    str2[18]=inv->get_att_Category();
    str1[19]="Importer";
    str2[19]=inv->get_att_Importer();
    str1[20]="Optional";
    str2[20]=inv->get_att_Optional();
    //... more Meta Data

    meta_Flag=new int[meta_length];
    for (int i=0;i<meta_length;i++) meta_Flag[i]=1;

    // Bacon Meta Data
    bacon_meta_length=24;
    bacon_str1=new QString[bacon_meta_length];
    bacon_str2=new QString[bacon_meta_length];
    bacon_str1[0]="K";
    bacon_str2[0]=QString::number(amsdata->get_bacon_K());
    bacon_str1[1]="d_min";
    bacon_str2[1]=QString::number(amsdata->get_bacon_d_min());
    bacon_str1[2]="d_max";
    bacon_str2[2]=QString::number(amsdata->get_bacon_d_max());
    bacon_str1[3]="d.by";
    bacon_str2[3]=QString::number(amsdata->get_bacon_d_by());
    bacon_str1[4]="acc.shape";
    bacon_str2[4]=QString::number(amsdata->get_bacon_acc_shape());
    bacon_str1[5]="acc.mean";
    bacon_str2[5]=QString::number(amsdata->get_bacon_acc_mean());
    bacon_str1[6]="mem.strength";
    bacon_str2[6]=QString::number(amsdata->get_bacon_mem_strength());
    bacon_str1[7]="mem.mean";
    bacon_str2[7]=QString::number(amsdata->get_bacon_mem_mean());
    bacon_str1[8]="cc";
    bacon_str2[8]=QString::number(amsdata->get_bacon_cc());
    bacon_str1[9]="cc1";
    bacon_str2[9]=amsdata->get_bacon_cc1();
    bacon_str1[10]="cc2";
    bacon_str2[10]=amsdata->get_bacon_cc2();
    bacon_str1[11]="cc3";
    bacon_str2[11]=amsdata->get_bacon_cc3();
    bacon_str1[12]="cc4";
    bacon_str2[12]=amsdata->get_bacon_cc4();
    bacon_str1[13]="postbomb";
    bacon_str2[13]=QString::number(amsdata->get_bacon_postbomb());
    bacon_str1[14]="t_a";
    bacon_str2[14]=QString::number(amsdata->get_bacon_t_a());
    bacon_str1[15]="t_b";
    bacon_str2[15]=QString::number(amsdata->get_bacon_t_b());
    bacon_str1[16]="normal";
    bacon_str2[16]=QString::number(amsdata->get_bacon_normal());
    bacon_str1[17]="suggest";
    bacon_str2[17]=QString::number(amsdata->get_bacon_suggest());
    bacon_str1[18]="th0";
    bacon_str2[18]=QString::number(amsdata->get_bacon_th0());
    bacon_str1[19]="th0p";
    bacon_str2[19]=QString::number(amsdata->get_bacon_th0p());
    bacon_str1[20]="burnin";
    bacon_str2[20]=QString::number(amsdata->get_bacon_burnin());
    bacon_str1[21]="ssize";
    bacon_str2[21]=QString::number(amsdata->get_bacon_ssize());
    bacon_str1[22]="yr_min";
    bacon_str2[22]=QString::number(amsdata->get_bacon_yr_min());
    bacon_str1[23]="yr_max";
    bacon_str2[23]=QString::number(amsdata->get_bacon_yr_max());
    //... more Meta Data

    bacon_meta_Flag=new int[bacon_meta_length];
    for (int i=0;i<bacon_meta_length;i++) bacon_meta_Flag[i]=1;
    metaData = new QStandardItemModel(0,0,this);
    modelIsotope = new QStandardItemModel(0,0,this);
    ageData = new QStandardItemModel(0,0,this);
    baconAge = new QStandardItemModel(0,0,this);
    baconOut = new QStandardItemModel(0,0,this);


    dlm="\t";
    setupTable();
    setupASCII();
    connect(ui->tableView_3,SIGNAL(clicked(QModelIndex)),this,SLOT(metaTableSelected(QModelIndex)));
    connect(ui->tableView_6,SIGNAL(clicked(QModelIndex)),this,SLOT(bacon_metaTableSelected(QModelIndex)));
    connect(ui->checkBox,SIGNAL(clicked(bool)),this,SLOT(delimiterChanged()));
    connect(ui->pushButton,SIGNAL(clicked(bool)),this,SLOT(browse()));
    connect(ui->spinBox,SIGNAL(valueChanged(int)),this,SLOT(delimiterChanged()));
    connect(ui->checkBox_2,SIGNAL(clicked(bool)),this,SLOT(delimiterChanged()));
    connect(ui->checkBox_3,SIGNAL(clicked(bool)),this,SLOT(delimiterChanged()));
    connect(ui->checkBox_4,SIGNAL(clicked(bool)),this,SLOT(delimiterChanged()));
    connect(ui->checkBox_5,SIGNAL(clicked(bool)),this,SLOT(delimiterChanged()));
    connect(ui->checkBox_6,SIGNAL(clicked(bool)),this,SLOT(delimiterChanged()));
    connect(ui->checkBox_7,SIGNAL(clicked(bool)),this,SLOT(delimiterChanged()));
}

Export::~Export()
{
    delete ui;
    delete str1;
    delete str2;
    delete amsdata;
    delete meta_Flag;
    delete bacon_meta_Flag;
    delete metaData;
    delete bacon_metaData;
    delete modelIsotope;
    delete ageData;
    delete bacon_str1;
    delete bacon_str2;
    delete baconAge;
    delete baconOut;
}

void Export::setupTable(){
    // setup Meta
    // create the model for Meta Data

    delete metaData;
    metaData = new QStandardItemModel(meta_length,3,this);
    metaData->setHorizontalHeaderItem(1, new QStandardItem(QString("Name")));
    metaData->setHorizontalHeaderItem(2, new QStandardItem(QString("Value")));
    metaData->setHorizontalHeaderItem(0, new QStandardItem(QString("Status")));

    ui->tableView_3->setModel(metaData);
    ui->tableView_3->setEditTriggers(QAbstractItemView::NoEditTriggers);
    QStandardItem *meta_Name = new QStandardItem[meta_length];
    QStandardItem *meta_Value = new QStandardItem[meta_length];
    QStandardItem *meta_Stat = new QStandardItem[meta_length];

    // Add Meta
    // Status Flag
    for (int i=0;i<meta_length;i++) {
        meta_Name[i].setData(str1[i],Qt::EditRole);
        metaData->setItem(i,1,&meta_Name[i]);

        meta_Value[i].setData(str2[i],Qt::EditRole);
        metaData->setItem(i,2,&meta_Value[i]);

        meta_Stat[i].setData("No Export",Qt::EditRole);
        meta_Stat[i].setCheckable(true);

        if (meta_Flag[i]==1) {
            meta_Stat[i].setCheckState(Qt::Checked);
            meta_Stat[i].setText("Export");
        }
        metaData->setItem(i,0,&meta_Stat[i]);
    }

    ui->tableView_3->setSortingEnabled(0);
    ui->tableView_3->verticalHeader()->setDefaultSectionSize(ui->tableView_3->verticalHeader()->minimumSectionSize());
    ui->tableView_3->resizeColumnsToContents();
    ui->tableView_3->setHorizontalScrollMode(ui->tableView_3->ScrollPerPixel);
    ui->tableView_3->setSelectionMode(QAbstractItemView::NoSelection);
    ui->tableView_3->horizontalHeader()->setStretchLastSection(1);

    // setup IsoData
    // create the model for Meta Data
    delete modelIsotope;
    modelIsotope = new QStandardItemModel(inv->get_Length(),10,this);
    modelIsotope->setHorizontalHeaderItem(0, new QStandardItem(QString("Depth\n[m]")));
    modelIsotope->setHorizontalHeaderItem(1, new QStandardItem(QString("Sample\nThickness\n[m]")));
    modelIsotope->setHorizontalHeaderItem(2, new QStandardItem(QString("Age\n[kyr]")));
    modelIsotope->setHorizontalHeaderItem(3, new QStandardItem(QString("Carbon\n[per mil]")));
    modelIsotope->setHorizontalHeaderItem(4, new QStandardItem(QString("Oxygen\n[per mil]")));
    modelIsotope->setHorizontalHeaderItem(5, new QStandardItem(QString("Carbon\nError\n[per mil]")));
    modelIsotope->setHorizontalHeaderItem(6, new QStandardItem(QString("Oxygen\nError\n[per mil]")));
    modelIsotope->setHorizontalHeaderItem(7, new QStandardItem(QString("Carbon\nCorrection\n[per mil]")));
    modelIsotope->setHorizontalHeaderItem(8, new QStandardItem(QString("Oxygen\nCorrection\n[per mil]")));
    modelIsotope->setHorizontalHeaderItem(9, new QStandardItem(QString("Flag")));
    modelIsotope->setHorizontalHeaderItem(10, new QStandardItem(QString("Comment")));

    ui->tableView->setModel(modelIsotope);
    ui->tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);

    QStandardItem *iso_Depth = new QStandardItem[inv->get_Length()];
    QStandardItem *iso_Sample_Thickness = new QStandardItem[inv->get_Length()];
    QStandardItem *iso_Age = new QStandardItem[inv->get_Length()];
    QStandardItem *iso_Oxygen = new QStandardItem[inv->get_Length()];
    QStandardItem *iso_Carbon = new QStandardItem[inv->get_Length()];
    QStandardItem *iso_Carbon_Error = new QStandardItem[inv->get_Length()];
    QStandardItem *iso_Oxygen_Error = new QStandardItem[inv->get_Length()];
    QStandardItem *iso_Carbon_Correction= new QStandardItem[inv->get_Length()];
    QStandardItem *iso_Oxygen_Correction = new QStandardItem[inv->get_Length()];
    QStandardItem *iso_Flag = new QStandardItem[inv->get_Length()];
    QStandardItem *iso_Comment = new QStandardItem[inv->get_Length()];

    for (int i=0;i<inv->get_Length();i++){
        iso_Depth[i].setText(QString::number(inv->get_data_Depth(i)));
        modelIsotope->setItem(i,0,&iso_Depth[i]);
        iso_Sample_Thickness[i].setText(QString::number(inv->get_data_Sample_Thickness(i)));
        modelIsotope->setItem(i,1,&iso_Sample_Thickness[i]);
        iso_Age[i].setText(QString::number(inv->get_data_Age(i)));
        modelIsotope->setItem(i,2,&iso_Age[i]);
        iso_Carbon[i].setText(QString::number(inv->get_data_d13C(i)));
        modelIsotope->setItem(i,3,&iso_Carbon[i]);
        iso_Oxygen[i].setText(QString::number(inv->get_data_d18O(i)));
        modelIsotope->setItem(i,4,&iso_Oxygen[i]);
        iso_Carbon_Error[i].setText(QString::number(inv->get_data_d13C_Err(i)));
        modelIsotope->setItem(i,5,&iso_Carbon_Error[i]);
        iso_Oxygen_Error[i].setText(QString::number(inv->get_data_d18O_Err(i)));
        modelIsotope->setItem(i,6,&iso_Oxygen_Error[i]);
        iso_Carbon_Correction[i].setText(QString::number(inv->get_data_d13C_Corr(i)));
        modelIsotope->setItem(i,7,&iso_Carbon_Correction[i]);
        iso_Oxygen_Correction[i].setText(QString::number(inv->get_data_d18O_Corr(i)));
        modelIsotope->setItem(i,8,&iso_Oxygen_Correction[i]);
        iso_Flag[i].setText(QString::number(inv->get_data_Use_Flag(i)));
        modelIsotope->setItem(i,9,&iso_Flag[i]);
        iso_Comment[i].setText(inv->get_data_Comments(i));
        modelIsotope->setItem(i,10,&iso_Comment[i]);
    }
    ui->tableView->setSortingEnabled(0);
    ui->tableView->resizeColumnsToContents();
    ui->tableView->verticalHeader()->setDefaultSectionSize(ui->tableView->verticalHeader()->minimumSectionSize());
    ui->tableView->horizontalHeader()->setStretchLastSection(1);
    ui->tableView->setSelectionMode(QAbstractItemView::NoSelection);
    ui->tableView->setHorizontalScrollMode(ui->tableView->ScrollPerPixel);

    // setup AgeModel
    delete ageData;
    ageData = new QStandardItemModel(amsdata->get_Length(),15,this);
    ageData->setHorizontalHeaderItem(0, new QStandardItem(QString("Index")));
    ageData->setHorizontalHeaderItem(1, new QStandardItem(QString("Depth")));
    ageData->setHorizontalHeaderItem(2, new QStandardItem(QString("Sample Thickness")));
    ageData->setHorizontalHeaderItem(3, new QStandardItem(QString("Label")));
    ageData->setHorizontalHeaderItem(4, new QStandardItem(QString("Type")));
    ageData->setHorizontalHeaderItem(5, new QStandardItem(QString("Age dated\n[ka]")));
    ageData->setHorizontalHeaderItem(6, new QStandardItem(QString("Age UCL\n[ka+]")));
    ageData->setHorizontalHeaderItem(7, new QStandardItem(QString("Age LCL\n[ka-]")));
    ageData->setHorizontalHeaderItem(8, new QStandardItem(QString("Res. Age\n[ka]")));
    ageData->setHorizontalHeaderItem(9, new QStandardItem(QString("Res. Age\nError\n[ka]")));
    ageData->setHorizontalHeaderItem(10, new QStandardItem(QString("Cal yrs\n[wm ka BP]")));
    ageData->setHorizontalHeaderItem(11, new QStandardItem(QString("Cal yrs min\n[95%]")));
    ageData->setHorizontalHeaderItem(12, new QStandardItem(QString("Cal yrs max\n[95%]")));
    ageData->setHorizontalHeaderItem(13, new QStandardItem(QString("Use Flag")));
    ageData->setHorizontalHeaderItem(14, new QStandardItem(QString("Comments")));

    ui->tableView_2->setModel(ageData);
    ui->tableView_2->setEditTriggers(QAbstractItemView::NoEditTriggers);
    QStandardItem *var_Index = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Depth = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Sample_Thickness = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Label = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Type = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Age_dated = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Age_UCL = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Age_LCL = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Age_Res = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Age_Res_Error = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Cal = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Cal_Min = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Cal_Max = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Use_Flag = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Comment = new QStandardItem[amsdata->get_Length()];

    for (int i=0;i<amsdata->get_Length();i++){
            var_Index[i].setData(i,Qt::EditRole);
            ageData->setItem(i,0,&var_Index[i]);

            var_Depth[i].setData(amsdata->get_Depth(i),Qt::EditRole);
            ageData->setItem(i,1,&var_Depth[i]);

            var_Sample_Thickness[i].setData(amsdata->get_Sample_Thickness(i),Qt::EditRole);
            ageData->setItem(i,2,&var_Sample_Thickness[i]);

            var_Label[i].setText(amsdata->get_LabID(i));
            ageData->setItem(i,3,&var_Label[i]);

            var_Type[i].setText(amsdata->get_Type(i));
            ageData->setItem(i,4,&var_Type[i]);

            var_Age_dated[i].setData(amsdata->get_Data(0,i),Qt::EditRole);
            ageData->setItem(i,5,&var_Age_dated[i]);

            var_Age_UCL[i].setData(amsdata->get_Data(1,i),Qt::EditRole);
            ageData->setItem(i,6,&var_Age_UCL[i]);

            var_Age_LCL[i].setData(amsdata->get_Data(2,i),Qt::EditRole);
            ageData->setItem(i,7,&var_Age_LCL[i]);

            var_Age_Res[i].setData(amsdata->get_Data(3,i),Qt::EditRole);
            ageData->setItem(i,8,&var_Age_Res[i]);

            var_Age_Res_Error[i].setData(amsdata->get_Reservoir_Error(i),Qt::EditRole);
            ageData->setItem(i,8,&var_Age_Res_Error[i]);

            var_Cal[i].setData(amsdata->get_Data(4,i),Qt::EditRole);
            ageData->setItem(i,10,&var_Cal[i]);

            var_Cal_Min[i].setData(amsdata->get_Data(5,i),Qt::EditRole);
            ageData->setItem(i,11,&var_Cal_Min[i]);

            var_Cal_Max[i].setData(amsdata->get_Data(6,i),Qt::EditRole);
            ageData->setItem(i,12,&var_Cal_Max[i]);

            var_Use_Flag[i].setData(amsdata->get_Data(7,i),Qt::EditRole);

            var_Use_Flag[i].setText(QString::number(amsdata->get_Data(7,i)));

            ageData->setItem(i,13,&var_Use_Flag[i]);
            ageData->setData(ageData->index(i, 13), Qt::AlignCenter,Qt::TextAlignmentRole);

            var_Comment[i].setText(amsdata->get_Age_Comment(i));
            ageData->setItem(i,14,&var_Comment[i]);

    }
    ui->tableView_2->setSortingEnabled(0);
    ui->tableView_2->horizontalHeader()->setSortIndicator(0,Qt::AscendingOrder);
    ui->tableView_2->verticalHeader()->setDefaultSectionSize(ui->tableView_2->verticalHeader()->minimumSectionSize());
    ui->tableView_2->resizeColumnsToContents();
    ui->tableView_2->setHorizontalScrollMode(ui->tableView_2->ScrollPerPixel);
    ui->tableView_2->setSelectionMode(QAbstractItemView::NoSelection);
    ui->tableView_2->horizontalHeader()->setStretchLastSection(1);

    // setup Bacon Meta
    // create the model for Bacon Meta Data

    bacon_metaData = new QStandardItemModel(bacon_meta_length,3,this);
    bacon_metaData->setHorizontalHeaderItem(1, new QStandardItem(QString("Name")));
    bacon_metaData->setHorizontalHeaderItem(2, new QStandardItem(QString("Value")));
    bacon_metaData->setHorizontalHeaderItem(0, new QStandardItem(QString("Status")));

    ui->tableView_6->setModel(bacon_metaData);
    ui->tableView_6->setEditTriggers(QAbstractItemView::NoEditTriggers);
    QStandardItem *bacon_meta_Name = new QStandardItem[bacon_meta_length];
    QStandardItem *bacon_meta_Value = new QStandardItem[bacon_meta_length];
    QStandardItem *bacon_meta_Stat = new QStandardItem[bacon_meta_length];

    // Add Meta
    // Status Flag
    for (int i=0;i<bacon_meta_length;i++) {
        bacon_meta_Name[i].setData(bacon_str1[i],Qt::EditRole);
        bacon_metaData->setItem(i,1,&bacon_meta_Name[i]);

        bacon_meta_Value[i].setData(bacon_str2[i],Qt::EditRole);
        bacon_metaData->setItem(i,2,&bacon_meta_Value[i]);

        bacon_meta_Stat[i].setData("No Export",Qt::EditRole);
        bacon_meta_Stat[i].setCheckable(true);

        if (bacon_meta_Flag[i]==1) {
            bacon_meta_Stat[i].setCheckState(Qt::Checked);
            bacon_meta_Stat[i].setText("Export");
        }
        bacon_metaData->setItem(i,0,&bacon_meta_Stat[i]);
    }

    ui->tableView_6->setSortingEnabled(0);
    ui->tableView_6->verticalHeader()->setDefaultSectionSize(ui->tableView_6->verticalHeader()->minimumSectionSize());
    ui->tableView_6->resizeColumnsToContents();
    ui->tableView_6->setHorizontalScrollMode(ui->tableView_6->ScrollPerPixel);
    ui->tableView_6->setSelectionMode(QAbstractItemView::NoSelection);
    ui->tableView_6->horizontalHeader()->setStretchLastSection(1);

    //setup Bacon Age model
    delete baconAge;
    baconAge = new QStandardItemModel(amsdata->get_bacon_age_nrow(),amsdata->get_bacon_age_ncol(),this);
    baconAge->setHorizontalHeaderItem(0, new QStandardItem(QString("Depth[m]")));
    baconAge->setHorizontalHeaderItem(1, new QStandardItem(QString("Age Average[kyr]")));
    baconAge->setHorizontalHeaderItem(2, new QStandardItem(QString("5% Range[kyr]")));
    baconAge->setHorizontalHeaderItem(3, new QStandardItem(QString("Median[kyr]")));
    baconAge->setHorizontalHeaderItem(4, new QStandardItem(QString("95% Range[kyr]")));


    ui->tableView_4->setModel(baconAge);
    ui->tableView_4->setEditTriggers(QAbstractItemView::NoEditTriggers);
    QStandardItem *var_D = new QStandardItem[amsdata->get_bacon_age_nrow()];
    QStandardItem *var_Average = new QStandardItem[amsdata->get_bacon_age_nrow()];
    QStandardItem *var_5 = new QStandardItem[amsdata->get_bacon_age_nrow()];
    QStandardItem *var_50 = new QStandardItem[amsdata->get_bacon_age_nrow()];
    QStandardItem *var_95 = new QStandardItem[amsdata->get_bacon_age_nrow()];

    float* agemodel=amsdata->get_bacon_age();

    for (int i=0;i<amsdata->get_bacon_age_nrow();i++){
            var_D[i].setData(agemodel[i+0*amsdata->get_bacon_age_nrow()]/100,Qt::EditRole);
            baconAge->setItem(i,0,&var_D[i]);
            var_Average[i].setData(agemodel[i+1*amsdata->get_bacon_age_nrow()]/1000,Qt::EditRole);
            baconAge->setItem(i,1,&var_Average[i]);
            var_5[i].setData(agemodel[i+2*amsdata->get_bacon_age_nrow()]/1000,Qt::EditRole);
            baconAge->setItem(i,2,&var_5[i]);
            var_50[i].setData(agemodel[i+3*amsdata->get_bacon_age_nrow()]/1000,Qt::EditRole);
            baconAge->setItem(i,3,&var_50[i]);
            var_95[i].setData(agemodel[i+4*amsdata->get_bacon_age_nrow()]/1000,Qt::EditRole);
            baconAge->setItem(i,4,&var_95[i]);
    }
    ui->tableView_4->setSortingEnabled(0);
    ui->tableView_4->horizontalHeader()->setSortIndicator(0,Qt::AscendingOrder);
    ui->tableView_4->verticalHeader()->setDefaultSectionSize(ui->tableView_4->verticalHeader()->minimumSectionSize());
    ui->tableView_4->resizeColumnsToContents();
    ui->tableView_4->setHorizontalScrollMode(ui->tableView_4->ScrollPerPixel);
    ui->tableView_4->setSelectionMode(QAbstractItemView::NoSelection);
    ui->tableView_4->horizontalHeader()->setStretchLastSection(1);

    if (ui->checkBox_6->isChecked()){
        // setup Bacon out
        int outr=amsdata->get_bacon_out_nrow();
        int outc=amsdata->get_bacon_out_ncol();
        if (outc>0){
            delete baconOut;
            baconOut = new QStandardItemModel(outr,outc-1,this);

            baconOut->setHorizontalHeaderItem(0, new QStandardItem(QString("Starting Age")));
            for (int i=0;i<amsdata->get_bacon_out_ncol()-3;i++) {
                float d1=amsdata->get_bacon_d_min()+i*((amsdata->get_bacon_d_max()-amsdata->get_bacon_d_min())/amsdata->get_bacon_K());
                float d2=amsdata->get_bacon_d_min()+(i+1)*((amsdata->get_bacon_d_max()-amsdata->get_bacon_d_min())/amsdata->get_bacon_K());
                baconOut->setHorizontalHeaderItem(1+i, new QStandardItem(QString("Acc(d="+QString::number(d1)+"-"+QString::number(d2)+"cm)")));
            }
            baconOut->setHorizontalHeaderItem(amsdata->get_bacon_out_ncol()-2, new QStandardItem(QString("Memory")));
            baconOut->setHorizontalHeaderItem(amsdata->get_bacon_out_ncol()-1, new QStandardItem(QString("Iteration")));



            ui->tableView_5->setModel(baconOut);
            ui->tableView_5->setEditTriggers(QAbstractItemView::NoEditTriggers);
            int nrow=amsdata->get_bacon_out_nrow();
            QStandardItem *var_Age = new QStandardItem[nrow];
            QStandardItem *var_Acc = new QStandardItem[nrow*amsdata->get_bacon_out_ncol()-3];
            QStandardItem *var_Mem = new QStandardItem[nrow];
            QStandardItem *var_It = new QStandardItem[nrow];

            float* out=amsdata->get_bacon_out();

            for (int i=0;i<nrow;i++){
                    var_Age[i].setData(out[0*nrow+i]/1000.0,Qt::EditRole);
                    baconOut->setItem(i,0,&var_Age[i]);
                    for (int j=1;j<amsdata->get_bacon_out_ncol()-2;j++){
                        var_Acc[(j-1)*nrow+i].setData(out[i+j*nrow],Qt::EditRole);
                        baconOut->setItem(i,j,&var_Acc[(j-1)*nrow+i]);
                    }
                    var_Mem[i].setData(out[i+(amsdata->get_bacon_out_ncol()-2)*nrow],Qt::EditRole);
                    baconOut->setItem(i,amsdata->get_bacon_out_ncol()-2,&var_Mem[i]);

                    var_It[i].setData(out[i+(amsdata->get_bacon_out_ncol()-1)*nrow],Qt::EditRole);
                    baconOut->setItem(i,amsdata->get_bacon_out_ncol()-1,&var_It[i]);



            }
            ui->tableView_5->setSortingEnabled(0);
            ui->tableView_5->horizontalHeader()->setSortIndicator(0,Qt::AscendingOrder);
            ui->tableView_5->verticalHeader()->setDefaultSectionSize(ui->tableView_5->verticalHeader()->minimumSectionSize());
            ui->tableView_5->resizeColumnsToContents();
            ui->tableView_5->setHorizontalScrollMode(ui->tableView_5->ScrollPerPixel);
            ui->tableView_5->setSelectionMode(QAbstractItemView::NoSelection);
        }
    }
}

void Export::metaTableSelected(QModelIndex mi){
    int sel=mi.row();
    //qDebug() << "Clicked :"+QString::number(sel)+":"+QString::number(mi.column());
    QStandardItemModel* model = qobject_cast<QStandardItemModel*>(ui->tableView_3->model());
    QString text = model->item(sel,mi.column())->text();
    //qDebug() << text;

    if (mi.column()==0){
        if (meta_Flag[sel]==1){
            meta_Flag[sel]=0;
        } else {
            meta_Flag[sel]=1;
        }
    }

    setupTable();
    setupASCII();
}
void Export::bacon_metaTableSelected(QModelIndex mi){
    int sel=mi.row();
    //qDebug() << "Clicked :"+QString::number(sel)+":"+QString::number(mi.column());
    QStandardItemModel* model = qobject_cast<QStandardItemModel*>(ui->tableView_6->model());
    QString text = model->item(sel,mi.column())->text();
    //qDebug() << text;

    if (mi.column()==0){
        if (bacon_meta_Flag[sel]==1){
            bacon_meta_Flag[sel]=0;
        } else {
            bacon_meta_Flag[sel]=1;
        }
    }

    setupTable();
    setupASCII();
}

void Export::delimiterChanged(){
    dlm=ui->lineEdit_2->text();
    dlm.replace("\\t","\t");


    setupTable();
    setupASCII();
}

void Export::setupASCII(){
    // Font setup
    QFont font;
    font.setFamily("Courier");
    font.setStyleHint(QFont::Monospace);
    font.setFixedPitch(true);
    font.setPointSize(10);

    ui->textBrowser->setFont(font);

    QFontMetrics metrics(font);
    ui->textBrowser->setTabStopWidth(ui->spinBox->value() * metrics.width(' '));

    // create the result shown on left
    txt.clear();
    if (ui->checkBox_2->checkState()==Qt::Checked){
        // Create Meta Data
        for (int i=0;i<meta_length;i++){
            if (meta_Flag[i]){
                QString tmp=str1[i];
                //while (tmp.size()<30) tmp.append(" ");
                //tmp.append(dlm);
                if (ui->checkBox->checkState()!=Qt::Checked){
                    if (i==20) {

                        QStringList opt=str2[i].split(";");
                        for (int ii=0;ii<opt.size();ii++){
                            QStringList var=opt.at(ii).split("=");
                            if (var.size()==2) txt.append(var.at(0)+dlm+var.at(1)+"\n");
                        }
                    }else{
                        txt.append(tmp+dlm+str2[i]+"\n");
                    }
                } else{
                    if (i==2 || i==3 || i==4||i==14||i==15){
                        QString tmp2=str2[i];
                        txt.append(tmp+dlm+tmp2.replace(".",",")+"\n");
                    }else{
                        if (i==20) {

                            QStringList opt=str2[i].split(";");
                            for (int ii=0;ii<opt.size();ii++){
                                QStringList var=opt.at(ii).split("=");
                                QString val=var.at(1);
                                val=val.replace(".",",");
                                if (var.size()==2) txt.append(var.at(0)+dlm+val+"\n");
                            }
                        }else{
                            txt.append(tmp+dlm+str2[i]+"\n");
                        }
                    }
                }
            }
        }
        txt.append("\n");
    }
    // Create Isotope Data
    if (ui->checkBox_3->checkState()==Qt::Checked){
        txt.append("Isotope Data\n");
        // Header of Table
        txt.append("Depth [m]"+dlm+"Sample Thickness [m]"+dlm+"Age [ka BP]"+dlm+"d13C [per mil PDB]"+dlm+"d18O [per mil PDB]"+dlm+"d13C Error [per mil PDB]"+dlm+"d18O Error [per mil PDB]"+dlm+"d13C Corr [per mil PDB]"+dlm+"d18O Corr [per mil PDB]"+dlm+"Use Flag"+dlm+"Comment\n");
        // Data
        for(int i=0;i<inv->get_Length();i++){
            if (ui->checkBox->checkState()!=Qt::Checked){
                txt.append(QString::number(inv->get_data_Depth(i))+dlm+
                           QString::number(inv->get_data_Sample_Thickness(i))+dlm+
                           QString::number(inv->get_data_Age(i))+dlm+
                           QString::number(inv->get_data_d13C(i))+dlm+
                           QString::number(inv->get_data_d18O(i))+dlm+
                           QString::number(inv->get_data_d13C_Err(i))+dlm+
                           QString::number(inv->get_data_d18O_Err(i))+dlm+
                           QString::number(inv->get_data_d13C_Corr(i))+dlm+
                           QString::number(inv->get_data_d18O_Corr(i))+dlm+
                           QString::number(inv->get_data_Use_Flag(i))+dlm+
                           inv->get_data_Comments(i)+"\n");
            }else{
                txt.append(QString::number(inv->get_data_Depth(i)).replace(".",",")+dlm+
                           QString::number(inv->get_data_Sample_Thickness(i)).replace(".",",")+dlm+
                           QString::number(inv->get_data_Age(i)).replace(".",",")+dlm+
                           QString::number(inv->get_data_d13C(i)).replace(".",",")+dlm+
                           QString::number(inv->get_data_d18O(i)).replace(".",",")+dlm+
                           QString::number(inv->get_data_d13C_Err(i)).replace(".",",")+dlm+
                           QString::number(inv->get_data_d18O_Err(i)).replace(".",",")+dlm+
                           QString::number(inv->get_data_d13C_Corr(i)).replace(".",",")+dlm+
                           QString::number(inv->get_data_d18O_Corr(i)).replace(".",",")+dlm+
                           QString::number(inv->get_data_Use_Flag(i)).replace(".",",")+dlm+
                           inv->get_data_Comments(i)+"\n");
            }
        }
        txt.append("\n");
    }
    // Create Age Model Data
    if (ui->checkBox_4->checkState()==Qt::Checked){
        txt.append("Age Model Data\n");
        // Header
        txt.append("Depth [m]"+dlm+"Sample Thickness [m]"+dlm+"Label"+dlm+"Type"+dlm+"Age dated [ka]"+dlm+"Age UCL [ka +]"+dlm+"Age LCL [ka -]"+dlm+"Res. Age [ka]"+dlm+"Res. Age Error [ka]"+dlm+"Cal yrs [wm ka BP]"+dlm+"Cal yrs min [95%]"+dlm+"Cal yrs max [95%]"+dlm+"Use Flag"+dlm+"Dating Method/Comments\n");
        // Data
        for(int i=0;i<amsdata->get_Length();i++){
            if (ui->checkBox->checkState()!=Qt::Checked){
                txt.append(QString::number(amsdata->get_Depth(i))+dlm+
                           QString::number(amsdata->get_Sample_Thickness(i))+dlm+
                           amsdata->get_LabID(i)+dlm+
                           amsdata->get_Type(i)+dlm+
                           QString::number(amsdata->get_Data(0,i))+dlm+
                           QString::number(amsdata->get_Data(1,i))+dlm+
                           QString::number(amsdata->get_Data(2,i))+dlm+
                           QString::number(amsdata->get_Data(3,i))+dlm+
                           QString::number(amsdata->get_Reservoir_Error(i))+dlm+
                           QString::number(amsdata->get_Data(4,i))+dlm+
                           QString::number(amsdata->get_Data(5,i))+dlm+
                           QString::number(amsdata->get_Data(6,i))+dlm+
                           QString::number(amsdata->get_Data(7,i))+dlm+
                           amsdata->get_Age_Comment(i)+"\n");
            }else{
                txt.append(QString::number(amsdata->get_Depth(i)).replace(".",",")+dlm+
                           QString::number(amsdata->get_Sample_Thickness(i)).replace(".",",")+dlm+
                           amsdata->get_LabID(i)+dlm+
                           amsdata->get_Type(i)+dlm+
                           QString::number(amsdata->get_Data(0,i)).replace(".",",")+dlm+
                           QString::number(amsdata->get_Data(1,i)).replace(".",",")+dlm+
                           QString::number(amsdata->get_Data(2,i)).replace(".",",")+dlm+
                           QString::number(amsdata->get_Data(3,i)).replace(".",",")+dlm+
                           QString::number(amsdata->get_Reservoir_Error(i)).replace(".",",")+dlm+
                           QString::number(amsdata->get_Data(4,i)).replace(".",",")+dlm+
                           QString::number(amsdata->get_Data(5,i)).replace(".",",")+dlm+
                           QString::number(amsdata->get_Data(6,i)).replace(".",",")+dlm+
                           QString::number(amsdata->get_Data(7,i))+dlm+
                           amsdata->get_Age_Comment(i)+"\n");
            }
        }
        txt.append("\n");
    }
    // Bacon Meta Data
    if (ui->checkBox_7->checkState()==Qt::Checked && amsdata->get_bacon_out_ncol()>0){
        txt.append("Bacon Parameters\n");
        for (int i=0;i<bacon_meta_length;i++){
            if (bacon_meta_Flag[i]){
                QString tmp=bacon_str1[i];
                while (tmp.size()<30) tmp.append(" ");
                tmp.append(dlm);
                if (ui->checkBox->checkState()!=Qt::Checked){
                    txt.append(tmp+dlm+bacon_str2[i]+"\n");
                } else{

                        QString tmp2=bacon_str2[i];
                        txt.append(tmp+dlm+tmp2.replace(".",",")+"\n");

                }
            }
        }
        txt.append("\n");
    }
    // Bacon Age Model
    if (ui->checkBox_5->checkState()==Qt::Checked&& amsdata->get_bacon_age_ncol()>0){
        txt.append("Bacon Age Model\n");
        // Header of Table
        txt.append("Depth in [m]"+dlm+"Average Age in [kyr]"+dlm+"5% Range in [kyr]"+dlm+"Median in [kyr]"+dlm+"5% Range in [kyr]\n");
        // Data
        for(int i=0;i<amsdata->get_bacon_age_nrow();i++){
            float* agemodel=amsdata->get_bacon_age();
            if (ui->checkBox->checkState()!=Qt::Checked){

                txt.append(QString::number(agemodel[i+0*amsdata->get_bacon_age_nrow()]/100)+dlm+
                           QString::number(agemodel[i+1*amsdata->get_bacon_age_nrow()]/1000)+dlm+
                           QString::number(agemodel[i+2*amsdata->get_bacon_age_nrow()]/1000)+dlm+
                           QString::number(agemodel[i+3*amsdata->get_bacon_age_nrow()]/1000)+dlm+
                           QString::number(agemodel[i+4*amsdata->get_bacon_age_nrow()]/1000)+"\n");
            }else{
                txt.append(QString::number(agemodel[i+0*amsdata->get_bacon_age_nrow()]/100).replace(".",",")+dlm+
                           QString::number(agemodel[i+1*amsdata->get_bacon_age_nrow()]/1000).replace(".",",")+dlm+
                           QString::number(agemodel[i+2*amsdata->get_bacon_age_nrow()]/1000).replace(".",",")+dlm+
                           QString::number(agemodel[i+3*amsdata->get_bacon_age_nrow()]/1000).replace(".",",")+dlm+
                           QString::number(agemodel[i+4*amsdata->get_bacon_age_nrow()]/1000).replace(".",",")+"\n");
            }
        }
        txt.append("\n");
    }
    // Bacon Output
    if (ui->checkBox_6->checkState()==Qt::Checked && amsdata->get_bacon_out_ncol()>0){
        txt.append("Bacon Output\n");
        // Header of Table
        txt.append("Starting Age in [kyr]"+dlm);
        for (int i=0;i<amsdata->get_bacon_out_ncol()-3;i++){
            float d1=amsdata->get_bacon_d_min()+i*((amsdata->get_bacon_d_max()-amsdata->get_bacon_d_min())/amsdata->get_bacon_K());
            float d2=amsdata->get_bacon_d_min()+(i+1)*((amsdata->get_bacon_d_max()-amsdata->get_bacon_d_min())/amsdata->get_bacon_K());
            txt.append(QString("Acc(d="+QString::number(d1)+"-"+QString::number(d2)+"cm)")+dlm);
        }
        txt.append("Memory"+dlm+"Iteration\n");
        // Data
        for(int i=0;i<amsdata->get_bacon_out_nrow();i++){
            float* output=amsdata->get_bacon_out();
            if (ui->checkBox->checkState()!=Qt::Checked){
                txt.append(QString::number(output[i+0*amsdata->get_bacon_out_nrow()]/1000)+dlm);
                for (int j=1;j<amsdata->get_bacon_out_ncol()-2;j++) txt.append(QString::number(output[i+j*amsdata->get_bacon_out_nrow()])+dlm);
                txt.append(QString::number(output[i+(amsdata->get_bacon_out_ncol()-2)*amsdata->get_bacon_out_nrow()])+dlm);
                txt.append(QString::number(output[i+(amsdata->get_bacon_out_ncol()-1)*amsdata->get_bacon_out_nrow()])+"\n");
            }else{
                txt.append(QString::number(output[i+0*amsdata->get_bacon_out_nrow()]/1000).replace(".",",")+dlm);
                for (int j=1;j<amsdata->get_bacon_out_ncol()-2;j++) txt.append(QString::number(output[i+j*amsdata->get_bacon_out_nrow()]).replace(".",",")+dlm);
                txt.append(QString::number(output[i+(amsdata->get_bacon_out_ncol()-2)*amsdata->get_bacon_out_nrow()]).replace(".",",")+dlm);
                txt.append(QString::number(output[i+(amsdata->get_bacon_out_ncol()-1)*amsdata->get_bacon_out_nrow()]).replace(".",",")+"\n");
            }
        }
        txt.append("\n");
    }
    // put to preview
    ui->textBrowser->clear();
    ui->textBrowser->setText(txt);
    update();
}

void Export::browse(){

    QString file = QFileDialog::getSaveFileName(this, tr("Select Save File"),
                                             resources.path_data+inv->get_att_Core(),
                                             tr("Excel (*.xlsx);;Text File (*.txt)"));

    //qDebug() << file;

    if (file.right(4)==".txt") save(file);
    if (file.right(5)==".xlsx") savexls(file);



    update();
}

void Export::save(QString file){
    // get file name
    QString QFilename=file;
    QFilename.replace(".xlsx",".txt");
    //qDebug() << QFilename;

    QFile f(QFilename);
    if(!f.open(QIODevice::WriteOnly | QIODevice::Text)) {
        //qDebug() <<  f.errorString();
    } else {
    //const char *text=txt.toStdString().c_str();
    //f.write(text,qstrlen(text));
    QTextStream out(&f);
    out<<txt;
    f.close();
    }
    QDesktopServices::openUrl(QUrl("file:///"+QFilename, QUrl::TolerantMode));
    emit(this->close());
}

void Export::savexls(QString file){
    // get file name
    QString QFilename=file;
    QFilename.replace(".txt",".xlsx");

    //qDebug() << QFilename;


    QXlsx::Document xlsx;
    if (ui->checkBox_2->checkState()==Qt::Checked){
        xlsx.addSheet("Meta Data", AbstractSheet::ST_WorkSheet);
        xlsx.selectSheet("Meta Data");
        xlsx.setColumnWidth(1, 2, 40);
        // Create Meta Data
        int count=0;
        for (int i=0;i<meta_length;i++){
            if (meta_Flag[i]){
                if (i!=20){
                    xlsx.write("A"+QString::number(count+1),str1[i]);
                    if(i==2||i==3||i==4||i==12||i==13||i==14||i==15){
                        Format lAlign;
                        lAlign.setHorizontalAlignment(Format::AlignLeft);
                        xlsx.write("B"+QString::number(count+1),str2[i].toDouble(),lAlign);
                    } else {
                        xlsx.write("B"+QString::number(count+1),str2[i]);
                    }
                } else {
                    QStringList opt=str2[i].split(";");
                    for (int ii=0;ii<opt.size();ii++){
                        if (opt.at(0)!=""){
                            QStringList var=opt.at(ii).split("=");
                            if (var.size()==2){
                                QString val=var.at(1);
                                val=val.replace(".",",");
                                if (var.size()==2) {
                                    xlsx.write("A"+QString::number(count+1+ii),var.at(0));
                                    xlsx.write("B"+QString::number(count+1+ii),val);
                                }
                            }
                        }
                    }
                    count=count+opt.size()-1;
                }
                count++;
            }
        }
    }
    if (ui->checkBox_3->checkState()==Qt::Checked){
        xlsx.addSheet("Proxy", AbstractSheet::ST_WorkSheet);
        xlsx.selectSheet("Proxys");
        xlsx.setColumnWidth(1, 9, 20);
        xlsx.write("A1","Depth [m]");
        xlsx.write("B1","Sample Thickness [m]");
        xlsx.write("C1","Age [ka BP]");
        xlsx.write("D1","d13C [per mil PDB]");
        xlsx.write("E1","d18O [per mil PDB]");
        xlsx.write("F1","d13C Error [per mil PDB]");
        xlsx.write("G1","d18O Error [per mil PDB]");
        xlsx.write("H1","d13C Corr [per mil PDB]");
        xlsx.write("I1","d18O Corr [per mil PDB]");
        xlsx.write("J1","Use Flag");
        xlsx.write("K1","Comment");
        for(int i=0;i<inv->get_Length();i++){
            if (isnan(inv->get_data_Depth(i))==false){xlsx.write("A"+QString::number(i+2),inv->get_data_Depth(i));}else{xlsx.write("A"+QString::number(i+2),"NAN");}
            if (isnan(inv->get_data_Sample_Thickness(i))==false){xlsx.write("B"+QString::number(i+2),inv->get_data_Sample_Thickness(i));}else{xlsx.write("B"+QString::number(i+2),"NAN");}
            if (isnan(inv->get_data_Age(i))==false){xlsx.write("C"+QString::number(i+2),inv->get_data_Age(i));}else{xlsx.write("C"+QString::number(i+2),"NAN");}
            if (isnan(inv->get_data_d13C(i))==false){xlsx.write("D"+QString::number(i+2),inv->get_data_d13C(i));}else{xlsx.write("D"+QString::number(i+2),"NAN");}
            if (isnan(inv->get_data_d18O(i))==false){xlsx.write("E"+QString::number(i+2),inv->get_data_d18O(i));}else{xlsx.write("E"+QString::number(i+2),"NAN");}
            if (isnan(inv->get_data_d13C_Err(i))==false){xlsx.write("F"+QString::number(i+2),inv->get_data_d13C_Err(i));}else{xlsx.write("F"+QString::number(i+2),"NAN");}
            if (isnan(inv->get_data_d18O_Err(i))==false){xlsx.write("G"+QString::number(i+2),inv->get_data_d18O_Err(i));}else{xlsx.write("G"+QString::number(i+2),"NAN");}
            if (isnan(inv->get_data_d13C_Corr(i))==false){xlsx.write("H"+QString::number(i+2),inv->get_data_d13C_Corr(i));}else{xlsx.write("H"+QString::number(i+2),"NAN");}
            if (isnan(inv->get_data_d18O_Corr(i))==false){xlsx.write("I"+QString::number(i+2),inv->get_data_d18O_Corr(i));}else{xlsx.write("I"+QString::number(i+2),"NAN");}
            if (isnan(inv->get_data_Use_Flag(i))==false){xlsx.write("J"+QString::number(i+2),inv->get_data_Use_Flag(i));}else{xlsx.write("J"+QString::number(i+2),"NAN");}
            xlsx.write("K"+QString::number(i+2),inv->get_data_Comments(i));
        }
    }
    if (ui->checkBox_4->checkState()==Qt::Checked){
        xlsx.addSheet("Age", AbstractSheet::ST_WorkSheet);
        xlsx.selectSheet("Age");
        xlsx.setColumnWidth(1, 12, 20);
        xlsx.write("A1","Depth [m]");
        xlsx.write("B1","Sample Thickness [m]");
        xlsx.write("C1","Label");
        xlsx.write("D1","Type");
        xlsx.write("E1","Age dated [ka]");
        xlsx.write("F1","Age UCL [ka +]");
        xlsx.write("G1","Age LCL [ka -]");
        xlsx.write("H1","Res. Age [ka]");
        xlsx.write("I1","Res. Age Error [ka]");
        xlsx.write("J1","Cal yrs [wm ka BP]");
        xlsx.write("K1","Cal yrs min [95%]");
        xlsx.write("L1","Cal yrs max [95%]");
        xlsx.write("M1","Use Flag");
        xlsx.write("N1","Dating Method/Comments");
        for(int i=0;i<amsdata->get_Length();i++){
            if (isnan(amsdata->get_Depth(i))==false){xlsx.write("A"+QString::number(i+2),amsdata->get_Depth(i));}else{xlsx.write("A"+QString::number(i+2),"NAN");}
            if (isnan(amsdata->get_Sample_Thickness(i))==false){xlsx.write("B"+QString::number(i+2),amsdata->get_Sample_Thickness(i));}else{xlsx.write("B"+QString::number(i+2),"NAN");}
            xlsx.write("C"+QString::number(i+2),amsdata->get_LabID(i));
            xlsx.write("D"+QString::number(i+2),amsdata->get_Type(i));
            if (isnan(amsdata->get_Data(0,i))==false){xlsx.write("E"+QString::number(i+2),amsdata->get_Data(0,i));}else{xlsx.write("E"+QString::number(i+2),"NAN");}
            if (isnan(amsdata->get_Data(1,i))==false){xlsx.write("F"+QString::number(i+2),amsdata->get_Data(1,i));}else{xlsx.write("F"+QString::number(i+2),"NAN");}
            if (isnan(amsdata->get_Data(2,i))==false){xlsx.write("G"+QString::number(i+2),amsdata->get_Data(2,i));}else{xlsx.write("G"+QString::number(i+2),"NAN");}
            if (isnan(amsdata->get_Data(3,i))==false){xlsx.write("H"+QString::number(i+2),amsdata->get_Data(3,i));}else{xlsx.write("H"+QString::number(i+2),"NAN");}
            if (isnan(amsdata->get_Reservoir_Error(i))==false){xlsx.write("I"+QString::number(i+2),amsdata->get_Reservoir_Error(i));}else{xlsx.write("I"+QString::number(i+2),"NAN");}
            if (isnan(amsdata->get_Data(4,i))==false){xlsx.write("J"+QString::number(i+2),amsdata->get_Data(4,i));}else{xlsx.write("J"+QString::number(i+2),"NAN");}
            if (isnan(amsdata->get_Data(5,i))==false){xlsx.write("K"+QString::number(i+2),amsdata->get_Data(5,i));}else{xlsx.write("K"+QString::number(i+2),"NAN");}
            if (isnan(amsdata->get_Data(6,i))==false){xlsx.write("L"+QString::number(i+2),amsdata->get_Data(6,i));}else{xlsx.write("L"+QString::number(i+2),"NAN");}
            if (isnan(amsdata->get_Data(7,i))==false){xlsx.write("M"+QString::number(i+2),amsdata->get_Data(7,i));}else{xlsx.write("M"+QString::number(i+2),"NAN");}
            xlsx.write("N"+QString::number(i+2),amsdata->get_Age_Comment(i));
        }
    }
    if (ui->checkBox_7->checkState()==Qt::Checked && amsdata->get_bacon_out_ncol()>0){
        xlsx.addSheet("Bacon Meta Data", AbstractSheet::ST_WorkSheet);
        xlsx.selectSheet("Bacon Meta Data");
        xlsx.setColumnWidth(1, 2, 40);
        // Create Meta Data
        int count=0;
        for (int i=0;i<bacon_meta_length;i++){
            if (bacon_meta_Flag[i]){
                xlsx.write("A"+QString::number(count+1),bacon_str1[i]);
                if(i!=9&&i!=10&&i!=11&&i!=12){
                    Format lAlign;
                    lAlign.setHorizontalAlignment(Format::AlignLeft);
                    xlsx.write("B"+QString::number(count+1),bacon_str2[i].toFloat(),lAlign);
                } else {
                    xlsx.write("B"+QString::number(count+1),bacon_str2[i]);
                }
                count++;
            }
        }
    }

    if (ui->checkBox_5->checkState()==Qt::Checked&& amsdata->get_bacon_age_ncol()>0){
        xlsx.addSheet("Bacon Age", AbstractSheet::ST_WorkSheet);
        xlsx.selectSheet("Bacon Age");
        xlsx.setColumnWidth(1, 9, 20);
        xlsx.write("A1","Depth in [m]");
        xlsx.write("B1","Average Age in [kyr]");
        xlsx.write("C1","5% Range in [kyr]");
        xlsx.write("D1","Median in [kyr]");
        xlsx.write("E1","95% Range in [kyr]");
        float* agemodel=amsdata->get_bacon_age();
        for(int i=0;i<amsdata->get_bacon_age_nrow();i++){
            if (isnan(agemodel[i+0*amsdata->get_bacon_age_nrow()])==false){xlsx.write("A"+QString::number(i+2),agemodel[i+0*amsdata->get_bacon_age_nrow()]/100);}else{xlsx.write("A"+QString::number(i+2),"NAN");}
            if (isnan(agemodel[i+1*amsdata->get_bacon_age_nrow()])==false){xlsx.write("B"+QString::number(i+2),agemodel[i+1*amsdata->get_bacon_age_nrow()]/1000);}else{xlsx.write("B"+QString::number(i+2),"NAN");}
            if (isnan(agemodel[i+2*amsdata->get_bacon_age_nrow()])==false){xlsx.write("C"+QString::number(i+2),agemodel[i+2*amsdata->get_bacon_age_nrow()]/1000);}else{xlsx.write("C"+QString::number(i+2),"NAN");}
            if (isnan(agemodel[i+3*amsdata->get_bacon_age_nrow()])==false){xlsx.write("D"+QString::number(i+2),agemodel[i+3*amsdata->get_bacon_age_nrow()]/1000);}else{xlsx.write("D"+QString::number(i+2),"NAN");}
            if (isnan(agemodel[i+4*amsdata->get_bacon_age_nrow()])==false){xlsx.write("E"+QString::number(i+2),agemodel[i+4*amsdata->get_bacon_age_nrow()]/1000);}else{xlsx.write("E"+QString::number(i+2),"NAN");}


        }
    }

    if (ui->checkBox_6->checkState()==Qt::Checked && amsdata->get_bacon_out_ncol()>0){
        xlsx.addSheet("Bacon Output", AbstractSheet::ST_WorkSheet);
        xlsx.selectSheet("Bacon Output");
        xlsx.setColumnWidth(1, amsdata->get_bacon_out_ncol(), 20);
        xlsx.write(1,1,"Starting Age in [kyr]");
        for (int i=0;i<amsdata->get_bacon_out_ncol()-3;i++){
            float d1=amsdata->get_bacon_d_min()+i*((amsdata->get_bacon_d_max()-amsdata->get_bacon_d_min())/amsdata->get_bacon_K());
            float d2=amsdata->get_bacon_d_min()+(i+1)*((amsdata->get_bacon_d_max()-amsdata->get_bacon_d_min())/amsdata->get_bacon_K());
            xlsx.write(1,i+2,"Acc(d="+QString::number(d1)+"-"+QString::number(d2)+"cm)"+dlm);
        }
        xlsx.write(1,amsdata->get_bacon_out_ncol()-1,"Memory");
        xlsx.write(1,amsdata->get_bacon_out_ncol(),"Iteration");

        float* output=amsdata->get_bacon_out();
        for(int i=0;i<amsdata->get_bacon_out_nrow();i++){
            if (isnan(output[i+0*amsdata->get_bacon_out_nrow()])==false){xlsx.write(2+i,1,output[i+0*amsdata->get_bacon_out_nrow()]/1000);}else{xlsx.write(i+2,1,"NAN");}
            for (int j=1;j<amsdata->get_bacon_out_ncol()-2;j++) if (isnan(output[i+0*amsdata->get_bacon_out_nrow()])==false){xlsx.write(2+i,j+1,output[i+j*amsdata->get_bacon_out_nrow()]);}else{xlsx.write(i+2,j+1,"NAN");}
            if (isnan(output[i+(amsdata->get_bacon_out_ncol()-2)*amsdata->get_bacon_out_nrow()])==false){xlsx.write(2+i,amsdata->get_bacon_out_ncol()-1,output[i+(amsdata->get_bacon_out_ncol()-2)*amsdata->get_bacon_out_nrow()]);}else{xlsx.write(i+2,amsdata->get_bacon_out_ncol()-1,"NAN");}
            if (isnan(output[i+(amsdata->get_bacon_out_ncol()-1)*amsdata->get_bacon_out_nrow()])==false){xlsx.write(2+i,amsdata->get_bacon_out_ncol(),output[i+(amsdata->get_bacon_out_ncol()-1)*amsdata->get_bacon_out_nrow()]);}else{xlsx.write(i+2,amsdata->get_bacon_out_ncol(),"NAN");}


            txt.append(QString::number(output[i+(amsdata->get_bacon_out_ncol()-2)*amsdata->get_bacon_out_nrow()])+dlm);
            txt.append(QString::number(output[i+(amsdata->get_bacon_out_ncol()-1)*amsdata->get_bacon_out_nrow()])+"\n");

        }
    }


    xlsx.saveAs(QFilename);


    QDesktopServices::openUrl(QUrl("file:///"+QFilename, QUrl::TolerantMode));
    emit(this->close());
}

bool Export::eventFilter(QObject *obj, QEvent *event)
{
    if (event->type() == QEvent::KeyPress)
    {
        if (obj==ui->tableView_2||obj==ui->tableView||obj==ui->tableView_3||obj==ui->textBrowser){
            QKeyEvent *keyEvent = static_cast<QKeyEvent *>(event);
            if (keyEvent->key()==Qt::Key_F1){
                ui->splitter->restoreState(sp);
                ui->splitter_2->restoreState(sp_2);
                //ui->splitter_3->restoreState(sp_3);
                return true;
            }
        }
    }
    return QObject::eventFilter(obj, event);
}
