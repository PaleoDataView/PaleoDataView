/********************************************************************************/
/*    This file is part of PaleoDataViewer.                       					*/
/*                                                                      		*/
/*    PaleoDataViewer is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoDataViewer is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoDataViewer.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#include "editor.h"
#include "ui_editor.h"

Editor::Editor(QWidget *parent,float *d,float *d_e,int c,int r) :
    QDialog(parent),data(d),data_err(d_e),column(c),row(r),
    ui(new Ui::Editor)
{
    ui->setupUi(this);
    this->setWindowTitle("Editor");

    useflag=new bool[c*r];
    color=new QColor[c*r];

    // Initialize: All true
    for (int i=0;i<c*r;i++) useflag[i]=true;
    // Initialize: All white
    for (int i=0;i<c*r;i++) {
        color[i].setRgb(128,128,128,255);

    }
    ccolor.setRgb(128,128,128,255);

    modelInventory = new QStandardItemModel(row,column,this);
    setupEditor();
    dat=new float[0];
    use=new bool[0];
    col=new QColor[0];
    dat_err=new float[0];
    dat_com=new QString[0];
    g=new Graph(this,data,0,0);
    g->setTitel("","","");
    g->setMultiplicator(1,1);
    g->setSize(ui->graphicsView->width(),ui->graphicsView->height());
    ui->graphicsView->setScene(g);
    connect(modelInventory,SIGNAL(dataChanged(QModelIndex,QModelIndex)),this,SLOT(editData(QModelIndex,QModelIndex)));
    connect(ui->tableView->selectionModel(),SIGNAL(selectionChanged(QItemSelection,QItemSelection)),this,SLOT(createPlot()));
    connect(ui->pushButton_2,SIGNAL(clicked(bool)),this,SLOT(invertUseFlag()));
    connect(ui->comboBox_2,SIGNAL(currentIndexChanged(int)),this,SLOT(createPlot()));
    connect(ui->pushButton,SIGNAL(clicked(bool)),this,SLOT(setColor()));
    connect(ui->pushButton_3,SIGNAL(clicked(bool)),this,SLOT(selectColor()));
    connect(ui->checkBox,SIGNAL(clicked(bool)),this,SLOT(createPlot()));
    connect(ui->comboBox_3,SIGNAL(currentIndexChanged(int)),this,SLOT(createPlot()));
    connect(ui->checkBox_3,SIGNAL(stateChanged(int)),this,SLOT(setInventory()));
    connect(ui->comboBox_4,SIGNAL(currentIndexChanged(int)),this,SLOT(createPlot()));
}

Editor::~Editor()
{
    delete ui;
    delete[] useflag;
    delete[] color;
    delete modelInventory;
    delete g;

    delete[] dat;
    delete[] use;
    delete[] col;
    delete[] dat_err;
    delete[] dat_com;
}

void Editor::setupEditor(){

    // create the model for Inventory

    for (int i=0;i<column;i++) modelInventory->setHorizontalHeaderItem(i, new QStandardItem(QString::number(i)));
    for (int i=0;i<row;i++) modelInventory->setVerticalHeaderItem(i, new QStandardItem(QString::number(i)));

    //...
    ui->tableView->setModel(modelInventory);

    QStandardItem *var_data = new QStandardItem[row*column];
    for (int c=0;c<column;c++){
        for (int r=0;r<row;r++){
            if (ui->checkBox_3->checkState()==Qt::Unchecked){
                var_data[r+c*row].setData(data[r+c*row],Qt::EditRole);
            }
            if (ui->checkBox_3->checkState()==Qt::Checked){
                var_data[r+c*row].setData(data_err[r+c*row],Qt::EditRole);
            }

            if (useflag[r+c*row]==true){
                QFont font;
                font.setBold(true);
                var_data[r+c*row].setFont(font);
                var_data[r+c*row].setForeground(Qt::black);
                var_data[r+c*row].setBackground(color[r+c*row]);
            } else {
                QFont font;
                font.setPixelSize(10);
                font.setItalic(true);
                var_data[r+c*row].setFont(font);
                var_data[r+c*row].setForeground(Qt::gray);
                var_data[r+c*row].setBackground(Qt::white);
            }

            modelInventory->setItem(r,c,&var_data[r+c*row]);

        }
    }
    ui->tableView->setEditTriggers(QAbstractItemView::DoubleClicked);
    ui->tableView->setSortingEnabled(0);
    ui->tableView->verticalHeader()->setDefaultSectionSize(ui->tableView->verticalHeader()->minimumSectionSize());
    ui->tableView->resizeColumnsToContents();
    ui->tableView->setHorizontalScrollMode(ui->tableView->ScrollPerPixel);
}

void Editor::editData(QModelIndex r,QModelIndex c){

    if (ui->checkBox_3->isChecked()){
        data_err[r.row()+r.column()*row]=modelInventory->item(r.row(),r.column())->text().toFloat();
    } else {
        data[r.row()+r.column()*row]=modelInventory->item(r.row(),r.column())->text().toFloat();
    }
}

void Editor::createPlot(){
    // get selected Line/s
    QModelIndexList select_column=ui->tableView->selectionModel()->selectedColumns();
    QModelIndexList select_row=ui->tableView->selectionModel()->selectedRows();
    int ignore=1;
    // Plot multiple 1D lines with numbering
    if (ui->comboBox->currentText()=="X(n)" && select_column.count()+select_row.count()>0){

        int length=0;
        if(select_column.count()==column) ignore=0;
        if ((select_row.count()*ignore>0 && column>row)||select_column.count()==0){
            length=column;
        } else {
            length=row;
        }
        // Preparing column data
        delete[] dat;
        delete[] use;
        delete[] col;
        delete[] dat_err;
        delete[] dat_com;
        dat=new float[(select_column.count()+select_row.count()*ignore)*length*2];
        use=new bool[(select_column.count()+select_row.count()*ignore)*length*2];
        col=new QColor[(select_column.count()+select_row.count()*ignore)*length*2];
        dat_err=new float[(select_column.count()+select_row.count()*ignore)*length*2];
        dat_com=new QString[(select_column.count()+select_row.count()*ignore)*length*2];

        // create numbers
        for (int i=0;i<length;i++) for (int j=0;j<(select_column.count()+select_row.count()*ignore)*2;j=j+2){
            dat[i+j*length]=i;
            dat_err[i+j*length]=i*0.1;
            dat_com[i+j*length]="X :"+QString::number(i);
            dat_com[i+(j+1)*length]="Y :"+QString::number(i*i);
        }

        // create columns
        for (int i=0;i<select_column.count();i++) {
            for (int j=0;j<length;j++){
                if (j<row){
                    dat[j+(i*2+1)*length]=data[j+select_column.at(i).column()*row];
                    dat_err[j+(i*2+1)*length]=data_err[j+select_column.at(i).column()*row];
                    use[j+(i*2+1)*length]=useflag[j+select_column.at(i).column()*row];
                    use[j+(i*2)*length]=useflag[j+select_column.at(i).column()*row];
                    col[j+(i*2)*length]=color[j+select_column.at(i).column()*row];

                    col[j+(i*2+1)*length]=color[j+select_column.at(i).column()*row];

                } else {
                    dat[j+(i*2+1)*length]=NAN;
                    use[j+(i*2+1)*length]=false;
                    use[j+(i*2)*length]=false;
                }
            }
        }
        // create rows
        for (int i=0;i<select_row.count()*ignore;i++) {
            for (int j=0;j<length;j++){
                if (j<column){
                    dat[j+(i*2+1+select_column.count()*2)*length]=data[select_row.at(i).row()+j*row];
                    dat_err[j+(i*2+1+select_column.count()*2)*length]=data_err[select_row.at(i).row()+j*row];
                    use[j+(i*2+1+select_column.count()*2)*length]=useflag[select_row.at(i).row()+j*row];
                    use[j+(i*2+select_column.count()*2)*length]=useflag[select_row.at(i).row()+j*row];
                    col[j+(i*2+select_column.count()*2)*length]=color[select_row.at(i).row()+j*row];
                    col[j+(i*2+1+select_column.count()*2)*length]=color[select_row.at(i).row()+j*row];

                } else {
                    dat[j+(i*2+1+select_column.count()*2)*length]=NAN;
                    use[j+(i*2+1+select_column.count()*2)*length]=false;
                    use[j+(i*2+select_column.count()*2)*length]=false;
                }
            }
        }

        g=new Graph(this,dat,(select_column.count()+select_row.count()*ignore)*2,length);
        g->setUse(use,ui->comboBox_2->currentIndex());
        g->setError(dat_err,ui->comboBox_3->currentIndex());
        g->setColor(col,ui->checkBox->isChecked());
        g->setComment(dat_com,ui->comboBox_4->currentIndex());
        g->setTitel("","x","x(n)");
        g->setMultiplicator(1,1);
        g->setTextSize(12,0,5);
        g->setSymbol(2);
        g->setSize(ui->graphicsView->width(),ui->graphicsView->height());
        g->autoSize();
        ui->graphicsView->setScene(g);
    }


}

void Editor::paintEvent(QPaintEvent *)
{
    g->setSize(ui->graphicsView->width(),ui->graphicsView->height());
}

void Editor::invertUseFlag(){
    for (int i=0;i<column;i++){
        for (int j=0;j<row;j++){
            bool isselect=ui->tableView->selectionModel()->isSelected(modelInventory->index(j,i,QModelIndex()));
            if (isselect==true) {
                if (useflag[j+i*row]==true){
                    useflag[j+i*row]=false;
                }else{
                    useflag[j+i*row]=true;
                }
            }
        }
    }
    setupEditor();
}

void Editor::setColor(){
    for (int i=0;i<column;i++){
        for (int j=0;j<row;j++){
            bool isselect=ui->tableView->selectionModel()->isSelected(modelInventory->index(j,i,QModelIndex()));
            if (isselect==true) {
                color[j+i*row]=ccolor;

            }
        }
    }
    setupEditor();
}

void Editor::setInventory(){
    setupEditor();
}

void Editor::selectColor(){
    QColorDialog cdiag;
    QColor col(cdiag.getColor(ccolor,this));
    if (col.isValid()){
        ccolor=col;
        QString color="background-color: rgb("+QString::number(ccolor.red())+","+QString::number(ccolor.green())+","+QString::number(ccolor.blue())+")";
        ui->pushButton_3->setStyleSheet(color);
    }
}


