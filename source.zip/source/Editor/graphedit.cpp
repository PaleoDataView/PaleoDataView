/********************************************************************************/
/*    This file is part of PaleoDataViewer.                       					*/
/*                                                                      		*/
/*    PaleoDataViewer is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoDataViewer is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoDataViewer.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#include <QDebug>
#include "Editor/graphedit.h"

GraphEdit::GraphEdit(QDialog *dialog,float *d,int c,int r)
    : diag(dialog),data(d),column(c),row(r)
{
    titel="Plot";
    titel_x="X(Y)";
    titel_y="Y(X)";
    plot_Size_X=100;
    plot_Size_Y=100;
    textsize=10;
    titelsize=0;
    margin=8;
    x_min=-1;
    x_max=1;
    y_min=-1;
    y_max=1;
    ticks_x=10;
    ticks_y=5;
    grid_flag=1;
    usemode=0;
    error=0;
    error2=0;
    marker=0;
    moveFlag=0;
    this->setSceneRect(-plot_Size_X/2+1,-plot_Size_Y/2+1,plot_Size_X-2,plot_Size_Y-2);

    // Generate ggrid
    ggrid=new GraphGrid(this,data,column,row);
    this->addItem(ggrid);
    gdata=new GraphData(this,data,column,row);
    this->addItem(gdata);
    key_flag=0;
    frame_x1=0;
    frame_x2=0;
    frame_y1=0;
    frame_y2=0;
    factor_x=1;
    factor_y=1;
    symbol_size=5;
    com_mode=0;
    com_hide=0;
    this->autoSize();
    line_width=1;
    line_color=Qt::black;
    marker_x=NAN;
    marker_y=NAN;
    marker_mode=0;
    setcolor_mode=0;

    set=new GraphSettings(diag,gdata,ggrid);


    header=new QStringList;
    err=new float[0];



    gg=new GraphGrid(this,data,column,row);
    gd=new GraphData(this,data,column,row);
    gdisplay=new GraphDisplay(diag,gd,gg);
}

GraphEdit::~GraphEdit()
{

    delete set;

    delete header;
    delete[] err;

    delete gg;
    delete gd;

    delete gdisplay;
}
// Sets the data array. Its one dim, but you have to give columns and rows
void GraphEdit::setData(float *d,int c,int r){
    data=d;
    column=c;
    row=r;

    ggrid->setData(data,column,row);
    gdata->setData(data,column,row);
    this->autoSize();
    update();

}


void GraphEdit::setError(float *d_e,int m){
    data_err=d_e;
    error=m;
    gdata->setError(data_err,error);
}

void GraphEdit::setError2(float *d_e,int m){
    data_err2=d_e;
    error2=m;
    gdata->setError2(data_err2,error2);
}

void GraphEdit::setComment(QString *s, int m){
    dat_com=s;
    com_mode=m;
    gdata->setComment(s,m);
}

void GraphEdit::setColor(QColor *col,bool m){
    col_dat=col;

    color=m;
    gdata->setColor(col_dat,m);
}

// Set Use Condition : true means to use point
// mode: 0 = no Use Mode
//       1 = Points Visible but crossed
//       2 = Points ignored completly
void GraphEdit::setUse(bool *u,int m){
    useflag=u;
    usemode=m;
    gdata->setUse(u,m);
}

// set Size of Plot in pixels
void GraphEdit::setSize(int x,int y){
    plot_Size_X=x;
    plot_Size_Y=y;
    ggrid->setSize(x,y);
    gdata->setSize(x,y);
}

// Set the titels of Plot and x-y Axis
void GraphEdit::setTitel(QString t,QString tx,QString ty){
    ggrid->setTitel(t,tx,ty);
    titel=t;
    titel_x=tx;
    titel_y=ty;

}
// sets multiplicators for axes (use 1 for normal or -1 for invert axis)
void GraphEdit::setMultiplicator(double fx, double fy){
    factor_x=fx;
    factor_y=fy;
    gdata->setMultiplicator(fx,fy);
    ggrid->setMultiplicator(fx,fy);
}

void GraphEdit::setTextSize(int texts, int titels, int margins){
    textsize=texts;
    titelsize=titels;
    margin=margins;
    gdata->setTextSize(textsize,titelsize,margin);
    ggrid->setTextSize(textsize,titelsize,margin);
}

void GraphEdit::setSymbol(int size){
    symbol_size=size;
    gdata->setSymbol(symbol_size);
}

void GraphEdit::setMark(int *d_m,int m){
    marker=m;
    data_mark=d_m;
    gdata->setMark(data_mark,marker);
}

void GraphEdit::setLineWidth(int i){
    line_width=i;
    gdata->setLineWidth(line_width);
}

void GraphEdit::setLineStyle(Qt::PenStyle sty){
    line_style=sty;
    gdata->setLineStyle(line_style);
}

void GraphEdit::setLineColor(QColor c){
    line_color=c;
    gdata->setLineColor(line_color);
}

void GraphEdit::addMarker(float x,float y,int m){
    marker_x=x;
    marker_y=y;
    marker_mode=m;
    gdata->addMarker(marker_x,marker_y,marker_mode);
}

void GraphEdit::setSetColor(QColor *c,int m){
    setcolor_mode=m;
    setcolor_color=c;
    gdata->setSetColor(setcolor_color,setcolor_mode);
}

// Autosize on all Data
void GraphEdit::autoSize(){
    x_min=9e999;
    x_max=-9e999;
    y_min=9e999;
    y_max=-9e999;
    for (int j=0;j<column;j=j+2){
        for (int i=0;i<row;i++){
            if (std::isnan(data[i+j*row])==0 && std::isnan(data[i+(j+1)*row])==0 && usemode!=2){
                if (error2==0){
                    if (error==0){
                        if (x_min>data[i+j*row]*factor_x) x_min=data[i+j*row]*factor_x;
                        if (x_max<data[i+j*row]*factor_x) x_max=data[i+j*row]*factor_x;
                        if (y_min>data[i+(j+1)*row]*factor_y) y_min=data[i+(j+1)*row]*factor_y;
                        if (y_max<data[i+(j+1)*row]*factor_y) y_max=data[i+(j+1)*row]*factor_y;
                    } else {
                        float x_err=data_err[i+j*row];
                        float y_err=data_err[i+(j+1)*row];
                        if (std::isnan(data_err[i+(j)*row])) x_err=0;
                        if (std::isnan(data_err[i+(j+1)*row])) y_err=0;
                        if (error==1){
                            if (x_min>(data[i+j*row]-x_err)*factor_x) x_min=(data[i+j*row]-x_err)*factor_x;
                            if (x_max<(data[i+j*row]+x_err)*factor_x) x_max=(data[i+j*row]+x_err)*factor_x;
                            if (y_min>(data[i+(j+1)*row])*factor_y) y_min=(data[i+(j+1)*row])*factor_y;
                            if (y_max<(data[i+(j+1)*row])*factor_y) y_max=(data[i+(j+1)*row])*factor_y;
                        }
                        if (error==2){
                            if (x_min>(data[i+j*row])*factor_x) x_min=(data[i+j*row])*factor_x;
                            if (x_max<(data[i+j*row])*factor_x) x_max=(data[i+j*row])*factor_x;
                            if (y_min>(data[i+(j+1)*row]-y_err)*factor_y) y_min=(data[i+(j+1)*row]-y_err)*factor_y;
                            if (y_max<(data[i+(j+1)*row]+y_err)*factor_y) y_max=(data[i+(j+1)*row]+y_err)*factor_y;
                        }
                        if (error==3){
                            if (x_min>(data[i+j*row]-x_err)*factor_x) x_min=(data[i+j*row]-x_err)*factor_x;
                            if (x_max<(data[i+j*row]+x_err)*factor_x) x_max=(data[i+j*row]+x_err)*factor_x;
                            if (y_min>(data[i+(j+1)*row]-y_err)*factor_y) y_min=(data[i+(j+1)*row]-y_err)*factor_y;
                            if (y_max<(data[i+(j+1)*row]+y_err)*factor_y) y_max=(data[i+(j+1)*row]+y_err)*factor_y;
                        }

                    }
                } else {


                    float x_err=data_err[i+j*row];
                    float y_err=data_err[i+(j+1)*row];
                    float x_err2=data_err2[i+j*row];
                    float y_err2=data_err2[i+(j+1)*row];
                    if (std::isnan(data_err[i+(j)*row])) x_err=0;
                    if (std::isnan(data_err[i+(j+1)*row])) y_err=0;
                    if (std::isnan(data_err2[i+(j)*row])) x_err2=0;
                    if (std::isnan(data_err2[i+(j+1)*row])) y_err2=0;
                    if (error2==1){
                        if (x_min>(data[i+j*row]-x_err)*factor_x) x_min=(data[i+j*row]-x_err)*factor_x;
                        if (x_max<(data[i+j*row]+x_err2)*factor_x) x_max=(data[i+j*row]+x_err2)*factor_x;
                        if (y_min>(data[i+(j+1)*row])*factor_y) y_min=(data[i+(j+1)*row])*factor_y;
                        if (y_max<(data[i+(j+1)*row])*factor_y) y_max=(data[i+(j+1)*row])*factor_y;
                    }
                    if (error2==2){
                        if (x_min>(data[i+j*row])*factor_x) x_min=(data[i+j*row])*factor_x;
                        if (x_max<(data[i+j*row])*factor_x) x_max=(data[i+j*row])*factor_x;
                        if (y_min>(data[i+(j+1)*row]-y_err)*factor_y) y_min=(data[i+(j+1)*row]-y_err)*factor_y;
                        if (y_max<(data[i+(j+1)*row]+y_err2)*factor_y) y_max=(data[i+(j+1)*row]+y_err2)*factor_y;
                    }
                    if (error2==3){
                        if (x_min>(data[i+j*row]-x_err)*factor_x) x_min=(data[i+j*row]-x_err)*factor_x;
                        if (x_max<(data[i+j*row]+x_err2)*factor_x) x_max=(data[i+j*row]+x_err2)*factor_x;
                        if (y_min>(data[i+(j+1)*row]-y_err)*factor_y) y_min=(data[i+(j+1)*row]-y_err)*factor_y;
                        if (y_max<(data[i+(j+1)*row]+y_err2)*factor_y) y_max=(data[i+(j+1)*row]+y_err2)*factor_y;
                    }

                }
            }
            if (std::isnan(data[i+j*row])==0 && std::isnan(data[i+(j+1)*row])==0 && usemode==2){
                if (error2==0){
                    if (error==0){
                        if (x_min>data[i+j*row]*factor_x
                                && useflag[i+j*row]==true) x_min=data[i+j*row]*factor_x;
                        if (x_max<data[i+j*row]*factor_x
                                && useflag[i+j*row]==true) x_max=data[i+j*row]*factor_x;
                        if (y_min>data[i+(j+1)*row]*factor_y
                                && useflag[i+(j+1)*row]==true) y_min=data[i+(j+1)*row]*factor_y;
                        if (y_max<data[i+(j+1)*row]*factor_y
                                && useflag[i+(j+1)*row]==true) y_max=data[i+(j+1)*row]*factor_y;
                    } else {
                        float x_err=data_err[i+j*row];
                        float y_err=data_err[i+(j+1)*row];
                        if (std::isnan(data_err[i+(j)*row])) x_err=0;
                        if (std::isnan(data_err[i+(j+1)*row])) y_err=0;
                        if (error==1){
                            if (x_min>(data[i+j*row]-x_err)*factor_x
                                    && useflag[i+j*row]==true) x_min=(data[i+j*row]-x_err)*factor_x;
                            if (x_max<(data[i+j*row]+x_err)*factor_x
                                    && useflag[i+j*row]==true) x_max=(data[i+j*row]+x_err)*factor_x;
                            if (y_min>(data[i+(j+1)*row])*factor_y
                                    && useflag[i+(j+1)*row]==true) y_min=(data[i+(j+1)*row])*factor_y;
                            if (y_max<(data[i+(j+1)*row])*factor_y
                                    && useflag[i+(j+1)*row]==true) y_max=(data[i+(j+1)*row])*factor_y;
                        }
                        if (error==2){
                            if (x_min>(data[i+j*row])*factor_x
                                    && useflag[i+j*row]==true) x_min=(data[i+j*row])*factor_x;
                            if (x_max<(data[i+j*row])*factor_x
                                    && useflag[i+j*row]==true) x_max=(data[i+j*row])*factor_x;
                            if (y_min>(data[i+(j+1)*row]-y_err)*factor_y
                                    && useflag[i+(j+1)*row]==true) y_min=(data[i+(j+1)*row]-y_err)*factor_y;
                            if (y_max<(data[i+(j+1)*row]+y_err)*factor_y
                                    && useflag[i+(j+1)*row]==true) y_max=(data[i+(j+1)*row]+y_err)*factor_y;
                        }
                        if (error==3){
                            if (x_min>(data[i+j*row]-x_err)*factor_x
                                    && useflag[i+j*row]==true) x_min=(data[i+j*row]-x_err)*factor_x;
                            if (x_max<(data[i+j*row]+x_err)*factor_x
                                    && useflag[i+j*row]==true) x_max=(data[i+j*row]+x_err)*factor_x;
                            if (y_min>(data[i+(j+1)*row]-y_err)*factor_y
                                    && useflag[i+(j+1)*row]==true) y_min=(data[i+(j+1)*row]-y_err)*factor_y;
                            if (y_max<(data[i+(j+1)*row]+y_err)*factor_y
                                    && useflag[i+(j+1)*row]==true) y_max=(data[i+(j+1)*row]+y_err)*factor_y;
                        }
                    }
                } else {

                    float x_err=data_err[i+j*row];
                    float y_err=data_err[i+(j+1)*row];
                    float x_err2=data_err2[i+j*row];
                    float y_err2=data_err2[i+(j+1)*row];
                    if (std::isnan(data_err[i+(j)*row])) x_err=0;
                    if (std::isnan(data_err[i+(j+1)*row])) y_err=0;
                    if (std::isnan(data_err2[i+(j)*row])) x_err2=0;
                    if (std::isnan(data_err2[i+(j+1)*row])) y_err2=0;
                    if (error2==1){
                        if (x_min>(data[i+j*row]-x_err)*factor_x
                                && useflag[i+j*row]==true) x_min=(data[i+j*row]-x_err)*factor_x;
                        if (x_max<(data[i+j*row]+x_err2)*factor_x
                                && useflag[i+j*row]==true) x_max=(data[i+j*row]+x_err2)*factor_x;
                        if (y_min>(data[i+(j+1)*row])*factor_y
                                && useflag[i+(j+1)*row]==true) y_min=(data[i+(j+1)*row])*factor_y;
                        if (y_max<(data[i+(j+1)*row])*factor_y
                                && useflag[i+(j+1)*row]==true) y_max=(data[i+(j+1)*row])*factor_y;
                    }
                    if (error2==2){
                        if (x_min>(data[i+j*row])*factor_x
                                && useflag[i+j*row]==true) x_min=(data[i+j*row])*factor_x;
                        if (x_max<(data[i+j*row])*factor_x
                                && useflag[i+j*row]==true) x_max=(data[i+j*row])*factor_x;
                        if (y_min>(data[i+(j+1)*row]-y_err)*factor_y
                                && useflag[i+(j+1)*row]==true) y_min=(data[i+(j+1)*row]-y_err)*factor_y;
                        if (y_max<(data[i+(j+1)*row]+y_err2)*factor_y
                                && useflag[i+(j+1)*row]==true) y_max=(data[i+(j+1)*row]+y_err2)*factor_y;
                    }
                    if (error2==3){
                        if (x_min>(data[i+j*row]-x_err)*factor_x
                                && useflag[i+j*row]==true) x_min=(data[i+j*row]-x_err)*factor_x;
                        if (x_max<(data[i+j*row]+x_err2)*factor_x
                                && useflag[i+j*row]==true) x_max=(data[i+j*row]+x_err2)*factor_x;
                        if (y_min>(data[i+(j+1)*row]-y_err)*factor_y
                                && useflag[i+(j+1)*row]==true) y_min=(data[i+(j+1)*row]-y_err)*factor_y;
                        if (y_max<(data[i+(j+1)*row]+y_err2)*factor_y
                                && useflag[i+(j+1)*row]==true) y_max=(data[i+(j+1)*row]+y_err2)*factor_y;
                    }

                }
            }
        }
    }
    x_min-=(x_max-x_min)*0.05;
    x_max+=(x_max-x_min)*0.05;
    y_min-=(y_max-y_min)*0.05;
    y_max+=(y_max-y_min)*0.05;
    if (x_min==x_max) {
        x_min-=1;
        x_max+=1;
    }
    if (y_min==y_max){
        y_min-=1;
        y_max+=1;
    }
    ggrid->setView(x_min,x_max,y_min,y_max);
    gdata->setView(x_min,x_max,y_min,y_max);
    update();
}

// Start drawing a frame if STRG is pressed : Starting Kooridinates
void GraphEdit::mousePressEvent(QGraphicsSceneMouseEvent* mouseEvent1){
    if (key_flag==1){
        frame_x1=mouseEvent1->scenePos().x();
        frame_y1=mouseEvent1->scenePos().y();
    }

}
// Realizes Point Clicked and Zoom-Frame-finish
void GraphEdit::mouseReleaseEvent(QGraphicsSceneMouseEvent* mouseEvent2){
    // Give Point Details
    if(moveFlag==0 && key_flag==0){
        x_min=gdata->get_x_min();
        x_max=gdata->get_x_max();
        y_min=gdata->get_y_min();
        y_max=gdata->get_y_max();

        int x1=mouseEvent2->scenePos().x();
        int y1=mouseEvent2->scenePos().y();

        // find closest dot
        double rx=999999e999;
        int count_row=-1;
        int count_column=-1;
        for (int j=0;j<column;j=j+2){
            for (int i=0;i<row;i++){
                int x2 = (int) (-plot_Size_X/2+4*textsize+margin + (double) (plot_Size_X-2*margin-4*textsize) * (double) (((data[i+j*row]*factor_x) - x_min) / (x_max - x_min)));
                int y2 = (int) (-plot_Size_Y/2+titelsize+margin + (double) (plot_Size_Y-2*margin-4*textsize-titelsize) * (double) ((y_max - (data[i+(j+1)*row]*factor_y)) / (y_max - y_min)));
                double r=(x1-x2)*(x1-x2)+(y1-y2)*(y1-y2);
                if (r<rx){
                   count_row=i;
                   count_column=j;
                   rx=r;
                }
            }
        }

        if (rx>16) {
            count_row=-1;
            count_column=-1;
        }


        int i=gdata->getSelected_Y();
        int j=gdata->getSelected_X();

        gdata->setSelected_Y(count_row);
        gdata->setSelected_X(count_column);

        // Give dot details
        if (count_row>-1 && count_column>-1){
            QString str="";
            if (com_mode>0) {
                if (dat_com[count_row+count_column*row].simplified()!="") str=dat_com[count_row+count_column*row]+"\n";
                str=str+titel_x+" : "+QString::number(data[count_row+count_column*row])+"\n"+titel_y+" : "+QString::number(data[count_row+(count_column+1)*row]);
                if (dat_com[count_row+(count_column+1)*row].simplified()!="") str=str+"\n"+dat_com[count_row+(count_column+1)*row];
            } else {
                str=titel_x+" : "+QString::number(data[count_row+count_column*row])+"\n"+titel_y+" : "+QString::number(data[count_row+(count_column+1)*row]);
            }

            QPoint pos;
            pos.setX(mouseEvent2->screenPos().x());
            pos.setY(mouseEvent2->screenPos().y());
            QToolTip::showText(pos,str,0);
        }
        update();

    }
    moveFlag=0;

    // Frame is finished : Final Kooridinates-> Zoom in
    if (key_flag==1){
        frame_x2=mouseEvent2->scenePos().x();
        frame_y2=mouseEvent2->scenePos().y();
        // zoom
        if (frame_x1>frame_x2){
            int temp=frame_x1;
            frame_x1=frame_x2;
            frame_x2=temp;
        }
        if (frame_y1>frame_y2){
            int temp=frame_y1;
            frame_y1=frame_y2;
            frame_y2=temp;
        }
        double new_x_min=0,new_y_min=0,new_x_max=0,new_y_max=0;

        x_min=gdata->get_x_min();
        x_max=gdata->get_x_max();
        y_min=gdata->get_y_min();
        y_max=gdata->get_y_max();
            double fx=(plot_Size_X-2*margin-4*textsize)/(x_max-x_min);
            new_x_min=x_min+(1.0/fx)*(frame_x1-(-plot_Size_X/2+margin+4*textsize));
            new_x_max=x_min+(1.0/fx)*(frame_x2-(-plot_Size_X/2+margin+4*textsize));
            double fy=(plot_Size_Y-2*margin-4*textsize-titelsize)/(y_max-y_min);
            new_y_min=y_max-(1.0/fy)*(frame_y2-(-plot_Size_Y/2+margin+titelsize));
            new_y_max=y_max-(1.0/fy)*(frame_y1-(-plot_Size_Y/2+margin+titelsize));

        ggrid->setView(new_x_min,new_x_max,new_y_min,new_y_max);
        gdata->setView(new_x_min,new_x_max,new_y_min,new_y_max);
        x_min=gdata->get_x_min();
        x_max=gdata->get_x_max();
        y_min=gdata->get_y_min();
        y_max=gdata->get_y_max();

        key_flag=0;
    }
    gdata->setRect(frame_x1,frame_x2,frame_y1,frame_y2,0);
    update();
}

// Realizes Drag and Zoom-Frame
void GraphEdit::mouseMoveEvent(QGraphicsSceneMouseEvent* mouseEvent3){
    // Allow Drag of View
    if (mouseEvent3->buttons()==Qt::LeftButton && key_flag==0){

        moveFlag=1;

        x_min=gdata->get_x_min();
        x_max=gdata->get_x_max();
        y_min=gdata->get_y_min();
        y_max=gdata->get_y_max();

        double new_x_min=0,new_y_min=0,new_x_max=0,new_y_max=0;


            double fx=(plot_Size_X-2*margin-4*textsize)/(x_max-x_min);
            new_x_min=x_min+(1.0/fx)*(mouseEvent3->lastScreenPos().x()-mouseEvent3->screenPos().x());
            new_x_max=x_max+(1.0/fx)*(mouseEvent3->lastScreenPos().x()-mouseEvent3->screenPos().x());
            double fy=(plot_Size_Y-2*margin-4*textsize-titelsize)/(y_max-y_min);
            new_y_min=y_min-(1.0/fy)*(mouseEvent3->lastScreenPos().y()-mouseEvent3->screenPos().y());
            new_y_max=y_max-(1.0/fy)*(mouseEvent3->lastScreenPos().y()-mouseEvent3->screenPos().y());

        //qDebug() << QString::number(new_x_min)+":"+QString::number(new_x_max);
        //qDebug() << QString::number(new_y_min)+":"+QString::number(new_y_max);
        ggrid->setView(new_x_min,new_x_max,new_y_min,new_y_max);
        gdata->setView(new_x_min,new_x_max,new_y_min,new_y_max);
        x_min=gdata->get_x_min();
        x_max=gdata->get_x_max();
        y_min=gdata->get_y_min();
        y_max=gdata->get_y_max();
        update();
    }
    // Allow to draw a frame if STRG is Pressed
    if (mouseEvent3->buttons()==Qt::LeftButton && key_flag==1){
        // draw Frame
        gdata->setRect(frame_x1,mouseEvent3->scenePos().x(),frame_y1,mouseEvent3->scenePos().y(),1);
        update();
    }

}

// Get Seleted Point(x)
int GraphEdit::getSelected_X(){
    return gdata->getSelected_X();
}

// Get Seleted Point(y)
int GraphEdit::getSelected_Y(){
    return gdata->getSelected_Y();
}

// MouseWheel for Changing Zoom
void GraphEdit::wheelEvent(QGraphicsSceneWheelEvent *mouseEvent4){
    x_min=gdata->get_x_min();
    x_max=gdata->get_x_max();
    y_min=gdata->get_y_min();
    y_max=gdata->get_y_max();

    double new_x_min=0,new_y_min=0,new_x_max=0,new_y_max=0;

    if (mouseEvent4->delta()/120>0) {
        new_x_min=x_min+(x_max-x_min)*0.1;
        new_x_max=x_max-(x_max-x_min)*0.1;
        new_y_min=y_min+(y_max-y_min)*0.1;
        new_y_max=y_max-(y_max-y_min)*0.1;
    }
    if (mouseEvent4->delta()/120<0) {
        new_x_min=x_min-(x_max-x_min)*0.1;
        new_x_max=x_max+(x_max-x_min)*0.1;
        new_y_min=y_min-(y_max-y_min)*0.1;
        new_y_max=y_max+(y_max-y_min)*0.1;
    }
    ggrid->setView(new_x_min,new_x_max,new_y_min,new_y_max);
    gdata->setView(new_x_min,new_x_max,new_y_min,new_y_max);
    x_min=gdata->get_x_min();
    x_max=gdata->get_x_max();
    y_min=gdata->get_y_min();
    y_max=gdata->get_y_max();
    update();

}


// Not Used Anymore
void GraphEdit::mouseDoubleClickEvent(QGraphicsSceneMouseEvent *mouseEvent5){

}

// Check if STRG is Pressed for starting to drawing a frame
void GraphEdit::keyPressEvent(QKeyEvent *event){
    //qDebug() << "Pressed :"+QString::number(event->key());
    if (event->key()==Qt::Key_Control){
        //qDebug() << "Control";
        key_flag=1;
    }
}

// Check if STRG is Pressed for stopping drawing a frame
void GraphEdit::keyReleaseEvent(QKeyEvent *event){
    //qDebug() << "Released :"+QString::number(event->key());
    if (event->key()==Qt::Key_Control){
        //qDebug() << "Control";
        key_flag=0;
    }
}

void GraphEdit::contextMenuEvent(QGraphicsSceneContextMenuEvent *event)
{
    QMenu menu;
    menu.addAction("Auto-Resize GraphEdit");

    menu.addSeparator();
    menu.addAction("Settings");
    if (com_mode>0 && com_hide==0) menu.addAction("Hide Comments");
    if (com_mode>0 && com_hide==1) menu.addAction("Show Comments");
    menu.addSeparator();
    menu.addAction("Save as Image");
    QAction *a = menu.exec(event->screenPos());

    if (a)
    {
        if (a->iconText()=="Auto-Resize GraphEdit"){
            this->autoSize();
        }

        if (a->iconText()=="Hide Comments"){
            com_hide=1;
            gdata->setComHide(com_hide);
            update();
        }
        if (a->iconText()=="Show Comments"){
            com_hide=0;
            gdata->setComHide(com_hide);
            update();
        }

        if (a->iconText()=="Settings"){
            GraphSettings *c=new GraphSettings(diag,gdata,ggrid);
            c->setModal(true);
            c->setWindowFlags(Qt::Dialog | Qt::WindowTitleHint | Qt::WindowMaximizeButtonHint | Qt::WindowCloseButtonHint | Qt::CustomizeWindowHint);
            c->show();
            update();
        }
        if (a->iconText()=="Save as Image"){
            //create duplicates of gdata and ggrid
            delete gg;
            delete gd;
            gg=new GraphGrid(this,data,column,row);
            gd=new GraphData(this,data,column,row);
            gg->setData(data,column,row);
            gd->setData(data,column,row);
            gd->setError(data_err,error);
            gd->setError2(data_err2,error2);
            gd->setComment(dat_com,com_mode);
            gd->setColor(col_dat,color);
            gd->setUse(useflag,usemode);
            gd->setSize(plot_Size_X,plot_Size_Y);
            gg->setSize(plot_Size_X,plot_Size_Y);
            gg->setTitel(ggrid->getTitel(),ggrid->getTitelX(),ggrid->getTitelY());
            gd->setMultiplicator(factor_x,factor_y);
            gg->setMultiplicator(factor_x,factor_y);
            gd->setTextSize(ggrid->getTextSize(),ggrid->getTitelSize(),ggrid->getMargin());
            gg->setTextSize(ggrid->getTextSize(),ggrid->getTitelSize(),ggrid->getMargin());
            gd->setSymbol(gdata->getSymbolSize());
            gd->setMark(data_mark,marker);
            gd->setLineColor(gdata->getLineColor());
            gd->setLineStyle(gdata->getLineStyle());
            gd->setLineWidth(gdata->getLineWidth());
            gd->setSetColor(setcolor_color,setcolor_mode);
            gg->setView(x_min,x_max,y_min,y_max);
            gd->setView(x_min,x_max,y_min,y_max);
            int i=gdata->getSelected_Y();
            int j=gdata->getSelected_X();
            gd->setSelected_Y(i);
            gd->setSelected_X(j);
            gd->setComHide(com_hide);
            gd->addMarker(marker_x,marker_y,marker_mode);
            delete gdisplay;
            gdisplay=new GraphDisplay(diag,gd,gg);
            gdisplay->setModal(true);
            gdisplay->setWindowFlags(Qt::Dialog | Qt::WindowTitleHint | Qt::WindowMaximizeButtonHint | Qt::WindowCloseButtonHint | Qt::CustomizeWindowHint);
            gdisplay->show();
        }
    }
}


