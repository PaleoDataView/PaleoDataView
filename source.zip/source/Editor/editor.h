/********************************************************************************/
/*    This file is part of PaleoDataViewer.                       					*/
/*                                                                      		*/
/*    PaleoDataViewer is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoDataViewer is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoDataViewer.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#ifndef EDITOR_H
#define EDITOR_H


#include <QDialog>
#include <QStandardItemModel>
#include <QDebug>
#include "graph.h"
#include <QColorDialog>

namespace Ui {
class Editor;
}

class Editor : public QDialog
{
    Q_OBJECT

public:
    explicit Editor(QWidget *parent = 0,float *d=0,float *d_e=0,int c=0,int r=0);

    ~Editor();

private slots:
    void editData(QModelIndex r,QModelIndex c);
    void createPlot();
    void invertUseFlag();
    void setInventory();
    void setColor();
    void selectColor();
private:
    void setupEditor();
    void paintEvent(QPaintEvent*);
    Ui::Editor *ui;


    float *data;
    float *data_err;
    bool *useflag;
    QColor *color;

    QColor ccolor;
    int column;
    int row;// Size of datasheet
    QStandardItemModel *modelInventory;
    Graph *g;

    float *dat;
    bool *use;
    QColor *col;
    float *dat_err;
    QString *dat_com;
};

#endif // EDITOR_H
