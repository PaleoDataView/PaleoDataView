/********************************************************************************/
/*    This file is part of PaleoDataViewer.                       					*/
/*                                                                      		*/
/*    PaleoDataViewer is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoDataViewer is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoDataViewer.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#ifndef GRAPHEDIT_H
#define GRAPHEDIT_H


#include <QDialog>
#include <QGraphicsSceneMouseEvent>
#include <QGraphicsScene>
#include "graphgrid.h"
#include "graphdata.h"
#include <QKeyEvent>
#include <QMenu>
#include "graphdisplay.h"
#include "graphsettings.h"

class GraphEdit : public QGraphicsScene
{
public:
    GraphEdit(QDialog *dialog=0,float *d=0,int c=0,int r=0);
    ~GraphEdit();
    void setData(float *d,int c,int r);
    void setComment(QString *s,int m);
    void setColor(QColor *c,bool m);
    void setUse(bool *u,int m);
    void setSize(int plot_width,int plot_height);
    void setTitel(QString t,QString tx,QString ty);
    void setTextSize(int texts, int titels,int margins);
    void setMultiplicator(double fx, double fy);
    void setSymbol(int size);
    void autoSize();
    int getSelected_X();
    int getSelected_Y();
    void setError(float *d_e,int m);
    void setError2(float *d_e,int m);
    void setMark(int *d_m,int m);
    void setLineWidth(int i);
    void setLineStyle(Qt::PenStyle sty);
    void setLineColor(QColor c);
    void addMarker(float x,float y,int m);
    void setSetColor(QColor *c,int m);

protected:
    void mousePressEvent(QGraphicsSceneMouseEvent* mouseEvent1) Q_DECL_OVERRIDE;
    void mouseReleaseEvent(QGraphicsSceneMouseEvent* mouseEvent2) Q_DECL_OVERRIDE;
    void mouseMoveEvent(QGraphicsSceneMouseEvent* mouseEvent3) Q_DECL_OVERRIDE;
    void wheelEvent(QGraphicsSceneWheelEvent *mouseEvent4) Q_DECL_OVERRIDE;
    void mouseDoubleClickEvent(QGraphicsSceneMouseEvent *mouseEvent5) Q_DECL_OVERRIDE;

    void keyPressEvent(QKeyEvent *event) Q_DECL_OVERRIDE;
    void keyReleaseEvent(QKeyEvent *event) Q_DECL_OVERRIDE;

    void contextMenuEvent(QGraphicsSceneContextMenuEvent *event);
private:

    QWidget *diag;

    GraphGrid *ggrid;
    GraphData *gdata;

    int plot_Size_X;
    int plot_Size_Y;
    QString titel;
    QString titel_x;
    QString titel_y;
    int textsize;
    int titelsize;
    int margin;
    double x_min,y_min,x_max,y_max;
    int ticks_x,ticks_y;
    int grid_flag;
    int moveFlag;

    int key_flag;
    int frame_x1,frame_x2,frame_y1,frame_y2;
    double factor_x,factor_y;

    float *data;
    bool *useflag;
    int usemode;
    int column,row;// Size of datasheet
    QColor *col_dat;
    bool color;
    float *data_err;
    float *data_err2;
    QString *dat_com;
    int com_mode;
    int error;
    int error2;
    int com_hide;
    int *data_mark;
    int marker;
    int symbol_size;
    int line_width;
    Qt::PenStyle line_style;
    QColor line_color;
    float marker_x;
    float marker_y;
    int marker_mode;
    int setcolor_mode;
    QColor *setcolor_color;


    QStringList *header;
    float *err;
    GraphSettings* set;
    GraphGrid* gg;
    GraphData* gd;
    GraphDisplay* gdisplay;
};
#endif // GRAPHEDIT_H
