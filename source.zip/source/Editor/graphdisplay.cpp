/********************************************************************************/
/*    This file is part of PaleoDataViewer.                       					*/
/*                                                                      		*/
/*    PaleoDataViewer is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoDataViewer is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoDataViewer.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#include "graphdisplay.h"
#include "ui_graphdisplay.h"

GraphDisplay::GraphDisplay(QWidget *parent,GraphData *g,GraphGrid *gg) :
    QDialog(parent),graphdata(g),graphgrid(gg),
    ui(new Ui::GraphDisplay)
{
    ui->setupUi(this);
    this->setWindowTitle("Please Adjust Size :"+QString::number(ui->graphicsView->width())+":"+QString::number(ui->graphicsView->height()));
    scene=new QGraphicsScene(this);
    scene->addItem(graphgrid);
    scene->addItem(graphdata);
    ui->graphicsView->setScene(scene);
    graphdata->setSize(ui->graphicsView->width(),ui->graphicsView->height());
    graphgrid->setSize(ui->graphicsView->width(),ui->graphicsView->height());

    connect(ui->buttonBox,SIGNAL(accepted()),this,SLOT(accepted()));
    connect(ui->buttonBox,SIGNAL(rejected()),this,SLOT(rejected()));
}

GraphDisplay::~GraphDisplay()
{
    delete ui;
    delete scene;
}

void GraphDisplay::accepted(){
    QString imagePath = QFileDialog::getSaveFileName(this,tr("Save File"),"",tr("JPEG (*.jpg *.jpeg);;PNG (*.png)" ));
    if (imagePath!=""){
        const QPixmap pixmap = ui->graphicsView->grab();
        pixmap.save(imagePath);
    }
    this->accept();
}

void GraphDisplay::rejected(){
    this->close();
}

void GraphDisplay::paintEvent(QPaintEvent *)
{
    this->setWindowTitle("Please Adjust Size :"+QString::number(ui->graphicsView->width())+":"+QString::number(ui->graphicsView->height()));
    graphdata->setSize(ui->graphicsView->width(),ui->graphicsView->height());
    graphgrid->setSize(ui->graphicsView->width(),ui->graphicsView->height());
}
