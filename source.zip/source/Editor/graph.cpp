/********************************************************************************/
/*    This file is part of PaleoDataViewer.                       					*/
/*                                                                      		*/
/*    PaleoDataViewer is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoDataViewer is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoDataViewer.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#include "graph.h"
#include <QDebug>

Graph::Graph(QWidget *dialog,float *d,int c,int r)
    : diag(dialog)
{

    plot_Size_X=100;
    plot_Size_Y=100;

    focus=0;

    moveFlag=0;
    number=1;
    // Setting up scene
    this->setSceneRect(-plot_Size_X/2+1,-plot_Size_Y/2+1,plot_Size_X-2,plot_Size_Y-2);

    // Generate plots
    x_min.reserve(number);
    y_min.reserve(number);
    x_max.reserve(number);
    y_max.reserve(number);

    x_axis_type.reserve(number);
    y_axis_type.reserve(number);

    ggrid.reserve(number);
    gdata.reserve(number);
    data.reserve(number);
    data_err.reserve(number);
    data_err2.reserve(number);
    error.reserve(number);
    error2.reserve(number);
    column.reserve(number);
    row.reserve(number);
    titel.reserve(number);
    titel_x.reserve(number);
    titel_y.reserve(number);
    path.reserve(number);
    textsize.reserve(number);
    titelsize.reserve(number);
    margin.reserve(number);
    dat_com.reserve(number);
    com_mode.reserve(number);
    com_hide.reserve(number);
    dat_label.reserve(number);
    label_mode.reserve(number);
    usemode.reserve(number);
    useflag.reserve(number);
    factor_x.reserve(number);
    factor_y.reserve(number);
    fix_x.reserve(number);
    fix_y.reserve(number);
    col_dat.reserve(number);
    color.reserve(number);
    data_mark.reserve(number);
    marker.reserve(number);
    symbol_size.reserve(number);
    line_width.reserve(number);
    line_style.reserve(number);
    line_color.reserve(number);
    marker_x.reserve(number);
    marker_y.reserve(number);
    marker_mode.reserve(number);

    setcolor_mode.reserve(number);
    setlinecolor_mode.reserve(number);
    setlinewidth_mode.reserve(number);
    setsymbolsize_mode.reserve(number);
    setsymboltype_mode.reserve(number);
    setlinestyle_mode.reserve(number);
    setcolor_color.reserve(number);
    setlinecolor_color.reserve(number);
    setsymbolsize.reserve(number);
    setsymboltype.reserve(number);
    setlinewidth.reserve(number);
    setlinestyle.reserve(number);

    setpoly_mode.reserve(number);
    setpoly.reserve(number);
    setarea_mode.reserve(number);
    setarea_x.reserve(number);
    setarea_y.reserve(number);

    background.reserve(number);
    background_filename.reserve(number);
    background_fileimage.reserve(number);
    background_image.reserve(number);
    background_x1.reserve(number);
    background_x2.reserve(number);
    background_y1.reserve(number);
    background_y2.reserve(number);

    repeat_x.reserve(number);
    repeat_x1.reserve(number);
    repeat_x2.reserve(number);
    repeat_y.reserve(number);
    repeat_y1.reserve(number);
    repeat_y2.reserve(number);

    fold_x.reserve(number);
    fold_y.reserve(number);

    limit_x1.reserve(number);
    limit_x2.reserve(number);
    limit_y1.reserve(number);
    limit_y2.reserve(number);

    lock_aspect.reserve(number);


    autosize.reserve(number);
    autosize_mode.reserve(number);

    for (int i=0;i<number;i++){
        data[i]=d;
        column[i]=c;
        row[i]=r;

        ggrid[i]=new GraphGrid(this,data[i],column[i],row[i]);
        ggrid[i]->setPos(0,-plot_Size_Y);
        this->addItem(ggrid[i]);


        gdata[i]=new GraphData(this,data[i],column[i],row[i]);
        gdata[i]->setPos(0,-plot_Size_Y);
        this->addItem(gdata[i]);




        ggrid[i]->setSize(plot_Size_X,plot_Size_Y/number);
        gdata[i]->setSize(plot_Size_X,plot_Size_Y/number);

        ggrid[i]->setPos(0,-plot_Size_Y/2+i*(plot_Size_Y/number)+(plot_Size_Y/number)/2);
        gdata[i]->setPos(0,-plot_Size_Y/2+i*(plot_Size_Y/number)+(plot_Size_Y/number)/2);

        titel[i]=new QString;
        titel_x[i]=new QString;
        titel_y[i]=new QString;
        path[i]=new QString;
        titel[i]->append("Plot");
        titel_x[i]->append("X(Y)");
        titel_y[i]->append("Y(X)");
        path[i]->append("");
        textsize[i]=12;
        titelsize[i]=12;
        margin[i]=0;
        dat_com[i]=NULL;
        com_mode[i]=0;
        com_hide[i]=0;
        dat_label[i]=NULL;
        label_mode[i]=0;
        usemode[i]=0;
        useflag[i]=0;
        factor_x[i]=1;
        factor_y[i]=1;
        fix_x[i]=false;
        fix_y[i]=false;
        col_dat[i]=NULL;
        color[i]=0;
        data_err[i]=0;
        data_err2[i]=0;
        error[i]=0;
        error2[i]=0;
        data_mark[i]=0;
        marker[i]=0;
        symbol_size[i]=5;
        line_width[i]=1;
        line_style[i]=Qt::SolidLine;
        line_color[i]=Qt::black;
        marker_x[i]=NAN;
        marker_y[i]=NAN;
        marker_mode[i]=0;

        setcolor_mode[i]=0;
        setlinecolor_mode[i]=0;
        setlinewidth_mode[i]=0;
        setsymbolsize_mode[i]=0;
        setsymboltype_mode[i]=0;
        setlinestyle_mode[i]=0;
        setcolor_color[i]=NULL;
        setlinecolor_color[i]=NULL;
        setsymbolsize[i]=NULL;
        setlinewidth[i]=NULL;
        setlinestyle[i]=NULL;
        autosize_mode[i]=0;
        autosize[i]=NULL;


        setpoly_mode[i]=0;
        setpoly[i]=NULL;
        setarea_mode[i]=0;
        setarea_x[i]=NULL;
        setarea_y[i]=NULL;

        x_min[i]=-1;
        y_min[i]=-1;
        x_max[i]=1;
        y_max[i]=1;

        x_axis_type[i]=0;
        y_axis_type[i]=0;

        background[i]=0;
        background_filename[i]=new QString();
        background_filename[i]->append("");
        background_fileimage[i]=NULL;
        background_image[i]=NULL;

        background_x1[i]=0;
        background_x2[i]=0;
        background_y1[i]=0;
        background_y2[i]=0;

        repeat_x[i]=0;
        repeat_x1[i]=-3.40282e+38;
        repeat_x2[i]=3.40282e+38;
        repeat_y[i]=0;
        repeat_y1[i]=-3.40282e+38;
        repeat_y2[i]=3.40282e+38;

        limit_x1[i]=-3.40282e+38;
        limit_x2[i]=3.40282e+38;
        limit_y1[i]=-3.40282e+38;
        limit_y2[i]=3.40282e+38;

        lock_aspect[i]=0;
        fold_x[i]=0;
        fold_y[i]=0;
    }
    key_flag=0;
    frame_x1=0;
    frame_x2=0;
    frame_y1=0;
    frame_y2=0;



    gobject=new GraphObject(this);
    gobject->setPos(0,0);
    this->addItem(gobject);

    gobject->setParameters(plot_Size_X,plot_Size_Y,number,&textsize[0],&titelsize[0],&margin[0],&x_min[0],&y_min[0],&x_max[0],&y_max[0],&factor_x[0],&factor_y[0]);

    this->autoSize();

    set=new GraphSettings(diag,gdata[0],ggrid[0]);


    header=new QStringList;
    err=new float[0];
    dataedit=new DataEdit(diag,data[0],err,column[0],row[0]);

    ggg=new GraphObject(this);
    gg=new GraphGrid(this,data[0],column[0],row[0]);
    gd=new GraphData(this,data[0],column[0],row[0]);
    gdisplay=new GraphDisplay(diag,gd,gg);
}

Graph::~Graph()
{
    deleteAll();
    delete set;
    delete gobject;// is added to this-> maybe not necessary
    delete header;
    delete[] err;
    delete dataedit;

    delete ggg;
    delete gg;
    delete gd;

    delete gdisplay;
}

void Graph::deleteAll(){
    for (int i=0;ggrid.size();i++) delete ggrid[i];
    for (int i=0;gdata.size();i++) delete gdata[i];


    for (int i=0;titel.size();i++) delete titel[i];
    for (int i=0;titel_x.size();i++) delete titel_x[i];
    for (int i=0;titel_y.size();i++) delete titel_y[i];
    for (int i=0;path.size();i++) delete path[i];

    for (int i=0;background_filename.size();i++) delete background_filename[i];
}

void Graph::setNumber(int n){
    deleteAll();
    this->clear();
    number=n;

    // Generate plots
    x_min.reserve(number);
    y_min.reserve(number);
    x_max.reserve(number);
    y_max.reserve(number);
    x_axis_type.reserve(number);
    y_axis_type.reserve(number);
    ggrid.reserve(number);
    gdata.reserve(number);
    data.reserve(number);
    data_err.reserve(number);
    data_err2.reserve(number);
    error.reserve(number);
    error2.reserve(number);
    column.reserve(number);
    row.reserve(number);
    titel.reserve(number);
    titel_x.reserve(number);
    titel_y.reserve(number);
    path.reserve(number);
    textsize.reserve(number);
    titelsize.reserve(number);
    margin.reserve(number);
    dat_com.reserve(number);
    com_mode.reserve(number);
    com_hide.reserve(number);
    dat_label.reserve(number);
    label_mode.reserve(number);
    usemode.reserve(number);
    useflag.reserve(number);
    factor_x.reserve(number);
    factor_y.reserve(number);
    fix_x.reserve(number);
    fix_y.reserve(number);
    col_dat.reserve(number);
    color.reserve(number);
    data_mark.reserve(number);
    marker.reserve(number);
    symbol_size.reserve(number);
    line_width.reserve(number);
    line_style.reserve(number);
    line_color.reserve(number);
    marker_x.reserve(number);
    marker_y.reserve(number);
    marker_mode.reserve(number);
    setcolor_mode.reserve(number);
    setlinecolor_mode.reserve(number);
    setlinewidth_mode.reserve(number);
    setsymbolsize_mode.reserve(number);
    setsymboltype_mode.reserve(number);
    setlinestyle_mode.reserve(number);
    setcolor_color.reserve(number);
    setlinecolor_color.reserve(number);
    setsymbolsize.reserve(number);
    setsymboltype.reserve(number);
    setlinewidth.reserve(number);
    setlinestyle.reserve(number);
    setpoly_mode.reserve(number);
    setpoly.reserve(number);
    setarea_mode.reserve(number);
    setarea_x.reserve(number);
    setarea_y.reserve(number);
    background.reserve(number);
    background_filename.reserve(number);
    background_fileimage.reserve(number);
    background_image.reserve(number);
    background_x1.reserve(number);
    background_x2.reserve(number);
    background_y1.reserve(number);
    background_y2.reserve(number);
    repeat_x.reserve(number);
    repeat_x1.reserve(number);
    repeat_x2.reserve(number);
    repeat_y.reserve(number);
    repeat_y1.reserve(number);
    repeat_y2.reserve(number);
    limit_x1.reserve(number);
    limit_x2.reserve(number);
    limit_y1.reserve(number);
    limit_y2.reserve(number);
    fold_x.reserve(number);
    fold_y.reserve(number);
    lock_aspect.reserve(number);
    autosize.reserve(number);
    autosize_mode.reserve(number);
    for (int i=0;i<number;i++){
        data[i]=0;
        column[i]=0;
        row[i]=0;

        ggrid[i]=new GraphGrid(this,data[i],column[i],row[i]);
        ggrid[i]->setPos(0,-plot_Size_Y);
        this->addItem(ggrid[i]);


        gdata[i]=new GraphData(this,data[i],column[i],row[i]);
        gdata[i]->setPos(0,-plot_Size_Y);
        this->addItem(gdata[i]);

        ggrid[i]->setSize(plot_Size_X,plot_Size_Y/number);
        gdata[i]->setSize(plot_Size_X,plot_Size_Y/number);

        ggrid[i]->setPos(0,-plot_Size_Y/2+i*(plot_Size_Y/number)+(plot_Size_Y/number)/2);
        gdata[i]->setPos(0,-plot_Size_Y/2+i*(plot_Size_Y/number)+(plot_Size_Y/number)/2);


        titel[i]=new QString;
        titel_x[i]=new QString;
        titel_y[i]=new QString;
        path[i]=new QString;
        titel[i]->append("Plot");
        titel_x[i]->append("X(Y)");
        titel_y[i]->append("Y(X)");
        path[i]->append("");
        textsize[i]=12;
        titelsize[i]=12;
        margin[i]=0;
        dat_com[i]=NULL;
        com_mode[i]=0;
        com_hide[i]=0;
        dat_label[i]=NULL;
        label_mode[i]=0;
        usemode[i]=0;
        useflag[i]=0;
        factor_x[i]=1;
        factor_y[i]=1;
        fix_x[i]=false;
        fix_y[i]=false;
        col_dat[i]=NULL;
        color[i]=0;
        data_err[i]=0;
        data_err2[i]=0;
        error[i]=0;
        error2[i]=0;
        data_mark[i]=0;
        marker[i]=0;
        symbol_size[i]=5;
        line_width[i]=1;
        line_style[i]=Qt::SolidLine;
        line_color[i]=Qt::black;
        marker_x[i]=NAN;
        marker_y[i]=NAN;
        marker_mode[i]=0;
        setcolor_mode[i]=0;
        setlinecolor_mode[i]=0;
        setlinewidth_mode[i]=0;
        setsymbolsize_mode[i]=0;
        setsymboltype_mode[i]=0;
        setlinestyle_mode[i]=0;
        setcolor_color[i]=NULL;
        setlinecolor_color[i]=NULL;
        setsymbolsize[i]=NULL;
        setsymboltype[i]=NULL;
        setlinewidth[i]=NULL;
        setlinestyle[i]=NULL;
        setpoly_mode[i]=0;
        setpoly[i]=NULL;
        setarea_mode[i]=0;
        setarea_x[i]=NULL;
        setarea_y[i]=NULL;
        x_min[i]=-1;
        y_min[i]=-1;
        x_max[i]=1;
        y_max[i]=1;
        x_axis_type[i]=0;
        y_axis_type[i]=0;
        background[i]=0;
        background_filename[i]=new QString();
        background_filename[i]->append("");
        background_fileimage[i]=NULL;
        background_image[i]=NULL;
        background_x1[i]=0;
        background_x2[i]=0;
        background_y1[i]=0;
        background_y2[i]=0;
        repeat_x[i]=0;
        repeat_x1[i]=-3.40282e+38;
        repeat_x2[i]=3.40282e+38;
        repeat_y[i]=0;
        repeat_y1[i]=-3.40282e+38;
        repeat_y2[i]=3.40282e+38;

        limit_x1[i]=-3.40282e+38;
        limit_x2[i]=3.40282e+38;
        limit_y1[i]=-3.40282e+38;
        limit_y2[i]=3.40282e+38;
        lock_aspect[i]=0;
        fold_x[i]=0;
        fold_y[i]=0;

        autosize_mode[i]=0;
        autosize[i]=NULL;

    }

    gobject=new GraphObject(this);
    gobject->setPos(0,0);
    this->addItem(gobject);
    gobject->setParameters(plot_Size_X,plot_Size_Y,number,&textsize[0],&titelsize[0],&margin[0],&x_min[0],&y_min[0],&x_max[0],&y_max[0],&factor_x[0],&factor_y[0]);

}

// Sets the data array. Its one dim, but you have to give columns and rows
void Graph::setData(float *d,int c,int r){
    data[0]=d;
    column[0]=c;
    row[0]=r;

    ggrid[0]->setData(data[0],column[0],row[0]);
    gdata[0]->setData(data[0],column[0],row[0]);
    error[0]=0;
    error2[0]=0;
    // maybe all must be reset to defaults!!!!

    update();

}

void Graph::setData(float *d,int c,int r,int n){
    data[n]=d;
    column[n]=c;
    row[n]=r;

    ggrid[n]->setData(data[n],column[n],row[n]);
    gdata[n]->setData(data[n],column[n],row[n]);
    error[n]=0;
    error2[n]=0;

    update();

}


void Graph::setError(float *d_e,int m){
    data_err[0]=d_e;
    error[0]=m;
    gdata[0]->setError(data_err[0],error[0]);
}

void Graph::setError2(float *d_e,int m){
    data_err2[0]=d_e;
    error2[0]=m;
    gdata[0]->setError2(data_err2[0],error2[0]);
}

void Graph::setError(float *d_e,int m,int n){
    data_err[n]=d_e;
    error[n]=m;
    gdata[n]->setError(data_err[n],error[n]);
}

void Graph::setError2(float *d_e,int m,int n){
    data_err2[n]=d_e;
    error2[n]=m;
    gdata[n]->setError2(data_err2[n],error2[n]);
}

void Graph::setComment(QString *s, int m){
    dat_com[0]=s;
    com_mode[0]=m;
    gdata[0]->setComment(s,m);

}

void Graph::setComment(QString *s, int m,int n){
    dat_com[n]=s;
    com_mode[n]=m;
    gdata[n]->setComment(s,m);
}

void Graph::setLabel(QString *s, int m){
    dat_label[0]=s;
    label_mode[0]=m;
    gdata[0]->setLabel(s,m);

}

void Graph::setLabel(QString *s, int m,int n){
    dat_label[n]=s;
    label_mode[n]=m;
    gdata[n]->setLabel(s,m);
}

void Graph::setColor(QColor *c,bool m){
    col_dat[0]=c;
    color[0]=m;
    gdata[0]->setColor(col_dat[0],color[0]);
}

void Graph::setColor(QColor *c,bool m,int n){
    col_dat[n]=c;
    color[n]=m;
    gdata[n]->setColor(col_dat[n],color[n]);
}

// Set Use Condition : true means to use point
// mode: 0 = no Use Mode
//       1 = Points Visible but crossed
//       2 = Points ignored completly
void Graph::setUse(bool *u,int m){
    useflag[0]=u;
    usemode[0]=m;
    gdata[0]->setUse(u,m);
}

void Graph::setUse(bool *u,int m,int n){
    useflag[n]=u;
    usemode[n]=m;
    gdata[n]->setUse(u,m);
}

// set Size of Plot in pixels
void Graph::setSize(int x,int y){
    plot_Size_X=x;
    plot_Size_Y=y;
    this->setSceneRect(-plot_Size_X/2+1,-plot_Size_Y/2+1,plot_Size_X-2,plot_Size_Y-2);
    for (int i=0;i<number;i++){
        ggrid[i]->setSize(x,y/number);
        gdata[i]->setSize(x,y/number);

        ggrid[i]->setPos(0,-plot_Size_Y/2+i*(plot_Size_Y/number)+(plot_Size_Y/number)/2);
        gdata[i]->setPos(0,-plot_Size_Y/2+i*(plot_Size_Y/number)+(plot_Size_Y/number)/2);


        x_min[i]=gdata[i]->get_x_min();
        x_max[i]=gdata[i]->get_x_max();
        y_min[i]=gdata[i]->get_y_min();
        y_max[i]=gdata[i]->get_y_max();

        double new_x_min=x_min[i],new_y_min=y_min[i],new_x_max=x_max[i],new_y_max=y_max[i];
        calcFrame(i);

        // check for limits
        if (new_x_min<limit_x1[i]) {
            new_x_max=new_x_max-(new_x_min-limit_x1[i]);
            if (new_x_max>limit_x2[i]) new_x_max=limit_x2[i];
            new_x_min=limit_x1[i];
        }
        if (new_x_max>limit_x2[i]){
            new_x_min=new_x_min+(limit_x2[i]-new_x_max);
            if (new_x_min<limit_x1[i]) new_x_min=limit_x1[i];
            new_x_max=limit_x2[i];
        }
        if (new_y_min<limit_y1[i]){
            new_y_max=new_y_max-(new_y_min-limit_y1[i]);
            if (new_y_max>limit_y2[i]) new_y_max=limit_y2[i];
            new_y_min=limit_y1[i];
        }
        if (new_y_max>limit_y2[i]){
            new_y_min=new_y_min+(limit_y2[i]-new_y_max);
            if (new_y_min<limit_y1[i]) new_y_min=limit_y1[i];
            new_y_max=limit_y2[i];
        }

        // adjust aspect_ratio
        if (lock_aspect[i]==1) {// x is bound to y
            float res=(new_y_max-new_y_min)/(float)frame_size_y;
            float x=new_x_min+(new_x_max-new_x_min)/2.0;
            new_x_min=x-((float)frame_size_x*res)/2.0;
            new_x_max=x+((float)frame_size_x*res)/2.0;
        }
        if (lock_aspect[i]==2) {// y is bound to x
            float res=(new_x_max-new_x_min)/(float)frame_size_x;
            float y=new_y_min+(new_y_max-new_y_min)/2.0;
            new_y_min=y-((float)frame_size_y*res)/2.0;
            new_y_max=y+((float)frame_size_y*res)/2.0;
        }

        if (new_x_min>=limit_x1[i] && new_x_max<=limit_x2[i] && new_y_min>=limit_y1[i] && new_y_max<=limit_y2[i]){
            ggrid[i]->setView(new_x_min,new_x_max,new_y_min,new_y_max);
            gdata[i]->setView(new_x_min,new_x_max,new_y_min,new_y_max);
        }

        gobject->setParameters(plot_Size_X,plot_Size_Y,number,&textsize[0],&titelsize[0],&margin[0],&x_min[0],&y_min[0],&x_max[0],&y_max[0],&factor_x[0],&factor_y[0]);

    }
}

// Set the titels of Plot and x-y Axis
void Graph::setTitel(QString t,QString tx,QString ty){
    ggrid[0]->setTitel(t,tx,ty);
    titel[0]->clear();
    titel_x[0]->clear();
    titel_y[0]->clear();

    titel[0]->append(t);
    titel_x[0]->append(tx);
    titel_y[0]->append(ty);

}
// Set the titels of Plot and x-y Axis
void Graph::setTitel(QString t,QString tx,QString ty,int n){
    ggrid[n]->setTitel(t,tx,ty);
    titel[n]->clear();
    titel_x[n]->clear();
    titel_y[n]->clear();
    titel[n]->append(t);
    titel_x[n]->append(tx);
    titel_y[n]->append(ty);
}
// sets multiplicators for axes (use 1 for normal or -1 for invert axis)
void Graph::setMultiplicator(double fx, double fy){
    factor_x[0]=fx;
    factor_y[0]=fy;
    gdata[0]->setMultiplicator(fx,fy);
    ggrid[0]->setMultiplicator(fx,fy);
    gobject->setParameters(plot_Size_X,plot_Size_Y,number,&textsize[0],&titelsize[0],&margin[0],&x_min[0],&y_min[0],&x_max[0],&y_max[0],&factor_x[0],&factor_y[0]);
}

void Graph::setMultiplicator(double fx, double fy,int n){
    factor_x[n]=fx;
    factor_y[n]=fy;
    gdata[n]->setMultiplicator(fx,fy);
    ggrid[n]->setMultiplicator(fx,fy);
    gobject->setParameters(plot_Size_X,plot_Size_Y,number,&textsize[0],&titelsize[0],&margin[0],&x_min[0],&y_min[0],&x_max[0],&y_max[0],&factor_x[0],&factor_y[0]);

}

void Graph::setTextSize(int texts, int titels, int margins){
    textsize[0]=texts;
    titelsize[0]=titels;
    margin[0]=margins;
    gdata[0]->setTextSize(textsize[0],titelsize[0],margin[0]);
    ggrid[0]->setTextSize(textsize[0],titelsize[0],margin[0]);
    gobject->setParameters(plot_Size_X,plot_Size_Y,number,&textsize[0],&titelsize[0],&margin[0],&x_min[0],&y_min[0],&x_max[0],&y_max[0],&factor_x[0],&factor_y[0]);

}

void Graph::setTextSize(int texts, int titels, int margins,int n){
    textsize[n]=texts;
    titelsize[n]=titels;
    margin[n]=margins;
    gdata[n]->setTextSize(textsize[n],titelsize[n],margin[n]);
    ggrid[n]->setTextSize(textsize[n],titelsize[n],margin[n]);
    gobject->setParameters(plot_Size_X,plot_Size_Y,number,&textsize[0],&titelsize[0],&margin[0],&x_min[0],&y_min[0],&x_max[0],&y_max[0],&factor_x[0],&factor_y[0]);

}

void Graph::setSymbol(int size){
    symbol_size[0]=size;
    gdata[0]->setSymbol(symbol_size[0]);
}
void Graph::setSymbol(int size,int n){
    symbol_size[n]=size;
    gdata[n]->setSymbol(symbol_size[n]);
}
int Graph::getSymbol(){
    return getSymbol(0);
}
int Graph::getSymbol(int n){
    return symbol_size[n];
}

void Graph::setMark(int *d_m,int m){
    marker[0]=m;
    data_mark[0]=d_m;
    gdata[0]->setMark(data_mark[0],marker[0]);
}

void Graph::setMark(int *d_m,int m,int n){
    marker[n]=m;
    data_mark[n]=d_m;
    gdata[n]->setMark(data_mark[n],marker[n]);
}

void Graph::setLineWidth(int i){
    line_width[0]=i;
    gdata[0]->setLineWidth(line_width[0]);
}

void Graph::setLineStyle(Qt::PenStyle sty){
    line_style[0]=sty;
    gdata[0]->setLineStyle(line_style[0]);
}

void Graph::setLineColor(QColor c){
    line_color[0]=c;
    gdata[0]->setLineColor(line_color[0]);
}

void Graph::setLineWidth(int i,int n){
    line_width[n]=i;
    gdata[n]->setLineWidth(line_width[n]);
}

void Graph::setLineStyle(Qt::PenStyle sty,int n){
    line_style[n]=sty;
    gdata[n]->setLineStyle(line_style[n]);
}

void Graph::setLineColor(QColor c,int n){
    line_color[n]=c;
    gdata[n]->setLineColor(line_color[n]);
}

void Graph::addMarker(float x,float y,int m){
    marker_x[0]=x;
    marker_y[0]=y;
    marker_mode[0]=m;
    gdata[0]->addMarker(marker_x[0],marker_y[0],marker_mode[0]);
    update();
}

void Graph::addMarker(float x,float y,int m,int n){
    marker_x[n]=x;
    marker_y[n]=y;
    marker_mode[n]=m;
    gdata[n]->addMarker(marker_x[n],marker_y[n],marker_mode[n]);
    update();
}

void Graph::setSetColor(QColor *c,int m){
    setcolor_mode[0]=m;
    setcolor_color[0]=c;
    gdata[0]->setSetColor(setcolor_color[0],setcolor_mode[0]);
}

void Graph::setSetLineColor(QColor *c,int m){
    setlinecolor_mode[0]=m;
    setlinecolor_color[0]=c;
    gdata[0]->setSetLineColor(setlinecolor_color[0],setlinecolor_mode[0]);
}

void Graph::setSetLineWidth(int *s,int m){
    setlinewidth_mode[0]=m;
    setlinewidth[0]=s;
    gdata[0]->setSetLineWidth(setlinewidth[0],setlinewidth_mode[0]);
}

void Graph::setSetSymbolsize(int *s,int m){
    setsymbolsize_mode[0]=m;
    setsymbolsize[0]=s;
    gdata[0]->setSetSymbolsize(setsymbolsize[0],setsymbolsize_mode[0]);
}

void Graph::setSetLineStyle(Qt::PenStyle *s, int m){
    setlinestyle_mode[0]=m;
    setlinestyle[0]=s;
    gdata[0]->setSetLineStyle(setlinestyle[0],setlinestyle_mode[0]);
}

void Graph::setSetColor(QColor *c,int m,int n){
    setcolor_mode[n]=m;
    setcolor_color[n]=c;
    gdata[n]->setSetColor(setcolor_color[n],setcolor_mode[n]);
}

void Graph::setSetLineColor(QColor *c,int m,int n){
    setlinecolor_mode[n]=m;
    setlinecolor_color[n]=c;
    gdata[n]->setSetLineColor(setlinecolor_color[n],setlinecolor_mode[n]);
}

void Graph::setSetLineWidth(int *s,int m,int n){
    setlinewidth_mode[n]=m;
    setlinewidth[n]=s;
    gdata[n]->setSetLineWidth(setlinewidth[n],setlinewidth_mode[n]);
}

void Graph::setSetSymbolsize(int *s,int m,int n){
    setsymbolsize_mode[n]=m;
    setsymbolsize[n]=s;
    gdata[n]->setSetSymbolsize(setsymbolsize[n],setsymbolsize_mode[n]);
}

void Graph::setSetSymboltype(int *t,int m){
    setsymboltype_mode[0]=m;
    setsymboltype[0]=t;
    gdata[0]->setSetSymboltype(setsymboltype[0],setsymboltype_mode[0]);
}

void Graph::setSetSymboltype(int *t,int m,int n){
    setsymboltype_mode[n]=m;
    setsymboltype[n]=t;
    gdata[n]->setSetSymboltype(setsymboltype[n],setsymboltype_mode[n]);
}

void Graph::setSetLineStyle(Qt::PenStyle *s, int m,int n){
    setlinestyle_mode[n]=m;
    setlinestyle[n]=s;
    gdata[n]->setSetLineStyle(setlinestyle[n],setlinestyle_mode[n]);
}


void Graph::setSetPoly(int *s,int m){
    setpoly_mode[0]=m;
    setpoly[0]=s;
    gdata[0]->setSetPoly(setpoly[0],setpoly_mode[0]);
}

void Graph::setSetArea(float* area_x,float* area_y,int area_mode){
    setarea_mode[0]=area_mode;
    setarea_x[0]=area_x;
    setarea_y[0]=area_y;
    gdata[0]->setSetArea(setarea_x[0],setarea_y[0],setarea_mode[0]);
}

void Graph::setSetPoly(int *s,int m,int n){
    setpoly_mode[n]=m;
    setpoly[n]=s;
    gdata[n]->setSetPoly(setpoly[n],setpoly_mode[n]);
}

void Graph::setSetArea(float* area_x,float* area_y,int area_mode,int n){
    setarea_mode[n]=area_mode;
    setarea_x[n]=area_x;
    setarea_y[n]=area_y;
    gdata[n]->setSetArea(setarea_x[n],setarea_y[n],setarea_mode[n]);
}

void Graph::fixRange(bool x,bool y){
    fix_x[0]=x;
    fix_y[0]=y;
}

void Graph::fixRange(bool x,bool y,int n){
    fix_x[n]=x;
    fix_y[n]=y;
}

void Graph::setAutosize(int* as,int as_m){
    setAutosize(as,as_m,0);
}

void Graph::setAutosize(int* as,int as_m,int n){
    autosize[n]=as;
    autosize_mode[n]=as_m;
}

// Autosize on all Data
void Graph::autoSize(){
    autoSize(0);
}

void Graph::autoSize(int n){
    x_min[n]=3.40282e+38;
    x_max[n]=-3.40282e+38;
    y_min[n]=3.40282e+38;
    y_max[n]=-3.40282e+38;
    for (int j=0;j<column[n];j=j+2){
        if (autosize_mode[n]>0){
            if (autosize[n][j]==1){
            for (int i=0;i<row[n];i++){
                if (std::isnan(data[n][i+j*row[n]])==0 && std::isnan(data[n][i+(j+1)*row[n]])==0 && usemode[n]!=2){
                    if (error2[n]==0){
                        if (error[n]==0){
                            if (x_min[n]>data[n][i+j*row[n]]*factor_x[n]) x_min[n]=data[n][i+j*row[n]]*factor_x[n];
                            if (x_max[n]<data[n][i+j*row[n]]*factor_x[n]) x_max[n]=data[n][i+j*row[n]]*factor_x[n];
                            if (y_min[n]>data[n][i+(j+1)*row[n]]*factor_y[n]) y_min[n]=data[n][i+(j+1)*row[n]]*factor_y[n];
                            if (y_max[n]<data[n][i+(j+1)*row[n]]*factor_y[n]) y_max[n]=data[n][i+(j+1)*row[n]]*factor_y[n];
                        } else {
                            float x_err=data_err[n][i+j*row[n]];
                            float y_err=data_err[n][i+(j+1)*row[n]];
                            if (std::isnan(data_err[n][i+(j)*row[n]])) x_err=0;
                            if (std::isnan(data_err[n][i+(j+1)*row[n]])) y_err=0;
                            if (error[n]==1){
                                if (x_min[n]>(data[n][i+j*row[n]]*factor_x[n]-x_err*abs(factor_x[n]))) x_min[n]=(data[n][i+j*row[n]]*factor_x[n]-x_err*abs(factor_x[n]));
                                if (x_max[n]<(data[n][i+j*row[n]]*factor_x[n]+x_err*abs(factor_x[n]))) x_max[n]=(data[n][i+j*row[n]]*factor_x[n]+x_err*abs(factor_x[n]));
                                if (y_min[n]>(data[n][i+(j+1)*row[n]])*factor_y[n]) y_min[n]=(data[n][i+(j+1)*row[n]])*factor_y[n];
                                if (y_max[n]<(data[n][i+(j+1)*row[n]])*factor_y[n]) y_max[n]=(data[n][i+(j+1)*row[n]])*factor_y[n];
                            }
                            if (error[n]==2){
                                if (x_min[n]>(data[n][i+j*row[n]])*factor_x[n]) x_min[n]=(data[n][i+j*row[n]])*factor_x[n];
                                if (x_max[n]<(data[n][i+j*row[n]])*factor_x[n]) x_max[n]=(data[n][i+j*row[n]])*factor_x[n];
                                if (y_min[n]>(data[n][i+(j+1)*row[n]]*factor_y[n]-y_err*abs(factor_y[n]))) y_min[n]=(data[n][i+(j+1)*row[n]]*factor_y[n]-y_err*abs(factor_y[n]));
                                if (y_max[n]<(data[n][i+(j+1)*row[n]]*factor_y[n]+y_err*abs(factor_y[n]))) y_max[n]=(data[n][i+(j+1)*row[n]]*factor_y[n]+y_err*abs(factor_y[n]));
                            }
                            if (error[n]==3){
                                if (x_min[n]>(data[n][i+j*row[n]]*factor_x[n]-x_err*abs(factor_x[n]))) x_min[n]=(data[n][i+j*row[n]]*factor_x[n]-x_err*abs(factor_x[n]));
                                if (x_max[n]<(data[n][i+j*row[n]]*factor_x[n]+x_err*abs(factor_x[n]))) x_max[n]=(data[n][i+j*row[n]]*factor_x[n]+x_err*abs(factor_x[n]));
                                if (y_min[n]>(data[n][i+(j+1)*row[n]]*factor_y[n]-y_err*abs(factor_y[n]))) y_min[n]=(data[n][i+(j+1)*row[n]]*factor_y[n]-y_err*abs(factor_y[n]));
                                if (y_max[n]<(data[n][i+(j+1)*row[n]]*factor_y[n]+y_err*abs(factor_y[n]))) y_max[n]=(data[n][i+(j+1)*row[n]]*factor_y[n]+y_err*abs(factor_y[n]));
                            }

                        }
                    } else {


                        float x_err=data_err[n][i+j*row[n]];
                        float y_err=data_err[n][i+(j+1)*row[n]];
                        float x_err2=data_err2[n][i+j*row[n]];
                        float y_err2=data_err2[n][i+(j+1)*row[n]];
                        if (std::isnan(data_err[n][i+(j)*row[n]])) x_err=0;
                        if (std::isnan(data_err[n][i+(j+1)*row[n]])) y_err=0;
                        if (std::isnan(data_err2[n][i+(j)*row[n]])) x_err2=0;
                        if (std::isnan(data_err2[n][i+(j+1)*row[n]])) y_err2=0;
                        if (error2[n]==1){
                            if (x_min[n]>(data[n][i+j*row[n]]-x_err)*factor_x[n]) x_min[n]=(data[n][i+j*row[n]]-x_err)*factor_x[n];
                            if (x_max[n]<(data[n][i+j*row[n]]+x_err2)*factor_x[n]) x_max[n]=(data[n][i+j*row[n]]+x_err2)*factor_x[n];
                            if (y_min[n]>(data[n][i+(j+1)*row[n]])*factor_y[n]) y_min[n]=(data[n][i+(j+1)*row[n]])*factor_y[n];
                            if (y_max[n]<(data[n][i+(j+1)*row[n]])*factor_y[n]) y_max[n]=(data[n][i+(j+1)*row[n]])*factor_y[n];
                        }
                        if (error2[n]==2){
                            if (x_min[n]>(data[n][i+j*row[n]])*factor_x[n]) x_min[n]=(data[n][i+j*row[n]])*factor_x[n];
                            if (x_max[n]<(data[n][i+j*row[n]])*factor_x[n]) x_max[n]=(data[n][i+j*row[n]])*factor_x[n];
                            if (y_min[n]>(data[n][i+(j+1)*row[n]]-y_err)*factor_y[n]) y_min[n]=(data[n][i+(j+1)*row[n]]-y_err)*factor_y[n];
                            if (y_max[n]<(data[n][i+(j+1)*row[n]]+y_err2)*factor_y[n]) y_max[n]=(data[n][i+(j+1)*row[n]]+y_err2)*factor_y[n];
                        }
                        if (error2[n]==3){

                            if (x_min[n]>(data[n][i+j*row[n]]*factor_x[n]-x_err*abs(factor_x[n]))) x_min[n]=(data[n][i+j*row[n]]*factor_x[n]-x_err*abs(factor_x[n]));
                            if (x_max[n]<(data[n][i+j*row[n]]*factor_x[n]+x_err2*abs(factor_x[n]))) x_max[n]=(data[n][i+j*row[n]]*factor_x[n]+x_err2*abs(factor_x[n]));
                            if (y_min[n]>(data[n][i+(j+1)*row[n]]*factor_y[n]-y_err*abs(factor_y[n]))) y_min[n]=(data[n][i+(j+1)*row[n]]*factor_y[n]-y_err*abs(factor_y[n]));
                            if (y_max[n]<(data[n][i+(j+1)*row[n]]*factor_y[n]+y_err2*abs(factor_y[n]))) y_max[n]=(data[n][i+(j+1)*row[n]]*factor_y[n]+y_err2*abs(factor_y[n]));
                        }

                    }
                }
                if (std::isnan(data[n][i+j*row[n]])==0 && std::isnan(data[n][i+(j+1)*row[n]])==0 && usemode[n]==2){
                    if (error2[n]==0) {
                        if (error[n]==0){
                            if (x_min[n]>data[n][i+j*row[n]]*factor_x[n]
                                    && useflag[n][i+j*row[n]]==true) x_min[n]=data[n][i+j*row[n]]*factor_x[n];
                            if (x_max[n]<data[n][i+j*row[n]]*factor_x[n]
                                    && useflag[n][i+j*row[n]]==true) x_max[n]=data[n][i+j*row[n]]*factor_x[n];
                            if (y_min[n]>data[n][i+(j+1)*row[n]]*factor_y[n]
                                    && useflag[n][i+(j+1)*row[n]]==true) y_min[n]=data[n][i+(j+1)*row[n]]*factor_y[n];
                            if (y_max[n]<data[n][i+(j+1)*row[n]]*factor_y[n]
                                    && useflag[n][i+(j+1)*row[n]]==true) y_max[n]=data[n][i+(j+1)*row[n]]*factor_y[n];
                        } else {
                            float x_err=data_err[n][i+j*row[n]];
                            float y_err=data_err[n][i+(j+1)*row[n]];
                            if (std::isnan(data_err[n][i+(j)*row[n]])) x_err=0;
                            if (std::isnan(data_err[n][i+(j+1)*row[n]])) y_err=0;
                            if (error[n]==1){
                                if (x_min[n]>(data[n][i+j*row[n]]*factor_x[n]-x_err*abs(factor_x[n]))&& useflag[n][i+(j+1)*row[n]]==true) x_min[n]=(data[n][i+j*row[n]]*factor_x[n]-x_err*abs(factor_x[n]));
                                if (x_max[n]<(data[n][i+j*row[n]]*factor_x[n]+x_err*abs(factor_x[n]))&& useflag[n][i+(j+1)*row[n]]==true) x_max[n]=(data[n][i+j*row[n]]*factor_x[n]+x_err*abs(factor_x[n]));
                                if (y_min[n]>(data[n][i+(j+1)*row[n]])*factor_y[n]
                                        && useflag[n][i+(j+1)*row[n]]==true) y_min[n]=(data[n][i+(j+1)*row[n]])*factor_y[n];
                                if (y_max[n]<(data[n][i+(j+1)*row[n]])*factor_y[n]
                                        && useflag[n][i+(j+1)*row[n]]==true) y_max[n]=(data[n][i+(j+1)*row[n]])*factor_y[n];
                            }
                            if (error[n]==2){
                                if (x_min[n]>(data[n][i+j*row[n]])*factor_x[n]
                                        && useflag[n][i+j*row[n]]==true) x_min[n]=(data[n][i+j*row[n]])*factor_x[n];
                                if (x_max[n]<(data[n][i+j*row[n]])*factor_x[n]
                                        && useflag[n][i+j*row[n]]==true) x_max[n]=(data[n][i+j*row[n]])*factor_x[n];
                                if (y_min[n]>(data[n][i+(j+1)*row[n]]*factor_y[n]-y_err*abs(factor_y[n]))&& useflag[n][i+(j+1)*row[n]]==true) y_min[n]=(data[n][i+(j+1)*row[n]]*factor_y[n]-y_err*abs(factor_y[n]));
                                if (y_max[n]<(data[n][i+(j+1)*row[n]]*factor_y[n]+y_err*abs(factor_y[n]))&& useflag[n][i+(j+1)*row[n]]==true) y_max[n]=(data[n][i+(j+1)*row[n]]*factor_y[n]+y_err*abs(factor_y[n]));
                            }
                            if (error[n]==3){
                                if (x_min[n]>(data[n][i+j*row[n]]*factor_x[n]-x_err*abs(factor_x[n]))&& useflag[n][i+(j+1)*row[n]]==true) x_min[n]=(data[n][i+j*row[n]]*factor_x[n]-x_err*abs(factor_x[n]));
                                if (x_max[n]<(data[n][i+j*row[n]]*factor_x[n]+x_err*abs(factor_x[n]))&& useflag[n][i+(j+1)*row[n]]==true) x_max[n]=(data[n][i+j*row[n]]*factor_x[n]+x_err*abs(factor_x[n]));
                                if (y_min[n]>(data[n][i+(j+1)*row[n]]*factor_y[n]-y_err*abs(factor_y[n]))&& useflag[n][i+(j+1)*row[n]]==true) y_min[n]=(data[n][i+(j+1)*row[n]]*factor_y[n]-y_err*abs(factor_y[n]));
                                if (y_max[n]<(data[n][i+(j+1)*row[n]]*factor_y[n]+y_err*abs(factor_y[n]))&& useflag[n][i+(j+1)*row[n]]==true) y_max[n]=(data[n][i+(j+1)*row[n]]*factor_y[n]+y_err*abs(factor_y[n]));

                            }
                        }
                    } else {

                        float x_err=data_err[n][i+j*row[n]];
                        float y_err=data_err[n][i+(j+1)*row[n]];
                        float x_err2=data_err2[n][i+j*row[n]];
                        float y_err2=data_err2[n][i+(j+1)*row[n]];
                        if (std::isnan(data_err[n][i+(j)*row[n]])) x_err=0;
                        if (std::isnan(data_err[n][i+(j+1)*row[n]])) y_err=0;
                        if (std::isnan(data_err2[n][i+(j)*row[n]])) x_err2=0;
                        if (std::isnan(data_err2[n][i+(j+1)*row[n]])) y_err2=0;
                        if (error2[n]==1){
                            if (x_min[n]>(data[n][i+j*row[n]]*factor_x[n]-x_err*abs(factor_x[n]))&& useflag[n][i+(j+1)*row[n]]==true) x_min[n]=(data[n][i+j*row[n]]*factor_x[n]-x_err*abs(factor_x[n]));
                            if (x_max[n]<(data[n][i+j*row[n]]*factor_x[n]+x_err2*abs(factor_x[n]))&& useflag[n][i+(j+1)*row[n]]==true) x_max[n]=(data[n][i+j*row[n]]*factor_x[n]+x_err2*abs(factor_x[n]));
                            if (y_min[n]>(data[n][i+(j+1)*row[n]])*factor_y[n]
                                    && useflag[n][i+(j+1)*row[n]]==true) y_min[n]=(data[n][i+(j+1)*row[n]])*factor_y[n];
                            if (y_max[n]<(data[n][i+(j+1)*row[n]])*factor_y[n]
                                    && useflag[n][i+(j+1)*row[n]]==true) y_max[n]=(data[n][i+(j+1)*row[n]])*factor_y[n];
                        }
                        if (error2[n]==2){
                            if (x_min[n]>(data[n][i+j*row[n]])*factor_x[n]
                                    && useflag[n][i+j*row[n]]==true) x_min[n]=(data[n][i+j*row[n]])*factor_x[n];
                            if (x_max[n]<(data[n][i+j*row[n]])*factor_x[n]
                                    && useflag[n][i+j*row[n]]==true) x_max[n]=(data[n][i+j*row[n]])*factor_x[n];
                            if (y_min[n]>(data[n][i+(j+1)*row[n]]*factor_y[n]-y_err*abs(factor_y[n]))&& useflag[n][i+(j+1)*row[n]]==true) y_min[n]=(data[n][i+(j+1)*row[n]]*factor_y[n]-y_err*abs(factor_y[n]));
                            if (y_max[n]<(data[n][i+(j+1)*row[n]]*factor_y[n]+y_err2*abs(factor_y[n]))&& useflag[n][i+(j+1)*row[n]]==true) y_max[n]=(data[n][i+(j+1)*row[n]]*factor_y[n]+y_err2*abs(factor_y[n]));
                        }
                        if (error2[n]==3){
                            if (x_min[n]>(data[n][i+j*row[n]]*factor_x[n]-x_err*abs(factor_x[n]))&& useflag[n][i+(j+1)*row[n]]==true) x_min[n]=(data[n][i+j*row[n]]*factor_x[n]-x_err*abs(factor_x[n]));
                            if (x_max[n]<(data[n][i+j*row[n]]*factor_x[n]+x_err2*abs(factor_x[n]))&& useflag[n][i+(j+1)*row[n]]==true) x_max[n]=(data[n][i+j*row[n]]*factor_x[n]+x_err2*abs(factor_x[n]));
                            if (y_min[n]>(data[n][i+(j+1)*row[n]]*factor_y[n]-y_err*abs(factor_y[n]))&& useflag[n][i+(j+1)*row[n]]==true) y_min[n]=(data[n][i+(j+1)*row[n]]*factor_y[n]-y_err*abs(factor_y[n]));
                            if (y_max[n]<(data[n][i+(j+1)*row[n]]*factor_y[n]+y_err2*abs(factor_y[n]))&& useflag[n][i+(j+1)*row[n]]==true) y_max[n]=(data[n][i+(j+1)*row[n]]*factor_y[n]+y_err2*abs(factor_y[n]));
                        }

                    }
                }
            }}
        } else {
            for (int i=0;i<row[n];i++){
                if (std::isnan(data[n][i+j*row[n]])==0 && std::isnan(data[n][i+(j+1)*row[n]])==0 && usemode[n]!=2){
                    if (error2[n]==0){
                        if (error[n]==0){
                            if (x_min[n]>data[n][i+j*row[n]]*factor_x[n]) x_min[n]=data[n][i+j*row[n]]*factor_x[n];
                            if (x_max[n]<data[n][i+j*row[n]]*factor_x[n]) x_max[n]=data[n][i+j*row[n]]*factor_x[n];
                            if (y_min[n]>data[n][i+(j+1)*row[n]]*factor_y[n]) y_min[n]=data[n][i+(j+1)*row[n]]*factor_y[n];
                            if (y_max[n]<data[n][i+(j+1)*row[n]]*factor_y[n]) y_max[n]=data[n][i+(j+1)*row[n]]*factor_y[n];
                        } else {
                            float x_err=data_err[n][i+j*row[n]];
                            float y_err=data_err[n][i+(j+1)*row[n]];
                            if (std::isnan(data_err[n][i+(j)*row[n]])) x_err=0;
                            if (std::isnan(data_err[n][i+(j+1)*row[n]])) y_err=0;
                            if (error[n]==1){
                                if (x_min[n]>(data[n][i+j*row[n]]*factor_x[n]-x_err*abs(factor_x[n]))) x_min[n]=(data[n][i+j*row[n]]*factor_x[n]-x_err*abs(factor_x[n]));
                                if (x_max[n]<(data[n][i+j*row[n]]*factor_x[n]+x_err*abs(factor_x[n]))) x_max[n]=(data[n][i+j*row[n]]*factor_x[n]+x_err*abs(factor_x[n]));
                                if (y_min[n]>(data[n][i+(j+1)*row[n]])*factor_y[n]) y_min[n]=(data[n][i+(j+1)*row[n]])*factor_y[n];
                                if (y_max[n]<(data[n][i+(j+1)*row[n]])*factor_y[n]) y_max[n]=(data[n][i+(j+1)*row[n]])*factor_y[n];
                            }
                            if (error[n]==2){
                                if (x_min[n]>(data[n][i+j*row[n]])*factor_x[n]) x_min[n]=(data[n][i+j*row[n]])*factor_x[n];
                                if (x_max[n]<(data[n][i+j*row[n]])*factor_x[n]) x_max[n]=(data[n][i+j*row[n]])*factor_x[n];
                                if (y_min[n]>(data[n][i+(j+1)*row[n]]*factor_y[n]-y_err*abs(factor_y[n]))) y_min[n]=(data[n][i+(j+1)*row[n]]*factor_y[n]-y_err*abs(factor_y[n]));
                                if (y_max[n]<(data[n][i+(j+1)*row[n]]*factor_y[n]+y_err*abs(factor_y[n]))) y_max[n]=(data[n][i+(j+1)*row[n]]*factor_y[n]+y_err*abs(factor_y[n]));
                            }
                            if (error[n]==3){
                                if (x_min[n]>(data[n][i+j*row[n]]*factor_x[n]-x_err*abs(factor_x[n]))) x_min[n]=(data[n][i+j*row[n]]*factor_x[n]-x_err*abs(factor_x[n]));
                                if (x_max[n]<(data[n][i+j*row[n]]*factor_x[n]+x_err*abs(factor_x[n]))) x_max[n]=(data[n][i+j*row[n]]*factor_x[n]+x_err*abs(factor_x[n]));
                                if (y_min[n]>(data[n][i+(j+1)*row[n]]*factor_y[n]-y_err*abs(factor_y[n]))) y_min[n]=(data[n][i+(j+1)*row[n]]*factor_y[n]-y_err*abs(factor_y[n]));
                                if (y_max[n]<(data[n][i+(j+1)*row[n]]*factor_y[n]+y_err*abs(factor_y[n]))) y_max[n]=(data[n][i+(j+1)*row[n]]*factor_y[n]+y_err*abs(factor_y[n]));
                            }

                        }
                    } else {


                        float x_err=data_err[n][i+j*row[n]];
                        float y_err=data_err[n][i+(j+1)*row[n]];
                        float x_err2=data_err2[n][i+j*row[n]];
                        float y_err2=data_err2[n][i+(j+1)*row[n]];
                        if (std::isnan(data_err[n][i+(j)*row[n]])) x_err=0;
                        if (std::isnan(data_err[n][i+(j+1)*row[n]])) y_err=0;
                        if (std::isnan(data_err2[n][i+(j)*row[n]])) x_err2=0;
                        if (std::isnan(data_err2[n][i+(j+1)*row[n]])) y_err2=0;
                        if (error2[n]==1){
                            if (x_min[n]>(data[n][i+j*row[n]]-x_err)*factor_x[n]) x_min[n]=(data[n][i+j*row[n]]-x_err)*factor_x[n];
                            if (x_max[n]<(data[n][i+j*row[n]]+x_err2)*factor_x[n]) x_max[n]=(data[n][i+j*row[n]]+x_err2)*factor_x[n];
                            if (y_min[n]>(data[n][i+(j+1)*row[n]])*factor_y[n]) y_min[n]=(data[n][i+(j+1)*row[n]])*factor_y[n];
                            if (y_max[n]<(data[n][i+(j+1)*row[n]])*factor_y[n]) y_max[n]=(data[n][i+(j+1)*row[n]])*factor_y[n];
                        }
                        if (error2[n]==2){
                            if (x_min[n]>(data[n][i+j*row[n]])*factor_x[n]) x_min[n]=(data[n][i+j*row[n]])*factor_x[n];
                            if (x_max[n]<(data[n][i+j*row[n]])*factor_x[n]) x_max[n]=(data[n][i+j*row[n]])*factor_x[n];
                            if (y_min[n]>(data[n][i+(j+1)*row[n]]-y_err)*factor_y[n]) y_min[n]=(data[n][i+(j+1)*row[n]]-y_err)*factor_y[n];
                            if (y_max[n]<(data[n][i+(j+1)*row[n]]+y_err2)*factor_y[n]) y_max[n]=(data[n][i+(j+1)*row[n]]+y_err2)*factor_y[n];
                        }
                        if (error2[n]==3){

                            if (x_min[n]>(data[n][i+j*row[n]]*factor_x[n]-x_err*abs(factor_x[n]))) x_min[n]=(data[n][i+j*row[n]]*factor_x[n]-x_err*abs(factor_x[n]));
                            if (x_max[n]<(data[n][i+j*row[n]]*factor_x[n]+x_err2*abs(factor_x[n]))) x_max[n]=(data[n][i+j*row[n]]*factor_x[n]+x_err2*abs(factor_x[n]));
                            if (y_min[n]>(data[n][i+(j+1)*row[n]]*factor_y[n]-y_err*abs(factor_y[n]))) y_min[n]=(data[n][i+(j+1)*row[n]]*factor_y[n]-y_err*abs(factor_y[n]));
                            if (y_max[n]<(data[n][i+(j+1)*row[n]]*factor_y[n]+y_err2*abs(factor_y[n]))) y_max[n]=(data[n][i+(j+1)*row[n]]*factor_y[n]+y_err2*abs(factor_y[n]));
                        }

                    }
                }
                if (std::isnan(data[n][i+j*row[n]])==0 && std::isnan(data[n][i+(j+1)*row[n]])==0 && usemode[n]==2){
                    if (error2[n]==0) {
                        if (error[n]==0){
                            if (x_min[n]>data[n][i+j*row[n]]*factor_x[n]
                                    && useflag[n][i+j*row[n]]==true) x_min[n]=data[n][i+j*row[n]]*factor_x[n];
                            if (x_max[n]<data[n][i+j*row[n]]*factor_x[n]
                                    && useflag[n][i+j*row[n]]==true) x_max[n]=data[n][i+j*row[n]]*factor_x[n];
                            if (y_min[n]>data[n][i+(j+1)*row[n]]*factor_y[n]
                                    && useflag[n][i+(j+1)*row[n]]==true) y_min[n]=data[n][i+(j+1)*row[n]]*factor_y[n];
                            if (y_max[n]<data[n][i+(j+1)*row[n]]*factor_y[n]
                                    && useflag[n][i+(j+1)*row[n]]==true) y_max[n]=data[n][i+(j+1)*row[n]]*factor_y[n];
                        } else {
                            float x_err=data_err[n][i+j*row[n]];
                            float y_err=data_err[n][i+(j+1)*row[n]];
                            if (std::isnan(data_err[n][i+(j)*row[n]])) x_err=0;
                            if (std::isnan(data_err[n][i+(j+1)*row[n]])) y_err=0;
                            if (error[n]==1){
                                if (x_min[n]>(data[n][i+j*row[n]]*factor_x[n]-x_err*abs(factor_x[n]))&& useflag[n][i+(j+1)*row[n]]==true) x_min[n]=(data[n][i+j*row[n]]*factor_x[n]-x_err*abs(factor_x[n]));
                                if (x_max[n]<(data[n][i+j*row[n]]*factor_x[n]+x_err*abs(factor_x[n]))&& useflag[n][i+(j+1)*row[n]]==true) x_max[n]=(data[n][i+j*row[n]]*factor_x[n]+x_err*abs(factor_x[n]));
                                if (y_min[n]>(data[n][i+(j+1)*row[n]])*factor_y[n]
                                        && useflag[n][i+(j+1)*row[n]]==true) y_min[n]=(data[n][i+(j+1)*row[n]])*factor_y[n];
                                if (y_max[n]<(data[n][i+(j+1)*row[n]])*factor_y[n]
                                        && useflag[n][i+(j+1)*row[n]]==true) y_max[n]=(data[n][i+(j+1)*row[n]])*factor_y[n];
                            }
                            if (error[n]==2){
                                if (x_min[n]>(data[n][i+j*row[n]])*factor_x[n]
                                        && useflag[n][i+j*row[n]]==true) x_min[n]=(data[n][i+j*row[n]])*factor_x[n];
                                if (x_max[n]<(data[n][i+j*row[n]])*factor_x[n]
                                        && useflag[n][i+j*row[n]]==true) x_max[n]=(data[n][i+j*row[n]])*factor_x[n];
                                if (y_min[n]>(data[n][i+(j+1)*row[n]]*factor_y[n]-y_err*abs(factor_y[n]))&& useflag[n][i+(j+1)*row[n]]==true) y_min[n]=(data[n][i+(j+1)*row[n]]*factor_y[n]-y_err*abs(factor_y[n]));
                                if (y_max[n]<(data[n][i+(j+1)*row[n]]*factor_y[n]+y_err*abs(factor_y[n]))&& useflag[n][i+(j+1)*row[n]]==true) y_max[n]=(data[n][i+(j+1)*row[n]]*factor_y[n]+y_err*abs(factor_y[n]));
                            }
                            if (error[n]==3){
                                if (x_min[n]>(data[n][i+j*row[n]]*factor_x[n]-x_err*abs(factor_x[n]))&& useflag[n][i+(j+1)*row[n]]==true) x_min[n]=(data[n][i+j*row[n]]*factor_x[n]-x_err*abs(factor_x[n]));
                                if (x_max[n]<(data[n][i+j*row[n]]*factor_x[n]+x_err*abs(factor_x[n]))&& useflag[n][i+(j+1)*row[n]]==true) x_max[n]=(data[n][i+j*row[n]]*factor_x[n]+x_err*abs(factor_x[n]));
                                if (y_min[n]>(data[n][i+(j+1)*row[n]]*factor_y[n]-y_err*abs(factor_y[n]))&& useflag[n][i+(j+1)*row[n]]==true) y_min[n]=(data[n][i+(j+1)*row[n]]*factor_y[n]-y_err*abs(factor_y[n]));
                                if (y_max[n]<(data[n][i+(j+1)*row[n]]*factor_y[n]+y_err*abs(factor_y[n]))&& useflag[n][i+(j+1)*row[n]]==true) y_max[n]=(data[n][i+(j+1)*row[n]]*factor_y[n]+y_err*abs(factor_y[n]));

                            }
                        }
                    } else {

                        float x_err=data_err[n][i+j*row[n]];
                        float y_err=data_err[n][i+(j+1)*row[n]];
                        float x_err2=data_err2[n][i+j*row[n]];
                        float y_err2=data_err2[n][i+(j+1)*row[n]];
                        if (std::isnan(data_err[n][i+(j)*row[n]])) x_err=0;
                        if (std::isnan(data_err[n][i+(j+1)*row[n]])) y_err=0;
                        if (std::isnan(data_err2[n][i+(j)*row[n]])) x_err2=0;
                        if (std::isnan(data_err2[n][i+(j+1)*row[n]])) y_err2=0;
                        if (error2[n]==1){
                            if (x_min[n]>(data[n][i+j*row[n]]*factor_x[n]-x_err*abs(factor_x[n]))&& useflag[n][i+(j+1)*row[n]]==true) x_min[n]=(data[n][i+j*row[n]]*factor_x[n]-x_err*abs(factor_x[n]));
                            if (x_max[n]<(data[n][i+j*row[n]]*factor_x[n]+x_err2*abs(factor_x[n]))&& useflag[n][i+(j+1)*row[n]]==true) x_max[n]=(data[n][i+j*row[n]]*factor_x[n]+x_err2*abs(factor_x[n]));
                            if (y_min[n]>(data[n][i+(j+1)*row[n]])*factor_y[n]
                                    && useflag[n][i+(j+1)*row[n]]==true) y_min[n]=(data[n][i+(j+1)*row[n]])*factor_y[n];
                            if (y_max[n]<(data[n][i+(j+1)*row[n]])*factor_y[n]
                                    && useflag[n][i+(j+1)*row[n]]==true) y_max[n]=(data[n][i+(j+1)*row[n]])*factor_y[n];
                        }
                        if (error2[n]==2){
                            if (x_min[n]>(data[n][i+j*row[n]])*factor_x[n]
                                    && useflag[n][i+j*row[n]]==true) x_min[n]=(data[n][i+j*row[n]])*factor_x[n];
                            if (x_max[n]<(data[n][i+j*row[n]])*factor_x[n]
                                    && useflag[n][i+j*row[n]]==true) x_max[n]=(data[n][i+j*row[n]])*factor_x[n];
                            if (y_min[n]>(data[n][i+(j+1)*row[n]]*factor_y[n]-y_err*abs(factor_y[n]))&& useflag[n][i+(j+1)*row[n]]==true) y_min[n]=(data[n][i+(j+1)*row[n]]*factor_y[n]-y_err*abs(factor_y[n]));
                            if (y_max[n]<(data[n][i+(j+1)*row[n]]*factor_y[n]+y_err2*abs(factor_y[n]))&& useflag[n][i+(j+1)*row[n]]==true) y_max[n]=(data[n][i+(j+1)*row[n]]*factor_y[n]+y_err2*abs(factor_y[n]));
                        }
                        if (error2[n]==3){
                            if (x_min[n]>(data[n][i+j*row[n]]*factor_x[n]-x_err*abs(factor_x[n]))&& useflag[n][i+(j+1)*row[n]]==true) x_min[n]=(data[n][i+j*row[n]]*factor_x[n]-x_err*abs(factor_x[n]));
                            if (x_max[n]<(data[n][i+j*row[n]]*factor_x[n]+x_err2*abs(factor_x[n]))&& useflag[n][i+(j+1)*row[n]]==true) x_max[n]=(data[n][i+j*row[n]]*factor_x[n]+x_err2*abs(factor_x[n]));
                            if (y_min[n]>(data[n][i+(j+1)*row[n]]*factor_y[n]-y_err*abs(factor_y[n]))&& useflag[n][i+(j+1)*row[n]]==true) y_min[n]=(data[n][i+(j+1)*row[n]]*factor_y[n]-y_err*abs(factor_y[n]));
                            if (y_max[n]<(data[n][i+(j+1)*row[n]]*factor_y[n]+y_err2*abs(factor_y[n]))&& useflag[n][i+(j+1)*row[n]]==true) y_max[n]=(data[n][i+(j+1)*row[n]]*factor_y[n]+y_err2*abs(factor_y[n]));
                        }

                    }
                }
            }
        }
    }
    x_min[n]-=(x_max[n]-x_min[n])*0.05;
    x_max[n]+=(x_max[n]-x_min[n])*0.05;
    y_min[n]-=(y_max[n]-y_min[n])*0.05;
    y_max[n]+=(y_max[n]-y_min[n])*0.05;
    if (x_min[n]==x_max[n]) {
        x_min[n]-=1;
        x_max[n]+=1;
    }
    if (y_min[n]==y_max[n]){
        y_min[n]-=1;
        y_max[n]+=1;
    }

    calcFrame(n);
    // adjust aspect_ratio
    if (lock_aspect[n]==1) {// x is bound to y
        float res=(y_max[n]-y_min[n])/(float)frame_size_y;
        float x=x_min[n]+(x_max[n]-x_min[n])/2.0;
        x_min[n]=x-((float)frame_size_x*res)/2.0;
        x_max[n]=x+((float)frame_size_x*res)/2.0;
    }
    if (lock_aspect[n]==2) {// y is bound to x
        float res=(x_max[n]-x_min[n])/(float)frame_size_x;
        float y=y_min[n]+(y_max[n]-y_min[n])/2.0;
        y_min[n]=y-((float)frame_size_y*res)/2.0;
        y_max[n]=y+((float)frame_size_y*res)/2.0;
    }


    ggrid[n]->setView(x_min[n],x_max[n],y_min[n],y_max[n]);
    gdata[n]->setView(x_min[n],x_max[n],y_min[n],y_max[n]);
    gobject->setParameters(plot_Size_X,plot_Size_Y,number,&textsize[0],&titelsize[0],&margin[0],&x_min[0],&y_min[0],&x_max[0],&y_max[0],&factor_x[0],&factor_y[0]);

    update();
}

// Start drawing a frame if STRG is pressed : Starting Kooridinates
void Graph::mousePressEvent(QGraphicsSceneMouseEvent* mouseEvent1){
    // get current info from graph
    focus=(mouseEvent1->scenePos().y()+plot_Size_Y/2)/(plot_Size_Y/number);

    textsize[focus]=ggrid[focus]->getTextSize();
    titelsize[focus]=ggrid[focus]->getTitelSize();
    margin[focus]=ggrid[focus]->getMargin();

    if (key_flag==1){
        frame_x1=mouseEvent1->scenePos().x();
        frame_y1=((mouseEvent1->scenePos().y()));
        //qDebug()<<QString::number(frame_y1);
    }
    if (key_flag==2){
        frame_x1=mouseEvent1->scenePos().x();
        frame_y1=((mouseEvent1->scenePos().y()));
        //qDebug()<<QString::number(frame_y1);
    }

}
// Realizes Point Clicked and Zoom-Frame-finish
void Graph::mouseReleaseEvent(QGraphicsSceneMouseEvent* mouseEvent2){

    //qDebug()<<QString::number(focus)+":"+QString::number(mouseEvent2->scenePos().y())+":"+QString::number((((mouseEvent2->scenePos().y()+plot_Size_Y/2)-(focus*(plot_Size_Y/number))-(plot_Size_Y/number)/2)));
    if(moveFlag==0 && key_flag==0){
        x_min[focus]=gdata[focus]->get_x_min();
        x_max[focus]=gdata[focus]->get_x_max();
        y_min[focus]=gdata[focus]->get_y_min();
        y_max[focus]=gdata[focus]->get_y_max();
        int x1=mouseEvent2->scenePos().x();
        int y1=mouseEvent2->scenePos().y();

        calcFrame(focus);
        //qDebug()<<QString::number(frame_top);
        float new_x_min=x_min[focus]+(mouseEvent2->scenePos().x()-symbol_size[focus]-frame_left)*(x_max[focus]-x_min[focus])/(frame_size_x);
        float new_y_min=y_max[focus]-(mouseEvent2->scenePos().y()+symbol_size[focus]-frame_top)*(y_max[focus]-y_min[focus])/(frame_size_y);
        float new_x_max=x_min[focus]+(mouseEvent2->scenePos().x()+symbol_size[focus]-frame_left)*(x_max[focus]-x_min[focus])/(frame_size_x);
        float new_y_max=y_max[focus]-(mouseEvent2->scenePos().y()-symbol_size[focus]-frame_top)*(y_max[focus]-y_min[focus])/(frame_size_y);


        //qDebug()<<QString::number(new_x_min)+" - "+QString::number(new_x_max)+" : "+QString::number(new_y_min)+" - "+QString::number(new_y_max);
        // create QList of all selected points
        select_plot=focus;
        select_x.clear();
        select_y.clear();
        for (int i=0;i<column[focus];i=i+2){
            for (int j=0;j<row[focus];j++) {



                float x_pos=data[focus][j+i*row[focus]];
                while(x_pos>repeat_x2[focus]) x_pos-=repeat_x2[focus]-repeat_x1[focus];
                while(x_pos<repeat_x1[focus]) x_pos+=repeat_x2[focus]-repeat_x1[focus];
                float y_pos=data[focus][j+(i+1)*row[focus]];
                while(y_pos>repeat_y2[focus]) y_pos-=repeat_y2[focus]-repeat_y1[focus];
                while(y_pos<repeat_y1[focus]) y_pos+=repeat_y2[focus]-repeat_y1[focus];

                if (x_pos*factor_x[focus]<=new_x_max &&
                        x_pos*factor_x[focus]>=new_x_min &&
                        y_pos*factor_y[focus]>=new_y_min &&
                        y_pos*factor_y[focus]<=new_y_max){

                    select_x.append(i);
                    select_y.append(j);
                }

                if (new_x_max>repeat_x2[focus] && new_x_min>=repeat_x1[focus]){
                    float nxmax=new_x_max;
                    while(nxmax>repeat_x2[focus]) nxmax-=repeat_x2[focus]-repeat_x1[focus];
                    if (x_pos*factor_x[focus]<=nxmax &&
                            x_pos*factor_x[focus]>=repeat_x1[focus] &&
                            y_pos*factor_y[focus]>=new_y_min &&
                            y_pos*factor_y[focus]<=new_y_max){
                        select_x.append(i);
                        select_y.append(j);
                    }
                }
                if (new_x_min<repeat_x1[focus] && new_x_max<=repeat_x2[focus]){
                    float nxmin=new_x_min;
                    while(nxmin<repeat_x1[focus]) nxmin+=repeat_x2[focus]-repeat_x1[focus];
                    if (x_pos*factor_x[focus]<=repeat_x2[focus] &&
                            x_pos*factor_x[focus]>=nxmin &&
                            y_pos*factor_y[focus]>=new_y_min &&
                            y_pos*factor_y[focus]<=new_y_max){
                        select_x.append(i);
                        select_y.append(j);
                    }
                }
            }
        }
        if (select_x.length()==0) gobject->checkSelect(x1,y1);
        if (select_x.length()>0){
            gdata[focus]->setSelected_X(select_x.at(select_x.length()-1));
            gdata[focus]->setSelected_Y(select_y.at(select_x.length()-1));
            QString str="";
            if (select_x.length()>1) str=str+QString::number(select_x.length())+" entries found at location\n\n";
            if (com_mode[focus]>0) {
                for (int i=0;i<select_x.length();i++){
                    if (dat_com[focus][select_y.at(i)+select_x.at(i)*row[focus]].simplified()!="") str=str+dat_com[focus][select_y.at(i)+select_x.at(i)*row[focus]]+"\n";
                    str=str+titel_x[focus]->simplified()+" : "+QString::number(data[focus][select_y.at(i)+select_x.at(i)*row[focus]])+"\n"+titel_y[focus]->simplified()+" : "+QString::number(data[focus][select_y.at(i)+(select_x.at(i)+1)*row[focus]]);
                    if (dat_com[focus][select_y.at(i)+(select_x.at(i)+1)*row[focus]].simplified()!="") str=str+"\n"+dat_com[focus][select_y.at(i)+(select_x.at(i)+1)*row[focus]];
                    if (i<select_x.length()-1) str=str+"\n\n";
                }
            } else {
                for (int i=0;i<select_x.length();i++){
                    str=str+titel_x[focus]->simplified()+" : "+QString::number(data[focus][select_y.at(i)+select_x.at(i)*row[focus]])+"\n"+titel_y[focus]->simplified()+" : "+QString::number(data[focus][select_y.at(i)+(select_x.at(i)+1)*row[focus]]);
                    if (i+1<select_x.length()) str=str+"\n\n";
                }
            }
            QPoint pos;
            pos.setX(mouseEvent2->screenPos().x());
            pos.setY(mouseEvent2->screenPos().y());
            QToolTip::showText(pos,str,0);
            emit(selected(select_plot,select_x.at(select_x.length()-1),select_y.at(select_y.length()-1)));
        }
        // emit click event in any case
        float x=x_min[focus]+(mouseEvent2->scenePos().x()-frame_left)*(x_max[focus]-x_min[focus])/(frame_size_x);
        float y=y_max[focus]-(mouseEvent2->scenePos().y()-frame_top)*(y_max[focus]-y_min[focus])/(frame_size_y);

        emit(click(select_plot,x,y));


        update();
        diag->update();

    }

    moveFlag=0;

    // Frame is finished : Final Kooridinates-> Zoom in
    if (key_flag==1){
        frame_x2=mouseEvent2->scenePos().x();
        frame_y2=((mouseEvent2->scenePos().y()));
        // zoom
        if (frame_x1>frame_x2){
            int temp=frame_x1;
            frame_x1=frame_x2;
            frame_x2=temp;
        }
        if (frame_y1>frame_y2){
            int temp=frame_y1;
            frame_y1=frame_y2;
            frame_y2=temp;
        }


        x_min[focus]=gdata[focus]->get_x_min();
        x_max[focus]=gdata[focus]->get_x_max();
        y_min[focus]=gdata[focus]->get_y_min();
        y_max[focus]=gdata[focus]->get_y_max();
        calcFrame(focus);
        double new_x_min=x_min[focus],new_y_min=y_min[focus],new_x_max=x_max[focus],new_y_max=y_max[focus];
            double fx=(frame_size_x)/(x_max[focus]-x_min[focus]);
            if(fix_x[focus]==false) new_x_min=x_min[focus]+(1.0/fx)*(frame_x1-(frame_left));
            if(fix_x[focus]==false) new_x_max=x_min[focus]+(1.0/fx)*(frame_x2-(frame_left));
            double fy=(frame_size_y)/(y_max[focus]-y_min[focus]);
            if(fix_y[focus]==false) new_y_min=y_max[focus]-(1.0/fy)*(frame_y2-(frame_top));
            if(fix_y[focus]==false) new_y_max=y_max[focus]-(1.0/fy)*(frame_y1-(frame_top));
        if (new_x_min!=new_x_max && new_y_min!=new_y_max){
            // adjust aspect_ratio
            if (lock_aspect[focus]==1) {// x is bound to y
                float res=(new_y_max-new_y_min)/(float)frame_size_y;
                float x=new_x_min+(new_x_max-new_x_min)/2.0;
                new_x_min=x-((float)frame_size_x*res)/2.0;
                new_x_max=x+((float)frame_size_x*res)/2.0;
            }
            if (lock_aspect[focus]==2) {// y is bound to x
                float res=(new_x_max-new_x_min)/(float)frame_size_x;
                float y=new_y_min+(new_y_max-new_y_min)/2.0;
                new_y_min=y-((float)frame_size_y*res)/2.0;
                new_y_max=y+((float)frame_size_y*res)/2.0;
            }




            if (new_x_min>=limit_x1[focus]&&new_x_max<=limit_x2[focus]&&new_y_min>=limit_y1[focus]&&new_y_max<=limit_y2[focus]){
                ggrid[focus]->setView(new_x_min,new_x_max,new_y_min,new_y_max);
                gdata[focus]->setView(new_x_min,new_x_max,new_y_min,new_y_max);
            }
        }
        x_min[focus]=gdata[focus]->get_x_min();
        x_max[focus]=gdata[focus]->get_x_max();
        y_min[focus]=gdata[focus]->get_y_min();
        y_max[focus]=gdata[focus]->get_y_max();
        gobject->setParameters(plot_Size_X,plot_Size_Y,number,&textsize[0],&titelsize[0],&margin[0],&x_min[0],&y_min[0],&x_max[0],&y_max[0],&factor_x[0],&factor_y[0]);

        key_flag=0;
    }
    // Frame is finished : Final Kooridinates-> create List of all points and sent it to parent
    if (key_flag==2){
        frame_x2=mouseEvent2->scenePos().x();
        frame_y2=((mouseEvent2->scenePos().y()+plot_Size_Y/2)-(focus*(plot_Size_Y/number))-(plot_Size_Y/number)/2);
        // zoom
        if (frame_x1>frame_x2){
            int temp=frame_x1;
            frame_x1=frame_x2;
            frame_x2=temp;
        }
        if (frame_y1>frame_y2){
            int temp=frame_y1;
            frame_y1=frame_y2;
            frame_y2=temp;
        }


        x_min[focus]=gdata[focus]->get_x_min();
        x_max[focus]=gdata[focus]->get_x_max();
        y_min[focus]=gdata[focus]->get_y_min();
        y_max[focus]=gdata[focus]->get_y_max();
        calcFrame(focus);
        double new_x_min=x_min[focus],new_y_min=y_min[focus],new_x_max=x_max[focus],new_y_max=y_max[focus];
        double fx=(frame_size_x)/(x_max[focus]-x_min[focus]);
        new_x_min=x_min[focus]+(1.0/fx)*(frame_x1-(frame_left));
        new_x_max=x_min[focus]+(1.0/fx)*(frame_x2-(frame_left));
        double fy=(frame_size_y)/(y_max[focus]-y_min[focus]);
        new_y_min=y_max[focus]-(1.0/fy)*(frame_y2-(frame_top));
        new_y_max=y_max[focus]-(1.0/fy)*(frame_y1-(frame_top));

        // create QList of all selected points
        select_plot=focus;
        select_x.clear();
        select_y.clear();
        for (int i=0;i<column[focus];i=i+2){
            for (int j=0;j<row[focus];j++) {



                float x_pos=data[focus][j+i*row[focus]];
                while(x_pos>repeat_x2[focus]) x_pos-=repeat_x2[focus]-repeat_x1[focus];
                while(x_pos<repeat_x1[focus]) x_pos+=repeat_x2[focus]-repeat_x1[focus];
                float y_pos=data[focus][j+(i+1)*row[focus]];
                while(y_pos>repeat_y2[focus]) y_pos-=repeat_y2[focus]-repeat_y1[focus];
                while(y_pos<repeat_y1[focus]) y_pos+=repeat_y2[focus]-repeat_y1[focus];
                if (x_pos*factor_x[focus]<=new_x_max &&
                        x_pos*factor_x[focus]>=new_x_min &&
                        y_pos*factor_y[focus]>=new_y_min &&
                        y_pos*factor_y[focus]<=new_y_max){
                    select_x.append(i);
                    select_y.append(j);
                }

                if (new_x_max>repeat_x2[focus] && new_x_min>=repeat_x1[focus]){
                    float nxmax=new_x_max;
                    while(nxmax>repeat_x2[focus]) nxmax-=repeat_x2[focus]-repeat_x1[focus];
                    if (x_pos*factor_x[focus]<=nxmax &&
                            x_pos*factor_x[focus]>=repeat_x1[focus] &&
                            y_pos*factor_y[focus]>=new_y_min &&
                            y_pos*factor_y[focus]<=new_y_max){
                        select_x.append(i);
                        select_y.append(j);
                    }
                }
                if (new_x_min<repeat_x1[focus] && new_x_max<=repeat_x2[focus]){
                    float nxmin=new_x_min;
                    while(nxmin<repeat_x1[focus]) nxmin+=repeat_x2[focus]-repeat_x1[focus];
                    if (x_pos*factor_x[focus]<=repeat_x2[focus] &&
                            x_pos*factor_x[focus]>=nxmin &&
                            y_pos*factor_y[focus]>=new_y_min &&
                            y_pos*factor_y[focus]<=new_y_max){
                        select_x.append(i);
                        select_y.append(j);
                    }
                }
            }
        }
        emit (selection(select_plot,select_x,select_y));
        key_flag=0;
    }
    gdata[focus]->setRect(frame_x1,frame_x2,frame_y1,frame_y2,0);
    update();
}

// Realizes Drag and Zoom-Frame
void Graph::mouseMoveEvent(QGraphicsSceneMouseEvent* mouseEvent3){
    // Allow Drag of View
    if (mouseEvent3->buttons()==Qt::LeftButton && key_flag==0){

        moveFlag=1;

        x_min[focus]=gdata[focus]->get_x_min();
        x_max[focus]=gdata[focus]->get_x_max();
        y_min[focus]=gdata[focus]->get_y_min();
        y_max[focus]=gdata[focus]->get_y_max();
        calcFrame(focus);
        double new_x_min=x_min[focus],new_y_min=y_min[focus],new_x_max=x_max[focus],new_y_max=y_max[focus];


            double fx=(frame_size_x)/(x_max[focus]-x_min[focus]);
            if(fix_x[focus]==false)new_x_min=x_min[focus]+(1.0/fx)*(mouseEvent3->lastScreenPos().x()-mouseEvent3->screenPos().x());
            if(fix_x[focus]==false)new_x_max=x_max[focus]+(1.0/fx)*(mouseEvent3->lastScreenPos().x()-mouseEvent3->screenPos().x());
            double fy=(frame_size_y)/(y_max[focus]-y_min[focus]);
            if(fix_y[focus]==false)new_y_min=y_min[focus]-(1.0/fy)*(mouseEvent3->lastScreenPos().y()-mouseEvent3->screenPos().y());
            if(fix_y[focus]==false)new_y_max=y_max[focus]-(1.0/fy)*(mouseEvent3->lastScreenPos().y()-mouseEvent3->screenPos().y());

        //qDebug() << QString::number(new_x_min)+":"+QString::number(new_x_max);
        //qDebug() << QString::number(new_y_min)+":"+QString::number(new_y_max);
            // check folding
            if (fold_x[focus]==1 && repeat_x2[focus]-new_x_min < new_x_max-repeat_x2[focus] && new_x_max>repeat_x2[focus]) {
                new_x_min=new_x_min-(repeat_x2[focus]-repeat_x1[focus]);
                new_x_max=new_x_max-(repeat_x2[focus]-repeat_x1[focus]);
            }
            if (fold_x[focus]==1 && new_x_min<repeat_x1[focus] && new_x_max-repeat_x1[focus]<repeat_x1[focus]-new_x_min) {
                new_x_min=new_x_min+(repeat_x2[focus]-repeat_x1[focus]);
                new_x_max=new_x_max+(repeat_x2[focus]-repeat_x1[focus]);
            }
            if (fold_y[focus]==1 && repeat_y2[focus]-new_y_min < new_y_max-repeat_y2[focus] && new_y_max>repeat_y2[focus]) {
                new_y_min=new_y_min-(repeat_y2[focus]-repeat_y1[focus]);
                new_y_max=new_y_max-(repeat_y2[focus]-repeat_y1[focus]);
            }
            if (fold_y[focus]==1 && new_y_min<repeat_y1[focus] && new_y_max-repeat_y1[focus]<repeat_y1[focus]-new_y_min) {
                new_y_min=new_y_min+(repeat_y2[focus]-repeat_y1[focus]);
                new_y_max=new_y_max+(repeat_y2[focus]-repeat_y1[focus]);
            }

            // check for limits
            if (new_x_min<limit_x1[focus]) {
                new_x_max=new_x_max-(new_x_min-limit_x1[focus]);
                if (new_x_max>limit_x2[focus]) new_x_max=limit_x2[focus];
                new_x_min=limit_x1[focus];
            }
            if (new_x_max>limit_x2[focus]){
                new_x_min=new_x_min+(limit_x2[focus]-new_x_max);
                if (new_x_min<limit_x1[focus]) new_x_min=limit_x1[focus];
                new_x_max=limit_x2[focus];
            }
            if (new_y_min<limit_y1[focus]){
                new_y_max=new_y_max-(new_y_min-limit_y1[focus]);
                if (new_y_max>limit_y2[focus]) new_y_max=limit_y2[focus];
                new_y_min=limit_y1[focus];
            }
            if (new_y_max>limit_y2[focus]){
                new_y_min=new_y_min+(limit_y2[focus]-new_y_max);
                if (new_y_min<limit_y1[focus]) new_y_min=limit_y1[focus];
                new_y_max=limit_y2[focus];
            }

            if (new_x_min>=limit_x1[focus]&&new_x_max<=limit_x2[focus]&&new_y_min>=limit_y1[focus]&&new_y_max<=limit_y2[focus]){
                ggrid[focus]->setView(new_x_min,new_x_max,new_y_min,new_y_max);
                gdata[focus]->setView(new_x_min,new_x_max,new_y_min,new_y_max);
            }
        x_min[focus]=gdata[focus]->get_x_min();
        x_max[focus]=gdata[focus]->get_x_max();
        y_min[focus]=gdata[focus]->get_y_min();
        y_max[focus]=gdata[focus]->get_y_max();
        gobject->setParameters(plot_Size_X,plot_Size_Y,number,&textsize[0],&titelsize[0],&margin[0],&x_min[0],&y_min[0],&x_max[0],&y_max[0],&factor_x[0],&factor_y[0]);

        update();
    }
    // Allow to draw a frame if STRG is Pressed
    if (mouseEvent3->buttons()==Qt::LeftButton && key_flag==1){
        // draw Frame
        int x1=frame_x1;
        int x2=mouseEvent3->scenePos().x();
        int y1=frame_y1;
        int y2=((mouseEvent3->scenePos().y()));
        calcFrame(focus);

        if (fix_x[focus]==true) {
            x1=frame_left;
            x2=frame_right;
        }
        if (fix_y[focus]==true) {
            y1=frame_top-(focus*(plot_Size_Y/number))+plot_Size_Y/4;
            y2=frame_bottom-(focus*(plot_Size_Y/number))+plot_Size_Y/4;
        }

        // adjust aspect_ratio
        if (lock_aspect[focus]==1) {// x is bound to y
            x2=x1+(y2-y1)/2*frame_size_x/frame_size_y;
            x1=x1-(y2-y1)/2*frame_size_x/frame_size_y;
        }
        if (lock_aspect[focus]==2) {// y is bound to x
            y2=y1+(x2-x1)/2*frame_size_y/frame_size_x;
            y1=y1-(x2-x1)/2*frame_size_y/frame_size_x;
        }
        qDebug()<<QString::number(y1)+":"+QString::number(y2);
        gdata[focus]->setRect(x1,x2,y1,y2,1);
        update();
    }
    // Allow to draw a frame if ALT is Pressed
    if (mouseEvent3->buttons()==Qt::LeftButton && key_flag==2){
        // draw Frame
        int x1=frame_x1;
        int x2=mouseEvent3->scenePos().x();
        int y1=frame_y1;
        int y2=((mouseEvent3->scenePos().y()));
        calcFrame(focus);
        if (fix_x[focus]==true) {
            x1=frame_left;
            x2=frame_right;
        }
        if (fix_y[focus]==true) {
            y1=frame_top-(focus*(plot_Size_Y/number))+plot_Size_Y/4;
            y2=frame_bottom-(focus*(plot_Size_Y/number))+plot_Size_Y/4;
        }
        gdata[focus]->setRect(x1,x2,y1,y2,2);
        update();
    }

}

// Get Seleted Point(x)
int Graph::getSelected_X(){
    return gdata[focus]->getSelected_X();
}

// Get Seleted Point(y)
int Graph::getSelected_Y(){
    return gdata[focus]->getSelected_Y();
}
// Get Seleted Point(x)
int Graph::getSelected_X(int n){
    return gdata[n]->getSelected_X();
}

// Get Seleted Point(y)
int Graph::getSelected_Y(int n){
    return gdata[n]->getSelected_Y();
}

// Set Seleted Point(x)
void Graph::setSelected_X(int x){
    gdata[0]->setSelected_X(x);
}

// Set Seleted Point(y)
void Graph::setSelected_Y(int y){
    gdata[0]->setSelected_Y(y);
}
// Set Seleted Point(x)
void Graph::setSelected_X(int x,int n){
    gdata[n]->setSelected_X(x);
}

// Set Seleted Point(y)
void Graph::setSelected_Y(int y,int n){
    gdata[n]->setSelected_Y(y);
}

// MouseWheel for Changing Zoom
void Graph::wheelEvent(QGraphicsSceneWheelEvent *mouseEvent4){
    focus=(mouseEvent4->scenePos().y()+plot_Size_Y/2)/(plot_Size_Y/number);
    x_min[focus]=gdata[focus]->get_x_min();
    x_max[focus]=gdata[focus]->get_x_max();
    y_min[focus]=gdata[focus]->get_y_min();
    y_max[focus]=gdata[focus]->get_y_max();

    double new_x_min=x_min[focus],new_y_min=y_min[focus],new_x_max=x_max[focus],new_y_max=y_max[focus];

    if (mouseEvent4->delta()/120>0) {
        if (fix_x[focus]==false) new_x_min=x_min[focus]+(x_max[focus]-x_min[focus])*0.1;
        if (fix_x[focus]==false) new_x_max=x_max[focus]-(x_max[focus]-x_min[focus])*0.1;
        if (fix_y[focus]==false) new_y_min=y_min[focus]+(y_max[focus]-y_min[focus])*0.1;
        if (fix_y[focus]==false) new_y_max=y_max[focus]-(y_max[focus]-y_min[focus])*0.1;
    }
    if (mouseEvent4->delta()/120<0) {
        if (fix_x[focus]==false) new_x_min=x_min[focus]-(x_max[focus]-x_min[focus])*0.1;
        if (fix_x[focus]==false) new_x_max=x_max[focus]+(x_max[focus]-x_min[focus])*0.1;
        if (fix_y[focus]==false) new_y_min=y_min[focus]-(y_max[focus]-y_min[focus])*0.1;
        if (fix_y[focus]==false) new_y_max=y_max[focus]+(y_max[focus]-y_min[focus])*0.1;
    }



    // check for limits
    if (new_x_min<limit_x1[focus]) {
        new_x_max=new_x_max-(new_x_min-limit_x1[focus]);
        if (new_x_max>limit_x2[focus]) new_x_max=limit_x2[focus];
        new_x_min=limit_x1[focus];
    }
    if (new_x_max>limit_x2[focus]){
        new_x_min=new_x_min+(limit_x2[focus]-new_x_max);
        if (new_x_min<limit_x1[focus]) new_x_min=limit_x1[focus];
        new_x_max=limit_x2[focus];
    }
    if (new_y_min<limit_y1[focus]){
        new_y_max=new_y_max-(new_y_min-limit_y1[focus]);
        if (new_y_max>limit_y2[focus]) new_y_max=limit_y2[focus];
        new_y_min=limit_y1[focus];
    }
    if (new_y_max>limit_y2[focus]){
        new_y_min=new_y_min+(limit_y2[focus]-new_y_max);
        if (new_y_min<limit_y1[focus]) new_y_min=limit_y1[focus];
        new_y_max=limit_y2[focus];
    }

    // check folding
    if (fold_x[focus]==1 && repeat_x2[focus]-new_x_min < new_x_max-repeat_x2[focus] && new_x_max>repeat_x2[focus]) {
        new_x_min=new_x_min-(repeat_x2[focus]-repeat_x1[focus]);
        new_x_max=new_x_max-(repeat_x2[focus]-repeat_x1[focus]);
    }
    if (fold_x[focus]==1 && new_x_min<repeat_x1[focus] && new_x_max-repeat_x1[focus]<repeat_x1[focus]-new_x_min) {
        new_x_min=new_x_min+(repeat_x2[focus]-repeat_x1[focus]);
        new_x_max=new_x_max+(repeat_x2[focus]-repeat_x1[focus]);
    }
    if (fold_y[focus]==1 && repeat_y2[focus]-new_y_min < new_y_max-repeat_y2[focus] && new_y_max>repeat_y2[focus]) {
        new_y_min=new_y_min-(repeat_y2[focus]-repeat_y1[focus]);
        new_y_max=new_y_max-(repeat_y2[focus]-repeat_y1[focus]);
    }
    if (fold_y[focus]==1 && new_y_min<repeat_y1[focus] && new_y_max-repeat_y1[focus]<repeat_y1[focus]-new_y_min) {
        new_y_min=new_y_min+(repeat_y2[focus]-repeat_y1[focus]);
        new_y_max=new_y_max+(repeat_y2[focus]-repeat_y1[focus]);
    }
    // adjust aspect_ratio
    if (lock_aspect[focus]==1) {// x is bound to y
        float res=(new_y_max-new_y_min)/(float)frame_size_y;
        float x=new_x_min+(new_x_max-new_x_min)/2.0;
        new_x_min=x-((float)frame_size_x*res)/2.0;
        new_x_max=x+((float)frame_size_x*res)/2.0;
    }
    if (lock_aspect[focus]==2) {// y is bound to x
        float res=(new_x_max-new_x_min)/(float)frame_size_x;
        float y=new_y_min+(new_y_max-new_y_min)/2.0;
        new_y_min=y-((float)frame_size_y*res)/2.0;
        new_y_max=y+((float)frame_size_y*res)/2.0;
    }




    if (new_x_min>=limit_x1[focus] && new_x_max<=limit_x2[focus] && new_y_min>=limit_y1[focus] && new_y_max<=limit_y2[focus]){
        ggrid[focus]->setView(new_x_min,new_x_max,new_y_min,new_y_max);
        gdata[focus]->setView(new_x_min,new_x_max,new_y_min,new_y_max);
    }
    x_min[focus]=gdata[focus]->get_x_min();
    x_max[focus]=gdata[focus]->get_x_max();
    y_min[focus]=gdata[focus]->get_y_min();
    y_max[focus]=gdata[focus]->get_y_max();
    gobject->setParameters(plot_Size_X,plot_Size_Y,number,&textsize[0],&titelsize[0],&margin[0],&x_min[0],&y_min[0],&x_max[0],&y_max[0],&factor_x[0],&factor_y[0]);

    update();

}


// For external usage
void Graph::mouseDoubleClickEvent(QGraphicsSceneMouseEvent *mouseEvent5){

    x_min[focus]=gdata[focus]->get_x_min();
    x_max[focus]=gdata[focus]->get_x_max();
    y_min[focus]=gdata[focus]->get_y_min();
    y_max[focus]=gdata[focus]->get_y_max();
    calcFrame(focus);
    float new_x_min=x_min[focus]+(mouseEvent5->scenePos().x()-symbol_size[focus]-frame_left)*(x_max[focus]-x_min[focus])/(frame_size_x);
    float new_y_min=y_max[focus]-((((mouseEvent5->scenePos().y()+symbol_size[focus]+plot_Size_Y/2)-(focus*(plot_Size_Y/number))-(plot_Size_Y/number)/2))-frame_top)*(y_max[focus]-y_min[focus])/(frame_size_y);
    float new_x_max=x_min[focus]+(mouseEvent5->scenePos().x()+symbol_size[focus]-frame_left)*(x_max[focus]-x_min[focus])/(frame_size_x);
    float new_y_max=y_max[focus]-((((mouseEvent5->scenePos().y()-symbol_size[focus]+plot_Size_Y/2)-(focus*(plot_Size_Y/number))-(plot_Size_Y/number)/2))-frame_top)*(y_max[focus]-y_min[focus])/(frame_size_y);
    //qDebug()<<QString::number(new_x_min)+" - "+QString::number(new_x_max)+" : "+QString::number(new_y_min)+" - "+QString::number(new_y_max);
    // create QList of all selected points
    select_plot=focus;
    select_x.clear();
    select_y.clear();
    for (int i=0;i<column[focus];i=i+2){
        for (int j=0;j<row[focus];j++) {



            float x_pos=data[focus][j+i*row[focus]];
            while(x_pos>repeat_x2[focus]) x_pos-=repeat_x2[focus]-repeat_x1[focus];
            while(x_pos<repeat_x1[focus]) x_pos+=repeat_x2[focus]-repeat_x1[focus];
            float y_pos=data[focus][j+(i+1)*row[focus]];
            while(y_pos>repeat_y2[focus]) y_pos-=repeat_y2[focus]-repeat_y1[focus];
            while(y_pos<repeat_y1[focus]) y_pos+=repeat_y2[focus]-repeat_y1[focus];
            if (x_pos*factor_x[focus]<=new_x_max &&
                    x_pos*factor_x[focus]>=new_x_min &&
                    y_pos*factor_y[focus]>=new_y_min &&
                    y_pos*factor_y[focus]<=new_y_max){
                select_x.append(i);
                select_y.append(j);
            }

            if (new_x_max>repeat_x2[focus] && new_x_min>=repeat_x1[focus]){
                float nxmax=new_x_max;
                while(nxmax>repeat_x2[focus]) nxmax-=repeat_x2[focus]-repeat_x1[focus];
                if (x_pos*factor_x[focus]<=nxmax &&
                        x_pos*factor_x[focus]>=repeat_x1[focus] &&
                        y_pos*factor_y[focus]>=new_y_min &&
                        y_pos*factor_y[focus]<=new_y_max){
                    select_x.append(i);
                    select_y.append(j);
                }
            }
            if (new_x_min<repeat_x1[focus] && new_x_max<=repeat_x2[focus]){
                float nxmin=new_x_min;
                while(nxmin<repeat_x1[focus]) nxmin+=repeat_x2[focus]-repeat_x1[focus];
                if (x_pos*factor_x[focus]<=repeat_x2[focus] &&
                        x_pos*factor_x[focus]>=nxmin &&
                        y_pos*factor_y[focus]>=new_y_min &&
                        y_pos*factor_y[focus]<=new_y_max){
                    select_x.append(i);
                    select_y.append(j);
                }
            }
        }
    }
    emit (selection(select_plot,select_x,select_y));

}

// Check if STRG is Pressed for starting to drawing a frame
void Graph::keyPressEvent(QKeyEvent *event){
    //qDebug() << "Pressed :"+QString::number(event->key());
    if (event->key()==Qt::Key_Control){
        //qDebug() << "Control";
        key_flag=1;
    }
    if (event->key()==Qt::Key_Alt){
        //qDebug() << "Control";
        key_flag=2;
    }
}

// Check if STRG is Pressed for stopping drawing a frame
void Graph::keyReleaseEvent(QKeyEvent *event){
    //qDebug() << "Released :"+QString::number(event->key());
    if (event->key()==Qt::Key_Control){
        //qDebug() << "Control";
        key_flag=0;
    }
    if (event->key()==Qt::Key_Alt){
        //qDebug() << "Control";
        key_flag=0;
    }

}

void Graph::contextMenuEvent(QGraphicsSceneContextMenuEvent *event)
{

    QMenu menu;
    menu.addAction("Auto-Resize Graph");
    menu.addAction("Show in Editor");
    menu.addSeparator();
    menu.addAction("Settings");
    if (error[focus]>0 && error[focus]==1) menu.addAction("Show Y-Error");
    if (error[focus]>0 && error[focus]==2) menu.addAction("Show X-Y Error");
    if (error[focus]>0 && error[focus]==3) menu.addAction("Show X-Error");
    if (com_mode[focus]>0 && com_hide[focus]==0) menu.addAction("Hide Comments");
    if (com_mode[focus]>0 && com_hide[focus]==1) menu.addAction("Show Comments");
    menu.addSeparator();
    menu.addAction("Save as Image");
    QAction *a = menu.exec(event->screenPos());

    if (a)
    {
        if (a->iconText()=="Auto-Resize Graph"){
            this->autoSize(focus);
        }
        if (a->iconText()=="Show in Editor"){
            if (error[focus]==0) {
                delete[] err;
                err=new float[column[focus]*row[focus]];
                delete dataedit;
                dataedit=new DataEdit(diag,data[focus],err,column[focus],row[focus]);
            } else {
                delete dataedit;
                dataedit=new DataEdit(diag,data[focus],data_err[focus],column[focus],row[focus]);
            }
            delete header;
            header=new QStringList;
            for (int i=0;i<column[focus];i=i+2) {
                QString* str=titel_x[focus];
                header->append("X("+QString::number(i/2)+")\n"+str->toLatin1());
                QString* str2=titel_y[focus];
                header->append("Y("+QString::number(i/2)+")\n"+str2->toLatin1());
            }
            dataedit->setHeader(header);

            dataedit->setModal(true);
            dataedit->setWindowFlags(Qt::Dialog | Qt::WindowTitleHint | Qt::WindowMaximizeButtonHint | Qt::WindowCloseButtonHint | Qt::CustomizeWindowHint);
            dataedit->show();
        }
        if (a->iconText()=="Show X-Error"){
            error[focus]=1;
            gdata[focus]->setError(data_err[focus],error[focus]);
            update();
        }
        if (a->iconText()=="Show Y-Error"){
            error[focus]=2;
            gdata[focus]->setError(data_err[focus],error[focus]);
            update();
        }
        if (a->iconText()=="Show X-Y Error"){
            error[focus]=3;
            gdata[focus]->setError(data_err[focus],error[focus]);
            update();
        }

        if (a->iconText()=="Hide Comments"){
            com_hide[focus]=1;
            gdata[focus]->setComHide(com_hide[focus]);
            update();
        }
        if (a->iconText()=="Show Comments"){
            com_hide[focus]=0;
            gdata[focus]->setComHide(com_hide[focus]);
            update();
        }

        if (a->iconText()=="Settings"){
            delete set;
            set=new GraphSettings(diag,gdata[focus],ggrid[focus]);
            set->setModal(true);
            set->setWindowFlags(Qt::Dialog | Qt::WindowTitleHint | Qt::WindowMaximizeButtonHint | Qt::WindowCloseButtonHint | Qt::CustomizeWindowHint);
            set->exec();
            saveSettings(focus);

        }
        if (a->iconText()=="Save as Image"){
            //create duplicates of gdata[0] and ggrid[0]
            delete gg;
            delete gd;
            delete ggg;
            ggg=new GraphObject(this);
            gg=new GraphGrid(this,data[focus],column[focus],row[focus]);
            gd=new GraphData(this,data[focus],column[focus],row[focus]);

            gg->setData(data[focus],column[focus],row[focus]);
            gd->setData(data[focus],column[focus],row[focus]);
            gd->setError(data_err[focus],error[focus]);
            gd->setError2(data_err2[focus],error2[focus]);
            gd->setComment(dat_com[focus],com_mode[focus]);
            gd->setColor(col_dat[focus],color[focus]);
            gd->setUse(useflag[focus],usemode[focus]);
            gd->setSize(plot_Size_X,plot_Size_Y);
            gg->setSize(plot_Size_X,plot_Size_Y);

            gg->setTitel(ggrid[focus]->getTitel(),ggrid[focus]->getTitelX(),ggrid[focus]->getTitelY());
            gd->setMultiplicator(factor_x[focus],factor_y[focus]);
            gg->setMultiplicator(factor_x[focus],factor_y[focus]);

            gd->setTextSize(ggrid[focus]->getTextSize(),ggrid[focus]->getTitelSize(),ggrid[focus]->getMargin());
            gg->setTextSize(ggrid[focus]->getTextSize(),ggrid[focus]->getTitelSize(),ggrid[focus]->getMargin());

            gd->setSymbol(gdata[focus]->getSymbolSize());
            gd->setMark(data_mark[focus],marker[focus]);
            gd->setLineColor(gdata[focus]->getLineColor());
            gd->setLineStyle(gdata[focus]->getLineStyle());
            gd->setLineWidth(gdata[focus]->getLineWidth());

            gg->setView(x_min[focus],x_max[focus],y_min[focus],y_max[focus]);
            gd->setView(x_min[focus],x_max[focus],y_min[focus],y_max[focus]);
            int i=gdata[focus]->getSelected_Y();
            int j=gdata[focus]->getSelected_X();
            gd->setSelected_Y(i);
            gd->setSelected_X(j);
            gd->setComHide(com_hide[focus]);
            gd->addMarker(marker_x[focus],marker_y[focus],marker_mode[focus]);
            gd->setSetPoly(setpoly[focus],setpoly_mode[focus]);
            gd->setSetArea(setarea_x[focus],setarea_y[focus],setarea_mode[focus]);
            gd->setSetSymbolsize(setsymbolsize[focus],setsymbolsize_mode[focus]);
            gd->setSetSymboltype(setsymboltype[focus],setsymboltype_mode[focus]);
            gd->setSetLineWidth(setlinewidth[focus],setlinewidth_mode[focus]);
            gd->setSetLineStyle(setlinestyle[focus],setlinestyle_mode[focus]);
            gd->setSetColor(setcolor_color[focus],setcolor_mode[focus]);
            gd->setSetLineColor(setlinecolor_color[focus],setlinecolor_mode[focus]);

            delete gdisplay;
            gdisplay=new GraphDisplay(diag,gd,gg);// GraphObject is missing!!!!!
            gdisplay->setModal(true);
            gdisplay->setWindowFlags(Qt::Dialog | Qt::WindowTitleHint | Qt::WindowMaximizeButtonHint | Qt::WindowCloseButtonHint | Qt::CustomizeWindowHint);
            gdisplay->show();
        }
    }
}

// addObject Parameters
void Graph::addLine(float x1,float y1,int n1,float x2,float y2,int n2,QColor c,int w,Qt::PenStyle s){
    gobject->addLine(x1,y1,n1,x2,y2,n2,c,w,s);
}

void Graph::setAddMode(int i){
    gobject->setParameters(plot_Size_X,plot_Size_Y,number,&textsize[0],&titelsize[0],&margin[0],&x_min[0],&y_min[0],&x_max[0],&y_max[0],&factor_x[0],&factor_y[0]);
    gobject->setAxisType(&x_axis_type[0],&y_axis_type[0]);

    gobject->setAddMode(i);
}

void Graph::addLineClear(){
    gobject->addLineClear();
}
void Graph::setAxisType(int x,int y){
    x_axis_type[0]=x;
    y_axis_type[0]=y;
    ggrid[0]->setAxisType(x_axis_type[0],y_axis_type[0]);
    gdata[0]->setAxisType(x_axis_type[0],y_axis_type[0]);
    gobject->setAxisType(&x_axis_type[0],&y_axis_type[0]);
}
// 0 means left/bottom : 1 means right/top
void Graph::setAxisType(int x,int y,int i){
    x_axis_type[i]=x;
    y_axis_type[i]=y;

    ggrid[i]->setAxisType(x_axis_type[i],y_axis_type[i]);
    gdata[i]->setAxisType(x_axis_type[i],y_axis_type[i]);
    gobject->setAxisType(&x_axis_type[0],&y_axis_type[0]);

}

int Graph::getSelectLine(){
    return gobject->getSelect();
}

void Graph::calcFrame(int i){
    if (y_axis_type[i]==0){
        frame_right=plot_Size_X/2-margin[i];
        frame_left=-plot_Size_X/2+5*textsize[i]+margin[i];
        frame_size_x=frame_right-frame_left;
    }
    if (y_axis_type[i]==1){
        frame_right=plot_Size_X/2-margin[i]-5*textsize[i];
        frame_left=-plot_Size_X/2+margin[i];
        frame_size_x=frame_right-frame_left;
    }
    if (y_axis_type[i]==2){
        frame_right=plot_Size_X/2-margin[i]-5*textsize[i];
        frame_left=-plot_Size_X/2+margin[i]+5*textsize[i];
        frame_size_x=frame_right-frame_left;
    }
    if (y_axis_type[i]==3){
        frame_right=plot_Size_X/2-margin[i];
        frame_left=-plot_Size_X/2+margin[i];
        frame_size_x=frame_right-frame_left;
    }
    if (x_axis_type[i]==0){
        frame_top=-plot_Size_Y/2+i*(plot_Size_Y/number)+titelsize[i]+margin[i];
        frame_size_y=(plot_Size_Y/number)-2*margin[i]-5*textsize[i]-titelsize[i];
        frame_bottom=frame_top+frame_size_y;

    }
    if (x_axis_type[i]==1){
        frame_top=-plot_Size_Y/2+i*(plot_Size_Y/number)+titelsize[i]+margin[i]+5*textsize[i];
        frame_size_y=(plot_Size_Y/number)-2*margin[i]-5*textsize[i]-titelsize[i];
        frame_bottom=frame_top+frame_size_y;
    }
    if (x_axis_type[i]==2){
        frame_top=-plot_Size_Y/2+i*(plot_Size_Y/number)+titelsize[i]+margin[i]+5*textsize[i];
        frame_size_y=(plot_Size_Y/number)-2*margin[i]-5*textsize[i]-titelsize[i]-5*textsize[i];
        frame_bottom=frame_top+frame_size_y;
    }
    if (x_axis_type[i]==3){
        frame_top=-plot_Size_Y/2+i*(plot_Size_Y/number)+margin[i];
        frame_size_y=(plot_Size_Y/number)-2*margin[i];
        frame_bottom=frame_top+frame_size_y;
    }

}

void Graph::comHide(int i){
    if (com_hide[i]){
        com_hide[i]=0;
        gdata[i]->setComHide(com_hide[i]);
    }else{
        com_hide[i]=1;
        gdata[i]->setComHide(com_hide[i]);
    }
}

void Graph::setComHide(int i,int n){
    com_hide[i]=n;
    gdata[i]->setComHide(n);
}

void Graph::setSettings(QString p,int n){
    path[n]->clear();
    path[n]->append(p);
    // read file if it exists
    readSettings(n);
}

void Graph::setSettings(QString p){
    setSettings(p,0);
}

void Graph::readSettings(int n){
    QString txt;
    // Open file
    QFile file(*path[n]);
    if(!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        //qDebug() <<  file.errorString();
    } else {
        txt.clear();
        QTextStream in(&file);
        while(!in.atEnd()) {
            txt.append(in.readLine().toLocal8Bit()+"\n");
        }
        file.close();
        //qDebug()<<txt;

        // Parse File
        QStringList lines=txt.split("\n");
        for (int i=0;i<lines.length();i++){
            QStringList line=lines[i].split("=");
            if (line.length()==2){
                QString var=line[0];
                QString val=line[1];
                //qDebug()<<var+"="+val;
                if (var=="Titel"){
                    titel[n]->clear();
                    titel[n]->append(val);
                }
                if (var=="Titel_X"){
                    titel_x[n]->clear();
                    titel_x[n]->append(val);
                }
                if (var=="Titel_Y"){
                    titel_y[n]->clear();
                    titel_y[n]->append(val);
                }
                if (var=="Symbolsize"){
                    symbol_size[n]=val.toInt();
                }
                if (var=="Textsize"){
                    textsize[n]=val.toInt();
                }
                if (var=="Titelsize"){
                    titelsize[n]=val.toInt();
                }
                if (var=="Margin"){
                    margin[n]=val.toInt();
                }
                if (var=="Linewidth"){
                    line_width[n]=val.toInt();
                }
                if (var=="Linestyle"){
                    if (val=="SolidLine") line_style[n]=Qt::SolidLine;
                    if (val=="DashDotLine") line_style[n]=Qt::DashDotLine;
                    if (val=="DashLine") line_style[n]=Qt::DashLine;
                    if (val=="DotLine") line_style[n]=Qt::DotLine;
                    if (val=="NoPen") line_style[n]=Qt::NoPen;
                    if (val=="DashDotDotLine") line_style[n]=Qt::DashDotDotLine;
                }
                if (var=="Linecolor"){
                    QStringList vals=val.split(",");
                    if (vals.length()==3){
                        line_color[n]=QColor(vals[0].toInt(),vals[1].toInt(),vals[2].toInt());
                    }

                }
            }

        }
    }
    setTitel(*titel[n],*titel_x[n],*titel_y[n],n);
    setSymbol(symbol_size[n],n);
    setTextSize(textsize[n],titelsize[n],margin[n],n);
    setLineColor(line_color[n],n);
    setLineStyle(line_style[n],n);
    setLineWidth(line_width[n],n);
    update();
}

void Graph::saveSettings(int n){
    if (*path[n]!=""){
        getBack(n);

        // Prepare txt
        QString txt;
        txt.clear();
        txt.append("Titel="+*titel[n]+"\n");
        txt.append("Titel_X="+*titel_x[n]+"\n");
        txt.append("Titel_Y="+*titel_y[n]+"\n");
        txt.append("Symbolsize="+QString::number(symbol_size[n])+"\n");
        txt.append("Titelsize="+QString::number(titelsize[n])+"\n");
        txt.append("Textsize="+QString::number(textsize[n])+"\n");
        txt.append("Margin="+QString::number(margin[n])+"\n");
        txt.append("Linewidth="+QString::number(line_width[n])+"\n");
        txt.append("Linecolor="+QString::number(line_color[n].red())+","+QString::number(line_color[n].green())+","+QString::number(line_color[n].blue())+"\n");
        txt.append("Linestyle=");
        if (line_style[n]==Qt::SolidLine) txt.append("SolidLine\n");
        if (line_style[n]==Qt::DotLine) txt.append("DotLine\n");
        if (line_style[n]==Qt::DashLine) txt.append("DashLine\n");
        if (line_style[n]==Qt::DashDotLine) txt.append("DashDotLine\n");
        if (line_style[n]==Qt::DashDotDotLine) txt.append("DashDotDotLine\n");
        if (line_style[n]==Qt::NoPen) txt.append("NoPen\n");

        // Write Everything
        QFile f(*path[n]);
        if(!f.open(QIODevice::WriteOnly | QIODevice::Text)) {
            qDebug() <<  f.errorString();
        } else {
        QTextStream out(&f);
        out<<txt;
        f.close();
        }
    }
}

void Graph::getBack(int n){
    titel[n]->clear();
    titel[n]->append(ggrid[n]->getTitel());
    titel_x[n]->clear();
    titel_x[n]->append(ggrid[n]->getTitelX());
    titel_y[n]->clear();
    titel_y[n]->append(ggrid[n]->getTitelY());
    titelsize[n]=ggrid[n]->getTitelSize();
    textsize[n]=ggrid[n]->getTextSize();
    margin[n]=ggrid[n]->getMargin();
    symbol_size[n]=gdata[n]->getSymbolSize();
    line_width[n]=gdata[n]->getLineWidth();
    line_color[n]=gdata[n]->getLineColor();
    line_style[n]=gdata[n]->getLineStyle();
}
void Graph::setBackground(QString filename, float x1, float x2, float y1, float y2, int mode){
   setBackground(filename, x1, x2, y1, y2, mode,0);
}

void Graph::setBackground(QString filename, float x1, float x2, float y1, float y2, int mode,int n){

    background[n]=mode;
    background_filename[n]->clear();
    background_filename[n]->append(filename);
    background_x1[n]=x1;
    background_x2[n]=x2;
    background_y1[n]=y1;
    background_y2[n]=y2;

    ggrid[n]->setBackground(filename,x1,x2,y1,y2,mode);
}

void Graph::setBackground2(QImage *i, float x1, float x2, float y1, float y2, int mode){
   setBackground2(i, x1, x2, y1, y2, mode,0);
}

void Graph::setBackground2(QImage *i, float x1, float x2, float y1, float y2, int mode,int n){

    background[n]=mode;

    background_image[n]=i;
    background_x1[n]=x1;
    background_x2[n]=x2;
    background_y1[n]=y1;
    background_y2[n]=y2;

    ggrid[n]->setBackground2(i,x1,x2,y1,y2,mode);
    update();
}

void Graph::setBackground(QImage *i, float x1, float x2, float y1, float y2, int mode){
   setBackground(i, x1, x2, y1, y2, mode,0);
}

void Graph::setBackground(QImage *i, float x1, float x2, float y1, float y2, int mode,int n){

    background[n]=mode;

    background_fileimage[n]=i;
    background_x1[n]=x1;
    background_x2[n]=x2;
    background_y1[n]=y1;
    background_y2[n]=y2;

    ggrid[n]->setBackground(i,x1,x2,y1,y2,mode);
    update();
}

void Graph::setRepeat(int x,float x1,float x2,int y,float y1,float y2,int n){
    repeat_x[n]=x;
    repeat_x1[n]=x1;
    repeat_x2[n]=x2;
    repeat_y[n]=y;
    repeat_y1[n]=y1;
    repeat_y2[n]=y2;

    ggrid[n]->setRepeat(x,x1,x2,y,y1,y2);
    gdata[n]->setRepeat(x,x1,x2,y,y1,y2);
}

void Graph::setRepeat(int x,float x1,float x2,int y,float y1,float y2){
    setRepeat(x,x1,x2,y,y1,y2,0);
}

void Graph::setLimit(int x1, int x2, int y1, int y2, int n){
    limit_x1[n]=x1;
    limit_x2[n]=x2;
    limit_y1[n]=y1;
    limit_y2[n]=y2;
}

void Graph::setLimit(int x1, int x2, int y1, int y2){
    setLimit(x1,x2,y1,y2,0);
}

void Graph::setLockAspect(int mode,int n){
    lock_aspect[n]=mode;
}
void Graph::setLockAspect(int mode){
    setLockAspect(mode,0);
}

void Graph::setFolding(int x,int y,int n){
    fold_x[n]=x;
    fold_y[n]=y;
}

void Graph::setFolding(int x,int y){
    setFolding(x,y,0);
}

void Graph::setView(int x1,int x2,int y1,int y2,int n){
    x_max[n]=x2;
    x_min[n]=x1;
    y_min[n]=y1;
    y_max[n]=y2;
    ggrid[n]->setView(x_min[n],x_max[n],y_min[n],y_max[n]);
    gdata[n]->setView(x_min[n],x_max[n],y_min[n],y_max[n]);
    update();
}

void Graph::setView(int x1,int x2,int y1,int y2){
    setView(x1,x2,y1,y2,0);
}
