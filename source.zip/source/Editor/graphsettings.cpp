/********************************************************************************/
/*    This file is part of PaleoDataViewer.                       					*/
/*                                                                      		*/
/*    PaleoDataViewer is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoDataViewer is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoDataViewer.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#include "graphsettings.h"
#include "ui_graphsettings.h"

GraphSettings::GraphSettings(QWidget *parent,GraphData *g,GraphGrid *gg) :
    QDialog(parent),graphdata(g),graphgrid(gg),
    ui(new Ui::GraphSettings)
{
    ui->setupUi(this);
    this->setWindowTitle("Please Edit Plot Settings");
    // Put original values
    ui->lineEdit->setText(graphgrid->getTitel());
    ui->spinBox->setValue(graphgrid->getTitelSize());
    ui->spinBox_3->setValue(graphgrid->getMargin());
    ui->spinBox_2->setValue(graphgrid->getTextSize());
    ui->lineEdit_2->setText(graphgrid->getTitelX());
    ui->lineEdit_3->setText(graphgrid->getTitelY());
    ui->spinBox_4->setValue(graphdata->getSymbolSize());
    ui->spinBox_5->setValue(graphdata->getLineWidth());

    Qt::PenStyle sty=graphdata->getLineStyle();
    if (sty==Qt::NoPen) ui->comboBox_4->setCurrentIndex(0);
    if (sty==Qt::SolidLine) ui->comboBox_4->setCurrentIndex(1);
    if (sty==Qt::DashLine) ui->comboBox_4->setCurrentIndex(2);
    if (sty==Qt::DotLine) ui->comboBox_4->setCurrentIndex(3);
    if (sty==Qt::DashDotLine) ui->comboBox_4->setCurrentIndex(4);
    if (sty==Qt::DashDotDotLine) ui->comboBox_4->setCurrentIndex(5);

    ui->graphicsView->setScene(new QGraphicsScene);
    ui->graphicsView->setBackgroundBrush(graphdata->getLineColor());

    connect(ui->buttonBox,SIGNAL(accepted()),this,SLOT(accepted()));
    connect(ui->buttonBox,SIGNAL(rejected()),this,SLOT(rejected()));
    connect(ui->pushButton,SIGNAL(clicked(bool)),this,SLOT(LineColor()));
}

GraphSettings::~GraphSettings()
{
    delete ui;
}

void GraphSettings::accepted(){
    // set all Settings in dgraph and ggraph
    graphgrid->setTextSize(ui->spinBox_2->value(),ui->spinBox->value(),ui->spinBox_3->value());
    graphdata->setTextSize(ui->spinBox_2->value(),ui->spinBox->value(),ui->spinBox_3->value());
    graphgrid->setTitel(ui->lineEdit->text(),ui->lineEdit_2->text(),ui->lineEdit_3->text());
    graphdata->setSymbol(ui->spinBox_4->value());
    graphdata->setLineWidth(ui->spinBox_5->value());
    if (ui->comboBox_4->currentIndex()==0)graphdata->setLineStyle(Qt::NoPen);
    if (ui->comboBox_4->currentIndex()==1)graphdata->setLineStyle(Qt::SolidLine);
    if (ui->comboBox_4->currentIndex()==2)graphdata->setLineStyle(Qt::DashLine);
    if (ui->comboBox_4->currentIndex()==3)graphdata->setLineStyle(Qt::DotLine);
    if (ui->comboBox_4->currentIndex()==4)graphdata->setLineStyle(Qt::DashDotLine);
    if (ui->comboBox_4->currentIndex()==5)graphdata->setLineStyle(Qt::DashDotDotLine);
    graphdata->setLineColor(ui->graphicsView->backgroundBrush().color());

}

void GraphSettings::rejected(){

}

void GraphSettings::LineColor(){
    QColorDialog cdiag;
    QColor col(cdiag.getColor(ui->graphicsView->backgroundBrush().color(),this));
    if (col.isValid()){
        ui->graphicsView->setBackgroundBrush(col);
    }
}
