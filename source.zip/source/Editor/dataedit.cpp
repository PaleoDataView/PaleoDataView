/********************************************************************************/
/*    This file is part of PaleoDataViewer.                       					*/
/*                                                                      		*/
/*    PaleoDataViewer is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoDataViewer is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoDataViewer.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#include "dataedit.h"
#include "ui_dataedit.h"


DataEdit::DataEdit(QWidget *parent,float *d,float *d_e,int c,int r) :
    QDialog(parent),data(d),data_err(d_e),column(c),row(r),
    ui(new Ui::DataEdit)
{
    ui->setupUi(this);
    this->setWindowTitle("Editor");

    useflag=new bool[c*r];
    col_dat=new QColor[c*r];
    // Initialize: All true
    for (int i=0;i<c*r;i++) useflag[i]=true;
    // Initialize: All white
    for (int i=0;i<c*r;i++) {
        col_dat[i].setRgb(128,128,128,255);
    }
    ccolor.setRgb(128,128,128,255);

    header=NULL;

    modelInventory = new QStandardItemModel(row,column,this);
    setupEditor();
    dat=new float[0];
    use=new bool[0];
    col=new QColor[0];
    dat_err=new float[0];
    select=new int[0];
    g=new GraphEdit(this,data,0,0);
    g->setTitel("","","");
    g->setMultiplicator(1,1);
    g->setSize(ui->graphicsView->width(),ui->graphicsView->height());
    ui->graphicsView->setScene(g);
    connect(modelInventory,SIGNAL(dataChanged(QModelIndex,QModelIndex)),this,SLOT(editData(QModelIndex,QModelIndex)));
    connect(ui->tableView->selectionModel(),SIGNAL(selectionChanged(QItemSelection,QItemSelection)),this,SLOT(createPlot()));
    connect(ui->pushButton_2,SIGNAL(clicked(bool)),this,SLOT(invertUseFlag()));
    connect(ui->comboBox_2,SIGNAL(currentIndexChanged(int)),this,SLOT(createPlot()));
    connect(ui->pushButton,SIGNAL(clicked(bool)),this,SLOT(setColor()));
    connect(ui->pushButton_3,SIGNAL(clicked(bool)),this,SLOT(selectColor()));
    connect(ui->checkBox,SIGNAL(clicked(bool)),this,SLOT(createPlot()));
    connect(ui->comboBox_3,SIGNAL(currentIndexChanged(int)),this,SLOT(createPlot()));
    connect(ui->comboBox,SIGNAL(currentIndexChanged(int)),this,SLOT(createPlot()));
    connect(ui->checkBox_3,SIGNAL(stateChanged(int)),this,SLOT(setInventory()));
    connect(ui->pushButton_4,SIGNAL(clicked(bool)),this,SLOT(copy()));
}

void DataEdit::setHeader(QStringList *h){
    delete header;
    header=h;
    setupEditor();
}

DataEdit::~DataEdit()
{
    delete ui;
    delete[] useflag;
    delete[] col_dat;

    delete modelInventory;
    delete g;
    delete[] dat;
    delete[] use;
    delete[] col;
    delete[] dat_err;
    delete[] select;
}

void DataEdit::setupEditor(){

    // create the model for Inventory

    for (int i=0;i<column;i++) modelInventory->setHorizontalHeaderItem(i, new QStandardItem(QString::number(i)));
    for (int i=0;i<row;i++) modelInventory->setVerticalHeaderItem(i, new QStandardItem(QString::number(i)));

    //...
    ui->tableView->setModel(modelInventory);

    QStandardItem *var_data = new QStandardItem[row*column];
    for (int c=0;c<column;c++){
        if (header!=NULL) {
            modelInventory->setHorizontalHeaderLabels(*header);
        } else {
            QStringList h;
            for (int i=0;i<column;i++) h<<QString::number(i);
            modelInventory->setHorizontalHeaderLabels(h);
        }

        for (int r=0;r<row;r++){
            if (ui->checkBox_3->checkState()==Qt::Unchecked){
                var_data[r+c*row].setData(data[r+c*row],Qt::EditRole);
            }
            if (ui->checkBox_3->checkState()==Qt::Checked){
                var_data[r+c*row].setData(data_err[r+c*row],Qt::EditRole);
            }

            if (useflag[r+c*row]==true){
                QFont font;
                font.setBold(true);
                var_data[r+c*row].setFont(font);
                var_data[r+c*row].setForeground(Qt::black);
                var_data[r+c*row].setBackground(col_dat[r+c*row]);
            } else {
                QFont font;
                font.setPixelSize(10);
                font.setItalic(true);
                var_data[r+c*row].setFont(font);
                var_data[r+c*row].setForeground(Qt::gray);
                var_data[r+c*row].setBackground(Qt::white);
            }

            modelInventory->setItem(r,c,&var_data[r+c*row]);

        }
    }
    ui->tableView->setEditTriggers(QAbstractItemView::DoubleClicked);
    ui->tableView->setSortingEnabled(0);
    ui->tableView->verticalHeader()->setDefaultSectionSize(ui->tableView->verticalHeader()->minimumSectionSize());
    ui->tableView->resizeColumnsToContents();
    ui->tableView->setHorizontalScrollMode(ui->tableView->ScrollPerPixel);
}

void DataEdit::editData(QModelIndex r,QModelIndex c){

    if (ui->checkBox_3->isChecked()){
        data_err[r.row()+r.column()*row]=modelInventory->item(r.row(),r.column())->text().toFloat();
    } else {
        data[r.row()+r.column()*row]=modelInventory->item(r.row(),r.column())->text().toFloat();
    }
}

void DataEdit::createPlot(){
    // get selected Line/s
    QModelIndexList select_column=ui->tableView->selectionModel()->selectedColumns();

    int length=row;
    int width=0;
    // Plot multiple 1D lines with numbering
    if (ui->comboBox->currentText()=="X(n)" && select_column.count()>0){
        // get number of selected Columns
        width=select_column.count();
        // Preparing column data
        delete[] dat;
        delete[] use;
        delete[] col;
        delete[] dat_err;

        dat=new float[(select_column.count())*length*2];
        use=new bool[(select_column.count())*length*2];
        col=new QColor[(select_column.count())*length*2];
        dat_err=new float[(select_column.count())*length*2];

        // create numbers
        for (int i=0;i<length;i++) for (int j=0;j<(select_column.count())*2;j=j+2){
            dat[i+j*length]=i;
            dat_err[i+j*length]=NAN;
        }

        // create columns
        for (int i=0;i<select_column.count();i++) {
            for (int j=0;j<length;j++){
                if (j<row){
                    dat[j+(i*2+1)*length]=data[j+select_column.at(i).column()*row];
                    dat_err[j+(i*2+1)*length]=data_err[j+select_column.at(i).column()*row];
                    use[j+(i*2+1)*length]=useflag[j+select_column.at(i).column()*row];
                    use[j+(i*2)*length]=useflag[j+select_column.at(i).column()*row];
                    col[j+(i*2)*length]=col_dat[j+select_column.at(i).column()*row];

                    col[j+(i*2+1)*length]=col_dat[j+select_column.at(i).column()*row];

                } else {
                    dat[j+(i*2+1)*length]=NAN;
                    use[j+(i*2+1)*length]=false;
                    use[j+(i*2)*length]=false;
                }
            }
            delete g;
            g=new GraphEdit(this,dat,width*2,length);
            g->setUse(use,ui->comboBox_2->currentIndex());
            g->setError(dat_err,ui->comboBox_3->currentIndex());
            g->setColor(col,ui->checkBox->isChecked());
            g->setTitel("","n","X(n)");
            g->setMultiplicator(1,1);
            g->setTextSize(8,0,5);
            g->setSymbol(2);
            g->setSize(ui->graphicsView->width(),ui->graphicsView->height());
            g->autoSize();
            ui->graphicsView->setScene(g);
        }
    }
    // Plot multiple 2D lines
    if (ui->comboBox->currentText()=="X(Y)" && select_column.count()>0){
        delete[] dat;
        delete[] use;
        delete[] col;
        delete[] dat_err;
        delete[] select;
        // Check for width of selected data and count XY combinations
        select=new int[(int)(column/2)];
        for (int i=0;i<column/2;i++) select[i]=0;
        for (int i=0;i<select_column.count();i++){
            select[(int)(select_column.at(i).column()/2)]=1;
        }
        int count=0;
        for (int i=0;i<column/2;i++) count+=select[i];
        width=count*2;
        // Preparing column data
        dat=new float[(count)*length*2];
        use=new bool[(count)*length*2];
        col=new QColor[(count)*length*2];

        dat_err=new float[(count)*length*2];



        // create columns
        int c_counter=0;
        for (int i=0;i<column;i=i+2) {
            if (select[(int)(i/2)]){
                for (int j=0;j<length;j++){
                    if (j<row){
                        dat[j+(c_counter)*length]=data[j+i*row];
                        dat[j+(c_counter+1)*length]=data[j+(i+1)*row];

                        dat_err[j+(c_counter)*length]=data_err[j+i*row];
                        dat_err[j+(c_counter+1)*length]=data_err[j+(i+1)*row];

                        use[j+(c_counter)*length]=useflag[j+i*row];
                        use[j+(c_counter+1)*length]=useflag[j+(i+1)*row];

                        col[j+(c_counter)*length]=col_dat[j+i*row];

                        col[j+(c_counter+1)*length]=col_dat[j+(i+1)*row];

                    } else {
                        dat[j+(c_counter)*length]=NAN;
                        dat[j+(c_counter+1)*length]=NAN;
                        use[j+(c_counter+1)*length]=false;
                        use[j+(c_counter)*length]=false;
                    }
                }
                c_counter+=2;
            }
        }
        delete g;
        g=new GraphEdit(this,dat,width,length);
        g->setUse(use,ui->comboBox_2->currentIndex());
        g->setError(dat_err,ui->comboBox_3->currentIndex());
        g->setColor(col,ui->checkBox->isChecked());
        g->setTitel("","Y","X(Y)");
        g->setMultiplicator(1,1);
        g->setTextSize(8,0,5);
        g->setSymbol(2);
        g->setSize(ui->graphicsView->width(),ui->graphicsView->height());
        g->autoSize();
        ui->graphicsView->setScene(g);

    }

}




void DataEdit::paintEvent(QPaintEvent *)
{
    g->setSize(ui->graphicsView->width(),ui->graphicsView->height());
}

void DataEdit::invertUseFlag(){
    for (int i=0;i<column;i++){
        for (int j=0;j<row;j++){
            bool isselect=ui->tableView->selectionModel()->isSelected(modelInventory->index(j,i,QModelIndex()));
            if (isselect==true) {
                if (useflag[j+i*row]==true){
                    useflag[j+i*row]=false;
                }else{
                    useflag[j+i*row]=true;
                }
            }
        }
    }
    setupEditor();
}

void DataEdit::setColor(){
    for (int i=0;i<column;i++){
        for (int j=0;j<row;j++){
            bool isselect=ui->tableView->selectionModel()->isSelected(modelInventory->index(j,i,QModelIndex()));
            if (isselect==true) {
                col_dat[j+i*row]=ccolor;

            }
        }
    }
    setupEditor();
}

void DataEdit::setInventory(){
    setupEditor();
}

void DataEdit::selectColor(){
    QColorDialog cdiag;
    QColor col(cdiag.getColor(ccolor,this));
    if (col.isValid()){
        ccolor=col;
        QString color="background-color: rgb("+QString::number(ccolor.red())+","+QString::number(ccolor.green())+","+QString::number(ccolor.blue())+")";
        ui->pushButton_3->setStyleSheet(color);
    }
}

void DataEdit::copy(){
    QString clipboardString;
    for (int i=0;i<column;i++) {
        QString str=header->at(i);
        clipboardString.append(str.replace("\n"," : "));
        if (i<column-1) {
            clipboardString.append("\t");
        }else {
            clipboardString.append("\n");
        }
    }
        QModelIndexList selectedIndexes = ui->tableView->selectionModel()->selectedIndexes();
        qSort(selectedIndexes);
        for (int i = 0; i < selectedIndexes.count(); ++i){
            QModelIndex current = selectedIndexes[i];
            QString displayText = current.data(Qt::DisplayRole).toString();
            //if (displayText=="nan") displayText="NAN";
             if (i + 1 < selectedIndexes.count()){
                QModelIndex next = selectedIndexes[i+1];
                if (next.row() != current.row()){
                    displayText.append("\n");
                }else{
                    displayText.append("\t");
                }
            }
            clipboardString.append(displayText);
        }
        qApp->clipboard()->setText(clipboardString);
}
