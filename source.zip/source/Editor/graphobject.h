/********************************************************************************/
/*    This file is part of PaleoDataViewer.                       					*/
/*                                                                      		*/
/*    PaleoDataViewer is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoDataViewer is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoDataViewer.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#ifndef GRAPHOBJECT_H
#define GRAPHOBJECT_H

#include <QGraphicsScene>
#include <QPainter>
#include <QFont>
#include <QGraphicsItem>
#include <math.h>

class GraphObject : public QGraphicsItem
{
public:
    GraphObject(QGraphicsScene *graphScene=0);

    void addLine(float x1,float y1,int n1,float x2,float y2,int n2,QColor c,int w,Qt::PenStyle s);
    void setAddMode(int i);
    void addLineClear();
    void setSize(int size_x,int size_y);
    void setParameters(int size_x,int size_y,int n,int* text,int* titel,int* marg,double* xmin,double* ymin,double* xmax,double* ymax,double* fx, double* fy);
    void setAxisType(int* x,int* y);
    void calcFrame(int i1,int i2);
    int getSelect();
    void setSelect(int i);
    void checkSelect(int x,int y);

    QRectF boundingRect() const Q_DECL_OVERRIDE;
    QPainterPath shape() const Q_DECL_OVERRIDE;
    void paint(QPainter *painter,const QStyleOptionGraphicsItem *option, QWidget *widget) Q_DECL_OVERRIDE;

private:
    QGraphicsScene *graph;

    int plotSize_X,plotSize_Y;
    int number;
    std::vector<int> textsize;
    std::vector<int> titelsize;
    std::vector<int> margin;
    std::vector<double> x_min;
    std::vector<double> y_min;
    std::vector<double> x_max;
    std::vector<double> y_max;
    std::vector<double> factor_x;
    std::vector<double> factor_y;
    int addline_mode=0;
    int addline_count=0;
    std::vector<float> addline_x1;
    std::vector<float> addline_y1;
    std::vector<int> addline_n1;
    std::vector<float> addline_x2;
    std::vector<float> addline_y2;
    std::vector<int> addline_n2;
    std::vector<QColor> addline_color;
    std::vector<int> addline_width;
    std::vector<Qt::PenStyle> addline_style;
    std::vector<int> x_axis_type;
    std::vector<int> y_axis_type;

    int frame_left1;
    int frame_right1;
    int frame_size_x1;
    int frame_top1;
    int frame_bottom1;
    int frame_size_y1;
    int frame_left2;
    int frame_right2;
    int frame_size_x2;
    int frame_top2;
    int frame_bottom2;
    int frame_size_y2;
    int select;
};

#endif // GRAPHOBJECT_H
