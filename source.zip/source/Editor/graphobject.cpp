/********************************************************************************/
/*    This file is part of PaleoDataViewer.                       					*/
/*                                                                      		*/
/*    PaleoDataViewer is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoDataViewer is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoDataViewer.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#include "graphobject.h"
#include <QDebug>

GraphObject::GraphObject(QGraphicsScene *graphScene)
    : graph(graphScene)
{
    addline_mode=0;
    select=-1;
}

void GraphObject::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget){
    // draw all lines
    if (addline_mode){
        for (int i=0;i<addline_count;i++){
            if (std::isnan(addline_x1[i])==false && std::isnan(addline_x2[i])==false && std::isnan(addline_y2[i])==false && std::isnan(addline_y1[i])==false){
                QPen pen;
                pen.setWidth(addline_width[i]);
                pen.setColor(addline_color[i]);
                pen.setStyle(addline_style[i]);
                painter->setPen(pen);
                painter->setRenderHint(QPainter::Antialiasing,true);
                calcFrame(addline_n1[i],addline_n2[i]);
                int x1 = (int) (frame_left1 + (double) (frame_size_x1) * (double) (((addline_x1[i]*factor_x[addline_n1[i]]) - x_min[addline_n1[i]]) / (x_max[addline_n1[i]] - x_min[addline_n1[i]])));
                int y1 = (int) (frame_top1 + (double) (frame_size_y1) * (double) ((y_max[addline_n1[i]] - (addline_y1[i]*factor_y[addline_n1[i]])) / (y_max[addline_n1[i]] - y_min[addline_n1[i]])));
                int x2 = (int) (frame_left2 + (double) (frame_size_x2) * (double) (((addline_x2[i]*factor_x[addline_n2[i]]) - x_min[addline_n2[i]]) / (x_max[addline_n2[i]] - x_min[addline_n2[i]])));
                int y2 = (int) (frame_top2 + (double) (frame_size_y2) * (double) ((y_max[addline_n2[i]] - (addline_y2[i]*factor_y[addline_n2[i]])) / (y_max[addline_n2[i]] - y_min[addline_n2[i]])));
                int p1_check=1;
                int p2_check=1;
                // check start and paint arrows
                if (addline_x1[i]*factor_x[addline_n1[i]]>x_min[addline_n1[i]]
                        && addline_x1[i]*factor_x[addline_n1[i]]<x_max[addline_n1[i]] &&
                        addline_y1[i]*factor_y[addline_n1[i]]>y_max[addline_n1[i]]){
                    // Paint Top Arrow
                    int x=x1;
                    int y=(int) (frame_top1 + (double) (frame_size_y1) * (double) ((y_max[addline_n1[i]] - (y_max[addline_n1[i]]*factor_y[addline_n1[i]])) / (y_max[addline_n1[i]] - y_min[addline_n1[i]])));
                    painter->drawLine(x,y,x,y+15);
                    painter->drawLine(x,y,x-5,y+5);
                    painter->drawLine(x,y,x+5,y+5);
                    y1=y+15;
                    p1_check=0;
                }
                if (addline_x1[i]*factor_x[addline_n1[i]]>x_min[addline_n1[i]]
                        && addline_x1[i]*factor_x[addline_n1[i]]<x_max[addline_n1[i]] &&
                        addline_y1[i]*factor_y[addline_n1[i]]<y_min[addline_n1[i]]){
                    // Paint Bottom Arrow
                    int x=x1;
                    int y=(int) (frame_top1 + (double) (frame_size_y1) * (double) ((y_max[addline_n1[i]] - (y_min[addline_n1[i]]*factor_y[addline_n1[i]])) / (y_max[addline_n1[i]] - y_min[addline_n1[i]])));
                    painter->drawLine(x,y,x,y-15);
                    painter->drawLine(x,y,x-5,y-5);
                    painter->drawLine(x,y,x+5,y-5);
                    y1=y-15;
                    p1_check=0;
                }
                if (addline_y1[i]*factor_y[addline_n1[i]]>y_min[addline_n1[i]]
                        && addline_y1[i]*factor_y[addline_n1[i]]<y_max[addline_n1[i]] &&
                        addline_x1[i]*factor_x[addline_n1[i]]>x_max[addline_n1[i]]){
                    // Paint Right Arrow
                    int y=y1;
                    int x=(int) (frame_left1 + (double) (frame_size_x1) * (double) (((x_max[addline_n1[i]]*factor_x[addline_n1[i]]) - x_min[addline_n1[i]]) / (x_max[addline_n1[i]] - x_min[addline_n1[i]])));
                    painter->drawLine(x,y,x-15,y);
                    painter->drawLine(x,y,x-5,y+5);
                    painter->drawLine(x,y,x-5,y-5);
                    x1=x-15;
                    p1_check=0;
                }
                if (addline_y1[i]*factor_y[addline_n1[i]]>y_min[addline_n1[i]]
                        && addline_y1[i]*factor_y[addline_n1[i]]<y_max[addline_n1[i]] &&
                        addline_x1[i]*factor_x[addline_n1[i]]<x_min[addline_n1[i]]){
                    // Paint Left Arrow
                    int y=y1;
                    int x=(int) (frame_left1 + (double) (frame_size_x1) * (double) (((x_min[addline_n1[i]]*factor_x[addline_n1[i]]) - x_min[addline_n1[i]]) / (x_max[addline_n1[i]] - x_min[addline_n1[i]])));
                    painter->drawLine(x,y,x+15,y);
                    painter->drawLine(x,y,x+5,y+5);
                    painter->drawLine(x,y,x+5,y-5);
                    x1=x+15;
                    p1_check=0;
                }
                if (addline_x1[i]*factor_x[addline_n1[i]]<x_min[addline_n1[i]] &&
                        addline_y1[i]*factor_y[addline_n1[i]]>y_max[addline_n1[i]]){
                    // Paint Left&Up Arrow
                    int y=(int) (frame_top1 + (double) (frame_size_y1) * (double) ((y_max[addline_n1[i]] - (y_max[addline_n1[i]]*factor_y[addline_n1[i]])) / (y_max[addline_n1[i]] - y_min[addline_n1[i]])));
                    int x=(int) (frame_left1 + (double) (frame_size_x1) * (double) (((x_min[addline_n1[i]]*factor_x[addline_n1[i]]) - x_min[addline_n1[i]]) / (x_max[addline_n1[i]] - x_min[addline_n1[i]])));
                    painter->drawLine(x,y,x+15,y+15);
                    painter->drawLine(x,y,x,y+5);
                    painter->drawLine(x,y,x+5,y);
                    x1=x+15;
                    y1=y+15;
                    p1_check=0;
                }
                if (addline_x1[i]*factor_x[addline_n1[i]]>x_max[addline_n1[i]] &&
                        addline_y1[i]*factor_y[addline_n1[i]]>y_max[addline_n1[i]]){
                    // Paint Right&Up Arrow
                    int y=(int) (frame_top1+ (double) (frame_size_y1) * (double) ((y_max[addline_n1[i]] - (y_max[addline_n1[i]]*factor_y[addline_n1[i]])) / (y_max[addline_n1[i]] - y_min[addline_n1[i]])));
                    int x=(int) (frame_left1 + (double) (frame_size_x1) * (double) (((x_max[addline_n1[i]]*factor_x[addline_n1[i]]) - x_min[addline_n1[i]]) / (x_max[addline_n1[i]] - x_min[addline_n1[i]])));
                    painter->drawLine(x,y,x-15,y+15);
                    painter->drawLine(x,y,x,y+5);
                    painter->drawLine(x,y,x-5,y);
                    x1=x-15;
                    y1=y+15;
                    p1_check=0;
                }
                if (addline_x1[i]*factor_x[addline_n1[i]]>x_max[addline_n1[i]] &&
                        addline_y1[i]*factor_y[addline_n1[i]]<y_min[addline_n1[i]]){
                    // Paint Right&Down Arrow
                    int y=(int) (frame_top1 + (double) (frame_size_y1) * (double) ((y_max[addline_n1[i]] - (y_min[addline_n1[i]]*factor_y[addline_n1[i]])) / (y_max[addline_n1[i]] - y_min[addline_n1[i]])));
                    int x=(int) (frame_left1 + (double) (frame_size_x1) * (double) (((x_max[addline_n1[i]]*factor_x[addline_n1[i]]) - x_min[addline_n1[i]]) / (x_max[addline_n1[i]] - x_min[addline_n1[i]])));
                    painter->drawLine(x,y,x-15,y-15);
                    painter->drawLine(x,y,x,y-5);
                    painter->drawLine(x,y,x-5,y);
                    x1=x-15;
                    y1=y-15;
                    p1_check=0;
                }
                if (addline_x1[i]*factor_x[addline_n1[i]]<x_min[addline_n1[i]] &&
                        addline_y1[i]*factor_y[addline_n1[i]]<y_min[addline_n1[i]]){
                    // Paint Left&Down Arrow
                    int y=(int) (frame_top1 + (double) (frame_size_y1) * (double) ((y_max[addline_n1[i]] - (y_min[addline_n1[i]]*factor_y[addline_n1[i]])) / (y_max[addline_n1[i]] - y_min[addline_n1[i]])));
                    int x=(int) (frame_left1 + (double) (frame_size_x1) * (double) (((x_min[addline_n1[i]]*factor_x[addline_n1[i]]) - x_min[addline_n1[i]]) / (x_max[addline_n1[i]] - x_min[addline_n1[i]])));
                    painter->drawLine(x,y,x+15,y-15);
                    painter->drawLine(x,y,x,y-5);
                    painter->drawLine(x,y,x+5,y);
                    x1=x+15;
                    y1=y-15;
                    p1_check=0;
                }

                // check end and paint arrows
                if (addline_x2[i]*factor_x[addline_n2[i]]>x_min[addline_n2[i]]
                        && addline_x2[i]*factor_x[addline_n2[i]]<x_max[addline_n2[i]] &&
                        addline_y2[i]*factor_y[addline_n2[i]]>y_max[addline_n2[i]]){
                    // Paint Top Arrow
                    int x=x2;
                    int y=(int) (frame_top2 + (double) (frame_size_y2) * (double) ((y_max[addline_n2[i]] - (y_max[addline_n2[i]]*factor_y[addline_n2[i]])) / (y_max[addline_n2[i]] - y_min[addline_n2[i]])));
                    painter->drawLine(x,y,x,y+15);
                    painter->drawLine(x,y,x-5,y+5);
                    painter->drawLine(x,y,x+5,y+5);
                    y2=y+15;
                    p2_check=0;
                }
                if (addline_x2[i]*factor_x[addline_n2[i]]>x_min[addline_n2[i]]
                        && addline_x2[i]*factor_x[addline_n2[i]]<x_max[addline_n2[i]] &&
                        addline_y2[i]*factor_y[addline_n2[i]]<y_min[addline_n2[i]]){
                    // Paint Bottom Arrow
                    int x=x2;
                    int y=(int) (frame_top2 + (double) (frame_size_y2) * (double) ((y_max[addline_n2[i]] - (y_min[addline_n2[i]]*factor_y[addline_n2[i]])) / (y_max[addline_n2[i]] - y_min[addline_n2[i]])));
                    painter->drawLine(x,y,x,y-15);
                    painter->drawLine(x,y,x-5,y-5);
                    painter->drawLine(x,y,x+5,y-5);
                    y2=y-15;
                    p2_check=0;
                }
                if (addline_y2[i]*factor_y[addline_n2[i]]>y_min[addline_n2[i]]
                        && addline_y2[i]*factor_y[addline_n2[i]]<y_max[addline_n2[i]] &&
                        addline_x2[i]*factor_x[addline_n2[i]]>x_max[addline_n2[i]]){
                    // Paint Right Arrow
                    int y=y2;
                    int x=(int) (frame_left2 + (double) (frame_size_x2) * (double) (((x_max[addline_n2[i]]*factor_x[addline_n2[i]]) - x_min[addline_n2[i]]) / (x_max[addline_n2[i]] - x_min[addline_n2[i]])));
                    painter->drawLine(x,y,x-15,y);
                    painter->drawLine(x,y,x-5,y+5);
                    painter->drawLine(x,y,x-5,y-5);
                    x2=x-15;
                    p2_check=0;
                }
                if (addline_y2[i]*factor_y[addline_n2[i]]>y_min[addline_n2[i]]
                        && addline_y2[i]*factor_y[addline_n2[i]]<y_max[addline_n2[i]] &&
                        addline_x2[i]*factor_x[addline_n2[i]]<x_min[addline_n2[i]]){
                    // Paint Left Arrow
                    int y=y2;
                    int x=(int) (frame_left2 + (double) (frame_size_x2) * (double) (((x_min[addline_n2[i]]*factor_x[addline_n2[i]]) - x_min[addline_n2[i]]) / (x_max[addline_n2[i]] - x_min[addline_n2[i]])));
                    painter->drawLine(x,y,x+15,y);
                    painter->drawLine(x,y,x+5,y+5);
                    painter->drawLine(x,y,x+5,y-5);
                    x2=x+15;
                    p2_check=0;
                }
                if (addline_x2[i]*factor_x[addline_n2[i]]<x_min[addline_n2[i]] &&
                        addline_y2[i]*factor_y[addline_n2[i]]>y_max[addline_n2[i]]){
                    // Paint Left&Up Arrow
                    int y=(int) (frame_top2 + (double) (frame_size_y2) * (double) ((y_max[addline_n2[i]] - (y_max[addline_n2[i]]*factor_y[addline_n2[i]])) / (y_max[addline_n2[i]] - y_min[addline_n2[i]])));
                    int x=(int) (frame_left2 + (double) (frame_size_x2) * (double) (((x_min[addline_n2[i]]*factor_x[addline_n2[i]]) - x_min[addline_n2[i]]) / (x_max[addline_n2[i]] - x_min[addline_n2[i]])));
                    painter->drawLine(x,y,x+15,y+15);
                    painter->drawLine(x,y,x,y+5);
                    painter->drawLine(x,y,x+5,y);
                    x2=x+15;
                    y2=y+15;
                    p2_check=0;
                }
                if (addline_x2[i]*factor_x[addline_n2[i]]>x_max[addline_n2[i]] &&
                        addline_y2[i]*factor_y[addline_n2[i]]>y_max[addline_n2[i]]){
                    // Paint Right&Up Arrow
                    int y=(int) (frame_top2 + (double) (frame_size_y2) * (double) ((y_max[addline_n2[i]] - (y_max[addline_n2[i]]*factor_y[addline_n2[i]])) / (y_max[addline_n2[i]] - y_min[addline_n2[i]])));
                    int x=(int) (frame_left2 + (double) (frame_size_x2) * (double) (((x_max[addline_n2[i]]*factor_x[addline_n2[i]]) - x_min[addline_n2[i]]) / (x_max[addline_n2[i]] - x_min[addline_n2[i]])));
                    painter->drawLine(x,y,x-15,y+15);
                    painter->drawLine(x,y,x,y+5);
                    painter->drawLine(x,y,x-5,y);
                    x2=x-15;
                    y2=y+15;
                    p2_check=0;
                }
                if (addline_x2[i]*factor_x[addline_n2[i]]>x_max[addline_n2[i]] &&
                        addline_y2[i]*factor_y[addline_n2[i]]<y_min[addline_n2[i]]){
                    // Paint Right&Down Arrow
                    int y=(int) (frame_top2 + (double) (frame_size_y2) * (double) ((y_max[addline_n2[i]] - (y_min[addline_n2[i]]*factor_y[addline_n2[i]])) / (y_max[addline_n2[i]] - y_min[addline_n2[i]])));
                    int x=(int) (frame_left2 + (double) (frame_size_x2) * (double) (((x_max[addline_n2[i]]*factor_x[addline_n2[i]]) - x_min[addline_n2[i]]) / (x_max[addline_n2[i]] - x_min[addline_n2[i]])));
                    painter->drawLine(x,y,x-15,y-15);
                    painter->drawLine(x,y,x,y-5);
                    painter->drawLine(x,y,x-5,y);
                    x2=x-15;
                    y2=y-15;
                    p2_check=0;
                }
                if (addline_x2[i]*factor_x[addline_n2[i]]<x_min[addline_n2[i]] &&
                        addline_y2[i]*factor_y[addline_n2[i]]<y_min[addline_n2[i]]){
                    // Paint Left&Down Arrow
                    int y=(int) (frame_top2 + (double) (frame_size_y2) * (double) ((y_max[addline_n2[i]] - (y_min[addline_n2[i]]*factor_y[addline_n2[i]])) / (y_max[addline_n2[i]] - y_min[addline_n2[i]])));
                    int x=(int) (frame_left2 + (double) (frame_size_x2) * (double) (((x_min[addline_n2[i]]*factor_x[addline_n2[i]]) - x_min[addline_n2[i]]) / (x_max[addline_n2[i]] - x_min[addline_n2[i]])));
                    painter->drawLine(x,y,x+15,y-15);
                    painter->drawLine(x,y,x,y-5);
                    painter->drawLine(x,y,x+5,y);
                    x2=x+15;
                    y2=y-15;
                    p2_check=0;
                }
                painter->drawLine(x1,y1,x2,y2);
                pen.setColor(Qt::black);
                pen.setWidth(1);
                pen.setStyle(Qt::SolidLine);
                painter->setPen(pen);
                painter->setBrush(addline_color[i]);
                if (p1_check) painter->drawRect(QRect(x1-addline_width[i]*2,y1-addline_width[i]*2,4*addline_width[i],4*addline_width[i]));
                if (p2_check) painter->drawRect(QRect(x2-addline_width[i]*2,y2-addline_width[i]*2,4*addline_width[i],4*addline_width[i]));
            }
        }

     }
}

void GraphObject::addLineClear(){
    addline_x1.clear();
    addline_y1.clear();
    addline_n1.clear();
    addline_x2.clear();
    addline_y2.clear();
    addline_n2.clear();
    addline_color.clear();
    addline_width.clear();
    addline_style.clear();
    addline_count=0;
    select=-1;
}

void GraphObject::addLine(float x1,float y1,int n1,float x2,float y2,int n2,QColor c,int w,Qt::PenStyle s){
    addline_x1.push_back(x1);
    addline_y1.push_back(y1);
    addline_n1.push_back(n1);
    addline_x2.push_back(x2);
    addline_y2.push_back(y2);
    addline_n2.push_back(n2);
    addline_color.push_back(c);
    addline_width.push_back(w);
    addline_style.push_back(s);
    addline_count++;
    select=-1;
}

void GraphObject::setAddMode(int i){
    addline_mode=i;
}

QRectF GraphObject::boundingRect() const
{
}

QPainterPath GraphObject::shape() const
{
}

void GraphObject::setParameters(int size_x,int size_y,int n,int* text,int* titel,int* marg,double* xmin,double* ymin,double* xmax,double* ymax,double* fx,double* fy){
    plotSize_X=size_x;
    plotSize_Y=size_y;
    number=n;
    textsize.reserve(number);
    titelsize.reserve(number);
    margin.reserve(number);
    x_min.reserve(number);
    y_min.reserve(number);
    x_max.reserve(number);
    y_max.reserve(number);
    x_axis_type.reserve(number);
    y_axis_type.reserve(number);
    factor_x.reserve(number);
    factor_y.reserve(number);
    for(int i=0;i<number;i++){
        textsize[i]=text[i];
        titelsize[i]=titel[i];
        margin[i]=marg[i];
        x_min[i]=xmin[i];
        y_min[i]=ymin[i];
        x_max[i]=xmax[i];
        y_max[i]=ymax[i];
        factor_x[i]=fx[i];
        factor_y[i]=fy[i];
        select=-1;
    }
}

void GraphObject::setSize(int size_x,int size_y){
    plotSize_X=size_x;
    plotSize_Y=size_y;
}

void GraphObject::setAxisType(int* x,int* y){
    for(int i=0;i<number;i++){
        x_axis_type[i]=x[i];
        y_axis_type[i]=y[i];

    }
}

int GraphObject::getSelect(){
    return select;
}

void GraphObject::setSelect(int i){
    select=i;
}

void GraphObject::checkSelect(int x,int y){
    select=-1;
    for (int i=0;i<addline_count;i++){
        calcFrame(addline_n1[i],addline_n2[i]);
        int x1 = (int) (frame_left1 + (double) (frame_size_x1) * (double) (((addline_x1[i]*factor_x[addline_n1[i]]) - x_min[addline_n1[i]]) / (x_max[addline_n1[i]] - x_min[addline_n1[i]])));
        int y1 = (int) (frame_top1 + (double) (frame_size_y1) * (double) ((y_max[addline_n1[i]] - (addline_y1[i]*factor_y[addline_n1[i]])) / (y_max[addline_n1[i]] - y_min[addline_n1[i]])));
        int x2 = (int) (frame_left2 + (double) (frame_size_x2) * (double) (((addline_x2[i]*factor_x[addline_n2[i]]) - x_min[addline_n2[i]]) / (x_max[addline_n2[i]] - x_min[addline_n2[i]])));
        int y2 = (int) (frame_top2 + (double) (frame_size_y2) * (double) ((y_max[addline_n2[i]] - (addline_y2[i]*factor_y[addline_n2[i]])) / (y_max[addline_n2[i]] - y_min[addline_n2[i]])));
        int p1_check=1;
        int p2_check=1;
        // check start and paint arrows
        if (addline_x1[i]*factor_x[addline_n1[i]]>x_min[addline_n1[i]]
                && addline_x1[i]*factor_x[addline_n1[i]]<x_max[addline_n1[i]] &&
                addline_y1[i]*factor_y[addline_n1[i]]>y_max[addline_n1[i]]){
            // Paint Top Arrow
            int x=x1;
            int y=(int) (frame_top1 + (double) (frame_size_y1) * (double) ((y_max[addline_n1[i]] - (y_max[addline_n1[i]]*factor_y[addline_n1[i]])) / (y_max[addline_n1[i]] - y_min[addline_n1[i]])));

            y1=y+15;
            p1_check=0;
        }
        if (addline_x1[i]*factor_x[addline_n1[i]]>x_min[addline_n1[i]]
                && addline_x1[i]*factor_x[addline_n1[i]]<x_max[addline_n1[i]] &&
                addline_y1[i]*factor_y[addline_n1[i]]<y_min[addline_n1[i]]){
            // Paint Bottom Arrow
            int x=x1;
            int y=(int) (frame_top1 + (double) (frame_size_y1) * (double) ((y_max[addline_n1[i]] - (y_min[addline_n1[i]]*factor_y[addline_n1[i]])) / (y_max[addline_n1[i]] - y_min[addline_n1[i]])));

            y1=y-15;
            p1_check=0;
        }
        if (addline_y1[i]*factor_y[addline_n1[i]]>y_min[addline_n1[i]]
                && addline_y1[i]*factor_y[addline_n1[i]]<y_max[addline_n1[i]] &&
                addline_x1[i]*factor_x[addline_n1[i]]>x_max[addline_n1[i]]){
            // Paint Right Arrow
            int y=y1;
            int x=(int) (frame_left1 + (double) (frame_size_x1) * (double) (((x_max[addline_n1[i]]*factor_x[addline_n1[i]]) - x_min[addline_n1[i]]) / (x_max[addline_n1[i]] - x_min[addline_n1[i]])));

            x1=x-15;
            p1_check=0;
        }
        if (addline_y1[i]*factor_y[addline_n1[i]]>y_min[addline_n1[i]]
                && addline_y1[i]*factor_y[addline_n1[i]]<y_max[addline_n1[i]] &&
                addline_x1[i]*factor_x[addline_n1[i]]<x_min[addline_n1[i]]){
            // Paint Left Arrow
            int y=y1;
            int x=(int) (frame_left1 + (double) (frame_size_x1) * (double) (((x_min[addline_n1[i]]*factor_x[addline_n1[i]]) - x_min[addline_n1[i]]) / (x_max[addline_n1[i]] - x_min[addline_n1[i]])));

            x1=x+15;
            p1_check=0;
        }
        if (addline_x1[i]*factor_x[addline_n1[i]]<x_min[addline_n1[i]] &&
                addline_y1[i]*factor_y[addline_n1[i]]>y_max[addline_n1[i]]){
            // Paint Left&Up Arrow
            int y=(int) (frame_top1 + (double) (frame_size_y1) * (double) ((y_max[addline_n1[i]] - (y_max[addline_n1[i]]*factor_y[addline_n1[i]])) / (y_max[addline_n1[i]] - y_min[addline_n1[i]])));
            int x=(int) (frame_left1 + (double) (frame_size_x1) * (double) (((x_min[addline_n1[i]]*factor_x[addline_n1[i]]) - x_min[addline_n1[i]]) / (x_max[addline_n1[i]] - x_min[addline_n1[i]])));

            x1=x+15;
            y1=y+15;
            p1_check=0;
        }
        if (addline_x1[i]*factor_x[addline_n1[i]]>x_max[addline_n1[i]] &&
                addline_y1[i]*factor_y[addline_n1[i]]>y_max[addline_n1[i]]){
            // Paint Right&Up Arrow
            int y=(int) (frame_top1+ (double) (frame_size_y1) * (double) ((y_max[addline_n1[i]] - (y_max[addline_n1[i]]*factor_y[addline_n1[i]])) / (y_max[addline_n1[i]] - y_min[addline_n1[i]])));
            int x=(int) (frame_left1 + (double) (frame_size_x1) * (double) (((x_max[addline_n1[i]]*factor_x[addline_n1[i]]) - x_min[addline_n1[i]]) / (x_max[addline_n1[i]] - x_min[addline_n1[i]])));

            x1=x-15;
            y1=y+15;
            p1_check=0;
        }
        if (addline_x1[i]*factor_x[addline_n1[i]]>x_max[addline_n1[i]] &&
                addline_y1[i]*factor_y[addline_n1[i]]<y_min[addline_n1[i]]){
            // Paint Right&Down Arrow
            int y=(int) (frame_top1 + (double) (frame_size_y1) * (double) ((y_max[addline_n1[i]] - (y_min[addline_n1[i]]*factor_y[addline_n1[i]])) / (y_max[addline_n1[i]] - y_min[addline_n1[i]])));
            int x=(int) (frame_left1 + (double) (frame_size_x1) * (double) (((x_max[addline_n1[i]]*factor_x[addline_n1[i]]) - x_min[addline_n1[i]]) / (x_max[addline_n1[i]] - x_min[addline_n1[i]])));

            x1=x-15;
            y1=y-15;
            p1_check=0;
        }
        if (addline_x1[i]*factor_x[addline_n1[i]]<x_min[addline_n1[i]] &&
                addline_y1[i]*factor_y[addline_n1[i]]<y_min[addline_n1[i]]){
            // Paint Left&Down Arrow
            int y=(int) (frame_top1 + (double) (frame_size_y1) * (double) ((y_max[addline_n1[i]] - (y_min[addline_n1[i]]*factor_y[addline_n1[i]])) / (y_max[addline_n1[i]] - y_min[addline_n1[i]])));
            int x=(int) (frame_left1 + (double) (frame_size_x1) * (double) (((x_min[addline_n1[i]]*factor_x[addline_n1[i]]) - x_min[addline_n1[i]]) / (x_max[addline_n1[i]] - x_min[addline_n1[i]])));

            x1=x+15;
            y1=y-15;
            p1_check=0;
        }

        // check end and paint arrows
        if (addline_x2[i]*factor_x[addline_n2[i]]>x_min[addline_n2[i]]
                && addline_x2[i]*factor_x[addline_n2[i]]<x_max[addline_n2[i]] &&
                addline_y2[i]*factor_y[addline_n2[i]]>y_max[addline_n2[i]]){
            // Paint Top Arrow
            int x=x2;
            int y=(int) (frame_top2 + (double) (frame_size_y2) * (double) ((y_max[addline_n2[i]] - (y_max[addline_n2[i]]*factor_y[addline_n2[i]])) / (y_max[addline_n2[i]] - y_min[addline_n2[i]])));

            y2=y+15;
            p2_check=0;
        }
        if (addline_x2[i]*factor_x[addline_n2[i]]>x_min[addline_n2[i]]
                && addline_x2[i]*factor_x[addline_n2[i]]<x_max[addline_n2[i]] &&
                addline_y2[i]*factor_y[addline_n2[i]]<y_min[addline_n2[i]]){
            // Paint Bottom Arrow
            int x=x2;
            int y=(int) (frame_top2 + (double) (frame_size_y2) * (double) ((y_max[addline_n2[i]] - (y_min[addline_n2[i]]*factor_y[addline_n2[i]])) / (y_max[addline_n2[i]] - y_min[addline_n2[i]])));

            y2=y-15;
            p2_check=0;
        }
        if (addline_y2[i]*factor_y[addline_n2[i]]>y_min[addline_n2[i]]
                && addline_y2[i]*factor_y[addline_n2[i]]<y_max[addline_n2[i]] &&
                addline_x2[i]*factor_x[addline_n2[i]]>x_max[addline_n2[i]]){
            // Paint Right Arrow
            int y=y2;
            int x=(int) (frame_left2 + (double) (frame_size_x2) * (double) (((x_max[addline_n2[i]]*factor_x[addline_n2[i]]) - x_min[addline_n2[i]]) / (x_max[addline_n2[i]] - x_min[addline_n2[i]])));

            x2=x-15;
            p2_check=0;
        }
        if (addline_y2[i]*factor_y[addline_n2[i]]>y_min[addline_n2[i]]
                && addline_y2[i]*factor_y[addline_n2[i]]<y_max[addline_n2[i]] &&
                addline_x2[i]*factor_x[addline_n2[i]]<x_min[addline_n2[i]]){
            // Paint Left Arrow
            int y=y2;
            int x=(int) (frame_left2 + (double) (frame_size_x2) * (double) (((x_min[addline_n2[i]]*factor_x[addline_n2[i]]) - x_min[addline_n2[i]]) / (x_max[addline_n2[i]] - x_min[addline_n2[i]])));

            x2=x+15;
            p2_check=0;
        }
        if (addline_x2[i]*factor_x[addline_n2[i]]<x_min[addline_n2[i]] &&
                addline_y2[i]*factor_y[addline_n2[i]]>y_max[addline_n2[i]]){
            // Paint Left&Up Arrow
            int y=(int) (frame_top2 + (double) (frame_size_y2) * (double) ((y_max[addline_n2[i]] - (y_max[addline_n2[i]]*factor_y[addline_n2[i]])) / (y_max[addline_n2[i]] - y_min[addline_n2[i]])));
            int x=(int) (frame_left2 + (double) (frame_size_x2) * (double) (((x_min[addline_n2[i]]*factor_x[addline_n2[i]]) - x_min[addline_n2[i]]) / (x_max[addline_n2[i]] - x_min[addline_n2[i]])));

            x2=x+15;
            y2=y+15;
            p2_check=0;
        }
        if (addline_x2[i]*factor_x[addline_n2[i]]>x_max[addline_n2[i]] &&
                addline_y2[i]*factor_y[addline_n2[i]]>y_max[addline_n2[i]]){
            // Paint Right&Up Arrow
            int y=(int) (frame_top2 + (double) (frame_size_y2) * (double) ((y_max[addline_n2[i]] - (y_max[addline_n2[i]]*factor_y[addline_n2[i]])) / (y_max[addline_n2[i]] - y_min[addline_n2[i]])));
            int x=(int) (frame_left2 + (double) (frame_size_x2) * (double) (((x_max[addline_n2[i]]*factor_x[addline_n2[i]]) - x_min[addline_n2[i]]) / (x_max[addline_n2[i]] - x_min[addline_n2[i]])));

            x2=x-15;
            y2=y+15;
            p2_check=0;
        }
        if (addline_x2[i]*factor_x[addline_n2[i]]>x_max[addline_n2[i]] &&
                addline_y2[i]*factor_y[addline_n2[i]]<y_min[addline_n2[i]]){
            // Paint Right&Down Arrow
            int y=(int) (frame_top2 + (double) (frame_size_y2) * (double) ((y_max[addline_n2[i]] - (y_min[addline_n2[i]]*factor_y[addline_n2[i]])) / (y_max[addline_n2[i]] - y_min[addline_n2[i]])));
            int x=(int) (frame_left2 + (double) (frame_size_x2) * (double) (((x_max[addline_n2[i]]*factor_x[addline_n2[i]]) - x_min[addline_n2[i]]) / (x_max[addline_n2[i]] - x_min[addline_n2[i]])));

            x2=x-15;
            y2=y-15;
            p2_check=0;
        }
        if (addline_x2[i]*factor_x[addline_n2[i]]<x_min[addline_n2[i]] &&
                addline_y2[i]*factor_y[addline_n2[i]]<y_min[addline_n2[i]]){
            // Paint Left&Down Arrow
            int y=(int) (frame_top2 + (double) (frame_size_y2) * (double) ((y_max[addline_n2[i]] - (y_min[addline_n2[i]]*factor_y[addline_n2[i]])) / (y_max[addline_n2[i]] - y_min[addline_n2[i]])));
            int x=(int) (frame_left2 + (double) (frame_size_x2) * (double) (((x_min[addline_n2[i]]*factor_x[addline_n2[i]]) - x_min[addline_n2[i]]) / (x_max[addline_n2[i]] - x_min[addline_n2[i]])));

            x2=x+15;
            y2=y-15;
            p2_check=0;
        }

        float dist=std::abs((y2-y1)*x-(x2-x1)*y+x2*y1-y2*x1)/std::sqrt((y2-y1)*(y2-y1)+(x2-x1)*(x2-x1));
        if (dist<addline_width[i]+1){
            select=i;
            break;
        }
    }
}



void GraphObject::calcFrame(int i1, int i2){
    if (y_axis_type[i1]==0){
        frame_right1=plotSize_X/2-margin[i1];
        frame_left1=-plotSize_X/2+5*textsize[i1]+margin[i1];
        frame_size_x1=frame_right1-frame_left1;
    }
    if (y_axis_type[i1]==1){
        frame_right1=plotSize_X/2-margin[i1]-5*textsize[i1];
        frame_left1=-plotSize_X/2+margin[i1];
        frame_size_x1=frame_right1-frame_left1;
    }
    if (x_axis_type[i1]==0){
        frame_top1=-plotSize_Y/2+i1*(plotSize_Y/number)+titelsize[i1]+margin[i1];
        frame_size_y1=(plotSize_Y/number)-2*margin[i1]-5*textsize[i1]-titelsize[i1];
        frame_bottom1=frame_top1+frame_size_y1;

    }
    if (x_axis_type[i1]==1){
        frame_top1=-plotSize_Y/2+i1*(plotSize_Y/number)+titelsize[i1]+margin[i1]+5*textsize[i1];
        frame_size_y1=(plotSize_Y/number)-2*margin[i1]-5*textsize[i1]-titelsize[i1];
        frame_bottom1=frame_top1+frame_size_y1;
    }
    if (y_axis_type[i2]==0){
        frame_right2=plotSize_X/2-margin[i2];
        frame_left2=-plotSize_X/2+5*textsize[i2]+margin[i2];
        frame_size_x2=frame_right2-frame_left2;
    }
    if (y_axis_type[i2]==1){
        frame_right2=plotSize_X/2-margin[i2]-5*textsize[i2];
        frame_left2=-plotSize_X/2+margin[i2];
        frame_size_x2=frame_right2-frame_left2;
    }
    if (x_axis_type[i2]==0){
        frame_top2=-plotSize_Y/2+i2*(plotSize_Y/number)+titelsize[i2]+margin[i2];
        frame_size_y2=(plotSize_Y/number)-2*margin[i2]-5*textsize[i2]-titelsize[i2];
        frame_bottom2=frame_top2+frame_size_y2;

    }
    if (x_axis_type[i2]==1){
        frame_top2=-plotSize_Y/2+i2*(plotSize_Y/number)+titelsize[i2]+margin[i2]+5*textsize[i2];
        frame_size_y2=(plotSize_Y/number)-2*margin[i2]-5*textsize[i2]-titelsize[i2];
        frame_bottom2=frame_top2+frame_size_y2;
    }

}
