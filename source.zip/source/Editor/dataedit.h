/********************************************************************************/
/*    This file is part of PaleoDataViewer.                       					*/
/*                                                                      		*/
/*    PaleoDataViewer is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoDataViewer is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoDataViewer.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#ifndef DATAEDIT_H
#define DATAEDIT_H

#include <QDialog>
#include <QStandardItemModel>
#include <QDebug>
#include "graphedit.h"
#include <QColorDialog>
#include <QApplication>
#include <QClipboard>

namespace Ui {
class DataEdit;
}

class DataEdit : public QDialog
{
    Q_OBJECT

public:
    explicit DataEdit(QWidget *parent = 0,float *d=0,float *d_e=0,int c=0,int r=0);

    ~DataEdit();
    void setHeader(QStringList *h);

private slots:
    void editData(QModelIndex r,QModelIndex c);
    void createPlot();
    void invertUseFlag();
    void setInventory();
    void setColor();
    void selectColor();
    void copy();
private:
    void setupEditor();
    void paintEvent(QPaintEvent*);

    Ui::DataEdit *ui;


    float *data;
    float *data_err;
    bool *useflag;
    QColor *col_dat;
    QColor ccolor;

    QStringList *header;
    int column;
    int row;// Size of datasheet
    QStandardItemModel *modelInventory;
    GraphEdit *g;

    float *dat;
    bool *use;
    QColor *col;
    float *dat_err;
    int *select;
};

#endif // DATAEDIT_H
