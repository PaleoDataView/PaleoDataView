/********************************************************************************/
/*    This file is part of PaleoDataViewer.                       					*/
/*                                                                      		*/
/*    PaleoDataViewer is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoDataViewer is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoDataViewer.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#ifndef DATAVIEW_H
#define DATAVIEW_H

#include <QDialog>
#include <QFileDialog>
#include <QDebug>
#include <QMainWindow>
#include "General/inventory.h"
#include <QStandardItemModel>
#include "Dialog/attdialog.h"
#include <QDesktopServices>
#include <QApplication>
namespace Ui {
class DataView;
}

class DataView : public QDialog
{
    Q_OBJECT

public:
    explicit DataView(QWidget *mainWindow,Inventory *inventory);
    ~DataView();
    void reject();
protected:
    bool eventFilter(QObject *obj, QEvent *event);

private slots:
    void entrySelected(QModelIndex mi);
    void isotopeSelected(QModelIndex mi);
    void refresh();
    void chooseFile();
    void view();
    void save();
    void select();
    void deselect();
    void invert();
    void apply();
    void reset();
    void tabSelect(int n);
    void applyIsotope(int n);
    void enterComment(QModelIndex mi);
    void attChanged(QString text,QString origin);
    void invertFlag(QModelIndex mi);
    void newBasin();
    void newOffsets();
signals:
    void selectionChanged();

private:
    void setupInventory();
    void setupIsotope();
    bool checkFilter(int i);


    Ui::DataView *ui;
    QWidget *mainW;
    Inventory *inv;
    QByteArray sp,sp_2,sp_3,sp_4;
    bool changes;
    QStandardItemModel *modelInventory;
    QStandardItemModel *modelIsotopeList;
    QStandardItemModel *modelIsotope;
    attDialog *attd;
    int oldCore;

};

#endif // DATAVIEW_H






