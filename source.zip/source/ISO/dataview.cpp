/********************************************************************************/
/*    This file is part of PaleoDataViewer.                       					*/
/*                                                                      		*/
/*    PaleoDataViewer is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoDataViewer is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoDataViewer.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#include "dataview.h"
#include "ui_dataview.h"

DataView::DataView(QWidget *mainWindow,Inventory *inventory) :
    mainW(mainWindow),inv(inventory),
    ui(new Ui::DataView)
{
    ui->setupUi(this);
    sp=ui->splitter->saveState();
    sp_2=ui->splitter_2->saveState();
    sp_3=ui->splitter_3->saveState();
    sp_4=ui->splitter_4->saveState();
    qApp->installEventFilter(this);
    this->setWindowTitle("Edit");
    oldCore=inv->get_currentCore();
    modelInventory = new QStandardItemModel(0,0,this);
    setupInventory();
    modelIsotopeList = new QStandardItemModel(0,0,this);
    modelIsotope = new QStandardItemModel(0,0,this);
    setupIsotope();
    attd=new attDialog(this,inv->get_data_Comments(0),QString::number(0));
    connect(ui->tableView_4,SIGNAL(clicked(QModelIndex)),this,SLOT(entrySelected(QModelIndex)));// Isotope selected
    connect(this,SIGNAL(selectionChanged()),mainW,SLOT(redraw_score()));// refresh main window

    connect(ui->pushButton_5,SIGNAL(clicked(bool)),this,SLOT(apply()));// apply filter
    connect(ui->doubleSpinBox,SIGNAL(editingFinished()),this,SLOT(apply()));// the same
    connect(ui->doubleSpinBox_2,SIGNAL(editingFinished()),this,SLOT(apply()));// the same
    connect(ui->pushButton_4,SIGNAL(clicked(bool)),this,SLOT(reset()));// reset filter to default
    connect(ui->pushButton,SIGNAL(clicked(bool)),this,SLOT(select()));// select all filtered inventory
    connect(ui->pushButton_2,SIGNAL(clicked(bool)),this,SLOT(deselect()));// deselect all filtered inventory
    connect(ui->pushButton_3,SIGNAL(clicked(bool)),this,SLOT(invert()));// invert all filtered inventory
    connect(ui->tabWidget,SIGNAL(currentChanged(int)),this,SLOT(tabSelect(int)));// tabs clicked call setup
    connect(ui->comboBox_5,SIGNAL(currentIndexChanged(int)),this,SLOT(applyIsotope(int)));// show all/selected cores
    connect(ui->tableView,SIGNAL(clicked(QModelIndex)),this,SLOT(isotopeSelected(QModelIndex)));// entry selected
    connect(ui->pushButton_6,SIGNAL(clicked(bool)),this,SLOT(chooseFile()));// choose e-paper file
    //connect(ui->pushButton_9,SIGNAL(clicked(bool)),this,SLOT(refresh()));// reload attributes from file
    connect(ui->pushButton_7,SIGNAL(clicked(bool)),this,SLOT(view()));// view e-paper
    connect(ui->pushButton_8,SIGNAL(clicked(bool)),this,SLOT(save()));// save changes to isotope data
    connect(ui->tableView_5,SIGNAL(doubleClicked(QModelIndex)),this,SLOT(enterComment(QModelIndex)));// edit comment of line in isotope data
    connect(ui->tableView_5,SIGNAL(clicked(QModelIndex)),this,SLOT(invertFlag(QModelIndex)));// edit comment of line in isotope data

    connect(ui->doubleSpinBox_5,SIGNAL(valueChanged(double)),this,SLOT(newBasin()));// new Basin
    connect(ui->doubleSpinBox_6,SIGNAL(valueChanged(double)),this,SLOT(newBasin()));// new Basin

    connect(ui->lineEdit_7,SIGNAL(returnPressed()),this,SLOT(newOffsets()));
    connect(ui->lineEdit_8,SIGNAL(returnPressed()),this,SLOT(newOffsets()));
    changes=false;

}

DataView::~DataView(){
    delete ui;
    delete modelInventory;
    delete modelIsotopeList;
    delete modelIsotope;
    delete attd;
    inv->set_currentCore(oldCore);

}


void DataView::setupInventory(){
    // get number of entries that pass filter
    bool filter[inv->get_Entries()];
    int sum=0;
    for (int i=0;i<inv->get_Entries();i++){
        if (checkFilter(i)){
            filter[i]=true;
            sum++;
        } else {
            filter[i]=false;
        }
    }
    // create the model for Inventory
    delete modelInventory;
    modelInventory = new QStandardItemModel(sum,13,this);
    modelInventory->setHorizontalHeaderItem(0, new QStandardItem(QString("Index")));
    modelInventory->setHorizontalHeaderItem(1, new QStandardItem(QString("Selected")));
    modelInventory->setHorizontalHeaderItem(2, new QStandardItem(QString("Name of Core")));
    modelInventory->setHorizontalHeaderItem(3, new QStandardItem(QString("Proxy")));
    modelInventory->setHorizontalHeaderItem(4, new QStandardItem(QString("Longitude")));
    modelInventory->setHorizontalHeaderItem(5, new QStandardItem(QString("Latitude")));
    modelInventory->setHorizontalHeaderItem(6, new QStandardItem(QString("Water\nDepth")));
    modelInventory->setHorizontalHeaderItem(7, new QStandardItem(QString("Basin")));
    modelInventory->setHorizontalHeaderItem(8, new QStandardItem(QString("Record\nType")));
    modelInventory->setHorizontalHeaderItem(9, new QStandardItem(QString("Oxygen\nUse Flag")));
    modelInventory->setHorizontalHeaderItem(10, new QStandardItem(QString("Carbon\nUse Flag")));
    modelInventory->setHorizontalHeaderItem(11, new QStandardItem(QString("Filename")));
    modelInventory->setHorizontalHeaderItem(12, new QStandardItem(QString("AgeModel")));

    //...
    ui->tableView_4->setModel(modelInventory);
    ui->tableView_4->setEditTriggers(QAbstractItemView::NoEditTriggers);
    QStandardItem *var_Index = new QStandardItem[sum];
    QStandardItem *var_Selected = new QStandardItem[sum];
    QStandardItem *var_Core = new QStandardItem[sum];
    QStandardItem *var_Species = new QStandardItem[sum];
    QStandardItem *var_Longitude = new QStandardItem[sum];
    QStandardItem *var_Latitude = new QStandardItem[sum];
    QStandardItem *var_Water_Depth = new QStandardItem[sum];
    QStandardItem *var_Basin = new QStandardItem[sum];
    QStandardItem *var_Record_Type = new QStandardItem[sum];
    QStandardItem *var_Oxygen_Use_Flag = new QStandardItem[sum];
    QStandardItem *var_Carbon_Use_flag = new QStandardItem[sum];
    QStandardItem *var_Filename = new QStandardItem[sum];
    QStandardItem *var_AgeModel = new QStandardItem[sum];
    int pos=0;
    for (int i=0;i<inv->get_Entries();i++){
        if (filter[i]){


            var_Index[pos].setData(i,Qt::EditRole);
            modelInventory->setItem(pos,0,&var_Index[pos]);

            var_Selected[pos].setCheckable(true);

            if (inv->get_Selected(i)) var_Selected[pos].setCheckState(Qt::Checked);
            modelInventory->setItem(pos,1,&var_Selected[pos]);
            modelInventory->setData(modelInventory->index(pos, 1), Qt::AlignCenter,Qt::TextAlignmentRole);

            var_Core[pos].setText(inv->get_Core(i));
            modelInventory->setItem(pos,2,&var_Core[pos]);

            var_Species[pos].setText(inv->get_Species(i));
            modelInventory->setItem(pos,3,&var_Species[pos]);

            var_Longitude[pos].setData(inv->get_Longitude(i),Qt::EditRole);
            modelInventory->setItem(pos,4,&var_Longitude[pos]);

            var_Latitude[pos].setData(inv->get_Latitude(i),Qt::EditRole);
            modelInventory->setItem(pos,5,&var_Latitude[pos]);

            var_Water_Depth[pos].setData(inv->get_Water_Depth(i),Qt::EditRole);
            modelInventory->setItem(pos,6,&var_Water_Depth[pos]);

            var_Basin[pos].setText(inv->get_Basinname(inv->get_Basin(i)));
            modelInventory->setItem(pos,7,&var_Basin[pos]);

            var_Record_Type[pos].setText(inv->get_Record_Type(i));
            modelInventory->setItem(pos,8,&var_Record_Type[pos]);


            var_Oxygen_Use_Flag[pos].setCheckable(true);

            if (inv->get_Oxygen_Use_Flag(i)){
                var_Oxygen_Use_Flag[pos].setCheckState(Qt::Checked);
            }else{
                var_Oxygen_Use_Flag[pos].setCheckState(Qt::Unchecked);
            }
            modelInventory->setItem(pos,9,&var_Oxygen_Use_Flag[pos]);
            modelInventory->setData(modelInventory->index(pos, 9), Qt::AlignCenter,Qt::TextAlignmentRole);



            var_Carbon_Use_flag[pos].setCheckable(true);

            if (inv->get_Carbon_Use_Flag(i)){
                var_Carbon_Use_flag[pos].setCheckState(Qt::Checked);
            }else{
                var_Carbon_Use_flag[pos].setCheckState(Qt::Unchecked);
            }
            modelInventory->setItem(pos,10,&var_Carbon_Use_flag[pos]);
            modelInventory->setData(modelInventory->index(pos, 10), Qt::AlignCenter,Qt::TextAlignmentRole);


            var_Filename[pos].setText(inv->get_Filename(i));
            modelInventory->setItem(pos,11,&var_Filename[pos]);

            var_AgeModel[pos].setText(QString::number(inv->get_AgeModel(i)));
            modelInventory->setItem(pos,12,&var_AgeModel[pos]);
            // coloring
            if (inv->get_Selected(i)){
                for (int j=0;j<12;j++) modelInventory->setData(modelInventory->index(pos, j), QColor(Qt::lightGray), Qt::BackgroundRole);
            }
            if (inv->get_Carbon_Use_Flag(i)){
                modelInventory->setData(modelInventory->index(pos, 10), QColor(Qt::green), Qt::BackgroundRole);
            } else {
                modelInventory->setData(modelInventory->index(pos, 10), QColor(Qt::red), Qt::BackgroundRole);
            }
            if (inv->get_Oxygen_Use_Flag(i)){
                modelInventory->setData(modelInventory->index(pos, 9), QColor(Qt::green), Qt::BackgroundRole);
            } else {
                modelInventory->setData(modelInventory->index(pos, 9), QColor(Qt::red), Qt::BackgroundRole);
            }
            pos++;
        }
    }
    ui->tableView_4->setSortingEnabled(1);
    ui->tableView_4->verticalHeader()->setDefaultSectionSize(ui->tableView_4->verticalHeader()->minimumSectionSize());
    ui->tableView_4->resizeColumnsToContents();
    ui->tableView_4->setHorizontalScrollMode(ui->tableView_4->ScrollPerPixel);


}

void DataView::entrySelected(QModelIndex mi){
    int sel=mi.row();
    QStandardItemModel* model = qobject_cast<QStandardItemModel*>(ui->tableView_4->model());
    QString text = model->item(sel,0)->text();
    if (mi.column()!=1 && mi.column()!=9 && mi.column()!=10){

        //qDebug() << "Clicked :"+QString::number(sel);

        inv->readData(text.toInt(0,10));
        setupInventory();
        emit(selectionChanged());
    }
    if (mi.column()==1){

        //qDebug() << "Clicked Selected:"+QString::number(sel);


        int i=text.toInt(0,10);
        inv->invert_Selected(i);

        setupInventory();
        emit(selectionChanged());
    }
    if (mi.column()==9){

        //qDebug() << "Clicked O Flag:"+QString::number(sel);


        int i=text.toInt(0,10);
        inv->invert_O_Flag(i);

        setupInventory();
        emit(selectionChanged());
    }
    if (mi.column()==10){

        //qDebug() << "Clicked C Flag:"+QString::number(sel);

        int i=text.toInt(0,10);
        inv->invert_C_Flag(i);

        setupInventory();
        emit(selectionChanged());
    }

}

void DataView::setupIsotope(){
    // List of Cores
    // get number of entries that pass filter
    int sum=0;
    if (ui->comboBox_5->currentText()=="Show All Cores")sum=inv->get_Entries();
    if (ui->comboBox_5->currentText()=="Show only Selected Cores") sum=inv->get_Selected_Sum();

    // create the model for Inventory
    delete modelIsotopeList;
    modelIsotopeList = new QStandardItemModel(sum,3,this);
    modelIsotopeList->setHorizontalHeaderItem(0, new QStandardItem(QString("Index")));
    modelIsotopeList->setHorizontalHeaderItem(1, new QStandardItem(QString("Name of Core")));
    modelIsotopeList->setHorizontalHeaderItem(2, new QStandardItem(QString("Proxy")));

    //...
    ui->tableView->setModel(modelIsotopeList);
    ui->tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
    QStandardItem *var_Index = new QStandardItem[sum];
    QStandardItem *var_Core = new QStandardItem[sum];
    QStandardItem *var_Species = new QStandardItem[sum];

    int pos=0;
    for (int i=0;i<inv->get_Entries();i++){
        if (ui->comboBox_5->currentText()=="Show All Cores" || (ui->comboBox_5->currentText()=="Show only Selected Cores"  && inv->get_Selected(i)==1)){


            var_Index[pos].setData(i,Qt::EditRole);
            modelIsotopeList->setItem(pos,0,&var_Index[pos]);

            var_Core[pos].setText(inv->get_Core(i));
            modelIsotopeList->setItem(pos,1,&var_Core[pos]);

            var_Species[pos].setText(inv->get_Species(i));
            modelIsotopeList->setItem(pos,2,&var_Species[pos]);



            pos++;
        }
    }
    ui->tableView->setSortingEnabled(1);
    ui->tableView->verticalHeader()->setDefaultSectionSize(ui->tableView->verticalHeader()->minimumSectionSize());
    ui->tableView->resizeColumnsToContents();
    ui->tableView->setHorizontalScrollMode(ui->tableView->ScrollPerPixel);


    // create the model for Isoptopes
    delete modelIsotope;
    modelIsotope = new QStandardItemModel(inv->get_Length(),11,this);
    modelIsotope->setHorizontalHeaderItem(0, new QStandardItem(QString("Depth\n[m]")));
    modelIsotope->setHorizontalHeaderItem(2, new QStandardItem(QString("Bacon\nAge\n[kyr]")));
    modelIsotope->setHorizontalHeaderItem(1, new QStandardItem(QString("Sample\nThickness\n[m]")));
    modelIsotope->setHorizontalHeaderItem(3, new QStandardItem(QString("Carbon\n[permil]")));
    modelIsotope->setHorizontalHeaderItem(4, new QStandardItem(QString("Oxygen\n[permil]")));
    modelIsotope->setHorizontalHeaderItem(5, new QStandardItem(QString("Carbon\nError\n[permil]")));
    modelIsotope->setHorizontalHeaderItem(6, new QStandardItem(QString("Oxygen\nError\n[permil]")));
    modelIsotope->setHorizontalHeaderItem(7, new QStandardItem(QString("Carbon\nCorrected\n[permil]")));
    modelIsotope->setHorizontalHeaderItem(8, new QStandardItem(QString("Oxygen\nCorrected\n[permil]")));
    modelIsotope->setHorizontalHeaderItem(9, new QStandardItem(QString("Flag")));
    modelIsotope->setHorizontalHeaderItem(10, new QStandardItem(QString("Comment")));
    //...
    ui->tableView_5->setModel(modelIsotope);
    ui->tableView_5->setEditTriggers(QAbstractItemView::NoEditTriggers);

    QStandardItem *iso_Depth = new QStandardItem[inv->get_Length()];
    QStandardItem *iso_Sample_Thickness = new QStandardItem[inv->get_Length()];
    QStandardItem *iso_Age = new QStandardItem[inv->get_Length()];
    QStandardItem *iso_Oxygen = new QStandardItem[inv->get_Length()];
    QStandardItem *iso_Carbon = new QStandardItem[inv->get_Length()];
    QStandardItem *iso_Carbon_Error = new QStandardItem[inv->get_Length()];
    QStandardItem *iso_Oxygen_Error = new QStandardItem[inv->get_Length()];
    QStandardItem *iso_Carbon_Corr = new QStandardItem[inv->get_Length()];
    QStandardItem *iso_Oxygen_Corr = new QStandardItem[inv->get_Length()];
    QStandardItem *iso_Flag = new QStandardItem[inv->get_Length()];
    QStandardItem *iso_Comment = new QStandardItem[inv->get_Length()];

    for (int i=0;i<inv->get_Length();i++){
        iso_Depth[i].setText(QString::number(inv->get_data_Depth(i)));
        modelIsotope->setItem(i,0,&iso_Depth[i]);
        iso_Sample_Thickness[i].setText(QString::number(inv->get_data_Sample_Thickness(i)));
        modelIsotope->setItem(i,1,&iso_Sample_Thickness[i]);
        iso_Age[i].setText(QString::number(inv->get_data_Age(i)));
        modelIsotope->setItem(i,2,&iso_Age[i]);
        iso_Oxygen[i].setText(QString::number(inv->get_data_d18O(i)));
        modelIsotope->setItem(i,3,&iso_Oxygen[i]);
        iso_Carbon[i].setText(QString::number(inv->get_data_d13C(i)));
        modelIsotope->setItem(i,4,&iso_Carbon[i]);
        iso_Oxygen_Error[i].setText(QString::number(inv->get_data_d18O_Err(i)));
        modelIsotope->setItem(i,5,&iso_Oxygen_Error[i]);
        iso_Carbon_Error[i].setText(QString::number(inv->get_data_d13C_Err(i)));
        modelIsotope->setItem(i,6,&iso_Carbon_Error[i]);
        iso_Oxygen_Corr[i].setText(QString::number(inv->get_data_d18O_Corr(i)));
        modelIsotope->setItem(i,7,&iso_Oxygen_Corr[i]);
        iso_Carbon_Corr[i].setText(QString::number(inv->get_data_d13C_Corr(i)));
        modelIsotope->setItem(i,8,&iso_Carbon_Corr[i]);


        iso_Flag[i].setCheckable(true);

        //iso_Flag[i].setText(QString::number(inv->get_data_Isotopes(6,i)));
        modelIsotope->setItem(i,9,&iso_Flag[i]);

        if (inv->get_data_Use_Flag(i)){
            iso_Flag[i].setCheckState(Qt::Checked);
        }else{
            iso_Flag[i].setCheckState(Qt::Unchecked);
        }
        modelIsotope->setItem(i,9,&iso_Flag[i]);
        modelIsotope->setData(modelIsotope->index(i, 9), Qt::AlignCenter,Qt::TextAlignmentRole);

        iso_Comment[i].setText(inv->get_data_Comments(i));
        modelIsotope->setItem(i,10,&iso_Comment[i]);

        if (inv->get_data_Use_Flag(i)){
            modelIsotope->setData(modelIsotope->index(i,9), QColor(Qt::green), Qt::BackgroundRole);
        } else {
            modelIsotope->setData(modelIsotope->index(i,9), QColor(Qt::red), Qt::BackgroundRole);
        }
    }
    ui->tableView_5->resizeColumnsToContents();
    ui->tableView_5->verticalHeader()->setDefaultSectionSize(ui->tableView_5->verticalHeader()->minimumSectionSize());
    ui->tableView_5->horizontalHeader()->setStretchLastSection(1);

    // Isotpe Data Attributes

    ui->lineEdit->setText(inv->get_att_Core());
    ui->lineEdit_2->setText(inv->get_att_Species());
    ui->doubleSpinBox_5->setValue(inv->get_att_Longitude());
    ui->doubleSpinBox_6->setValue(inv->get_att_Latitude());
    ui->doubleSpinBox_7->setValue(inv->get_att_Water_Depth());
    ui->label_26->setText(inv->get_Basinname(inv->get_Basin(inv->get_att_Longitude(),inv->get_att_Latitude())));
    if (inv->get_att_Record_Type()=="Unknown" ) ui->comboBox_6->setCurrentIndex(0);
    if (inv->get_att_Record_Type()=="sb" ) ui->comboBox_6->setCurrentIndex(1);
    if (inv->get_att_Record_Type()=="sp" ) ui->comboBox_6->setCurrentIndex(2);
    if (inv->get_att_Record_Type()=="db" ) ui->comboBox_6->setCurrentIndex(3);
    if (inv->get_att_Record_Type()=="dp" ) ui->comboBox_6->setCurrentIndex(4);
    ui->lineEdit_3->setText(inv->get_att_Device());
    if (inv->get_att_Carbon_Use_Flag()){
        ui->checkBox->setCheckState(Qt::Checked);
    } else {
        ui->checkBox->setCheckState(Qt::Unchecked);
    }
    if (inv->get_att_Oxygen_Use_Flag()){
        ui->checkBox_2->setCheckState(Qt::Checked);
    } else {
        ui->checkBox_2->setCheckState(Qt::Unchecked);
    }
    ui->lineEdit_7->setText(QString::number(inv->get_att_C_Correction()));
    ui->lineEdit_8->setText(QString::number(inv->get_att_O_Correction()));
    ui->plainTextEdit_3->setPlainText(inv->get_att_C_Justification());
    ui->plainTextEdit_4->setPlainText(inv->get_att_O_Justification());
    ui->lineEdit_4->setText(inv->get_att_Data_Source());
    ui->lineEdit_5->setText(inv->get_att_Laboratory());
    ui->plainTextEdit->setPlainText(inv->get_att_Reference());
    ui->lineEdit_6->setText(inv->get_att_EPaper());
    ui->plainTextEdit_2->setPlainText(inv->get_att_Comment());
    ui->lineEdit_9->setText(inv->get_att_Category());
    ui->lineEdit_10->setText(inv->get_att_Importer());
    ui->plainTextEdit_5->setPlainText(inv->get_att_Optional());
    /*
    delete var_Index;
    delete var_Core;
    delete var_Species;

    delete iso_Depth;
    delete iso_Age;
    delete iso_Oxygen;
    delete iso_Carbon;
    delete iso_Carbon2;
    delete iso_Oxygen2;
    delete iso_Flag;
    delete iso_Comment;

    delete modelIsotopeList;
    delete modelIsotope;*/
}

void DataView::select(){
    setupInventory();
    for (int i=0;i<ui->tableView_4->verticalHeader()->count();i++){
        QStandardItemModel* model = qobject_cast<QStandardItemModel*>(ui->tableView_4->model());
        QString text = model->item(i,0)->text();
        int j=text.toInt(0,10);
        inv->set_Selected(j,1);
    }
    setupInventory();
    emit(selectionChanged());
}

void DataView::deselect(){
    setupInventory();
    for (int i=0;i<ui->tableView_4->verticalHeader()->count();i++){
        QStandardItemModel* model = qobject_cast<QStandardItemModel*>(ui->tableView_4->model());
        QString text = model->item(i,0)->text();
        int j=text.toInt(0,10);
        inv->set_Selected(j,0);
    }
    setupInventory();
    emit(selectionChanged());
}

void DataView::invert(){
    setupInventory();
    for (int i=0;i<ui->tableView_4->verticalHeader()->count();i++){
        QStandardItemModel* model = qobject_cast<QStandardItemModel*>(ui->tableView_4->model());
        QString text = model->item(i,0)->text();
        int j=text.toInt(0,10);
        inv->invert_Selected(j);
    }
    setupInventory();
    emit(selectionChanged());
}

void DataView::apply(){
    setupInventory();
}

void DataView::reset(){
    ui->doubleSpinBox_2->setValue(-180.0);
    ui->doubleSpinBox->setValue(180.0);
    ui->doubleSpinBox_3->setValue(90.0);
    ui->doubleSpinBox_4->setValue(-90.0);
    ui->radioButton->setCheckable(false);
    ui->spinBox->setValue(0);
    ui->spinBox_2->setValue(10000);
    ui->comboBox->setCurrentIndex(0);
    ui->comboBox_2->setCurrentIndex(0);
    ui->comboBox_3->setCurrentIndex(0);
    ui->comboBox_4->setCurrentIndex(0);

    setupInventory();
}

bool DataView::checkFilter(int i){
    bool ok=true;
    // check longitude
    if ((inv->get_Longitude(i)<ui->doubleSpinBox_2->value() || inv->get_Longitude(i)>ui->doubleSpinBox->value()) && ui->radioButton->isChecked()==false) ok=false;
    if ((inv->get_Longitude(i)>=ui->doubleSpinBox_2->value() && inv->get_Longitude(i)<=ui->doubleSpinBox->value()) && ui->radioButton->isChecked()==true) ok=false;
    // check Latitude
    if (inv->get_Latitude(i)<ui->doubleSpinBox_4->value() || inv->get_Latitude(i)>ui->doubleSpinBox_3->value()) ok=false;
    // check Water Depth
    if (inv->get_Water_Depth(i)<ui->spinBox->value() || inv->get_Water_Depth(i)>ui->spinBox_2->value()) ok=false;
    // check Ocean
    if (inv->get_Basin(i)!=1 && ui->comboBox->currentText()=="Atlantic Ocean") ok=false;
    if (inv->get_Basin(i)!=2 && ui->comboBox->currentText()=="Pacific Ocean") ok=false;
    if (inv->get_Basin(i)!=3 && ui->comboBox->currentText()=="Indian Ocean") ok=false;
    if (inv->get_Basin(i)!=4 && ui->comboBox->currentText()=="Mediteranian Ocean") ok=false;
    if (inv->get_Basin(i)!=10 && ui->comboBox->currentText()=="Antarctic Ocean") ok=false;
    if (inv->get_Basin(i)!=11 && ui->comboBox->currentText()=="Arctic Ocean") ok=false;
    // Use Flags
    if (inv->get_Oxygen_Use_Flag(i)==1 && ui->comboBox_2->currentText()=="False") ok=false;
    if (inv->get_Oxygen_Use_Flag(i)==0 && ui->comboBox_2->currentText()=="True") ok=false;
    if (inv->get_Carbon_Use_Flag(i)==1 && ui->comboBox_3->currentText()=="False") ok=false;
    if (inv->get_Carbon_Use_Flag(i)==0 && ui->comboBox_3->currentText()=="True") ok=false;
    // Record Type
    if (inv->get_Record_Type(i)!="sb" && ui->comboBox_4->currentText()=="sb") ok=false;
    if (inv->get_Record_Type(i)!="sp" && ui->comboBox_4->currentText()=="sp") ok=false;
    if (inv->get_Record_Type(i)!="db" && ui->comboBox_4->currentText()=="db") ok=false;
    if (inv->get_Record_Type(i)!="dp" && ui->comboBox_4->currentText()=="dp") ok=false;
    return ok;
}

void DataView::tabSelect(int n){
    //qDebug()<< "Tab Selected:"+QString::number(n);
    if (n==0) setupInventory();
    if (n==1) setupIsotope();
}

void DataView::applyIsotope(int n){
    setupIsotope();
}


void DataView::isotopeSelected(QModelIndex mi){

        int sel=mi.row();
        //qDebug() << "Clicked :"+QString::number(sel);
        QStandardItemModel* model = qobject_cast<QStandardItemModel*>(ui->tableView_4->model());
        QString text = model->item(sel,0)->text();
        inv->readData(text.toInt(0,10));
        setupIsotope();
}

void DataView::chooseFile(){
    QString file = QFileDialog::getOpenFileName(this, tr("Select File"),
                                             QDir::homePath(),
                                             tr("PDF (*.pdf)"));
    //qDebug() << file;
    inv->set_att_EPaper(file);
    setupIsotope();
}

void DataView::view(){
    //qDebug() << "Open: "+inv->get_att_EPaper();
    QDesktopServices::openUrl(QUrl("file:///"+inv->get_att_EPaper(), QUrl::TolerantMode));
}

void DataView::refresh(){
    setupIsotope();
}

void DataView::save(){
    if (inv->get_currentCore()>=0) {
    inv->readData(inv->get_currentCore());
    inv->set_att_Core(ui->lineEdit->text());
    inv->set_Core(ui->lineEdit->text());
    inv->set_att_Species(ui->lineEdit_2->text());
    inv->set_Species(ui->lineEdit_2->text());
    inv->set_att_Longitude(ui->doubleSpinBox_5->value());
    inv->set_Longitude(ui->doubleSpinBox_5->value());
    inv->set_att_Latitude(ui->doubleSpinBox_6->value());
    inv->set_Latitude(ui->doubleSpinBox_6->value());
    inv->set_att_Water_Depth(ui->doubleSpinBox_7->value());
    inv->set_Water_Depth(ui->doubleSpinBox_7->value());
    inv->set_att_Category(ui->lineEdit_9->text());
    inv->set_att_Importer(ui->lineEdit_10->text());
    inv->set_att_Optiona(ui->plainTextEdit_5->toPlainText());
    if (ui->comboBox_6->currentIndex()==0) {
        inv->set_att_Record_Type("Unknown");
        inv->set_Record_Type("Unknown");
    }
    if (ui->comboBox_6->currentIndex()==1) {
        inv->set_att_Record_Type("sb");
        inv->set_Record_Type("sb");
    }
    if (ui->comboBox_6->currentIndex()==2) {
        inv->set_att_Record_Type("sp");
        inv->set_Record_Type("sp");
    }
    if (ui->comboBox_6->currentIndex()==3) {
        inv->set_att_Record_Type("db");
        inv->set_Record_Type("db");
    }
    if (ui->comboBox_6->currentIndex()==4) {
        inv->set_att_Record_Type("dp");
        inv->set_Record_Type("dp");
    }
    inv->set_att_Device(ui->lineEdit_3->text());

    if (ui->checkBox->checkState()==Qt::Checked){
        inv->set_att_C_Use_Flag(1);
        inv->set_C_Use_Flag(1);
    } else {
        inv->set_att_C_Use_Flag(0);
        inv->set_C_Use_Flag(0);
    }
    if (ui->checkBox_2->checkState()==Qt::Checked){
        inv->set_att_O_Use_Flag(1);
        inv->set_O_Use_Flag(1);
    } else {
        inv->set_att_O_Use_Flag(0);
        inv->set_O_Use_Flag(0);
    }

    inv->set_att_C_Correction(ui->lineEdit_7->text().toDouble());
    inv->set_att_O_Correction(ui->lineEdit_8->text().toDouble());
    inv->set_att_C_Justification(ui->plainTextEdit_3->toPlainText());
    inv->set_att_O_Justification(ui->plainTextEdit_4->toPlainText());
    inv->set_att_Data_Source(ui->lineEdit_4->text());
    inv->set_att_Laboratory(ui->lineEdit_5->text());
    inv->set_att_Reference(ui->plainTextEdit->toPlainText());
    inv->set_att_EPaper(ui->lineEdit_6->text());
    inv->set_att_Comment(ui->plainTextEdit_2->toPlainText());

    inv->set_Basin(inv->get_Basin(inv->get_att_Longitude(),inv->get_att_Latitude()));

    inv->save();
    inv->saveData();
    setupIsotope();
    }
}

void DataView::enterComment(QModelIndex mi){
        int sel=mi.row();

        if (mi.column()==10){
            //qDebug() << "Clicked :"+QString::number(sel);
            delete attd;
            attd=new attDialog(this,inv->get_data_Comments(sel),QString::number(sel));
            attd->setModal(true);
            attd->show();
        }

}

void DataView::attChanged(QString text,QString origin){
        int sel=origin.toInt(0,10);
        //qDebug() << "Text:"+text;
        inv->set_data_Comment(text,sel);
        inv->saveData();
        setupIsotope();
}

void DataView::invertFlag(QModelIndex mi){

        int sel=mi.row();
        if (mi.column()==9){
            if (inv->get_data_Use_Flag(mi.row())==1){
                qDebug()<<"click";
                inv->set_data_Use_Flag(0,mi.row());
                setupIsotope();
                ui->tableView_5->scrollTo(mi.model()->index(mi.row(),mi.column()),QAbstractItemView::PositionAtCenter);
            }else {
                inv->set_data_Use_Flag(1,mi.row());
                setupIsotope();
                ui->tableView_5->scrollTo(mi.model()->index(mi.row(),mi.column()),QAbstractItemView::PositionAtCenter);
            }

        }
}


void DataView::newBasin(){
    ui->label_26->setText(inv->get_Basinname(inv->get_Basin(ui->doubleSpinBox_5->value(),ui->doubleSpinBox_6->value())));

}

bool DataView::eventFilter(QObject *obj, QEvent *event)
{
    if (event->type() == QEvent::KeyPress)
    {
        if (obj==ui->tableView||obj==ui->tableView_4||obj==ui->tableView_5||obj==ui->tabWidget||obj==ui->tab_3||obj==ui->tab_4){
            QKeyEvent *keyEvent = static_cast<QKeyEvent *>(event);
            if (keyEvent->key()==Qt::Key_F1){
                ui->splitter->restoreState(sp);
                ui->splitter_2->restoreState(sp_2);
                ui->splitter_3->restoreState(sp_3);
                ui->splitter_4->restoreState(sp_4);
                return true;
            }
        }
    }
    return QObject::eventFilter(obj, event);
}

void DataView::newOffsets(){

    float off_c=ui->lineEdit_7->text().toFloat();
    float off_o=ui->lineEdit_8->text().toFloat();
    inv->set_att_C_Correction(off_c);
    inv->set_att_O_Correction(off_o);
    for (int i=0;i<inv->get_Length();i++){
        inv->set_data_Isotopes(4,i,inv->get_data_Isotopes(2,i)+off_c);
        inv->set_data_Isotopes(5,i,inv->get_data_Isotopes(3,i)+off_o);
    }

    inv->save();
    inv->saveData();
    setupIsotope();
}

void DataView::reject()
{
    QMessageBox::StandardButton resBtn = QMessageBox::Yes;
    if (changes) {
        resBtn = QMessageBox::question( this,"PaleoDataViewer - AMS",
                                        tr("There are unsaved changes.\nAre you sure?\n"),
                                        QMessageBox::Cancel | QMessageBox::Yes,
                                        QMessageBox::Yes);
    }
    if (resBtn == QMessageBox::Yes) {
        QDialog::reject();
    }
}
