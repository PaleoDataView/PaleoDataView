#include "importall.h"
#include "ui_importall.h"

ImportAll::ImportAll(QMainWindow *mainWindow,Inventory *inventory) :
                     mainW(mainWindow),inv2(inventory),
                     ui(new Ui::ImportAll)
{
    ui->setupUi(this);

    inv=new Inventory();
    inv->read();// create an inventory to initialize Variables

    amsdata=new AMSData(inv2);

    exist_meta=0;
    exist_iso=0;
    exist_age=0;
    meta_length=21;
    str1=new QString[meta_length];
    str2=new QString[meta_length];
    str1[0]="Core";

    str1[1]="Species";

    str1[2]="Longitude [dez]";

    str1[3]="Latitude [dez]";

    str1[4]="Water Depth [m]";

    str1[5]="Device";

    str1[6]="Type";

    str1[7]="Laboratory";

    str1[8]="Electronic Paper";

    str1[9]="Comments";

    str1[10]="Data Source";

    str1[11]="Reference";

    str1[12]="O-Use Flag";

    str1[13]="C-Use Flag";

    str1[14]="O-Correction";

    str1[15]="C-Correction";

    str1[16]="O-Justification";

    str1[17]="C-Justification";


    str1[18]="Category";
    str1[19]="Importer";
    str1[20]="Optional";



    // bring them into shape
    //for (int i=0;i<meta_length;i++) {
    //    while (str1[i].size()<30) str1[i].append(" ");
    //    str1[i].append(":");
    //}

    dlm="\t";
    save_OK=0;
    QFont font;
    font.setFamily("Courier");
    font.setStyleHint(QFont::Monospace);
    font.setFixedPitch(true);
    font.setPointSize(10);

    ui->plainTextEdit->setFont(font);

    connect(ui->pushButton,SIGNAL(clicked(bool)),this,SLOT(browse()));
    connect(ui->pushButton_2,SIGNAL(clicked(bool)),this,SLOT(start()));
    connect(this,SIGNAL(refresh()),mainW,SLOT(redraw_score()));
}

ImportAll::~ImportAll()
{
    delete ui;
    delete inv;
    delete[] str1;
    delete[] str2;
    delete amsdata;
}

void ImportAll::browse(){
    QString folder = QFileDialog::getExistingDirectory(this, tr("Select Folder"),
                                             "",0);

    ui->lineEdit->setText(folder);

    QDir dir=folder;
    dir.setFilter(QDir::Files | QDir::Hidden | QDir::NoSymLinks);
    QStringList filters;
    filters<<"*.xlsx"<<"*.txt";
    dir.setNameFilters(filters);
    list = dir.entryInfoList();

    ui->plainTextEdit->appendPlainText("\n"+QString::number(list.size())+" files(EXCEL+ASCII) found at specified location :");
    for (int i=0;i<list.size();i++) ui->plainTextEdit->appendPlainText(list.at(i).fileName());

}

void ImportAll::start(){
    ui->plainTextEdit->appendPlainText("Starting to import...");
    for (int i=0;i<inv2->get_Entries();i++) inv2->set_Selected(i,0); // deselect all
    for (int filenr=0;filenr<list.size();filenr++){
        ui->plainTextEdit->appendPlainText(list.at(filenr).fileName()+"found.");
        update();
        // Init
        exist_meta=0;
        exist_iso=0;
        exist_age=0;

        //-----------------------------------------------------------
        //extract txt from file
        QString QFilename=ui->lineEdit->text()+"/"+list.at(filenr).fileName();
        //qDebug() << QFilename;
        if (QFilename.right(4)==".txt"){
            QFile file(QFilename);
            if(!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
                //qDebug() <<  file.errorString();
            } else {
                txt.clear();
                QTextStream in(&file);
                while(!in.atEnd()) {
                    txt.append(in.readLine().toLocal8Bit()+"\n");
                }

            file.close();
        }
        }
        if (QFilename.right(5)==".xlsx"){
            //qDebug() <<"reading Excel";
            QXlsx::Document xlsx(QFilename);
            txt.clear();
            if (xlsx.selectSheet("Meta Data")){
                //qDebug() <<"reading Meta";
                int i=0;
                while (xlsx.read("A"+QString::number(i+1)).toString()!=""){
                    //qDebug() << QString::number(i);
                    QString s1=xlsx.read("A"+QString::number(i+1)).toString();
                    //while (s1.size()<30) s1.append(" ");
                    //s1.append(":");
                    QString s2=xlsx.read("B"+QString::number(i+1)).toString();
                    txt.append(s1+dlm+s2+"\n");
                    i++;
                }
                txt.append("\n");
            }
            if (xlsx.selectSheet("Proxy")){

                //qDebug() <<"reading Isotope";
                int i=0;
                txt.append("Isotope Data\n");
                while (xlsx.read("A"+QString::number(i+1)).toString()!=""){
                    //qDebug() << QString::number(i);
                    QString s1=xlsx.read("A"+QString::number(i+1)).toString();
                    QString s2=xlsx.read("B"+QString::number(i+1)).toString();
                    QString s3=xlsx.read("C"+QString::number(i+1)).toString();
                    QString s4=xlsx.read("D"+QString::number(i+1)).toString();
                    QString s5=xlsx.read("E"+QString::number(i+1)).toString();
                    QString s6=xlsx.read("F"+QString::number(i+1)).toString();
                    QString s7=xlsx.read("G"+QString::number(i+1)).toString();
                    QString s8=xlsx.read("H"+QString::number(i+1)).toString();
                    QString s9=xlsx.read("I"+QString::number(i+1)).toString();
                    QString s10=xlsx.read("J"+QString::number(i+1)).toString();
                    QString s11=xlsx.read("K"+QString::number(i+1)).toString();


                    txt.append(s1+"\t"+s2+"\t"+s3+"\t"+s4+"\t"+s5+"\t"+s6+"\t"+s7+"\t"+s8+"\t"+s9+"\t"+s10+"\t"+s11+"\n");
                    //if (i>0)txt.append(QString::number(s1.toFloat(0))+"\t"+QString::number(s2.toFloat(0))+"\t"+QString::number(s3.toFloat(0))+"\t"+QString::number(s4.toFloat(0))+"\t"+QString::number(s5.toFloat(0))+"\t"+QString::number(s6.toFloat(0))+"\t"+QString::number(s7.toFloat(0))+"\t"+QString::number(s8.toFloat(0))+"\t"+QString::number(s9.toFloat(0))+"\t"+QString::number(s10.toFloat(0))+"\t"+s11+"\n");



                    i++;
                }
                txt.append("\n");
            }
            if (xlsx.selectSheet("Isotopes")){

                //qDebug() <<"reading Isotope";
                int i=0;
                txt.append("Isotope Data\n");
                while (xlsx.read("A"+QString::number(i+1)).toString()!=""){
                    //qDebug() << QString::number(i);
                    QString s1=xlsx.read("A"+QString::number(i+1)).toString();
                    QString s2=xlsx.read("B"+QString::number(i+1)).toString();
                    QString s3=xlsx.read("C"+QString::number(i+1)).toString();
                    QString s4=xlsx.read("D"+QString::number(i+1)).toString();
                    QString s5=xlsx.read("E"+QString::number(i+1)).toString();
                    QString s6=xlsx.read("F"+QString::number(i+1)).toString();
                    QString s7=xlsx.read("G"+QString::number(i+1)).toString();
                    QString s8=xlsx.read("H"+QString::number(i+1)).toString();
                    QString s9=xlsx.read("I"+QString::number(i+1)).toString();
                    QString s10=xlsx.read("J"+QString::number(i+1)).toString();
                    QString s11=xlsx.read("K"+QString::number(i+1)).toString();


                    txt.append(s1+"\t"+s2+"\t"+s3+"\t"+s4+"\t"+s5+"\t"+s6+"\t"+s7+"\t"+s8+"\t"+s9+"\t"+s10+"\t"+s11+"\n");
                    //if (i>0)txt.append(QString::number(s1.toFloat(0))+"\t"+QString::number(s2.toFloat(0))+"\t"+QString::number(s3.toFloat(0))+"\t"+QString::number(s4.toFloat(0))+"\t"+QString::number(s5.toFloat(0))+"\t"+QString::number(s6.toFloat(0))+"\t"+QString::number(s7.toFloat(0))+"\t"+QString::number(s8.toFloat(0))+"\t"+QString::number(s9.toFloat(0))+"\t"+QString::number(s10.toFloat(0))+"\t"+s11+"\n");



                    i++;
                }
                txt.append("\n");
            }
            if (xlsx.selectSheet("Age")){

                //qDebug() <<"reading Age Model";
                int i=0;
                txt.append("Age Model Data\n");
                while (xlsx.read("A"+QString::number(i+1)).toString()!=""){
                    //qDebug() << QString::number(i);
                    QString s1=xlsx.read("A"+QString::number(i+1)).toString();
                    QString s2=xlsx.read("B"+QString::number(i+1)).toString();
                    QString s3=xlsx.read("C"+QString::number(i+1)).toString();
                    QString s4=xlsx.read("D"+QString::number(i+1)).toString();
                    QString s5=xlsx.read("E"+QString::number(i+1)).toString();
                    QString s6=xlsx.read("F"+QString::number(i+1)).toString();
                    QString s7=xlsx.read("G"+QString::number(i+1)).toString();
                    QString s8=xlsx.read("H"+QString::number(i+1)).toString();
                    QString s9=xlsx.read("I"+QString::number(i+1)).toString();
                    QString s10=xlsx.read("J"+QString::number(i+1)).toString();
                    QString s11=xlsx.read("K"+QString::number(i+1)).toString();
                    QString s12=xlsx.read("L"+QString::number(i+1)).toString();
                    QString s13=xlsx.read("M"+QString::number(i+1)).toString();
                    QString s14=xlsx.read("N"+QString::number(i+1)).toString();
                    txt.append(s1+"\t"+s2+"\t"+s3+"\t"+s4+"\t"+s5+"\t"+s6+"\t"+s7+"\t"+s8+"\t"+s9+"\t"+s10+"\t"+s11+"\t"+s12+"\t"+s13+"\t"+s14+"\n");
                    //if (i>0)txt.append(QString::number(s1.toFloat(0))+"\t"+s2+"\t"+s3+"\t"+QString::number(s4.toFloat(0))+"\t"+QString::number(s5.toFloat(0))+"\t"+QString::number(s6.toFloat(0))+"\t"+QString::number(s7.toFloat(0))+"\t"+QString::number(s8.toFloat(0))+"\t"+QString::number(s9.toFloat(0))+"\t"+QString::number(s10.toFloat(0))+"\t"+QString::number(s11.toFloat(0))+"\t"+s12+"\n");
                    i++;
                }
                txt.append("\n");
            }
            if (xlsx.selectSheet("Age Model")){

                //qDebug() <<"reading Age Model";
                int i=0;
                txt.append("Age Model Data\n");
                while (xlsx.read("A"+QString::number(i+1)).toString()!=""){
                    //qDebug() << QString::number(i);
                    QString s1=xlsx.read("A"+QString::number(i+1)).toString();
                    QString s2=xlsx.read("B"+QString::number(i+1)).toString();
                    QString s3=xlsx.read("C"+QString::number(i+1)).toString();
                    QString s4=xlsx.read("D"+QString::number(i+1)).toString();
                    QString s5=xlsx.read("E"+QString::number(i+1)).toString();
                    QString s6=xlsx.read("F"+QString::number(i+1)).toString();
                    QString s7=xlsx.read("G"+QString::number(i+1)).toString();
                    QString s8=xlsx.read("H"+QString::number(i+1)).toString();
                    QString s9=xlsx.read("I"+QString::number(i+1)).toString();
                    QString s10=xlsx.read("J"+QString::number(i+1)).toString();
                    QString s11=xlsx.read("K"+QString::number(i+1)).toString();
                    QString s12=xlsx.read("L"+QString::number(i+1)).toString();
                    QString s13=xlsx.read("M"+QString::number(i+1)).toString();
                    QString s14=xlsx.read("N"+QString::number(i+1)).toString();
                    txt.append(s1+"\t"+s2+"\t"+s3+"\t"+s4+"\t"+s5+"\t"+s6+"\t"+s7+"\t"+s8+"\t"+s9+"\t"+s10+"\t"+s11+"\t"+s12+"\t"+s13+"\t"+s14+"\n");
                    //if (i>0)txt.append(QString::number(s1.toFloat(0))+"\t"+s2+"\t"+s3+"\t"+QString::number(s4.toFloat(0))+"\t"+QString::number(s5.toFloat(0))+"\t"+QString::number(s6.toFloat(0))+"\t"+QString::number(s7.toFloat(0))+"\t"+QString::number(s8.toFloat(0))+"\t"+QString::number(s9.toFloat(0))+"\t"+QString::number(s10.toFloat(0))+"\t"+QString::number(s11.toFloat(0))+"\t"+s12+"\n");
                    i++;
                }
                txt.append("\n");
            }
        }
        ui->plainTextEdit->appendPlainText("...Reading complete...");
        update();
        //qDebug() << "finished reading";

        // get Filename

        QStringList filelist=QFilename.split("/");
        QStringList file=filelist.at(filelist.size()-1).split(".");
        QString f=file.at(0);
        QString saveToFileName=resources.path_data+f+".nc";

        //---------------------------------------------------------------
        // Parse txt

        // create new Isotope File in Inventory
        //qDebug()<<"newIso";
        //amsdata->newAMS(1);//qDebug()<<"newams";
        exist_meta=0;
        exist_iso=0;
        exist_age=0;
        save_OK=0;
        //qDebug()<<"init";
        // parse meta Data

        QStringList lines = txt.split("\n"); //Separate into lines
        int iso_data=0;
        int age_data=0;
        int counter=0;
        // clear optional attribute
        inv->set_att_Optiona("");
        int* iso_header=new int[0];
        int iso_header_size=0;
        int* age_header=new int[0];
        int age_header_size=0;

        for (int i=0;i<lines.size();i++){
            if (iso_data==0 && age_data==0 && lines.at(i).left(12)!="Isotope Data" && lines.at(i).left(14)!="Age Model Data"){ // if not in iso or age mode search for meta
                QStringList fields=lines.at(i).split(dlm);
                QString comp=fields.at(0);
                comp.remove(dlm);

                comp=comp.simplified();
                int found=0;
                if (comp==str1[0]){
                    //qDebug() << "found core name :"+fields.at(1);
                    inv->set_att_Core(fields.at(1).simplified());

                    found=1;
                }
                if (comp==str1[1]){
                    //qDebug() << "found species :"+fields.at(1);
                    inv->set_att_Species(fields.at(1).simplified());

                    found=1;
                }
                if (comp==str1[2]){
                    //qDebug() << "found Longitude :"+fields.at(1);
                    QString tmp=fields.at(1);
                    inv->set_att_Longitude(tmp.replace(",",".").toDouble());

                    found=1;
                }
                if (comp==str1[3]){
                    //qDebug() << "found Latitude :"+fields.at(1);
                    QString tmp=fields.at(1);
                    inv->set_att_Latitude(tmp.replace(",",".").toDouble());

                    found=1;
                }
                if (comp==str1[4]){
                    //qDebug() << "found water depth :"+fields.at(1);
                    QString tmp=fields.at(1);
                    inv->set_att_Water_Depth(tmp.replace(",",".").toDouble());

                    found=1;
                }
                if (comp==str1[5]){
                    //qDebug() << "found Device :"+fields.at(1);
                    inv->set_att_Device(fields.at(1).simplified());

                    found=1;
                }
                if (comp==str1[6]){
                    //qDebug() << "found Record Type :"+fields.at(1);
                    QString tmp=fields.at(1).simplified();
                    inv->set_att_Record_Type(tmp);

                    found=1;
                }
                if (comp==str1[7]){
                    //qDebug() << "found "+str1[7]+" :"+fields.at(1);
                    QString tmp=fields.at(1).simplified();
                    inv->set_att_Laboratory(tmp);

                    found=1;
                }
                if (comp==str1[8]){
                    //qDebug() << "found "+str1[8]+" :"+fields.at(1);
                    QString tmp=fields.at(1).simplified();
                    inv->set_att_EPaper(tmp);

                    found=1;
                }
                if (comp==str1[9]){
                    //qDebug() << "found "+str1[9]+" :"+fields.at(1);
                    QString tmp=fields.at(1).simplified();
                    inv->set_att_Comment(tmp);

                    found=1;
                }
                if (comp==str1[10]){
                    //qDebug() << "found "+str1[10]+" :"+fields.at(1);
                    QString tmp=fields.at(1).simplified();
                    inv->set_att_Data_Source(tmp);

                    found=1;
                }
                if (comp==str1[11]){
                    //qDebug() << "found "+str1[11]+" :"+fields.at(1);
                    QString tmp=fields.at(1).simplified();
                    inv->set_att_Reference(tmp);

                    found=1;
                }
                if (comp==str1[12]){
                    //qDebug() << "found "+str1[12]+" :"+fields.at(1);
                    QString tmp=fields.at(1);
                    inv->set_att_O_Use_Flag(tmp.toDouble());

                    found=1;
                }
                if (comp==str1[13]){
                    //qDebug() << "found "+str1[13]+" :"+fields.at(1);
                    QString tmp=fields.at(1);
                    inv->set_att_C_Use_Flag(tmp.toDouble());

                    found=1;
                }
                if (comp==str1[14]){
                    //qDebug() << "found "+str1[14]+" :"+fields.at(1);
                    QString tmp=fields.at(1);
                    inv->set_att_O_Correction(tmp.toDouble());

                    found=1;
                }
                if (comp==str1[15]){
                    //qDebug() << "found "+str1[15]+" :"+fields.at(1);
                    QString tmp=fields.at(1);
                    inv->set_att_C_Correction(tmp.toDouble());

                    found=1;
                }
                if (comp==str1[16]){
                    //qDebug() << "found "+str1[16]+" :"+fields.at(1);
                    QString tmp=fields.at(1).simplified();
                    inv->set_att_O_Justification(tmp);

                    found=1;
                }
                if (comp==str1[17]){
                    //qDebug() << "found "+str1[17]+" :"+fields.at(1);
                    QString tmp=fields.at(1).simplified();
                    inv->set_att_C_Justification(tmp);

                    found=1;
                }

                if (comp==str1[18]){
                    //qDebug() << "found "+str1[17]+" :"+fields.at(1);
                    QString tmp=fields.at(1).simplified();
                    inv->set_att_Category(tmp);

                    found=1;
                }
                if (comp==str1[19]){
                    //qDebug() << "found "+str1[17]+" :"+fields.at(1);
                    QString tmp=fields.at(1).simplified();
                    inv->set_att_Importer(tmp);

                    found=1;
                }
                //... more to come...

                // if nothing was found...
                if (found==0 && comp!=""){
                    // add as optional attribute
                    QString tmp=fields.at(1).simplified();
                    QString tmp2=inv->get_att_Optional();
                    if (tmp2!="") tmp2=tmp2+";";
                    inv->set_att_Optiona(tmp2+comp+"="+tmp);
                    qDebug()<<"found:"+comp+"="+tmp;

                    found=1;
                }



            }
            // Parse Isodata
            if (iso_data==1){
                QStringList fields=lines.at(i).split(dlm);
                //qDebug() <<lines.at(i);
                if (fields.at(0)!=""){
                    if (fields.size()==iso_header_size){
                        if (counter!=0) inv->addIsotope();

                        for (int j=0;j<fields.size();j++){
                            QString tmp=fields.at(j);
                            if (iso_header[j]==0) inv->set_data_Depth(tmp.replace(",",".").toDouble(),counter);
                            if (iso_header[j]==1) inv->set_data_Sample_Thickness(tmp.replace(",",".").toDouble(),counter);
                            if (iso_header[j]==2) inv->set_data_Age(tmp.replace(",",".").toDouble(),counter);
                            if (iso_header[j]==3) inv->set_data_d13C(tmp.replace(",",".").toDouble(),counter);
                            if (iso_header[j]==4) inv->set_data_d18O(tmp.replace(",",".").toDouble(),counter);
                            if (iso_header[j]==5) inv->set_data_d13C_Err(tmp.replace(",",".").toDouble(),counter);
                            if (iso_header[j]==6) inv->set_data_d18O_Err(tmp.replace(",",".").toDouble(),counter);
                            if (iso_header[j]==7) inv->set_data_d13C_Corr(tmp.replace(",",".").toDouble(),counter);
                            if (iso_header[j]==8) inv->set_data_d18O_Corr(tmp.replace(",",".").toDouble(),counter);
                            if (iso_header[j]==9) inv->set_data_Use_Flag(tmp.replace(",",".").toDouble(),counter);
                            if (iso_header[j]==10) inv->set_data_Comment(tmp,counter);
                        }

                        counter++;
                        //qDebug() << "parsed";
                        exist_iso=1;
                    } else {
                        // not enough data error
                    }
                } else {
                    iso_data=0;
                }
            }
            //Toggle iso_data mode
            if (lines.at(i).left(12)=="Isotope Data" && iso_data==0) {
                iso_data=1;
                age_data=0;
                // read Header
                i++;
                QStringList fields=lines.at(i).split(dlm);
                //qDebug()<<"Header:"+lines.at(i);
                delete[] iso_header;
                iso_header=new int[fields.size()];
                for (int g=0;g<fields.size();g++) iso_header[g]=-1;
                iso_header_size=fields.size();
                for (int header=0;header<fields.size();header++){
                    if (fields[header].simplified()=="Depth [m]") iso_header[header]=0;
                    if (fields[header].simplified()=="Sample Thickness [m]") iso_header[header]=1;
                    if (fields[header].simplified()=="Age [ka BP]") iso_header[header]=2;//
                    if (fields[header].simplified()=="d13C [per mil PDB]") iso_header[header]=3;
                    if (fields[header].simplified()=="d18O [per mil PDB]") iso_header[header]=4;
                    if (fields[header].simplified()=="d13C Error [per mil PDB]") iso_header[header]=5;
                    if (fields[header].simplified()=="d18O Error [per mil PDB]") iso_header[header]=6;
                    if (fields[header].simplified()=="d13C Corr [per mil PDB]") iso_header[header]=7;
                    if (fields[header].simplified()=="d18O Corr [per mil PDB]") iso_header[header]=8;
                    if (fields[header].simplified()=="Use Flag") iso_header[header]=9;
                    if (fields[header].simplified()=="Comment") iso_header[header]=10;
                }

                counter=0; // number of entry
                inv->newIsotope(1);
                //qDebug() << "Found IsoData";

            }

            // Parse Age Data
            if (age_data==1){
                QStringList fields=lines.at(i).split(dlm);
                //qDebug() <<lines.at(i);
                if (fields.size()==age_header_size){
                    QString tmp=fields.at(0);
                    for (int j=0;j<fields.size();j++){
                        QString tmp=fields.at(j);
                        if (age_header[j]==0) amsdata->set_Depth(counter,tmp.replace(",",".").toDouble());
                        if (age_header[j]==1) amsdata->set_Sample_Thickness(counter,tmp.replace(",",".").toDouble());
                        if (age_header[j]==2) amsdata->set_LabID(counter,tmp);
                        if (age_header[j]==3) amsdata->set_Type(counter,tmp);
                        if (age_header[j]==4) amsdata->set_Data(0,counter,tmp.replace(",",".").toDouble());
                        if (age_header[j]==5) amsdata->set_Data(1,counter,tmp.replace(",",".").toDouble());
                        if (age_header[j]==6) amsdata->set_Data(2,counter,tmp.replace(",",".").toDouble());
                        if (age_header[j]==7) amsdata->set_Data(3,counter,tmp.replace(",",".").toDouble());
                        if (age_header[j]==8) amsdata->set_Reservoir_Error(counter,tmp.replace(",",".").toDouble());
                        if (age_header[j]==9) amsdata->set_Data(4,counter,tmp.replace(",",".").toDouble());
                        if (age_header[j]==10) amsdata->set_Data(5,counter,tmp.replace(",",".").toDouble());
                        if (age_header[j]==11) amsdata->set_Data(6,counter,tmp.replace(",",".").toDouble());
                        if (age_header[j]==12) amsdata->set_Data(7,counter,tmp.replace(",",".").toInt());
                        if (age_header[j]==13) amsdata->set_Age_Comment(tmp,counter);
                    }
                    counter++;
                    exist_age=1;
                } else {
                    age_data=0;
                }
            }
            //Toggle age_data mode
            if (lines.at(i).left(14)=="Age Model Data" && age_data==0) {
                iso_data=0;
                age_data=1;

                // read Header
                i++;
                QStringList fields=lines.at(i).split(dlm);
                //qDebug()<<"Header:"+lines.at(i);
                delete[] age_header;
                age_header=new int[fields.size()];
                for (int g=0;g<fields.size();g++) age_header[g]=-1;
                age_header_size=fields.size();
                for (int header=0;header<fields.size();header++){
                    if (fields[header].simplified()=="Depth [m]") age_header[header]=0;
                    if (fields[header].simplified()=="Sample Thickness [m]") age_header[header]=1;
                    if (fields[header].simplified()=="Label") age_header[header]=2;
                    if (fields[header].simplified()=="Type") age_header[header]=3;
                    if (fields[header].simplified()=="Age dated [ka]") age_header[header]=4;
                    if (fields[header].simplified()=="Age UCL [ka +]") age_header[header]=5;
                    if (fields[header].simplified()=="Age LCL [ka -]") age_header[header]=6;
                    if (fields[header].simplified()=="Res. Age [ka]") age_header[header]=7;
                    if (fields[header].simplified()=="Res. Age Error [ka]") age_header[header]=8;
                    if (fields[header].simplified()=="Cal yrs [wm ka BP]") age_header[header]=9;
                    if (fields[header].simplified()=="Cal yrs min [95%]") age_header[header]=10;
                    if (fields[header].simplified()=="Cal yrs max [95%]") age_header[header]=11;
                    if (fields[header].simplified()=="Use Flag") age_header[header]=12;
                    if (fields[header].simplified()=="Dating Method/Comments") age_header[header]=13;
                }

                counter=0; // number of entry
                int length=0;
                while (i+length<lines.size()-1 && lines.at(i+length)!=""){
                    length++;
                }
                if (length==0){
                    age_data=0;
                }else{
                    amsdata->newAMS(length-1);
                }
                //qDebug() << "Length of AMS: "+QString::number(length-1);

            }


        }
        if (meta_length>0) exist_meta=1;
        //qDebug() << "parsen finished";
        // Create corrected isotopes
        for (int i=0;i<inv->get_Length();i++) {
            if (inv->get_data_d13C_Corr(i)==0 ||inv->get_data_d13C_Corr(i)==NAN) inv->set_data_d13C_Corr(inv->get_data_d13C(i)+inv->get_att_C_Correction(),i);
            if (inv->get_data_d18O_Corr(i)==0 ||inv->get_data_d18O_Corr(i)==NAN) inv->set_data_d18O_Corr(inv->get_data_d18O(i)+inv->get_att_O_Correction(),i);
        }

        delete[] iso_header;
        delete[] age_header;
        save_OK=1;
        ui->plainTextEdit->appendPlainText("...Parsing complete...");
        update();

        //---------------------------------------------------------------------
        // save
        QFilename=saveToFileName;
        if (QFilename=="") QFilename=inv->get_att_Core()+".nc";
        QFilename.replace("\\","/");
        QStringList QPath=QFilename.split("/");
        QFilename=QPath.at(QPath.size()-1);
        QFilename.replace(QString(".txt"),QString(".nc"));
        QFilename.replace(QString(".xlsx"),QString(".nc"));

        int save=save_OK;
        int exist=0;
        // Check if Entry already exists
        int count=-1;
        if (inv2->get_Entries()>0){
        for (int i=0;i<inv2->get_Entries();i++){

            QString str1=inv->get_att_Core().replace('\0',' ');
            QString str2=inv2->get_Core(i).replace('\0',' ');
            QString str3=inv->get_att_Species().replace('\0',' ');
            QString str4=inv2->get_Species(i).replace('\0',' ');
            if (str1.simplified()==str2.simplified() && str3.simplified()==str4.simplified()){
                count=i;
                exist=1;
                break;
            }
        }

        // Give out a warning
        if (count>-1 && save==1) {

            if (!ui->radioButton->isChecked()){
                save=0;
                ui->plainTextEdit->appendPlainText("...Already Exists -> NOT Saved!\n");
                update();

            } else {
            // Correct Inventory entry count
                inv2->set_currentCore(count);
                // enter information into last inventory
                inv2->set_Core(inv->get_att_Core());
                inv2->set_Species(inv->get_att_Species());
                inv2->set_Longitude(inv->get_att_Longitude());
                inv2->set_Latitude(inv->get_att_Latitude());
                inv2->set_Water_Depth(inv->get_att_Water_Depth());
                inv2->set_Basin(0);
                inv2->set_O_Use_Flag(inv->get_att_Oxygen_Use_Flag());
                inv2->set_C_Use_Flag(inv->get_att_Carbon_Use_Flag());
                inv2->set_Record_Type(inv->get_att_Record_Type());
                inv2->set_Selected(inv2->get_currentCore(),1);
                inv2->set_Filename(QFilename);
                if (exist_age==1){
                    amsdata->set_Inventory(inv2);
                    amsdata->AMSSave();
                    inv2->set_AgeModel(inv2->get_currentCore(),1);
                } else {
                    inv2->set_AgeModel(inv2->get_currentCore(),0);
                }
            }
        }

        // Check if Filename is already in Library
        count=-1;

        for (int i=0;i<inv2->get_Entries();i++){


            QString str1=inv2->get_Filename(i).replace('\0',' ');

            if (QFilename.simplified()==str1.simplified()){
                count=i;
                exist=1;
                break;
            }
        }
        // Give out a warning
        if (count>-1 && save==1) {

            if (!ui->radioButton->isChecked()){
                save=0;
                ui->plainTextEdit->appendPlainText("...Already Exists -> NOT Saved!\n");
                update();

            } else {
                // Correct Inventory entry count
                inv2->set_currentCore(count);
                // enter information into last inventory
                inv2->set_Core(inv->get_att_Core());
                inv2->set_Species(inv->get_att_Species());
                inv2->set_Longitude(inv->get_att_Longitude());
                inv2->set_Latitude(inv->get_att_Latitude());
                inv2->set_Water_Depth(inv->get_att_Water_Depth());
                inv2->set_Basin(0);
                inv2->set_O_Use_Flag(inv->get_att_Oxygen_Use_Flag());
                inv2->set_C_Use_Flag(inv->get_att_Carbon_Use_Flag());
                inv2->set_Record_Type(inv->get_att_Record_Type());
                inv2->set_Selected(inv2->get_currentCore(),1);
                inv2->set_Filename(QFilename);

                if (exist_age==1){
                    amsdata->set_Inventory(inv2);
                    amsdata->AMSSave();
                    inv2->set_AgeModel(inv2->get_currentCore(),1);
                } else {
                    inv2->set_AgeModel(inv2->get_currentCore(),0);
                }
            }


        }

        }

        // save to library
        if (save_OK==1 && save==1){
            // save Data



            inv->saveData(QFilename);
            ui->plainTextEdit->appendPlainText("...Saving Complete\n");
            update();

            if (exist==0){
                // new Entry
                inv2->addEntry();
                inv2->set_currentCore(inv2->get_Entries()-1);
                // enter information into last inventory
                inv2->set_Core(inv->get_att_Core());
                inv2->set_Species(inv->get_att_Species());
                inv2->set_Longitude(inv->get_att_Longitude());
                inv2->set_Latitude(inv->get_att_Latitude());
                inv2->set_Water_Depth(inv->get_att_Water_Depth());
                inv2->set_Basin(inv2->get_Basin(inv->get_att_Longitude(),inv->get_att_Latitude()));
                inv2->set_O_Use_Flag(inv->get_att_Oxygen_Use_Flag());
                inv2->set_C_Use_Flag(inv->get_att_Carbon_Use_Flag());
                inv2->set_Record_Type(inv->get_att_Record_Type());
                inv2->set_Selected(inv2->get_currentCore(),1);
                inv2->set_Filename(QFilename);

                if (exist_age==1){
                    amsdata->set_Inventory(inv2);
                    amsdata->AMSSave();
                    inv2->set_AgeModel(inv2->get_currentCore(),1);
                } else {
                    inv2->set_AgeModel(inv2->get_currentCore(),0);
                }


            }
        }
    }

    emit(refresh());
    ui->plainTextEdit->appendPlainText("Imported all files. Close this window to return to the MainWindow. The new Files are already selected.");

}


