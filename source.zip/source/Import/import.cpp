/********************************************************************************/
/*    This file is part of PaleoDataViewer.                       					*/
/*                                                                      		*/
/*    PaleoDataViewer is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoDataViewer is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoDataViewer.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#include "import.h"
#include "ui_import.h"

Import::Import(QMainWindow *mainWindow,Inventory *inventory) :
    mainW(mainWindow),inv2(inventory),
    ui(new Ui::Import)
{

    ui->setupUi(this);
    sp=ui->splitter->saveState();
    sp_2=ui->splitter_2->saveState();
    sp_3=ui->splitter_3->saveState();
    qApp->installEventFilter(this);
    inv=new Inventory();
    inv->read();// create an inventory to initialize Variables


    amsdata=new AMSData(inv2);
    metaData = new QStandardItemModel(0,0,this);
    modelIsotope = new QStandardItemModel(0,0,this);
    ageData= new QStandardItemModel(0,0,this);
    exist_meta=0;
    exist_iso=0;
    exist_age=0;
    meta_length=21;
    str1=new QString[meta_length];
    str2=new QString[meta_length];
    str1[0]="Core";

    str1[1]="Species";

    str1[2]="Longitude [dez]";

    str1[3]="Latitude [dez]";

    str1[4]="Water Depth [m]";

    str1[5]="Device";

    str1[6]="Type";

    str1[7]="Laboratory";

    str1[8]="Electronic Paper";

    str1[9]="Comments";

    str1[10]="Data Source";

    str1[11]="Reference";

    str1[12]="O-Use Flag";

    str1[13]="C-Use Flag";

    str1[14]="O-Correction";

    str1[15]="C-Correction";

    str1[16]="O-Justification";

    str1[17]="C-Justification";


    str1[18]="Category";
    str1[19]="Importer";
    str1[20]="Optional";



    // bring them into shape
    //for (int i=0;i<meta_length;i++) {
    //    while (str1[i].size()<30) str1[i].append(" ");
    //    str1[i].append(":");
    //}

    dlm="\t";
    save_OK=0;
    QFont font;
    font.setFamily("Courier");
    font.setStyleHint(QFont::Monospace);
    font.setFixedPitch(true);
    font.setPointSize(10);

    ui->plainTextEdit->setFont(font);

    connect(ui->pushButton,SIGNAL(clicked(bool)),this,SLOT(browse()));
    connect(ui->pushButton_4,SIGNAL(clicked(bool)),this,SLOT(browse2()));
    connect(ui->pushButton_2,SIGNAL(clicked(bool)),this,SLOT(import()));
    connect(ui->pushButton_3,SIGNAL(clicked(bool)),this,SLOT(save()));
    connect(this,SIGNAL(refresh()),mainW,SLOT(redraw_score()));

}

Import::~Import()
{
    delete ui;
    delete amsdata;
    delete str1;
    delete str2;
    delete metaData;
    delete modelIsotope;
    delete ageData;
    delete inv;
}

void Import::browse(){
    QString filename = QFileDialog::getOpenFileName(this, tr("Select File"),
                                             resources.path_data,
                                             tr("Excel (*.xlsx);;Text File (*.txt)"));
    //qDebug() << filename;
    ui->lineEdit->setText(filename);
    // read File and put to TextBrowser
    // get file name
    QString QFilename=ui->lineEdit->text();
    //qDebug() << QFilename;
    if (QFilename.right(4)==".txt"){
        QFile file(QFilename);
        if(!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
            //qDebug() <<  file.errorString();
        } else {
            txt.clear();
            QTextStream in(&file);
            while(!in.atEnd()) {
                txt.append(in.readLine().toLocal8Bit()+"\n");
            }

        file.close();
    }
    }
    if (QFilename.right(5)==".xlsx"){
        //qDebug() <<"reading Excel";
        QXlsx::Document xlsx(QFilename);
        txt.clear();
        if (xlsx.selectSheet("Meta Data")){
            //qDebug() <<"reading Meta";
            int i=0;
            while (xlsx.read("A"+QString::number(i+1)).toString()!=""){
                //qDebug() << QString::number(i);
                QString s1=xlsx.read("A"+QString::number(i+1)).toString();
                //while (s1.size()<30) s1.append(" ");
                //s1.append(":");
                QString s2=xlsx.read("B"+QString::number(i+1)).toString();
                txt.append(s1+dlm+s2+"\n");
                i++;
            }
            txt.append("\n");
        }
        if (xlsx.selectSheet("Proxy")){

            //qDebug() <<"reading Isotope";
            int i=0;
            txt.append("Isotope Data\n");
            while (xlsx.read("A"+QString::number(i+1)).toString()!=""){
                //qDebug() << QString::number(i);
                QString s1=xlsx.read("A"+QString::number(i+1)).toString();
                QString s2=xlsx.read("B"+QString::number(i+1)).toString();
                QString s3=xlsx.read("C"+QString::number(i+1)).toString();
                QString s4=xlsx.read("D"+QString::number(i+1)).toString();
                QString s5=xlsx.read("E"+QString::number(i+1)).toString();
                QString s6=xlsx.read("F"+QString::number(i+1)).toString();
                QString s7=xlsx.read("G"+QString::number(i+1)).toString();
                QString s8=xlsx.read("H"+QString::number(i+1)).toString();
                QString s9=xlsx.read("I"+QString::number(i+1)).toString();
                QString s10=xlsx.read("J"+QString::number(i+1)).toString();
                QString s11=xlsx.read("K"+QString::number(i+1)).toString();


                txt.append(s1+"\t"+s2+"\t"+s3+"\t"+s4+"\t"+s5+"\t"+s6+"\t"+s7+"\t"+s8+"\t"+s9+"\t"+s10+"\t"+s11+"\n");
                //if (i>0)txt.append(QString::number(s1.toFloat(0))+"\t"+QString::number(s2.toFloat(0))+"\t"+QString::number(s3.toFloat(0))+"\t"+QString::number(s4.toFloat(0))+"\t"+QString::number(s5.toFloat(0))+"\t"+QString::number(s6.toFloat(0))+"\t"+QString::number(s7.toFloat(0))+"\t"+QString::number(s8.toFloat(0))+"\t"+QString::number(s9.toFloat(0))+"\t"+QString::number(s10.toFloat(0))+"\t"+s11+"\n");



                i++;
            }
            txt.append("\n");
        }
        if (xlsx.selectSheet("Isotopes")){

            //qDebug() <<"reading Isotope";
            int i=0;
            txt.append("Isotope Data\n");
            while (xlsx.read("A"+QString::number(i+1)).toString()!=""){
                //qDebug() << QString::number(i);
                QString s1=xlsx.read("A"+QString::number(i+1)).toString();
                QString s2=xlsx.read("B"+QString::number(i+1)).toString();
                QString s3=xlsx.read("C"+QString::number(i+1)).toString();
                QString s4=xlsx.read("D"+QString::number(i+1)).toString();
                QString s5=xlsx.read("E"+QString::number(i+1)).toString();
                QString s6=xlsx.read("F"+QString::number(i+1)).toString();
                QString s7=xlsx.read("G"+QString::number(i+1)).toString();
                QString s8=xlsx.read("H"+QString::number(i+1)).toString();
                QString s9=xlsx.read("I"+QString::number(i+1)).toString();
                QString s10=xlsx.read("J"+QString::number(i+1)).toString();
                QString s11=xlsx.read("K"+QString::number(i+1)).toString();


                txt.append(s1+"\t"+s2+"\t"+s3+"\t"+s4+"\t"+s5+"\t"+s6+"\t"+s7+"\t"+s8+"\t"+s9+"\t"+s10+"\t"+s11+"\n");
                //if (i>0)txt.append(QString::number(s1.toFloat(0))+"\t"+QString::number(s2.toFloat(0))+"\t"+QString::number(s3.toFloat(0))+"\t"+QString::number(s4.toFloat(0))+"\t"+QString::number(s5.toFloat(0))+"\t"+QString::number(s6.toFloat(0))+"\t"+QString::number(s7.toFloat(0))+"\t"+QString::number(s8.toFloat(0))+"\t"+QString::number(s9.toFloat(0))+"\t"+QString::number(s10.toFloat(0))+"\t"+s11+"\n");



                i++;
            }
            txt.append("\n");
        }
        if (xlsx.selectSheet("Age")){

            //qDebug() <<"reading Age Model";
            int i=0;
            txt.append("Age Model Data\n");
            while (xlsx.read("A"+QString::number(i+1)).toString()!=""){
                //qDebug() << QString::number(i);
                QString s1=xlsx.read("A"+QString::number(i+1)).toString();
                QString s2=xlsx.read("B"+QString::number(i+1)).toString();
                QString s3=xlsx.read("C"+QString::number(i+1)).toString();
                QString s4=xlsx.read("D"+QString::number(i+1)).toString();
                QString s5=xlsx.read("E"+QString::number(i+1)).toString();
                QString s6=xlsx.read("F"+QString::number(i+1)).toString();
                QString s7=xlsx.read("G"+QString::number(i+1)).toString();
                QString s8=xlsx.read("H"+QString::number(i+1)).toString();
                QString s9=xlsx.read("I"+QString::number(i+1)).toString();
                QString s10=xlsx.read("J"+QString::number(i+1)).toString();
                QString s11=xlsx.read("K"+QString::number(i+1)).toString();
                QString s12=xlsx.read("L"+QString::number(i+1)).toString();
                QString s13=xlsx.read("M"+QString::number(i+1)).toString();
                QString s14=xlsx.read("N"+QString::number(i+1)).toString();
                txt.append(s1+"\t"+s2+"\t"+s3+"\t"+s4+"\t"+s5+"\t"+s6+"\t"+s7+"\t"+s8+"\t"+s9+"\t"+s10+"\t"+s11+"\t"+s12+"\t"+s13+"\t"+s14+"\n");
                //if (i>0)txt.append(QString::number(s1.toFloat(0))+"\t"+s2+"\t"+s3+"\t"+QString::number(s4.toFloat(0))+"\t"+QString::number(s5.toFloat(0))+"\t"+QString::number(s6.toFloat(0))+"\t"+QString::number(s7.toFloat(0))+"\t"+QString::number(s8.toFloat(0))+"\t"+QString::number(s9.toFloat(0))+"\t"+QString::number(s10.toFloat(0))+"\t"+QString::number(s11.toFloat(0))+"\t"+s12+"\n");
                i++;
            }
            txt.append("\n");
        }
        if (xlsx.selectSheet("Age Model")){

            //qDebug() <<"reading Age Model";
            int i=0;
            txt.append("Age Model Data\n");
            while (xlsx.read("A"+QString::number(i+1)).toString()!=""){
                //qDebug() << QString::number(i);
                QString s1=xlsx.read("A"+QString::number(i+1)).toString();
                QString s2=xlsx.read("B"+QString::number(i+1)).toString();
                QString s3=xlsx.read("C"+QString::number(i+1)).toString();
                QString s4=xlsx.read("D"+QString::number(i+1)).toString();
                QString s5=xlsx.read("E"+QString::number(i+1)).toString();
                QString s6=xlsx.read("F"+QString::number(i+1)).toString();
                QString s7=xlsx.read("G"+QString::number(i+1)).toString();
                QString s8=xlsx.read("H"+QString::number(i+1)).toString();
                QString s9=xlsx.read("I"+QString::number(i+1)).toString();
                QString s10=xlsx.read("J"+QString::number(i+1)).toString();
                QString s11=xlsx.read("K"+QString::number(i+1)).toString();
                QString s12=xlsx.read("L"+QString::number(i+1)).toString();
                QString s13=xlsx.read("M"+QString::number(i+1)).toString();
                QString s14=xlsx.read("N"+QString::number(i+1)).toString();
                txt.append(s1+"\t"+s2+"\t"+s3+"\t"+s4+"\t"+s5+"\t"+s6+"\t"+s7+"\t"+s8+"\t"+s9+"\t"+s10+"\t"+s11+"\t"+s12+"\t"+s13+"\t"+s14+"\n");
                //if (i>0)txt.append(QString::number(s1.toFloat(0))+"\t"+s2+"\t"+s3+"\t"+QString::number(s4.toFloat(0))+"\t"+QString::number(s5.toFloat(0))+"\t"+QString::number(s6.toFloat(0))+"\t"+QString::number(s7.toFloat(0))+"\t"+QString::number(s8.toFloat(0))+"\t"+QString::number(s9.toFloat(0))+"\t"+QString::number(s10.toFloat(0))+"\t"+QString::number(s11.toFloat(0))+"\t"+s12+"\n");
                i++;
            }
            txt.append("\n");
        }
    }
    //qDebug() << "finished reading";

    ui->plainTextEdit->clear();

    ui->plainTextEdit->setPlainText(txt);

    // get Filename
    QStringList filelist=QFilename.split("/");
    QStringList file=filelist.at(filelist.size()-1).split(".");
    QString f=file.at(0);
    ui->lineEdit_2->setText(resources.path_data+f+".nc");
    update();
}

void Import::browse2(){
    QString file = QFileDialog::getSaveFileName(this, tr("Select Save Filename"),
                                             resources.path_data+inv->get_att_Core(),
                                             tr("Library File (*.nc)"));

    //qDebug() << file;
    ui->lineEdit_2->setText(file);
}


void Import::import(){//qDebug() <<"started parsing";
    txt=ui->plainTextEdit->toPlainText();
    // create new Isotope File in Inventory
    //qDebug()<<"newIso";
    //amsdata->newAMS(1);//qDebug()<<"newams";
    exist_meta=0;
    exist_iso=0;
    exist_age=0;
    //qDebug()<<"init";
    // parse meta Data

    QStringList lines = txt.split("\n"); //Separate into lines
    int iso_data=0;
    int age_data=0;
    int counter=0;
    // clear optional attribute
    inv->set_att_Optiona("");
    int* iso_header=new int[0];
    int iso_header_size=0;
    int* age_header=new int[0];
    int age_header_size=0;

    for (int i=0;i<lines.size();i++){
        if (iso_data==0 && age_data==0 && lines.at(i).left(12)!="Isotope Data" && lines.at(i).left(14)!="Age Model Data"){ // if not in iso or age mode search for meta
            QStringList fields=lines.at(i).split(dlm);
            QString comp=fields.at(0);
            comp.remove(dlm);

            comp=comp.simplified();
            int found=0;
            if (comp==str1[0]){
                //qDebug() << "found core name :"+fields.at(1);
                inv->set_att_Core(fields.at(1).simplified());

                found=1;
            }
            if (comp==str1[1]){
                //qDebug() << "found species :"+fields.at(1);
                inv->set_att_Species(fields.at(1).simplified());

                found=1;
            }
            if (comp==str1[2]){
                //qDebug() << "found Longitude :"+fields.at(1);
                QString tmp=fields.at(1);
                inv->set_att_Longitude(tmp.replace(",",".").toDouble());

                found=1;
            }
            if (comp==str1[3]){
                //qDebug() << "found Latitude :"+fields.at(1);
                QString tmp=fields.at(1);
                inv->set_att_Latitude(tmp.replace(",",".").toDouble());

                found=1;
            }
            if (comp==str1[4]){
                //qDebug() << "found water depth :"+fields.at(1);
                QString tmp=fields.at(1);
                inv->set_att_Water_Depth(tmp.replace(",",".").toDouble());

                found=1;
            }
            if (comp==str1[5]){
                //qDebug() << "found Device :"+fields.at(1);
                inv->set_att_Device(fields.at(1).simplified());

                found=1;
            }
            if (comp==str1[6]){
                //qDebug() << "found Record Type :"+fields.at(1);
                QString tmp=fields.at(1).simplified();
                inv->set_att_Record_Type(tmp);

                found=1;
            }
            if (comp==str1[7]){
                //qDebug() << "found "+str1[7]+" :"+fields.at(1);
                QString tmp=fields.at(1).simplified();
                inv->set_att_Laboratory(tmp);

                found=1;
            }
            if (comp==str1[8]){
                //qDebug() << "found "+str1[8]+" :"+fields.at(1);
                QString tmp=fields.at(1).simplified();
                inv->set_att_EPaper(tmp);

                found=1;
            }
            if (comp==str1[9]){
                //qDebug() << "found "+str1[9]+" :"+fields.at(1);
                QString tmp=fields.at(1).simplified();
                inv->set_att_Comment(tmp);

                found=1;
            }
            if (comp==str1[10]){
                //qDebug() << "found "+str1[10]+" :"+fields.at(1);
                QString tmp=fields.at(1).simplified();
                inv->set_att_Data_Source(tmp);

                found=1;
            }
            if (comp==str1[11]){
                //qDebug() << "found "+str1[11]+" :"+fields.at(1);
                QString tmp=fields.at(1).simplified();
                inv->set_att_Reference(tmp);

                found=1;
            }
            if (comp==str1[12]){
                //qDebug() << "found "+str1[12]+" :"+fields.at(1);
                QString tmp=fields.at(1);
                inv->set_att_O_Use_Flag(tmp.toDouble());

                found=1;
            }
            if (comp==str1[13]){
                //qDebug() << "found "+str1[13]+" :"+fields.at(1);
                QString tmp=fields.at(1);
                inv->set_att_C_Use_Flag(tmp.toDouble());

                found=1;
            }
            if (comp==str1[14]){
                //qDebug() << "found "+str1[14]+" :"+fields.at(1);
                QString tmp=fields.at(1);
                inv->set_att_O_Correction(tmp.toDouble());

                found=1;
            }
            if (comp==str1[15]){
                //qDebug() << "found "+str1[15]+" :"+fields.at(1);
                QString tmp=fields.at(1);
                inv->set_att_C_Correction(tmp.toDouble());

                found=1;
            }
            if (comp==str1[16]){
                //qDebug() << "found "+str1[16]+" :"+fields.at(1);
                QString tmp=fields.at(1).simplified();
                inv->set_att_O_Justification(tmp);

                found=1;
            }
            if (comp==str1[17]){
                //qDebug() << "found "+str1[17]+" :"+fields.at(1);
                QString tmp=fields.at(1).simplified();
                inv->set_att_C_Justification(tmp);

                found=1;
            }

            if (comp==str1[18]){
                //qDebug() << "found "+str1[17]+" :"+fields.at(1);
                QString tmp=fields.at(1).simplified();
                inv->set_att_Category(tmp);

                found=1;
            }
            if (comp==str1[19]){
                //qDebug() << "found "+str1[17]+" :"+fields.at(1);
                QString tmp=fields.at(1).simplified();
                inv->set_att_Importer(tmp);

                found=1;
            }
            //... more to come...

            // if nothing was found...
            if (found==0 && comp!=""){
                // add as optional attribute
                QString tmp=fields.at(1).simplified();
                QString tmp2=inv->get_att_Optional();
                if (tmp2!="") tmp2=tmp2+";";
                inv->set_att_Optiona(tmp2+comp+"="+tmp);
                qDebug()<<"found:"+comp+"="+tmp;

                found=1;
            }



        }
        // Parse Isodata
        if (iso_data==1){
            QStringList fields=lines.at(i).split(dlm);
            //qDebug() <<lines.at(i);
            if (fields.at(0)!=""){
                if (fields.size()==iso_header_size){
                    if (counter!=0) inv->addIsotope();

                    for (int j=0;j<fields.size();j++){
                        QString tmp=fields.at(j);
                        if (iso_header[j]==0) inv->set_data_Depth(tmp.replace(",",".").toDouble(),counter);
                        if (iso_header[j]==1) if (tmp.replace(",",".").toDouble()!=0) inv->set_data_Sample_Thickness(tmp.replace(",",".").toDouble(),counter); else inv->set_data_Sample_Thickness(NAN,counter);
                        if (iso_header[j]==2) inv->set_data_Age(tmp.replace(",",".").toDouble(),counter);
                        if (iso_header[j]==3) inv->set_data_d13C(tmp.replace(",",".").toDouble(),counter);
                        if (iso_header[j]==4) inv->set_data_d18O(tmp.replace(",",".").toDouble(),counter);
                        if (iso_header[j]==5) inv->set_data_d13C_Err(tmp.replace(",",".").toDouble(),counter);
                        if (iso_header[j]==6) inv->set_data_d18O_Err(tmp.replace(",",".").toDouble(),counter);
                        if (iso_header[j]==7) inv->set_data_d13C_Corr(tmp.replace(",",".").toDouble(),counter);
                        if (iso_header[j]==8) inv->set_data_d18O_Corr(tmp.replace(",",".").toDouble(),counter);
                        if (iso_header[j]==9) inv->set_data_Use_Flag(tmp.replace(",",".").toDouble(),counter);
                        if (iso_header[j]==10) inv->set_data_Comment(tmp,counter);
                    }

                    counter++;
                    //qDebug() << "parsed";
                    exist_iso=1;
                } else {
                    // not enough data error
                }
            } else {
                iso_data=0;
            }
        }
        //Toggle iso_data mode
        if (lines.at(i).left(12)=="Isotope Data" && iso_data==0) {
            iso_data=1;
            age_data=0;
            // read Header
            i++;
            QStringList fields=lines.at(i).split(dlm);
            //qDebug()<<"Header:"+lines.at(i);
            delete[] iso_header;
            iso_header=new int[fields.size()];
            iso_header_size=fields.size();
            for (int header=0;header<fields.size();header++){
                if (fields[header].simplified()=="Depth [m]") iso_header[header]=0;
                if (fields[header].simplified()=="Sample Thickness [m]") iso_header[header]=1;
                if (fields[header].simplified()=="Age [ka BP]") iso_header[header]=2;//
                if (fields[header].simplified()=="d13C [per mil PDB]") iso_header[header]=3;
                if (fields[header].simplified()=="d18O [per mil PDB]") iso_header[header]=4;
                if (fields[header].simplified()=="d13C Error [per mil PDB]") iso_header[header]=5;
                if (fields[header].simplified()=="d18O Error [per mil PDB]") iso_header[header]=6;
                if (fields[header].simplified()=="d13C Corr [per mil PDB]") iso_header[header]=7;
                if (fields[header].simplified()=="d18O Corr [per mil PDB]") iso_header[header]=8;
                if (fields[header].simplified()=="Use Flag") iso_header[header]=9;
                if (fields[header].simplified()=="Comment") iso_header[header]=10;
            }

            counter=0; // number of entry
            inv->newIsotope(1);
            //qDebug() << "Found IsoData";

        }

        // Parse Age Data
        if (age_data==1){
            QStringList fields=lines.at(i).split(dlm);
            //qDebug() <<lines.at(i);
            if (fields.size()==age_header_size){
                QString tmp=fields.at(0);
                for (int j=0;j<fields.size();j++){
                    QString tmp=fields.at(j);
                    if (age_header[j]==0) amsdata->set_Depth(counter,tmp.replace(",",".").toDouble());
                    if (age_header[j]==1) if (tmp.replace(",",".").toDouble()!=0) amsdata->set_Sample_Thickness(counter,tmp.replace(",",".").toDouble()); else amsdata->set_Sample_Thickness(counter,NAN);
                    if (age_header[j]==2) amsdata->set_LabID(counter,tmp);
                    if (age_header[j]==3) amsdata->set_Type(counter,tmp);
                    if (age_header[j]==4) amsdata->set_Data(0,counter,tmp.replace(",",".").toDouble());
                    if (age_header[j]==5) amsdata->set_Data(1,counter,tmp.replace(",",".").toDouble());
                    if (age_header[j]==6) amsdata->set_Data(2,counter,tmp.replace(",",".").toDouble());
                    if (age_header[j]==7) amsdata->set_Data(3,counter,tmp.replace(",",".").toDouble());
                    if (age_header[j]==8) amsdata->set_Reservoir_Error(counter,tmp.replace(",",".").toDouble());
                    if (age_header[j]==9) amsdata->set_Data(4,counter,tmp.replace(",",".").toDouble());
                    if (age_header[j]==10) amsdata->set_Data(5,counter,tmp.replace(",",".").toDouble());
                    if (age_header[j]==11) amsdata->set_Data(6,counter,tmp.replace(",",".").toDouble());
                    if (age_header[j]==12) amsdata->set_Data(7,counter,tmp.replace(",",".").toInt());
                    if (age_header[j]==13) amsdata->set_Age_Comment(tmp,counter);
                }
                counter++;
                exist_age=1;
            } else {
                age_data=0;
            }
        }
        //Toggle age_data mode
        if (lines.at(i).left(14)=="Age Model Data" && age_data==0) {
            iso_data=0;
            age_data=1;

            // read Header
            i++;
            QStringList fields=lines.at(i).split(dlm);
            //qDebug()<<"Header:"+lines.at(i);
            delete[] age_header;
            age_header=new int[fields.size()];
            age_header_size=fields.size();
            for (int header=0;header<fields.size();header++){
                if (fields[header].simplified()=="Depth [m]") age_header[header]=0;
                if (fields[header].simplified()=="Sample Thickness [m]") age_header[header]=1;
                if (fields[header].simplified()=="Label") age_header[header]=2;
                if (fields[header].simplified()=="Type") age_header[header]=3;
                if (fields[header].simplified()=="Age dated [ka]") age_header[header]=4;
                if (fields[header].simplified()=="Age UCL [ka +]") age_header[header]=5;
                if (fields[header].simplified()=="Age LCL [ka -]") age_header[header]=6;
                if (fields[header].simplified()=="Res. Age [ka]") age_header[header]=7;
                if (fields[header].simplified()=="Res. Age Error [ka]") age_header[header]=8;
                if (fields[header].simplified()=="Cal yrs [wm ka BP]") age_header[header]=9;
                if (fields[header].simplified()=="Cal yrs min [95%]") age_header[header]=10;
                if (fields[header].simplified()=="Cal yrs max [95%]") age_header[header]=11;
                if (fields[header].simplified()=="Use Flag") age_header[header]=12;
                if (fields[header].simplified()=="Dating Method/Comments") age_header[header]=13;
            }

            counter=0; // number of entry
            int length=0;
            while (i+length<lines.size()-1 && lines.at(i+length)!=""){
                length++;
            }
            if (length==0){
                age_data=0;
            }else{
                amsdata->newAMS(length-1);
            }
            //qDebug() << "Length of AMS: "+QString::number(length-1);

        }


    }
    if (meta_length>0) exist_meta=1;
    //qDebug() << "parsen finished";
    // Create corrected isotopes
    for (int i=0;i<inv->get_Length();i++) {
        if (inv->get_data_d13C_Corr(i)==0 ||inv->get_data_d13C_Corr(i)==NAN) inv->set_data_d13C_Corr(inv->get_data_d13C(i)+inv->get_att_C_Correction(),i);
        if (inv->get_data_d18O_Corr(i)==0 ||inv->get_data_d18O_Corr(i)==NAN) inv->set_data_d18O_Corr(inv->get_data_d18O(i)+inv->get_att_O_Correction(),i);
    }
    setupTable();
    delete[] iso_header;
    delete[] age_header;
    save_OK=1;

}

void Import::setupTable(){
    // setup Meta
    if (exist_meta){
    // create the model for Meta Data
    //qDebug() << "setting up Meta Table";
    delete metaData;
    metaData = new QStandardItemModel(meta_length,2,this);
    metaData->setHorizontalHeaderItem(0, new QStandardItem(QString("Name")));
    metaData->setHorizontalHeaderItem(1, new QStandardItem(QString("Value")));


    ui->tableView_3->setModel(metaData);
    ui->tableView_3->setEditTriggers(QAbstractItemView::NoEditTriggers);
    QStandardItem *meta_Name = new QStandardItem[meta_length];
    QStandardItem *meta_Value = new QStandardItem[meta_length];


    // Add Meta

    str2[0]=inv->get_att_Core();

    str2[1]=inv->get_att_Species();

    str2[2]=QString::number(inv->get_att_Longitude());

    str2[3]=QString::number(inv->get_att_Latitude());

    str2[4]=QString::number(inv->get_att_Water_Depth());

    str2[5]=inv->get_att_Device();

    str2[6]=inv->get_att_Record_Type();

    str2[7]=inv->get_att_Laboratory();

    str2[8]=inv->get_att_EPaper();

    str2[9]=inv->get_att_Comment();

    str2[10]=inv->get_att_Data_Source();

    str2[11]=inv->get_att_Reference();

    str2[12]=QString::number(inv->get_att_Oxygen_Use_Flag());

    str2[13]=QString::number(inv->get_att_Carbon_Use_Flag());

    str2[14]=QString::number(inv->get_att_O_Correction());

    str2[15]=QString::number(inv->get_att_C_Correction());

    str2[16]=inv->get_att_O_Justification();

    str2[17]=inv->get_att_C_Justification();

    str2[18]=inv->get_att_Category();
    str2[19]=inv->get_att_Importer();
    str2[20]=inv->get_att_Optional();

    // and more...
    for (int i=0;i<meta_length;i++) {
        meta_Name[i].setData(str1[i],Qt::EditRole);
        metaData->setItem(i,0,&meta_Name[i]);

        meta_Value[i].setData(str2[i],Qt::EditRole);
        metaData->setItem(i,1,&meta_Value[i]);
    }

    ui->tableView_3->setSortingEnabled(0);
    ui->tableView_3->verticalHeader()->setDefaultSectionSize(ui->tableView_3->verticalHeader()->minimumSectionSize());
    ui->tableView_3->resizeColumnsToContents();
    ui->tableView_3->setHorizontalScrollMode(ui->tableView_3->ScrollPerPixel);
    ui->tableView_3->setSelectionMode(QAbstractItemView::NoSelection);
    ui->tableView_3->horizontalHeader()->setStretchLastSection(1);
    }
    // setup IsoData
    if (exist_iso){
    // create the model for Meta Data
    //qDebug() << "setting up Iso Table";
    delete modelIsotope;
    modelIsotope = new QStandardItemModel(inv->get_Length(),10,this);
    modelIsotope->setHorizontalHeaderItem(0, new QStandardItem(QString("Depth")));
    modelIsotope->setHorizontalHeaderItem(1, new QStandardItem(QString("Sample\nThickness")));
    modelIsotope->setHorizontalHeaderItem(2, new QStandardItem(QString("Age")));
    modelIsotope->setHorizontalHeaderItem(3, new QStandardItem(QString("d13C")));
    modelIsotope->setHorizontalHeaderItem(4, new QStandardItem(QString("d18O")));
    modelIsotope->setHorizontalHeaderItem(5, new QStandardItem(QString("d13C\nError")));
    modelIsotope->setHorizontalHeaderItem(6, new QStandardItem(QString("d18O\nError")));
    modelIsotope->setHorizontalHeaderItem(7, new QStandardItem(QString("d13C\nCorrected")));
    modelIsotope->setHorizontalHeaderItem(8, new QStandardItem(QString("d18O\nCorrected")));
    modelIsotope->setHorizontalHeaderItem(9, new QStandardItem(QString("Flag")));
    modelIsotope->setHorizontalHeaderItem(10, new QStandardItem(QString("Comment")));

    ui->tableView->setModel(modelIsotope);
    ui->tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
    //qDebug() << "1";
    QStandardItem *iso_Depth = new QStandardItem[inv->get_Length()];
    QStandardItem *iso_Sample_Thickness = new QStandardItem[inv->get_Length()];
    QStandardItem *iso_Age = new QStandardItem[inv->get_Length()];
    QStandardItem *iso_Oxygen = new QStandardItem[inv->get_Length()];
    QStandardItem *iso_Carbon = new QStandardItem[inv->get_Length()];
    QStandardItem *iso_Carbon_Err = new QStandardItem[inv->get_Length()];
    QStandardItem *iso_Oxygen_Err = new QStandardItem[inv->get_Length()];
    QStandardItem *iso_Carbon_Corr = new QStandardItem[inv->get_Length()];
    QStandardItem *iso_Oxygen_Corr = new QStandardItem[inv->get_Length()];
    QStandardItem *iso_Flag = new QStandardItem[inv->get_Length()];
    QStandardItem *iso_Comment = new QStandardItem[inv->get_Length()];

    for (int i=0;i<inv->get_Length();i++){
        iso_Depth[i].setText(QString::number(inv->get_data_Depth(i)));
        modelIsotope->setItem(i,0,&iso_Depth[i]);
        iso_Sample_Thickness[i].setText(QString::number(inv->get_data_Sample_Thickness(i)));
        modelIsotope->setItem(i,1,&iso_Sample_Thickness[i]);
        iso_Age[i].setText(QString::number(inv->get_data_Age(i)));
        modelIsotope->setItem(i,2,&iso_Age[i]);


        iso_Carbon[i].setText(QString::number(inv->get_data_d13C(i)));
        modelIsotope->setItem(i,3,&iso_Carbon[i]);
        iso_Oxygen[i].setText(QString::number(inv->get_data_d18O(i)));
        modelIsotope->setItem(i,4,&iso_Oxygen[i]);

        iso_Carbon_Err[i].setText(QString::number(inv->get_data_d13C_Err(i)));
        modelIsotope->setItem(i,5,&iso_Carbon_Err[i]);
        iso_Oxygen_Err[i].setText(QString::number(inv->get_data_d18O_Err(i)));
        modelIsotope->setItem(i,6,&iso_Oxygen_Err[i]);

        iso_Carbon_Corr[i].setText(QString::number(inv->get_data_d13C_Corr(i)));
        modelIsotope->setItem(i,7,&iso_Carbon_Corr[i]);
        iso_Oxygen_Corr[i].setText(QString::number(inv->get_data_d18O_Corr(i)));
        modelIsotope->setItem(i,8,&iso_Oxygen_Corr[i]);

        iso_Flag[i].setText(QString::number(inv->get_data_Use_Flag(i)));
        modelIsotope->setItem(i,9,&iso_Flag[i]);
        iso_Comment[i].setText(inv->get_data_Comments(i));
        modelIsotope->setItem(i,10,&iso_Comment[i]);
    }
    //qDebug() << "2";
    ui->tableView->setSortingEnabled(0);
    ui->tableView->resizeColumnsToContents();
    ui->tableView->verticalHeader()->setDefaultSectionSize(ui->tableView->verticalHeader()->minimumSectionSize());
    ui->tableView->horizontalHeader()->setStretchLastSection(1);
    ui->tableView->setSelectionMode(QAbstractItemView::NoSelection);
    ui->tableView->setHorizontalScrollMode(ui->tableView->ScrollPerPixel);

    }

    // setup AgeModel
    if (exist_age){
    //qDebug() << "setting up Age Table";
        delete ageData;
    ageData = new QStandardItemModel(amsdata->get_Length(),15,this);
    ageData->setHorizontalHeaderItem(0, new QStandardItem(QString("Index")));
    ageData->setHorizontalHeaderItem(1, new QStandardItem(QString("Depth")));
    ageData->setHorizontalHeaderItem(2, new QStandardItem(QString("Sample\nThickness")));
    ageData->setHorizontalHeaderItem(3, new QStandardItem(QString("Label")));
    ageData->setHorizontalHeaderItem(4, new QStandardItem(QString("Type")));
    ageData->setHorizontalHeaderItem(5, new QStandardItem(QString("Age dated\n[ka]")));
    ageData->setHorizontalHeaderItem(6, new QStandardItem(QString("Age UCL\n[ka+]")));
    ageData->setHorizontalHeaderItem(7, new QStandardItem(QString("Age LCL\n[ka-]")));
    ageData->setHorizontalHeaderItem(8, new QStandardItem(QString("Res. Age\n[ka]")));
    ageData->setHorizontalHeaderItem(9, new QStandardItem(QString("Res. Age Error\n[ka]")));
    ageData->setHorizontalHeaderItem(10, new QStandardItem(QString("Cal yrs\n[wm ka BP]")));
    ageData->setHorizontalHeaderItem(11, new QStandardItem(QString("Cal yrs min\n[95%]")));
    ageData->setHorizontalHeaderItem(12, new QStandardItem(QString("Cal yrs max\n[95%]")));
    ageData->setHorizontalHeaderItem(13, new QStandardItem(QString("Use Flag")));
    ageData->setHorizontalHeaderItem(14, new QStandardItem(QString("Comments")));
    //qDebug() << "1";
    ui->tableView_2->setModel(ageData);
    ui->tableView_2->setEditTriggers(QAbstractItemView::NoEditTriggers);
    QStandardItem *var_Index = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Depth = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Sample_Thickness = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Label = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Type = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Age_dated = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Age_UCL = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Age_LCL = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Age_Res = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Age_Res_Error = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Cal = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Cal_Min = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Cal_Max = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Use_Flag = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Comment = new QStandardItem[amsdata->get_Length()];
    //qDebug()<<"2";
    for (int i=0;i<amsdata->get_Length();i++){
            var_Index[i].setData(i,Qt::EditRole);
            ageData->setItem(i,0,&var_Index[i]);

            var_Depth[i].setText(QString::number(amsdata->get_Depth(i)));
            ageData->setItem(i,1,&var_Depth[i]);

            var_Sample_Thickness[i].setText(QString::number(amsdata->get_Sample_Thickness(i)));
            ageData->setItem(i,2,&var_Sample_Thickness[i]);

            var_Label[i].setText(amsdata->get_LabID(i));
            ageData->setItem(i,3,&var_Label[i]);

            var_Type[i].setText(amsdata->get_Type(i));
            ageData->setItem(i,4,&var_Type[i]);

            var_Age_dated[i].setText(QString::number(amsdata->get_Data(0,i)));
            ageData->setItem(i,5,&var_Age_dated[i]);

            var_Age_UCL[i].setText(QString::number(amsdata->get_Data(1,i)));
            ageData->setItem(i,6,&var_Age_UCL[i]);

            var_Age_LCL[i].setText(QString::number(amsdata->get_Data(2,i)));
            ageData->setItem(i,7,&var_Age_LCL[i]);

            var_Age_Res[i].setText(QString::number(amsdata->get_Data(3,i)));
            ageData->setItem(i,8,&var_Age_Res[i]);

            var_Age_Res_Error[i].setText(QString::number(amsdata->get_Reservoir_Error(i)));
            ageData->setItem(i,9,&var_Age_Res_Error[i]);

            var_Cal[i].setText(QString::number(amsdata->get_Data(4,i)));
            ageData->setItem(i,10,&var_Cal[i]);

            var_Cal_Min[i].setText(QString::number(amsdata->get_Data(5,i)));
            ageData->setItem(i,11,&var_Cal_Min[i]);

            var_Cal_Max[i].setText(QString::number(amsdata->get_Data(6,i)));
            ageData->setItem(i,12,&var_Cal_Max[i]);



            var_Use_Flag[i].setText(QString::number(amsdata->get_Data(7,i)));

            ageData->setItem(i,13,&var_Use_Flag[i]);
            ageData->setData(ageData->index(i, 12), Qt::AlignCenter,Qt::TextAlignmentRole);

            var_Comment[i].setText(amsdata->get_Age_Comment(i));
            ageData->setItem(i,14,&var_Comment[i]);

    }
    //qDebug()<<"3";
    ui->tableView_2->setSortingEnabled(0);
    ui->tableView_2->horizontalHeader()->setSortIndicator(0,Qt::AscendingOrder);
    ui->tableView_2->verticalHeader()->setDefaultSectionSize(ui->tableView_2->verticalHeader()->minimumSectionSize());
    ui->tableView_2->resizeColumnsToContents();
    ui->tableView_2->setHorizontalScrollMode(ui->tableView_2->ScrollPerPixel);
    ui->tableView_2->setSelectionMode(QAbstractItemView::NoSelection);
    ui->tableView_2->horizontalHeader()->setStretchLastSection(1);
    }
    //qDebug() << "Tables finished";
}

void Import::save(){
    QString QFilename=ui->lineEdit_2->text();
    if (QFilename=="") QFilename=inv->get_att_Core()+".nc";
    QFilename.replace("\\","/");
    QStringList QPath=QFilename.split("/");
    QFilename=QPath.at(QPath.size()-1);
    QFilename.replace(QString(".txt"),QString(".nc"));
    QFilename.replace(QString(".xlsx"),QString(".nc"));

    int save=save_OK;
    int exist=0;
    // Check if Entry already exists
    int count=-1;
    if (inv2->get_Entries()>0){
    for (int i=0;i<inv2->get_Entries();i++){

        QString str1=inv->get_att_Core().replace('\0',' ');
        QString str2=inv2->get_Core(i).replace('\0',' ');
        QString str3=inv->get_att_Species().replace('\0',' ');
        QString str4=inv2->get_Species(i).replace('\0',' ');
        if (str1.simplified()==str2.simplified() && str3.simplified()==str4.simplified()){
            count=i;
            exist=1;
            break;
        }
    }

    // Give out a warning
    if (count>-1 && save==1) {
        QMessageBox msgBox;
        msgBox.setText("This core and proxy already exists.");
        msgBox.setInformativeText("Do you want to save anyway?");
        msgBox.setStandardButtons(QMessageBox::Save | QMessageBox::Discard);
        msgBox.setDefaultButton(QMessageBox::Save);
        int ret = msgBox.exec();
        if (ret==QMessageBox::Discard){
            save=0;
        } else {
        // Correct Inventory entry count
            inv2->set_currentCore(count);
            // enter information into last inventory
            inv2->set_Core(inv->get_att_Core());
            inv2->set_Species(inv->get_att_Species());
            inv2->set_Longitude(inv->get_att_Longitude());
            inv2->set_Latitude(inv->get_att_Latitude());
            inv2->set_Water_Depth(inv->get_att_Water_Depth());
            inv2->set_Basin(0);
            inv2->set_O_Use_Flag(inv->get_att_Oxygen_Use_Flag());
            inv2->set_C_Use_Flag(inv->get_att_Carbon_Use_Flag());
            inv2->set_Record_Type(inv->get_att_Record_Type());
            inv2->set_Selected(inv2->get_currentCore(),1);
            inv2->set_Filename(QFilename);
            if (exist_age==1){
                amsdata->set_Inventory(inv2);
                amsdata->AMSSave();
                inv2->set_AgeModel(inv2->get_currentCore(),1);
            } else {
                inv2->set_AgeModel(inv2->get_currentCore(),0);
            }
        }
    }

    // Check if Filename is already in Library
    count=-1;

    for (int i=0;i<inv2->get_Entries();i++){


        QString str1=inv2->get_Filename(i).replace('\0',' ');

        if (QFilename.simplified()==str1.simplified()){
            count=i;
            exist=1;
            break;
        }
    }
    // Give out a warning
    if (count>-1 && save==1) {
        QMessageBox msgBox;
        msgBox.setText("This data was already put into the database.");
        msgBox.setInformativeText("Do you want to replace it?");
        msgBox.setStandardButtons(QMessageBox::Save | QMessageBox::Discard);
        msgBox.setDefaultButton(QMessageBox::Save);
        int ret = msgBox.exec();
        if (ret==QMessageBox::Discard){
            save=0;
        } else {
            // Correct Inventory entry count
            inv2->set_currentCore(count);
            // enter information into last inventory
            inv2->set_Core(inv->get_att_Core());
            inv2->set_Species(inv->get_att_Species());
            inv2->set_Longitude(inv->get_att_Longitude());
            inv2->set_Latitude(inv->get_att_Latitude());
            inv2->set_Water_Depth(inv->get_att_Water_Depth());
            inv2->set_Basin(0);
            inv2->set_O_Use_Flag(inv->get_att_Oxygen_Use_Flag());
            inv2->set_C_Use_Flag(inv->get_att_Carbon_Use_Flag());
            inv2->set_Record_Type(inv->get_att_Record_Type());
            inv2->set_Selected(inv2->get_currentCore(),1);
            inv2->set_Filename(QFilename);

            if (exist_age==1){
                amsdata->set_Inventory(inv2);
                amsdata->AMSSave();
                inv2->set_AgeModel(inv2->get_currentCore(),1);
            } else {
                inv2->set_AgeModel(inv2->get_currentCore(),0);
            }
        }
    }

    }

    // save to library
    if (save_OK==1 && save==1){
        // save Data



        inv->saveData(QFilename);


        if (exist==0){
            // new Entry
            inv2->addEntry();
            inv2->set_currentCore(inv2->get_Entries()-1);
            // enter information into last inventory
            inv2->set_Core(inv->get_att_Core());
            inv2->set_Species(inv->get_att_Species());
            inv2->set_Longitude(inv->get_att_Longitude());
            inv2->set_Latitude(inv->get_att_Latitude());
            inv2->set_Water_Depth(inv->get_att_Water_Depth());
            inv2->set_Basin(inv2->get_Basin(inv->get_att_Longitude(),inv->get_att_Latitude()));
            inv2->set_O_Use_Flag(inv->get_att_Oxygen_Use_Flag());
            inv2->set_C_Use_Flag(inv->get_att_Carbon_Use_Flag());
            inv2->set_Record_Type(inv->get_att_Record_Type());
            inv2->set_Selected(inv2->get_currentCore(),1);
            inv2->set_Filename(QFilename);

            if (exist_age==1){
                amsdata->set_Inventory(inv2);
                amsdata->AMSSave();
                inv2->set_AgeModel(inv2->get_currentCore(),1);
            } else {
                inv2->set_AgeModel(inv2->get_currentCore(),0);
            }
        }



        emit(refresh());
        close();
    }

}

bool Import::eventFilter(QObject *obj, QEvent *event)
{
    if (event->type() == QEvent::KeyPress)
    {
        if (obj==ui->tableView_2||obj==ui->tableView||obj==ui->tableView_3||obj==ui->plainTextEdit){
            QKeyEvent *keyEvent = static_cast<QKeyEvent *>(event);
            if (keyEvent->key()==Qt::Key_F1){
                ui->splitter->restoreState(sp);
                ui->splitter_2->restoreState(sp_2);
                ui->splitter_3->restoreState(sp_3);
                return true;
            }
        }
    }
    return QObject::eventFilter(obj, event);
}

