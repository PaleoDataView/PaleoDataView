#ifndef IMPORTALL_H
#define IMPORTALL_H

#include <QDialog>
#include <QStandardItemModel>
#include "General/inventory.h"
#include <QDebug>
#include <QMainWindow>
#include "AMS/amsdata.h"
#include <QFileDialog>
#include "General/resources.h"
#include <QDesktopServices>
#include "QtXlsx/src/xlsx/xlsxdocument.h"
#include <QMessageBox>
#include <QApplication>
using namespace QXlsx;

namespace Ui {
class ImportAll;
}

class ImportAll : public QDialog
{
    Q_OBJECT

public:
    explicit ImportAll(QMainWindow *mainWindow,Inventory *inventory);
    ~ImportAll();

private slots:
    void browse();
    void start();
signals:
    void refresh();
private:



    Ui::ImportAll *ui;
    Resources resources;
    Inventory *inv;
    Inventory *inv2;
    AMSData *amsdata;
    QString txt;
    QMainWindow *mainW;

    QString *str1;
    QString *str2;
    QString dlm;

    QStandardItemModel *metaData;
    QStandardItemModel *modelIsotope;
    QStandardItemModel *ageData;
    int meta_length;
    int exist_meta;
    int exist_iso;
    int exist_age;
    int save_OK;

    QFileInfoList list;
};

#endif // IMPORTALL_H
