#include "showbacon.h"
#include "ui_showbacon.h"

ShowBacon::ShowBacon(QWidget *parent,float* out,int ncol,int nrow,float min,float by,float max,int k) :
    QDialog(parent),
    ui(new Ui::ShowBacon)
{
    ui->setupUi(this);
    out_Data=out;
    out_ncol=ncol;
    out_nrow=nrow;
    dmin=min;
    dby=by;
    dmax=max;
    K=k;
    outData = new QStandardItemModel(0,0,this);

}

ShowBacon::~ShowBacon()
{
    delete ui;
    delete outData;
}

void ShowBacon::setupOut(){

    delete outData;
    outData = new QStandardItemModel(out_nrow,out_ncol,this);
    outData->setHorizontalHeaderItem(0, new QStandardItem(QString("Starting Age")));
    for (int i=0;i<out_ncol-3;i++) {
        float d1=dmin+i*((dmax-dmin)/K);
        float d2=dmin+(i+1)*((dmax-dmin)/K);
        outData->setHorizontalHeaderItem(1+i, new QStandardItem(QString("Acc(d="+QString::number(d1)+"-"+QString::number(d2)+"cm)")));
    }
    outData->setHorizontalHeaderItem(out_ncol-2, new QStandardItem(QString("Memory")));
    outData->setHorizontalHeaderItem(out_ncol-1, new QStandardItem(QString("Iteration")));



    ui->tableView->setModel(outData);
    ui->tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
    int nrow=out_nrow;



    QStandardItem *var_Age = new QStandardItem[nrow];
    QStandardItem *var_Acc = new QStandardItem[nrow*out_ncol-3];
    QStandardItem *var_Mem = new QStandardItem[nrow];
    QStandardItem *var_It = new QStandardItem[nrow];



    for (int i=0;i<nrow;i++){
            var_Age[i].setData(out_Data[0*(nrow)+i]/1000.0,Qt::EditRole);
            outData->setItem(i,0,&var_Age[i]);
            for (int j=1;j<out_ncol-2;j++){
                var_Acc[(j-1)*nrow+i].setData(out_Data[i+j*nrow],Qt::EditRole);
                outData->setItem(i,j,&var_Acc[(j-1)*nrow+i]);
            }
            var_Mem[i].setData(out_Data[i+(out_ncol-2)*nrow],Qt::EditRole);
            outData->setItem(i,out_ncol-2,&var_Mem[i]);

            var_It[i].setData(out_Data[i+(out_ncol-1)*nrow],Qt::EditRole);
            outData->setItem(i,out_ncol-1,&var_It[i]);
    }
    ui->tableView->setSortingEnabled(0);

    ui->tableView->horizontalHeader()->setSortIndicator(0,Qt::AscendingOrder);
    ui->tableView->verticalHeader()->setDefaultSectionSize(ui->tableView->verticalHeader()->minimumSectionSize());
    ui->tableView->resizeColumnsToContents();
    ui->tableView->setHorizontalScrollMode(ui->tableView->ScrollPerPixel);
    ui->tableView->setSelectionMode(QAbstractItemView::NoSelection);

}
