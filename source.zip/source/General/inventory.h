/********************************************************************************/
/*    This file is part of PaleoDataViewer.                       					*/
/*                                                                      		*/
/*    PaleoDataViewer is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoDataViewer is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoDataViewer.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#ifndef INVENTORY_H
#define INVENTORY_H

#include <stdlib.h>
#include <QDebug.h>
#include "netCDF/include/netcdf.h"
#include <QString>
#include <stdlib.h>
#include "General/resources.h"
#include <QDir>

#include <string.h>

using namespace std;

#define ERR(e) {qDebug("Error: '%s' : %i\n", nc_strerror(e)),e; exit(1);}


class Inventory
{

public:
    explicit Inventory();
    ~Inventory();

public:
    // ******* Inventory
    void read();
    void save();
    void generate();
    void addEntry();
    void deleteEntry(int n);
    void noData();

    //******** Inventory Data
    QString get_Core(int n);
    void set_Core(QString str);

    double get_Latitude(int n);
    void set_Latitude(double v);

    double get_Longitude(int n);
    void set_Longitude(double v);

    QString get_Filename(int n);
    void set_Filename(QString str);

    QString get_Species(int n);
    void set_Species(QString str);

    double get_Basin(int n);
    void set_Basin(int b);

    double get_Water_Depth(int n);
    void set_Water_Depth(double v);

    double get_Oxygen_Use_Flag(int n);
    void invert_O_Flag(int n);
    void set_O_Use_Flag(int n);

    double get_Carbon_Use_Flag(int n);
    void invert_C_Flag(int n);
    void set_C_Use_Flag(int n);

    QString get_Record_Type(int n);
    void set_Record_Type(QString str);

    int get_AgeModel(int n);
    void set_AgeModel(int n,int i);
    //********** Iventory Meta
    unsigned int get_Entries();
    unsigned int get_Selected(int n);
    unsigned int get_Selected_Sum();
    void invert_Selected(int n);
    void set_Selected(int n,int m);

    //********** Data
    void readData(int n);
    void readData(QString Filename);
    void saveData();
    void saveData(QString filename);
    int get_currentCore();
    void set_currentCore(QString name,QString proxy);
    void set_currentCore(int i);
    void newIsotope(int isolength);
    void newIsotopeMeta();
    void addIsotope();

    //********** Data attributes
    double get_data_Isotopes(int i,int j);
    void set_data_Isotopes(int i,int j,double v);
    QString get_data_Comments(int j);

    double get_data_Depth(int i);
    double get_data_Sample_Thickness(int i);
    double get_data_Age(int i);
    double get_data_d13C(int i);
    double get_data_d18O(int i);
    double get_data_d13C_Corr(int i);
    double get_data_d18O_Corr(int i);
    double get_data_d13C_Err(int i);
    double get_data_d18O_Err(int i);
    int get_data_Use_Flag(int i);
    QString get_data_Comment(int i);

    void set_data_Depth(double v,int i);
    void set_data_Sample_Thickness(double v,int i);
    void set_data_Age(double v,int i);
    void set_data_d13C(double v,int i);
    void set_data_d18O(double v,int i);
    void set_data_d13C_Corr(double v,int i);
    void set_data_d18O_Corr(double v,int i);
    void set_data_d13C_Err(double v,int i);
    void set_data_d18O_Err(double v,int i);
    void set_data_Use_Flag(int v,int i);
    void set_data_Comment(QString str,int i);

    double get_Int_Value_18O(double depth,QString str);

    QString get_att_Core();
    void set_att_Core(QString str);

    double get_att_Latitude();
    void set_att_Latitude(double v);

    double get_att_Longitude();
    void set_att_Longitude(double v);

    QString get_att_Device();
    void set_att_Device(QString str);

    double get_att_Water_Depth();
    void set_att_Water_Depth(double v);

    QString get_att_Species();
    void set_att_Species(QString str);

    QString get_att_Laboratory();
    void set_att_Laboratory(QString str);

    QString get_att_Reference();
    void set_att_Reference(QString str);

    QString get_att_Comment();
    void set_att_Comment(QString str);

    QString get_att_EPaper();
    void set_att_EPaper(QString s);

    double get_att_Oxygen_Use_Flag();
    void set_att_O_Use_Flag(int n);

    double get_att_Carbon_Use_Flag();
    void set_att_C_Use_Flag(int n);

    double get_att_O_Correction();
    void set_att_O_Correction(double v);

    QString get_att_O_Justification();
    void set_att_O_Justification(QString str);

    double get_att_C_Correction();
    void set_att_C_Correction(double v);

    QString get_att_C_Justification();
    void set_att_C_Justification(QString str);

    QString get_att_Data_Source();
    void set_att_Data_Source(QString str);

    QString get_att_Record_Type();
    void set_att_Record_Type(QString str);

    QString get_att_Importer();
    void set_att_Importer(QString str);

    QString get_att_Optional();
    void set_att_Optiona(QString str);

    QString get_att_Category();
    void set_att_Category(QString str);


    // ******** Data Meta
    unsigned int get_Length();
    int get_flag_Data_OK();
    void set_flag_Data_OK(int n);
    //void set_data_Comment(QString str,int j);
/*
    // ********* Age Model
    void new_Age_Model();
    void read_Age_Model();
    void save_Age_Model();
    void add_Point(double depth,double age);
    void remove_Point(int n);
    double get_Point_Depth(int n);
    double get_Point_Age(int n);
    int get_Age_Model_Size();
    double get_Int_Value_Age(double depth,QString str);
    double get_Int_Value_Depth(double age,QString str);
    void apply_Age_Model(QString str);
*/
    // ********* TargetDaten
    void readTarget();
    int get_Target_Length(int i);
    double get_Target_Age(int n,int i);
    double get_Target_Value(int n,int i);
    double get_Target_Error(int n,int i);
    double get_Target_Age_Error(int n,int i);
    int get_Target_Vari();
    QString get_Target_Name(int i);
    // ******** Basin
    void read_Basin();
    int get_Basin(float lon, float lat);
    QString get_Basinname(float lon,float lat);
    QString get_Basinname(int i);

private:
    // Inventory data
    QString* var_Core;
    double* var_Latitude;
    double* var_Longitude;
    QString* var_Filename;
    QString* var_Species;
    double* var_Basin;
    double* var_Water_Depth;
    double* var_Oxygen_Use_Flag;
    double* var_Carbon_Use_Flag;
    QString* var_Record_Type;
    unsigned int entries=0;
    unsigned int* selected;
    int *var_AgeModel;
    int current_Core;





    // Core Data

    unsigned int length=0; // Length of Data Variable
    // no use
    double* data_Isotopes;
    int data_Isotopes_row=0;
    int data_Isotopes_col=0;
    QString* data_Comments;

    // DATA VARIABLES
    std::vector<double> data_Depth;
    std::vector<double> data_Sample_Thickness;
    std::vector<double> data_Age;
    std::vector<double> data_d13C;
    std::vector<double> data_d18O;
    std::vector<double> data_d13C_Corr;
    std::vector<double> data_d18O_Corr;
    std::vector<double> data_d13C_Err;
    std::vector<double> data_d18O_Err;
    std::vector<int> data_Use_Flag;
    std::vector<QString*> data_Comment;

    // ATTRIBUTES
    // Mandatory
    QString     att_Core="No Core Selected";
    double      att_Latitude=0;
    double      att_Longitude=0;
    double      att_Water_Depth=0;
    QString     att_Species="na";
    QString     att_Record_Type="na";
    // Proxy specific
    QString     att_Device="na";
    QString     att_Laboratory="na";
    QString     att_Instrumentation="na";
    QString     att_Data_Source="na";
    QString     att_Comment="na";
    QString     att_Category="na";
    QString     att_Reference="na";
    QString     att_Importer="na";
    // Optional/Proxy specific
    QString     att_EPaper="na";
    double      att_Oxygen_Use_Flag=0;
    double      att_Carbon_Use_Flag=0;
    double      att_O_Correction=0;
    QString     att_O_Justification="na";
    double      att_C_Correction=0;
    QString     att_C_Justification="na";
    // Dump/User specified
    QString     att_Optional="";// dump of all additional parameters


    int         flag_Data_OK=0;
/*
    // ********* Age Model Data
    double* age_Model_Depth;
    double* age_Model_Age;
    unsigned int age_Model_Length;
*/
    // ********* Target Data
    QStringList header;
    QList<QList<double> > target;





    double* target_Govin;
    unsigned int length_Govin;
    double* target_LH4;
    unsigned int length_LH4;
    Resources resources;

    // ********* Basin
    double* basin_data;
    int basin_lon;
    int basin_lat;
};

#endif // INVENTORY_H
