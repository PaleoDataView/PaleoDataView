/********************************************************************************/
/*    This file is part of PaleoDataViewer.                       					*/
/*                                                                      		*/
/*    PaleoDataViewer is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoDataViewer is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoDataViewer.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#include "resources.h"

Resources::Resources()
{
    // create defaults
    workdir="Default";
    path_PaleoDataViewer=QDir::homePath()+"/Documents/PaleoDataViewer";
    filename_global=path_PaleoDataViewer+"/Resources/Map/Global_map_2.jpg";
    filename_ATL=path_PaleoDataViewer+"/Resources/Map/Atlantic.jpg";
    filename_PAC=path_PaleoDataViewer+"/Resources/Map/Pacific.jpg";
    filename_IND=path_PaleoDataViewer+"/Resources/Map/Indic.jpg";
    filename_MED=path_PaleoDataViewer+"/Resources/Map/Med.jpg";
    // Application Database
    filename_inventory=path_PaleoDataViewer+"/"+workdir+"/inventory.nc";
    path_data=path_PaleoDataViewer+"/"+workdir+"/Isotopes/";
    path_target=path_PaleoDataViewer+"/Resources/Calibration/";
    path_age=path_PaleoDataViewer+"/"+workdir+"/Age/";
    path_hydro=path_PaleoDataViewer+"/Resources/Hydro/";
    filename_C14_Cal=path_PaleoDataViewer+"/Resorces/Calibration/IntCal13.14c";
    path_Bacon=path_PaleoDataViewer+"/Resources/Bacon";

    // Read Pathdata from File
    QString txt;
    QFile file(QDir::homePath()+"/Documents/PaleoDataViewer/PaleoDataViewer_Config.txt");
    if(!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        /*QMessageBox msgBox;
        msgBox.setText("Warning no PaleoDataViewer_Config found.");
        msgBox.setInformativeText("This is probably your first time running PaleoDataViewer.\nA config-file will be generated after defining a working directory.\nThe standard directory was created during installation in\n..\\documents\\PaleoDataViewer\n");
        msgBox.setIcon(QMessageBox::Warning);

        msgBox.exec();*/
        save();
    } else {
        txt.clear();
        QTextStream in(&file);
        while(!in.atEnd()) {
            txt.append(in.readLine().toLocal8Bit()+"\n");
        }
        file.close();
    }
    //qDebug()<< txt;
    // Assign QString Variables
    QStringList lines = txt.split("\n");
    for (int i=0;i<lines.size();i++){
        QStringList fields=lines.at(i).split("=");
        if (fields.at(0)=="path_PaleoDataViewer"){
            path_PaleoDataViewer=fields.at(1);
            // apply to all paths/files
            filename_global=path_PaleoDataViewer+"/Resources/Map/Global_map_2.jpg";
            filename_ATL=path_PaleoDataViewer+"/Resources/Map/Atlantic.jpg";
            filename_PAC=path_PaleoDataViewer+"/Resources/Map/Pacific.jpg";
            filename_IND=path_PaleoDataViewer+"/Resources/Map/Indic.jpg";
            filename_MED=path_PaleoDataViewer+"/Resources/Map/Med.jpg";
            // Application Database
            filename_inventory=path_PaleoDataViewer+"/"+workdir+"/inventory.nc";
            path_data=path_PaleoDataViewer+"/"+workdir+"/Isotopes/";
            path_target=path_PaleoDataViewer+"/Resources/Calibration/";
            path_age=path_PaleoDataViewer+"/"+workdir+"/Age/";
            path_hydro=path_PaleoDataViewer+"/Resources/Hydro/";
            filename_C14_Cal=path_PaleoDataViewer+"/Resources/Calibration/IntCal13.14c";
            path_Bacon=path_PaleoDataViewer+"/Resources/Bacon";
        }
        if (fields.at(0)=="filename_global"){
            filename_global=fields.at(1);
        }
        if (fields.at(0)=="filename_ATL"){
            filename_ATL=fields.at(1);
        }
        if (fields.at(0)=="filename_PAC"){
            filename_PAC=fields.at(1);
        }
        if (fields.at(0)=="filename_IND"){
            filename_IND=fields.at(1);
        }
        if (fields.at(0)=="filename_MED"){
            filename_MED=fields.at(1);
        }
        if (fields.at(0)=="filename_inventory"){
            filename_inventory=fields.at(1);
        }
        if (fields.at(0)=="path_data"){
            path_data=fields.at(1);
        }
        if (fields.at(0)=="path_target"){
            path_target=fields.at(1);
        }
        if (fields.at(0)=="path_age"){
            path_age=fields.at(1);
        }
        if (fields.at(0)=="path_hydro"){
            path_hydro=fields.at(1);
        }
        if (fields.at(0)=="filename_C14_Cal"){
            filename_C14_Cal=fields.at(1);
        }
        if (fields.at(0)=="filename_Bacon"){
            path_Bacon=fields.at(1);
        }
        if (fields.at(0)=="workdir"){
            workdir=fields.at(1);
            filename_inventory=path_PaleoDataViewer+"/"+workdir+"/inventory.nc";
            path_data=path_PaleoDataViewer+"/"+workdir+"/Isotopes/";
            path_age=path_PaleoDataViewer+"/"+workdir+"/Age/";
        }

    }
}

QString Resources::get_path_PaleoDataViewer(){
    return path_PaleoDataViewer;
}
QString Resources::get_filename_global(){
    return filename_global;
}
QString Resources::get_filename_ATL(){
    return filename_ATL;
}
QString Resources::get_filename_PAC(){
    return filename_PAC;
}
QString Resources::get_filename_IND(){
    return filename_IND;
}
QString Resources::get_filename_MED(){
    return filename_MED;
}
QString Resources::get_filename_inventory(){
    return filename_inventory;
}
QString Resources::get_path_data(){
    return path_data;
}
QString Resources::get_path_target(){
    return path_target;
}
QString Resources::get_path_age(){
    return path_age;
}
QString Resources::get_filename_C14_Cal(){
    return filename_C14_Cal;
}
QString Resources::get_path_hydro(){
    return path_hydro;
}
QString Resources::get_path_bacon(){
    qDebug()<<path_Bacon;
    return path_Bacon;
}

QString Resources::get_workdir(){
    return workdir;
}

void Resources::set_filename_global(QString str){
    filename_global=str;
}

void Resources::set_filename_ATL(QString str){
    filename_ATL=str;
}

void Resources::set_filename_PAC(QString str){
    filename_PAC=str;
}

void Resources::set_filename_IND(QString str){
    filename_IND=str;
}

void Resources::set_filename_MED(QString str){
    filename_MED=str;
}

void Resources::set_filename_inventory(QString str){
    filename_inventory=str;
}

void Resources::set_path_data(QString str){
    path_data=str;
}

void Resources::set_path_age(QString str){
    path_age=str;
}

void Resources::set_path_target(QString str){
    path_target=str;
}

void Resources::set_filename_C14_Cal(QString str){
    filename_C14_Cal=str;
}

void Resources::set_path_hydro(QString str){
    path_hydro=str;
}

void Resources::set_workdir(QString str){
    workdir=str;
}

void Resources::set_path_PaleoDataViewer(QString str){
    path_PaleoDataViewer=str;
    // apply to all paths/files
    filename_global=path_PaleoDataViewer+"/Resources/Map/Global_map_2.jpg";
    filename_ATL=path_PaleoDataViewer+"/Resources/Map/Atlantic.jpg";
    filename_PAC=path_PaleoDataViewer+"/Resources/Map/Pacific.jpg";
    filename_IND=path_PaleoDataViewer+"/Resources/Map/Indic.jpg";
    filename_MED=path_PaleoDataViewer+"/Resources/Map/Med.jpg";
    // Application Database
    filename_inventory=path_PaleoDataViewer+"/"+workdir+"/inventory.nc";
    path_data=path_PaleoDataViewer+"/"+workdir+"/Isotopes/";
    path_target=path_PaleoDataViewer+"/Resources/Calibration/";
    path_age=path_PaleoDataViewer+"/"+workdir+"/Age/";
    path_hydro=path_PaleoDataViewer+"/Resources/Hydro/";
    filename_C14_Cal=path_PaleoDataViewer+"/Resources/Calibration/IntCal13.14c";
    path_Bacon=path_PaleoDataViewer+"/Resources/Bacon";
}

void Resources::set_path_bacon(QString str){
    path_Bacon=str;
}

void Resources::save(){
    QString txt="path_PaleoDataViewer="+path_PaleoDataViewer+"\n";
    txt.append("workdir="+workdir+"\n");

    QFile f(QDir::homePath()+"/Documents/PaleoDataViewer/PaleoDataViewer_Config.txt");

    if(!f.open(QIODevice::WriteOnly | QIODevice::Text)) {
        //qDebug() <<  f.errorString();
    } else {

    QTextStream out(&f);
    out<<txt;
    f.close();


    }

}
