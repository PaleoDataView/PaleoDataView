/********************************************************************************/
/*    This file is part of PaleoDataViewer.                       					*/
/*                                                                      		*/
/*    PaleoDataViewer is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoDataViewer is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoDataViewer.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#include "inventory.h"

Inventory::Inventory(){
    entries=0;
    length=0;
    current_Core=-1;
    //age_Model_Length=0;
    var_Core=new QString [entries];
    var_Latitude=new double [entries];
    var_Longitude=new double [entries];
    var_Filename=new QString [entries];
    var_Species=new QString [entries];
    var_Basin=new double [entries];
    var_Water_Depth=new double [entries];
    var_Oxygen_Use_Flag=new double [entries];
    var_Carbon_Use_Flag=new double [entries];
    var_Record_Type=new QString [entries];
    selected=new unsigned int[entries];
    var_AgeModel=new int [entries];
    data_Comment.reserve(1);
    data_Comment[0]=new QString();
    data_Comment[0]->append("");


}

Inventory::~Inventory(){
    delete[] var_Core;
    delete[] var_Latitude;
    delete[] var_Longitude;
    delete[] var_Filename;
    delete[] var_Species;
    delete[] var_Basin;
    delete[] var_Water_Depth;
    delete[] var_Oxygen_Use_Flag;
    delete[] var_Carbon_Use_Flag;
    delete[] var_Record_Type;
    delete[] selected;

    delete[] var_AgeModel;
    for (int i=0;i<data_Comment.size();i++) delete data_Comment[i];

    delete[] data_Isotopes;


    delete[] target_Govin;
    delete[] target_LH4;
}

void Inventory::noData(){
    current_Core=-1;
    flag_Data_OK=0;
}

// **************** Inventory
void Inventory::read(){
    QString QFilename=resources.filename_inventory;
    char* filename;
    string fname=QFilename.toStdString();
    filename=new char[fname.size()+1];
    strcpy(filename,fname.c_str());
    //qDebug() << "Inventory : "+QFilename;
    // Initialize ids and meta
    int ncid;
    int varid[10];
    int dimid[4]={0};
    size_t dimlen[4]={0};

    int retval;// for Errors

    // Open the file
    if (!(retval = nc_open(filename, NC_NOWRITE, &ncid))){


    // get info forunsigned character variables
    if ((retval = nc_inq_dimid(ncid, "cname", &dimid[0])))
       ERR(retval);
    if ((retval = nc_inq_dimlen(ncid, dimid[0], &dimlen[0])))
       ERR(retval);
    if ((retval = nc_inq_dimid(ncid, "iname", &dimid[1])))
       ERR(retval);
    if ((retval = nc_inq_dimlen(ncid, dimid[1], &dimlen[1])))
       ERR(retval);
    if ((retval = nc_inq_dimid(ncid, "sname", &dimid[2])))
       ERR(retval);
    if ((retval = nc_inq_dimlen(ncid, dimid[2], &dimlen[2])))
       ERR(retval);
    if ((retval = nc_inq_dimid(ncid, "typeid", &dimid[3])))
       ERR(retval);
    if ((retval = nc_inq_dimlen(ncid, dimid[3], &dimlen[3])))
       ERR(retval);
    //qDebug() << "length of Core "+QString::number( dimlen[0]);
    //qDebug() << "length of Filename "+QString::number(dimlen[1]);
    //qDebug() << "length of Species "+QString::number(dimlen[2]);
    //qDebug() << "length of Type "+QString::number(dimlen[3]);


    // get varid for each variable
    if ((retval = nc_inq_varid(ncid, "Core", &varid[0])))
       ERR(retval);
    if ((retval = nc_inq_varid(ncid, "Latitude", &varid[1])))
       ERR(retval);
    if ((retval = nc_inq_varid(ncid, "Longitude", &varid[2])))
       ERR(retval);
    if ((retval = nc_inq_varid(ncid, "Filename", &varid[3])))
       ERR(retval);
    if ((retval = nc_inq_varid(ncid, "Species", &varid[4])))
       ERR(retval);
    if ((retval = nc_inq_varid(ncid, "Basin", &varid[5])))
       ERR(retval);
    if ((retval = nc_inq_varid(ncid, "Water Depth", &varid[6])))
       ERR(retval);
    if ((retval = nc_inq_varid(ncid, "Oxygen Use Flag", &varid[7])))
       ERR(retval);
    if ((retval = nc_inq_varid(ncid, "Carbon Use Flag", &varid[8])))
       ERR(retval);
    if ((retval = nc_inq_varid(ncid, "Record Type", &varid[9])))
       ERR(retval);
    //qDebug() << "def finished";
    // Get number of entires
    entries=0;
    nc_inq_dimlen(ncid,varid[0],&entries);
    //qDebug() << "entries "+QString::number( entries);



    /* start reading ....*/
    // read var_Core
   unsigned char text[(dimlen[0])*entries];
    if ((retval = nc_get_var(ncid,varid[0],&text[0]))) ERR(retval);

    var_Core=new QString [entries];

    for (unsigned int i=0;i<entries;i++){
        for (unsigned int j=0;j<dimlen[0];j++){
            var_Core[i].append(text[i+entries*j]);
        }
    }

    // read var_Latitude
    var_Latitude=new double [entries];
    if ((retval = nc_get_var_double(ncid,varid[1],&var_Latitude[0]))) ERR(retval);

    // read var_Longitude
    var_Longitude=new double [entries];
    if ((retval = nc_get_var_double(ncid,varid[2],&var_Longitude[0]))) ERR(retval);

    // read var_Filename
   unsigned char text1[(dimlen[1])*entries];
    if ((retval = nc_get_var(ncid,varid[3],&text1[0]))) ERR(retval);

    var_Filename=new QString [entries];

    for (unsigned int i=0;i<entries;i++){
        for (unsigned int j=0;j<dimlen[1];j++){
            var_Filename[i].append(text1[i+entries*j]);
        }
        var_Filename[i].truncate(var_Filename[i].indexOf(".nc")+3);
        //qDebug() << var_Filename[i];
    }
    // cut spaces


    // read var_Species
   unsigned char text2[(dimlen[2])*entries];
    if ((retval = nc_get_var(ncid,varid[4],&text2[0]))) ERR(retval);

    var_Species=new QString [entries];

    for (unsigned int i=0;i<entries;i++){
        for (unsigned int j=0;j<dimlen[2];j++){
            var_Species[i].append(text2[i+entries*j]);
        }
    }

    // read var_Basin
    var_Basin=new double [entries];
    if ((retval = nc_get_var_double(ncid,varid[5],&var_Basin[0]))) ERR(retval);

    // read var_Water_Depth
    var_Water_Depth=new double [entries];
    if ((retval = nc_get_var_double(ncid,varid[6],&var_Water_Depth[0]))) ERR(retval);

    // read var_Oxygen_Use_Flag
    var_Oxygen_Use_Flag=new double [entries];
    if ((retval = nc_get_var_double(ncid,varid[7],&var_Oxygen_Use_Flag[0]))) ERR(retval);

    // read var_Carbon_Use_Flag
    var_Carbon_Use_Flag=new double [entries];
    if ((retval = nc_get_var_double(ncid,varid[8],&var_Carbon_Use_Flag[0]))) ERR(retval);

    // read var_Record_Type
   unsigned char text3[(dimlen[3])*entries];
    if ((retval = nc_get_var(ncid,varid[9],&text3[0]))) ERR(retval);

    var_Record_Type=new QString [entries];

    for (unsigned int i=0;i<entries;i++){
        for (unsigned int j=0;j<dimlen[3];j++){
            var_Record_Type[i].append(text3[i+entries*j]);
        }
    }

    // create selected-Flag
    selected=new unsigned int[entries];
    for (unsigned int i=0;i<entries;i++) selected[i]=0;

    /* Close the file, freeing all resources. */
    if ((retval = nc_close(ncid)))
       ERR(retval);
    } else {

        if (nc_strerror(retval)=="No such file or directory") {
            //qDebug() << "Start generating ...";
            entries=0;
            var_Core=new QString [entries];
            var_Latitude=new double [entries];
            var_Longitude=new double [entries];
            var_Filename=new QString [entries];
            var_Species=new QString [entries];
            var_Basin=new double [entries];
            var_Water_Depth=new double [entries];
            var_Oxygen_Use_Flag=new double [entries];
            var_Carbon_Use_Flag=new double [entries];
            var_Record_Type=new QString [entries];
            selected=new unsigned int[entries];

        } else {
            //qDebug() << "Start generating ...";
            entries=0;
            var_Core=new QString [entries];
            var_Latitude=new double [entries];
            var_Longitude=new double [entries];
            var_Filename=new QString [entries];
            var_Species=new QString [entries];
            var_Basin=new double [entries];
            var_Water_Depth=new double [entries];
            var_Oxygen_Use_Flag=new double [entries];
            var_Carbon_Use_Flag=new double [entries];
            var_Record_Type=new QString [entries];
            selected=new unsigned int[entries];

           // ERR(retval);
        }
    }
    // Check if AgeModel available
    var_AgeModel=new int [entries];
    for (int i=0;i<entries;i++){
        // get file name of age file
        QString name=get_Core(i).replace('\0',' ');
        name.simplified();
        QFilename.clear();
        QFilename=resources.path_age+name+".age";



        fname=QFilename.toStdString();
        delete[] filename;

        char *filename=new char[fname.size()+1];
        strcpy(filename,fname.c_str());
        //qDebug() << name;
        // Open the file
        if (!(retval = nc_open(filename, NC_NOWRITE, &ncid))){

            var_AgeModel[i]=1;
            // Close the file, freeing all resources.
            if ((retval = nc_close(ncid)))
               ERR(retval);
        } else {
            var_AgeModel[i]=0;
            //qDebug()<<"Not found";
            if (nc_strerror(retval)=="No such file or directory") {
                //qDebug() << "Age model not found...";
            } else {

               // ERR(retval);
            }
        }
        delete[] filename;
    }
}

void Inventory::save(){
    // get file name
    QString QFilename=resources.filename_inventory;
    char* filename;
    string fname=QFilename.toStdString();
    filename=new char[fname.size()+1];
    strcpy(filename,fname.c_str());
    //qDebug() << "Save Inventory to :"+QFilename;


    // Initialize ids and meta
    int ncid;
    int retval;// for Errors

    // Create the file
    if ((retval = nc_create(filename, NC_WRITE,&ncid)))
       ERR(retval);

    // length of inventory
    int drows=0;
    if ((retval = nc_def_dim(ncid,"record",entries,&drows)))
       ERR(retval);
    //qDebug() << "entries"+QString::number(drows);
    // length of unsigned character variables
    int corename_length=0;
    for (int i=0;i<entries;i++) if (corename_length<var_Core[i].length()) corename_length=var_Core[i].length();
    int corename=0;
    if ((retval = nc_def_dim(ncid,"cname",corename_length,&corename)))
       ERR(retval);
    //qDebug() << "Core length"+QString::number(corename_length);

    int isofilename_length=0;
    for (int i=0;i<entries;i++) if (isofilename_length<var_Filename[i].length()) isofilename_length=var_Filename[i].length();
    int isofilename=0;
    if ((retval = nc_def_dim(ncid,"iname",isofilename_length,&isofilename)))
       ERR(retval);
    //qDebug() << "filename length"+QString::number(isofilename_length);

    int speciesname_length=0;
    for (int i=0;i<entries;i++) if (speciesname_length<var_Species[i].length()) speciesname_length=var_Species[i].length();
    int speciesname=0;
    if ((retval = nc_def_dim(ncid,"sname",speciesname_length,&speciesname)))
       ERR(retval);
    //qDebug() << "Species length"+QString::number(speciesname_length);

    int typeident_length=0;
    for (int i=0;i<entries;i++) if (typeident_length<var_Record_Type[i].length()) typeident_length=var_Record_Type[i].length();
    int typeident=0;
    if ((retval = nc_def_dim(ncid,"typeid",typeident_length,&typeident)))
       ERR(retval);
    //qDebug() << "type length"+QString::number(typeident_length);

    // define variables
    // Core
    int dim[2];
    dim[0]=drows;
    dim[1]=corename;
    int coreLabel;
    if ((retval = nc_def_var(ncid,"Core",NC_CHAR,2,dim,&coreLabel)))
        ERR(retval);
    //qDebug() << coreLabel;
    // Latitude
    int dimm[1];
    dimm[0]=drows;
    int latitude;
    if ((retval = nc_def_var(ncid,"Latitude",NC_DOUBLE,1,dimm,&latitude)))
        ERR(retval);
    //qDebug() << latitude;
    // Longitude
    int longitude;
    if ((retval = nc_def_var(ncid,"Longitude",NC_DOUBLE,1,dimm,&longitude)))
        ERR(retval);
    //qDebug() << longitude;
    // isoFilename
    dim[0]=drows;
    dim[1]=isofilename;
    int isoFilename;
    if ((retval = nc_def_var(ncid,"Filename",NC_CHAR,2,dim,&isoFilename)))
        ERR(retval);
    //qDebug() << isoFilename;
    // specname
    dim[0]=drows;
    dim[1]=speciesname;
    int specname;
    if ((retval = nc_def_var(ncid,"Species",NC_CHAR,2,dim,&specname)))
        ERR(retval);
    //qDebug() << specname;
    // basin
    int basinflag;
    if ((retval = nc_def_var(ncid,"Basin",NC_DOUBLE,1,dimm,&basinflag)))
        ERR(retval);
    //qDebug() << basinflag;
    // water depth
    int wdepth;
    if ((retval = nc_def_var(ncid,"Water Depth",NC_DOUBLE,1,dimm,&wdepth)))
        ERR(retval);
    //qDebug() << wdepth;
    // uflagO
    int uflagO;
    if ((retval = nc_def_var(ncid,"Oxygen Use Flag",NC_DOUBLE,1,dimm,&uflagO)))
        ERR(retval);
    //qDebug() << uflagO;
    // uflagC
    int uflagC;
    if ((retval = nc_def_var(ncid,"Carbon Use Flag",NC_DOUBLE,1,dimm,&uflagC)))
        ERR(retval);
    //qDebug() << uflagC;
    // type
    dim[0]=drows;
    dim[1]=typeident;
    int type;
    if ((retval = nc_def_var(ncid,"Record Type",NC_CHAR,2,dim,&type)))
        ERR(retval);
    //qDebug() << type;

    // end definition mode
    if ((retval = nc_enddef(ncid)))
        ERR(retval);
    {
    // write data
    // coreLabel
   unsigned char text[corename_length][entries];
   for (int ii=0;ii<corename_length;ii++) for(int i=0;i<entries;i++) text[ii][i]=' ';
    for (int i=0;i<entries;i++){
        for (int j=0;j<var_Core[i].length();j++) text[j][i]=var_Core[i].at(j).toLatin1();
    }
    if ((retval = nc_put_var(ncid,coreLabel,&text[0][0])))
        ERR(retval);
    //qDebug() << "CoreLabel written";
    }

    // latitude
    if ((retval = nc_put_var(ncid,latitude,var_Latitude)))
        ERR(retval);
    //qDebug() << "Latitude written";

    // longitude
    if ((retval = nc_put_var(ncid,longitude,var_Longitude)))
        ERR(retval);
    //qDebug() << "Longitude written";

    // isoFilename
    {
   unsigned char text[isofilename_length][entries];
   for (int ii=0;ii<isofilename_length;ii++) for(int i=0;i<entries;i++) text[ii][i]=' ';

    for (int i=0;i<entries;i++){
        for (int j=0;j<var_Filename[i].length();j++) text[j][i]=var_Filename[i].at(j).toLatin1();
    }
    if ((retval = nc_put_var(ncid,isoFilename,&text[0][0])))
        ERR(retval);
    //qDebug() << "isoFilename written";
    }

    // specname
    {
   unsigned char text[speciesname_length][entries];
   for (int ii=0;ii<speciesname_length;ii++) for(int i=0;i<entries;i++) text[ii][i]=' ';

    for (int i=0;i<entries;i++){
        for (int j=0;j<var_Species[i].length();j++) text[j][i]=var_Species[i].at(j).toLatin1();
    }
    if ((retval = nc_put_var(ncid,specname,&text[0][0])))
        ERR(retval);
    //qDebug() << "specname written";
    }

    // basinflag
    if ((retval = nc_put_var(ncid,basinflag,var_Basin)))
        ERR(retval);
    //qDebug() << "basinflag written";

    // wdepth
    if ((retval = nc_put_var(ncid,wdepth,var_Water_Depth)))
        ERR(retval);
    //qDebug() << "wdepth written";

    // uflagO
    if ((retval = nc_put_var(ncid,uflagO,var_Oxygen_Use_Flag)))
        ERR(retval);
    //qDebug() << "uflagO written";

    // uflagC
    if ((retval = nc_put_var(ncid,uflagC,var_Carbon_Use_Flag)))
        ERR(retval);
    //qDebug() << "uflagC written";

    // type
    {
   unsigned char text[typeident_length][entries];
   for (int ii=0;ii<typeident_length;ii++) for(int i=0;i<entries;i++) text[ii][i]=' ';

    for (int i=0;i<entries;i++){
        for (int j=0;j<var_Record_Type[i].length();j++) text[j][i]=var_Record_Type[i].at(j).toLatin1();
    }
    if ((retval = nc_put_var(ncid,type,&text[0][0])))
        ERR(retval);
    //qDebug() << "type written";
    }

    // Close the file, freeing all resources.
    if ((retval = nc_close(ncid)))
        ERR(retval);
    delete[] filename;

}

void Inventory::generate(){
    // get Entry from Directory
    QDir dir=resources.path_data;
    dir.setFilter(QDir::Files | QDir::Hidden | QDir::NoSymLinks);
    dir.setNameFilters(QStringList("*.nc"));
    QFileInfoList list = dir.entryInfoList();
    //qDebug() << QString::number(list.size());
    for (int i = 0; i < list.size(); ++i) {
            QFileInfo fileInfo = list.at(i);
            //qDebug() << fileInfo.fileName();

            // Check if Filename is already in inventory
            int found=-1;
            for (int j=0;j<entries;j++){
                if (var_Filename[j]==fileInfo.fileName()){
                    //qDebug() << "Found";
                    found=j;
                    break;
                }
            }

            if (found>-1){
                // check if still consistent
                // read data
                // readData(found);


            }
            if (found==-1){
                // read Data
                readData(fileInfo.fileName());
                // create new Entry in Inventory
                addEntry();
                // enter information into last inventory
                var_Core[entries-1]=att_Core;
                var_Latitude[entries-1]=att_Latitude;
                var_Longitude[entries-1]=att_Longitude;
                var_Filename[entries-1]=fileInfo.fileName();
                var_Species[entries-1]=att_Species;
                var_Basin[entries-1]=get_Basin(att_Longitude,att_Latitude);
                var_Water_Depth[entries-1]=att_Water_Depth;
                var_Oxygen_Use_Flag[entries-1]=att_Oxygen_Use_Flag;
                var_Carbon_Use_Flag[entries-1]=att_Carbon_Use_Flag;
                var_Record_Type[entries-1]=att_Record_Type;
                selected[entries-1]=0;

                // Check if AgeModel available


                // get file name of age file
                QString name=get_Core(entries-1).replace('\0',' ');
                name.replace(" ","");
                QString QFilename;
                QFilename.clear();
                QFilename=resources.path_age+name+".age";


                string fname=QFilename.toStdString();
                char* filename;
                filename=new char[fname.size()+1];
                strcpy(filename,fname.c_str());
                //qDebug() << name;
                // Open the file
                int retval,ncid;
                if (!(retval = nc_open(filename, NC_NOWRITE, &ncid))){

                    var_AgeModel[entries-1]=1;
                    // Close the file, freeing all resources.
                    if ((retval = nc_close(ncid)))
                       ERR(retval);
                } else {
                    var_AgeModel[entries-1]=0;
                    //qDebug()<<"Not found";
                    if (nc_strerror(retval)=="No such file or directory") {
                        //qDebug() << "Age model not found...";
                    } else {

                       // ERR(retval);
                    }
                }
                delete[] filename;
            }

    }

    // check if Inventory entries still exist
    for (int i=0;i<entries;i++){
        // get file name
        QString QFilename=resources.path_data+this->get_Filename(i);

        char* filename;
        string fname=QFilename.toStdString();
        filename=new char[fname.size()+1];
        strcpy(filename,fname.c_str());
        //qDebug() << QFilename;

        // Initialize ids and meta
        int ncid;
        int retval;// for Errors

        // Open the file
        if ((retval = nc_open(filename, NC_NOWRITE, &ncid))){
            // Problem with File so delete it from inventory
            //qDebug()<<"delete :"+QString::number(i)+" of "+QString::number(entries);
            this->deleteEntry(i);
            i=-1;// Reset counter because of changing index(must be -1 because of inc at end of loop)
        } else {
        if ((retval = nc_close(ncid))) ERR(retval);
        }
        delete[] filename;

    }


    // save inventory
    if (entries>0) save();
    noData();
}

void Inventory::addEntry(){
    // add inventory line
    if (entries>0){
        // save inventory data temporarilly
        QString *temp_var_Core;
        temp_var_Core=new QString[entries];
        double *temp_var_Latitude=new double[entries];
        double *temp_var_Longitude=new double[entries];
        QString *temp_var_Filename;
        temp_var_Filename=new QString[entries];
        QString *temp_var_Species;
        temp_var_Species=new QString[entries];
        double *temp_var_Basin=new double[entries];
        double *temp_var_Water_Depth =new double[entries];
        double *temp_var_Oxygen_Use_Flag =new double[entries];
        double *temp_var_Carbon_Use_Flag=new double[entries];
        QString *temp_var_Record_Type;
        temp_var_Record_Type=new QString[entries];
        unsigned int *temp_selected=new unsigned int[entries];
        int *temp_AgeModel=new int[entries];
        for (int i=0;i<entries;i++){
            temp_var_Core [i]=var_Core[i];
            temp_var_Latitude [i]=var_Latitude[i];
            temp_var_Longitude [i]=var_Longitude[i];
            temp_var_Filename [i]=var_Filename[i];
            temp_var_Species [i]=var_Species[i];
            temp_var_Basin[i]=var_Basin[i];
            temp_var_Water_Depth [i]=var_Water_Depth[i];
            temp_var_Oxygen_Use_Flag [i]=var_Oxygen_Use_Flag[i];
            temp_var_Carbon_Use_Flag [i]=var_Carbon_Use_Flag[i];
            temp_var_Record_Type [i]=var_Record_Type[i];
            temp_selected[i]=selected[i];
            temp_AgeModel[i]=var_AgeModel[i];
        }
        // delete old data
        delete[] var_Core;
        delete[] var_Latitude;
        delete[] var_Longitude;
        delete[] var_Filename;
        delete[] var_Species;
        delete[] var_Basin;
        delete[] var_Water_Depth;
        delete[] var_Oxygen_Use_Flag;
        delete[] var_Carbon_Use_Flag;
        delete[] var_Record_Type;
        delete[] selected;
        delete[] var_AgeModel;
        // create new Inventory with old data
        entries++;
        var_Core=new QString [entries];
        var_Latitude=new double [entries];
        var_Longitude=new double [entries];
        var_Filename=new QString [entries];
        var_Species=new QString [entries];
        var_Basin=new double [entries];
        var_Water_Depth=new double [entries];
        var_Oxygen_Use_Flag=new double [entries];
        var_Carbon_Use_Flag=new double [entries];
        var_Record_Type=new QString [entries];
        selected=new unsigned int[entries];
        var_AgeModel=new int [entries];
        for (int i=0;i<entries-1;i++){
            var_Core [i]=temp_var_Core[i];
            var_Latitude [i]=temp_var_Latitude[i];
            var_Longitude [i]=temp_var_Longitude[i];
            var_Filename [i]=temp_var_Filename[i];
            var_Species [i]=temp_var_Species[i];
            var_Basin[i]=temp_var_Basin[i];
            var_Water_Depth [i]=temp_var_Water_Depth[i];
            var_Oxygen_Use_Flag [i]=temp_var_Oxygen_Use_Flag[i];
            var_Carbon_Use_Flag [i]=temp_var_Carbon_Use_Flag[i];
            var_Record_Type [i]=temp_var_Record_Type[i];
            selected[i]=temp_selected[i];
            var_AgeModel[i]=temp_AgeModel[i];
        }
        delete[] temp_var_Core;
        delete[] temp_var_Latitude;
        delete[] temp_var_Longitude;
        delete[] temp_var_Filename;
        delete[] temp_var_Species;
        delete[] temp_var_Basin;
        delete[] temp_var_Water_Depth;
        delete[] temp_var_Oxygen_Use_Flag;
        delete[] temp_var_Carbon_Use_Flag;
        delete[] temp_var_Record_Type;
        delete[] temp_selected;
        delete[] temp_AgeModel;
    } else {
        delete[] var_Core;
        delete[] var_Latitude;
        delete[] var_Longitude;
        delete[] var_Filename;
        delete[] var_Species;
        delete[] var_Basin;
        delete[] var_Water_Depth;
        delete[] var_Oxygen_Use_Flag;
        delete[] var_Carbon_Use_Flag;
        delete[] var_Record_Type;
        delete[] selected;
        delete[] var_AgeModel;
        // create inventory if empty
       entries=1;
       var_Core=new QString [entries];
       var_Latitude=new double [entries];
       var_Longitude=new double [entries];
       var_Filename=new QString [entries];
       var_Species=new QString [entries];
       var_Basin=new double [entries];
       var_Water_Depth=new double [entries];
       var_Oxygen_Use_Flag=new double [entries];
       var_Carbon_Use_Flag=new double [entries];
       var_Record_Type=new QString [entries];
       selected=new unsigned int[entries];
       var_AgeModel=new int [entries];
    }

}

void Inventory::deleteEntry(int n){
    // delete inventory line
    if (entries>0){
        // save inventory data temporarilly
        QString *temp_var_Core;
        temp_var_Core=new QString[entries];
        double *temp_var_Latitude=new double[entries];
        double *temp_var_Longitude=new double[entries];
        QString *temp_var_Filename;
        temp_var_Filename=new QString[entries];
        QString *temp_var_Species;
        temp_var_Species=new QString[entries];
        double *temp_var_Basin=new double[entries];
        double *temp_var_Water_Depth =new double[entries];
        double *temp_var_Oxygen_Use_Flag =new double[entries];
        double *temp_var_Carbon_Use_Flag=new double[entries];
        QString *temp_var_Record_Type;
        temp_var_Record_Type=new QString[entries];
        unsigned int *temp_selected=new unsigned int[entries];

        int *temp_AgeModel=new int[entries];
        for (int i=0;i<entries;i++){
            temp_var_Core [i]=var_Core[i];
            temp_var_Latitude [i]=var_Latitude[i];
            temp_var_Longitude [i]=var_Longitude[i];
            temp_var_Filename [i]=var_Filename[i];
            temp_var_Species [i]=var_Species[i];
            temp_var_Basin[i]=var_Basin[i];
            temp_var_Water_Depth [i]=var_Water_Depth[i];
            temp_var_Oxygen_Use_Flag [i]=var_Oxygen_Use_Flag[i];
            temp_var_Carbon_Use_Flag [i]=var_Carbon_Use_Flag[i];
            temp_var_Record_Type [i]=var_Record_Type[i];
            temp_selected[i]=selected[i];
            temp_AgeModel[i]=var_AgeModel[i];
        }
        // delete old data
        delete[] var_Core;
        delete[] var_Latitude;
        delete[] var_Longitude;
        delete[] var_Filename;
        delete[] var_Species;
        delete[] var_Basin;
        delete[] var_Water_Depth;
        delete[] var_Oxygen_Use_Flag;
        delete[] var_Carbon_Use_Flag;
        delete[] var_Record_Type;
        delete[] selected;
        delete[] var_AgeModel;
        // create new Inventory with old data
        entries--;
        var_Core=new QString [entries];
        var_Latitude=new double [entries];
        var_Longitude=new double [entries];
        var_Filename=new QString [entries];
        var_Species=new QString [entries];
        var_Basin=new double [entries];
        var_Water_Depth=new double [entries];
        var_Oxygen_Use_Flag=new double [entries];
        var_Carbon_Use_Flag=new double [entries];
        var_Record_Type=new QString [entries];
        selected=new unsigned int[entries];
        var_AgeModel=new int [entries];

        int count=0;
        for (int i=0;i<entries;i++){
            if (i!=n){
                var_Core [count]=temp_var_Core[i];
                var_Latitude [count]=temp_var_Latitude[i];
                var_Longitude [count]=temp_var_Longitude[i];
                var_Filename [count]=temp_var_Filename[i];
                var_Species [count]=temp_var_Species[i];
                var_Basin[count]=temp_var_Basin[i];
                var_Water_Depth [count]=temp_var_Water_Depth[i];
                var_Oxygen_Use_Flag [count]=temp_var_Oxygen_Use_Flag[i];
                var_Carbon_Use_Flag [count]=temp_var_Carbon_Use_Flag[i];
                var_Record_Type [count]=temp_var_Record_Type[i];
                selected[count]=temp_selected[i];
                var_AgeModel[count]=temp_AgeModel[i];
                count++;
            }
        }
        delete[] temp_var_Core;
        delete[] temp_var_Latitude;
        delete[] temp_var_Longitude;
        delete[] temp_var_Filename;
        delete[] temp_var_Species;
        delete[] temp_var_Basin;
        delete[] temp_var_Water_Depth;
        delete[] temp_var_Oxygen_Use_Flag;
        delete[] temp_var_Carbon_Use_Flag;
        delete[] temp_var_Record_Type;
        delete[] temp_selected;
        delete[] temp_AgeModel;

    } else {
        delete[] var_Core;
        delete[] var_Latitude;
        delete[] var_Longitude;
        delete[] var_Filename;
        delete[] var_Species;
        delete[] var_Basin;
        delete[] var_Water_Depth;
        delete[] var_Oxygen_Use_Flag;
        delete[] var_Carbon_Use_Flag;
        delete[] var_Record_Type;
        delete[] selected;
        delete[] var_AgeModel;
        // create inventory if empty
       entries=1;
       var_Core=new QString [entries];
       var_Latitude=new double [entries];
       var_Longitude=new double [entries];
       var_Filename=new QString [entries];
       var_Species=new QString [entries];
       var_Basin=new double [entries];
       var_Water_Depth=new double [entries];
       var_Oxygen_Use_Flag=new double [entries];
       var_Carbon_Use_Flag=new double [entries];
       var_Record_Type=new QString [entries];
       selected=new unsigned int[entries];
       var_AgeModel=new int [entries];
    }

}



QString Inventory::get_Core(int n){
    return var_Core[n];
}

void Inventory::set_Core(QString str){
    var_Core[current_Core]=str;
}

double Inventory::get_Latitude(int n){
    return var_Latitude[n];
}

void Inventory::set_Latitude(double v){
    var_Latitude[current_Core]=v;
}

double Inventory::get_Longitude(int n){
    return var_Longitude[n];
}

void Inventory::set_Longitude(double v){
    var_Longitude[current_Core]=v;

}

QString Inventory::get_Filename(int n){
    return var_Filename[n];
}

void Inventory::set_Filename(QString str){
    var_Filename[current_Core]=str;
}

QString Inventory::get_Species(int n){
    return var_Species[n];
}

void Inventory::set_Species(QString str){
    var_Species[current_Core]=str;

}

double Inventory::get_Basin(int n){
    return var_Basin[n];
}

void Inventory::set_Basin(int b){
    var_Basin[current_Core]=b;
}

double Inventory::get_Water_Depth(int n){
    return var_Water_Depth[n];
}

void Inventory::set_Water_Depth(double v){
    var_Water_Depth[current_Core]=v;

}

double Inventory::get_Oxygen_Use_Flag(int n){
    return var_Oxygen_Use_Flag[n];
}

void Inventory::set_O_Use_Flag(int n){
    var_Oxygen_Use_Flag[current_Core]=n;
}

double Inventory::get_Carbon_Use_Flag(int n){
    return var_Carbon_Use_Flag[n];
}

void Inventory::set_C_Use_Flag(int n){
    var_Carbon_Use_Flag[current_Core]=n;
}

QString Inventory::get_Record_Type(int n){
    return var_Record_Type[n];
}

void Inventory::set_Record_Type(QString str){
    var_Record_Type[current_Core]=str;

}

unsigned int Inventory::get_Entries(){
    return entries;
}

unsigned int Inventory::get_Selected(int n){
    return selected[n];
}

unsigned int Inventory::get_Selected_Sum(){
    int sum=0;
    for (int i=0;i<entries;i++) sum+=selected[i];
    return sum;
}

void Inventory::invert_Selected(int n){
    if (selected[n]){
        selected[n]=0;
    } else {
        selected[n]=1;
    }

}

void Inventory::set_Selected(int n,int m){
    selected[n]=m;

}

int Inventory::get_AgeModel(int n){
    return var_AgeModel[n];
}

void Inventory::set_AgeModel(int n,int i){
    var_AgeModel[n]=i;
}

//*************  Data
void Inventory::readData(int n){
    flag_Data_OK=0;
    if (n>=0){
    // get file name
    QString QFilename=this->get_Filename(n);
    current_Core=n;
    readData(QFilename);
    }




}

void Inventory::readData(QString Filename){
    flag_Data_OK=0;

    // get file name
    QString QFilename=resources.path_data+Filename;

    char* filename;
    string fname=QFilename.toStdString();
    filename=new char[fname.size()+1];
    strcpy(filename,fname.c_str());
    //qDebug() << QFilename;

    // Initialize ids and meta
    int ncid;
    int varid[11];
    int dimid[2]={0};
    size_t dimlen[2]={0};
    size_t attlen[22]={0};


    int retval;// for Errors

    // Open the file
    if ((retval = nc_open(filename, NC_NOWRITE, &ncid)))
       ERR(retval);




    // -------------------- READ ATTRIBUTES -------------------------------

    // -------------------- Must Have -----------------------
    // 1:read att_Core
    if ((retval = nc_inq_attlen(ncid,NC_GLOBAL,"Core",&attlen[0])))
       ERR(retval);
   unsigned char text[attlen[0]+1];
   for (int ii=0;ii<attlen[0]+1;ii++) text[ii]=' ';
    if ((retval = nc_get_att(ncid,NC_GLOBAL,"Core",&text[0])))
       ERR(retval);
    att_Core="";
    for (unsigned int j=0;j<attlen[0];j++){
            att_Core.append(text[j]);
    }
    //qDebug() << att_Core;

    // 2:read att_Latitude
    att_Latitude=0;
    if ((retval = nc_get_att_double(ncid,NC_GLOBAL,"Latitude",&att_Latitude)))
       ERR(retval);
    //qDebug() << QString::number(att_Latitude);

    // 3:read att_Longitude
    att_Longitude=0;
    if ((retval = nc_get_att_double(ncid,NC_GLOBAL,"Longitude",&att_Longitude)))
       ERR(retval);
    //qDebug() << QString::number(att_Longitude);

    // 4:read att_Water_Depth
    att_Water_Depth=0;
    if ((retval = nc_get_att_double(ncid,NC_GLOBAL,"Water Depth",&att_Water_Depth)))
       ERR(retval);
    //qDebug() << QString::number(att_Water_Depth);

    // 5:read att_Species
    if ((retval = nc_inq_attlen(ncid,NC_GLOBAL,"Species",&attlen[5])))
       ERR(retval);
    unsigned char text3[attlen[5]+1];
    if ((retval = nc_get_att(ncid,NC_GLOBAL,"Species",&text3[0])))
       ERR(retval);
    att_Species.clear();
    for (unsigned int j=0;j<attlen[5];j++){
            att_Species.append(text3[j]);
    }
    //qDebug() << att_Species;

    // 6:read att_Record_Type
    if ((retval = nc_inq_attlen(ncid,NC_GLOBAL,"Record Type",&attlen[17])))
       ERR(retval);
   unsigned char text11[attlen[17]+1];
    if ((retval = nc_get_att(ncid,NC_GLOBAL,"Record Type",&text11[0])))
       ERR(retval);
    att_Record_Type="";
    for (unsigned int j=0;j<attlen[17];j++){
            att_Record_Type.append(text11[j]);
    }
    //qDebug() << att_Record_Type;

    // ------------------------- Proxy Specific --------------------------

    // 7:read att_Device
    if ((retval = nc_inq_attlen(ncid,NC_GLOBAL,"Device",&attlen[3])))
       ERR(retval);
    unsigned char text2[attlen[3]+1];
    if ((retval = nc_get_att(ncid,NC_GLOBAL,"Device",&text2[0])))
       ERR(retval);
    att_Device="";
    for (unsigned int j=0;j<attlen[3];j++){
            att_Device.append(text2[j]);
    }
    //qDebug() << att_Device;

    // 8:read att_Laboratory
    if ((retval = nc_inq_attlen(ncid,NC_GLOBAL,"Laboratory",&attlen[6])))
       ERR(retval);
    unsigned char text4[attlen[6]+1];
    if ((retval = nc_get_att(ncid,NC_GLOBAL,"Laboratory",&text4[0])))
       ERR(retval);
    att_Laboratory="";
    for (unsigned int j=0;j<attlen[6];j++){
            att_Laboratory.append(text4[j]);
    }
    //qDebug() << att_Laboratory;

    // 9:read att_Instrumentation
    if ((retval = nc_inq_attlen(ncid,NC_GLOBAL,"Instrumentation",&attlen[18])))
       ERR(retval);
    unsigned char text16[attlen[18]+1];
    if ((retval = nc_get_att(ncid,NC_GLOBAL,"Instrumentation",&text16[0])))
       ERR(retval);
    att_Instrumentation="";
    for (unsigned int j=0;j<attlen[18];j++){
            att_Instrumentation.append(text16[j]);
    }
    //qDebug() << att_Instrumentation;

    // 10:read att_Data_Source
    if ((retval = nc_inq_attlen(ncid,NC_GLOBAL,"Data Source",&attlen[16])))
       ERR(retval);
   unsigned char text10[attlen[16]+1];
    if ((retval = nc_get_att(ncid,NC_GLOBAL,"Data Source",&text10[0])))
       ERR(retval);
    att_Data_Source="";
    for (unsigned int j=0;j<attlen[16];j++){
            att_Data_Source.append(text10[j]);
    }
    //qDebug() << att_Data_Source;

    // 11:read att_Comment
    if ((retval = nc_inq_attlen(ncid,NC_GLOBAL,"Comment",&attlen[8])))
       ERR(retval);
    unsigned char text6[attlen[8]+1];
    if ((retval = nc_get_att(ncid,NC_GLOBAL,"Comment",&text6[0])))
       ERR(retval);
    att_Comment="";
    for (unsigned int j=0;j<attlen[8];j++){
            att_Comment.append(QChar(text6[j]));
    }
    //qDebug() << att_Comment;

    // 12:read att_Proxy_Category
    if ((retval = nc_inq_attlen(ncid,NC_GLOBAL,"Proxy Category",&attlen[19])))
       ERR(retval);
    unsigned char text12[attlen[19]+1];
    if ((retval = nc_get_att(ncid,NC_GLOBAL,"Proxy Category",&text12[0])))
       ERR(retval);
    att_Category="";
    for (unsigned int j=0;j<attlen[19];j++){
            att_Category.append(text12[j]);
    }
    //qDebug() << att_Instrumentation;

    // 13:read att_Reference
    if ((retval = nc_inq_attlen(ncid,NC_GLOBAL,"Reference",&attlen[7])))
       ERR(retval);
   unsigned char text5[attlen[7]+1]; // Why do i need a new variable???
    if ((retval = nc_get_att(ncid,NC_GLOBAL,"Reference",&text5[0])))
       ERR(retval);
    att_Reference="";
    for (unsigned int j=0;j<attlen[7];j++){
            att_Reference.append(text5[j]);
    }
    //qDebug() << att_Reference;

    // 14:read att_Importer
    if ((retval = nc_inq_attlen(ncid,NC_GLOBAL,"Importer",&attlen[20])))
       ERR(retval);
    unsigned char text15[attlen[20]+1];
    if ((retval = nc_get_att(ncid,NC_GLOBAL,"Importer",&text15[0])))
       ERR(retval);
    att_Importer="";
    for (unsigned int j=0;j<attlen[20];j++){
            att_Importer.append(text15[j]);
    }
    //qDebug() << att_Importer;

    //------------------------ Optional --------------------------------

    // 15:read att_EPaper
    if ((retval = nc_inq_attlen(ncid,NC_GLOBAL,"E-Paper",&attlen[9])))
       ERR(retval);
    unsigned char text7[attlen[9]+1];
    if ((retval = nc_get_att(ncid,NC_GLOBAL,"E-Paper",&text7[0])))
       ERR(retval);
    att_EPaper="";
    for (unsigned int j=0;j<attlen[9];j++){
            att_EPaper.append(text7[j]);
    }
    //qDebug() << att_EPaper;

    // 16:read att_Oxygen_Use_Flag
    att_Oxygen_Use_Flag=0;
    if ((retval = nc_get_att_double(ncid,NC_GLOBAL,"Oxygen Use Flag",&att_Oxygen_Use_Flag)))
       ERR(retval);
    //qDebug() << QString::number(att_Oxygen_Use_Flag);

    // 17:read att_Carbon_Use_Flag
    att_Carbon_Use_Flag=0;
    if ((retval = nc_get_att_double(ncid,NC_GLOBAL,"Carbon Use Flag",&att_Carbon_Use_Flag)))
       ERR(retval);
    //qDebug() << QString::number(att_Carbon_Use_Flag);

    // 18:read att_O_Correction
    att_O_Correction=0;
    if ((retval = nc_get_att_double(ncid,NC_GLOBAL,"O-Correction",&att_O_Correction)))
       ERR(retval);
    //qDebug() << QString::number(att_O_Correction);

    // 19:read att_O_Justification
    if ((retval = nc_inq_attlen(ncid,NC_GLOBAL,"O-Correction Justification",&attlen[13])))
       ERR(retval);
   unsigned char text8[attlen[13]+1];
    if ((retval = nc_get_att(ncid,NC_GLOBAL,"O-Correction Justification",&text8[0])))
       ERR(retval);
    att_O_Justification="";
    for (unsigned int j=0;j<attlen[13];j++){
            att_O_Justification.append(text8[j]);
    }
    //qDebug() << att_O_Justification;

    // 20:read att_C_Correction
    att_C_Correction=0;
    if ((retval = nc_get_att_double(ncid,NC_GLOBAL,"C-Correction",&att_C_Correction)))
       ERR(retval);
    QString::number(att_C_Correction); //This is Critical Why?

    // 21:read att_C_Justification
    if ((retval = nc_inq_attlen(ncid,NC_GLOBAL,"C-Correction Justification",&attlen[15])))
       ERR(retval);
   unsigned char text9[attlen[15]+1];
    if ((retval = nc_get_att(ncid,NC_GLOBAL,"C-Correction Justification",&text9[0])))
       ERR(retval);
    att_C_Justification="";
    for (unsigned int j=0;j<attlen[15];j++){
            att_C_Justification.append(text9[j]);
    }
    //qDebug() << att_C_Justification;

    // 22:read att_Optional
    if ((retval = nc_inq_attlen(ncid,NC_GLOBAL,"Optional",&attlen[21])))
       ERR(retval);
   unsigned char text14[attlen[21]+1];
    if ((retval = nc_get_att(ncid,NC_GLOBAL,"Optional",&text14[0])))
       ERR(retval);
    att_Optional="";
    for (unsigned int j=0;j<attlen[21];j++){
            att_Optional.append(text14[j]);
    }
    //qDebug() << att_Optional;

    //----------------- read data ---------------------------------
    // get dims

    if ((retval = nc_inq_dimid(ncid, "Length", &dimid[0])))
       ERR(retval);
    if ((retval = nc_inq_dimlen(ncid, dimid[0], &dimlen[0])))
       ERR(retval);
    if ((retval = nc_inq_dimid(ncid, "Character", &dimid[1])))
       ERR(retval);
    if ((retval = nc_inq_dimlen(ncid, dimid[1], &dimlen[1])))
       ERR(retval);
    length=dimlen[0];
    //qDebug()<<QString::number(dimlen[0]);
    //qDebug()<<QString::number(dimlen[1]);


    // read Depth
    if ((retval = nc_inq_varid(ncid, "Depth", &varid[0])))
       ERR(retval);
    data_Depth.clear();
    for (int i=0;i<length;i++) data_Depth.push_back(0);
    if ((retval = nc_get_var_double(ncid,varid[0],&data_Depth[0]))) ERR(retval);
    //for (int i=0;i<length;i++)qDebug()<<QString::number(data_Depth[i]);

    // read sample_Thickness
    if ((retval = nc_inq_varid(ncid, "Sample Thickness", &varid[1])))
       ERR(retval);
    data_Sample_Thickness.clear();
    for (int i=0;i<length;i++) data_Sample_Thickness.push_back(0);
    if ((retval = nc_get_var_double(ncid,varid[1],&data_Sample_Thickness[0]))) ERR(retval);
    //for (int i=0;i<length;i++)qDebug()<<QString::number(data_Sample_Thickness[i]);

    // read Age
    if ((retval = nc_inq_varid(ncid, "Age", &varid[2])))
       ERR(retval);
    data_Age.clear();
    for (int i=0;i<length;i++) data_Age.push_back(0);
    if ((retval = nc_get_var_double(ncid,varid[2],&data_Age[0]))) ERR(retval);
    //for (int i=0;i<length;i++)qDebug()<<QString::number(data_Age[i]);

    // read d13C
    if ((retval = nc_inq_varid(ncid, "d13C", &varid[3])))
       ERR(retval);
    data_d13C.clear();
    for (int i=0;i<length;i++) data_d13C.push_back(0);
    if ((retval = nc_get_var_double(ncid,varid[3],&data_d13C[0]))) ERR(retval);
    //for (int i=0;i<length;i++)qDebug()<<QString::number(data_d13C[i]);

    // read d18O
    if ((retval = nc_inq_varid(ncid, "d18O", &varid[4])))
       ERR(retval);
    data_d18O.clear();
    for (int i=0;i<length;i++) data_d18O.push_back(0);
    if ((retval = nc_get_var_double(ncid,varid[4],&data_d18O[0]))) ERR(retval);
    //for (int i=0;i<length;i++)qDebug()<<QString::number(data_d18O[i]);

    // read d13C_Corr
    if ((retval = nc_inq_varid(ncid, "d13C Corr", &varid[5])))
       ERR(retval);
    data_d13C_Corr.clear();
    for (int i=0;i<length;i++) data_d13C_Corr.push_back(0);
    if ((retval = nc_get_var_double(ncid,varid[5],&data_d13C_Corr[0]))) ERR(retval);
    //for (int i=0;i<length;i++)qDebug()<<QString::number(data_d13C_Corr[i]);

    // read d18_Corr
    if ((retval = nc_inq_varid(ncid, "d18O Corr", &varid[6])))
       ERR(retval);
    data_d18O_Corr.clear();
    for (int i=0;i<length;i++) data_d18O_Corr.push_back(0);
    if ((retval = nc_get_var_double(ncid,varid[6],&data_d18O_Corr[0]))) ERR(retval);
    //for (int i=0;i<length;i++)qDebug()<<QString::number(data_d18O_Corr[i]);

    // read d13C Err
    if ((retval = nc_inq_varid(ncid, "d13C Err", &varid[7])))
       ERR(retval);
    data_d13C_Err.clear();
    for (int i=0;i<length;i++) data_d13C_Err.push_back(0);
    if ((retval = nc_get_var_double(ncid,varid[7],&data_d13C_Err[0]))) ERR(retval);
    //for (int i=0;i<length;i++)qDebug()<<QString::number(data_d13C_Err[i]);

    // read d18O_Err
    if ((retval = nc_inq_varid(ncid, "d18O Err", &varid[8])))
       ERR(retval);
    data_d18O_Err.clear();
    for (int i=0;i<length;i++) data_d18O_Err.push_back(0);
    if ((retval = nc_get_var_double(ncid,varid[8],&data_d18O_Err[0]))) ERR(retval);
    //for (int i=0;i<length;i++)qDebug()<<QString::number(data_d18O_Err[i]);

    // read Use Flag
    if ((retval = nc_inq_varid(ncid, "Use Flag", &varid[9])))
       ERR(retval);
    data_Use_Flag.clear();
    for (int i=0;i<length;i++) data_Use_Flag.push_back(0);
    if ((retval = nc_get_var_int(ncid,varid[9],&data_Use_Flag[0]))) ERR(retval);
    //for (int i=0;i<length;i++)qDebug()<<QString::number(data_Use_Flag[i]);

    // get varid for Comment variable
    if ((retval = nc_inq_varid(ncid, "Comment", &varid[10])))
       ERR(retval);
    unsigned char com[dimlen[0]*dimlen[1]];
    if ((retval = nc_get_var(ncid,varid[10],&com[0]))) ERR(retval);
    data_Comment.clear();

    for (int i=0;i<dimlen[0];i++){
        data_Comment.push_back(new QString(""));
        for (int j=0;j<dimlen[1];j++){
            if (com[j*dimlen[0]+i]!=0){
                data_Comment[i]->append(com[j*dimlen[0]+i]);
            }
        }
        //qDebug() << data_Comment[i]->toLatin1();
    }


    // Close the file, freeing all resources.
    if ((retval = nc_close(ncid)))
       ERR(retval);
    flag_Data_OK=1;
    delete[] filename;
}

void Inventory::newIsotope(int isolength){

    length=isolength;

    // creating init variable data of length
    data_Depth.clear();
    data_Depth.reserve(length);
    for(int i=0;i<length;i++) data_Depth.push_back(0);

    data_Sample_Thickness.clear();
    data_Sample_Thickness.reserve(length);
    for(int i=0;i<length;i++) data_Sample_Thickness.push_back(0);

    data_Age.clear();
    data_Age.reserve(length);
    for(int i=0;i<length;i++) data_Age.push_back(0);

    data_d13C.clear();
    data_d13C.reserve(length);
    for(int i=0;i<length;i++) data_d13C.push_back(0);

    data_d18O.clear();
    data_d18O.reserve(length);
    for(int i=0;i<length;i++) data_d18O.push_back(0);

    data_d13C_Corr.clear();
    data_d13C_Corr.reserve(length);
    for(int i=0;i<length;i++) data_d13C_Corr.push_back(0);

    data_d18O_Corr.clear();
    data_d18O_Corr.reserve(length);
    for(int i=0;i<length;i++) data_d18O_Corr.push_back(0);

    data_d13C_Err.clear();
    data_d13C_Err.reserve(length);
    for(int i=0;i<length;i++) data_d13C_Err.push_back(0);

    data_d18O_Err.clear();
    data_d18O_Err.reserve(length);
    for(int i=0;i<length;i++) data_d18O_Err.push_back(0);

    data_Use_Flag.clear();
    data_Use_Flag.reserve(length);
    for(int i=0;i<length;i++) data_Use_Flag.push_back(0);

    data_Comment.clear();
    data_Comment.reserve(length);
    for (int i=0;i<length;i++) {
        data_Comment.push_back(new QString("na"));

    }


}

void Inventory::newIsotopeMeta(){
    flag_Data_OK=1;

    att_Core="";
    att_Latitude=0;
    att_Longitude=0;
    att_Water_Depth=0;
    att_Species="na";
    att_Record_Type="na";
    // Proxy specific
    att_Device="na";
    att_Laboratory="na";
    att_Instrumentation="na";
    att_Data_Source="na";
    att_Comment="na";
    att_Category="na";
    att_Reference="na";
    att_Importer="na";
    // Optional/Proxy specific
    att_EPaper="na";
    att_Oxygen_Use_Flag=0;
    att_Carbon_Use_Flag=0;
    att_O_Correction=0;
    att_O_Justification="na";
    att_C_Correction=0;
    att_C_Justification="na";
    // Dump/User specified
    att_Optional="";// dump of all additional parameters
}

void Inventory::addIsotope(){

    data_Depth.push_back(0);

    data_Sample_Thickness.push_back(0);

    data_Age.push_back(0);

    data_d13C.push_back(0);

    data_d18O.push_back(0);

    data_d13C_Corr.push_back(0);

    data_d18O_Corr.push_back(0);

    data_d13C_Err.push_back(0);

    data_d18O_Err.push_back(0);

    data_Use_Flag.push_back(0);

    data_Comment.push_back(new QString("na"));

    length++;
}

int Inventory::get_flag_Data_OK(){
    return flag_Data_OK;
}

void Inventory::set_flag_Data_OK(int n){
    flag_Data_OK=n;
}

// Old Style
// 0 : Depth
// 1 : Age
// 2 : C13
// 3 : O14
// 4 : C13 Corrected
// 5 : O14 Corrected
// 6 : Flag
double Inventory::get_data_Isotopes(int i,int j){
    double value=NAN;
    if (j<length){
        if (i==0) value=data_Depth[j];
        if (i==1) value=data_Age[j];
        if (i==2) value=data_d13C[j];
        if (i==3) value=data_d18O[j];
        if (i==4) value=data_d13C_Corr[j];
        if (i==5) value=data_d18O_Corr[j];
        if (i==6) value=data_Use_Flag[j];
    }
    return value;
}

void Inventory::set_data_Isotopes(int i,int j,double v){
    if (j<length){
        if (i==0) data_Depth[j]=v;
        if (i==1) data_Age[j]=v;
        if (i==2) data_d13C[j]=v;
        if (i==3) data_d18O[j]=v;
        if (i==4) data_d13C_Corr[j]=v;
        if (i==5) data_d18O_Corr[j]=v;
        if (i==6) data_Use_Flag[j]=(int)v;
    }
}

double Inventory::get_data_Depth(int i){
    return data_Depth[i];
}

double Inventory::get_data_Sample_Thickness(int i){
    return data_Sample_Thickness[i];
}

double Inventory::get_data_Age(int i){
    return data_Age[i];
}

double Inventory::get_data_d13C(int i){
    return data_d13C[i];
}

double Inventory::get_data_d18O(int i){
    return data_d18O[i];
}

double Inventory::get_data_d13C_Corr(int i){
    return data_d13C_Corr[i];
}

double Inventory::get_data_d18O_Corr(int i){
    return data_d18O_Corr[i];
}

double Inventory::get_data_d13C_Err(int i){
    return data_d13C_Err[i];
}

double Inventory::get_data_d18O_Err(int i){
    return data_d18O_Err[i];
}

int Inventory::get_data_Use_Flag(int i){
    return data_Use_Flag[i];
}

QString Inventory::get_data_Comment(int i){
    return data_Comment[i]->toLatin1();
}

void Inventory::set_data_Depth(double v,int i){
    data_Depth[i]=v;
}

void Inventory::set_data_Sample_Thickness(double v,int i){
    data_Sample_Thickness[i]=v;
}

void Inventory::set_data_Age(double v,int i){
    data_Age[i]=v;
}

void Inventory::set_data_d13C(double v,int i){
    data_d13C[i]=v;
}

void Inventory::set_data_d18O(double v,int i){
    data_d18O[i]=v;
}

void Inventory::set_data_d13C_Corr(double v,int i){
    data_d13C_Corr[i]=v;
}

void Inventory::set_data_d18O_Corr(double v,int i){
    data_d18O_Corr[i]=v;
}

void Inventory::set_data_d13C_Err(double v,int i){
    data_d13C_Err[i]=v;
}

void Inventory::set_data_d18O_Err(double v,int i){
    data_d18O_Err[i]=v;
}

void Inventory::set_data_Use_Flag(int v,int i){
    data_Use_Flag[i]=v;
}

void Inventory::set_data_Comment(QString str,int i){
    data_Comment[i]->clear();
    data_Comment[i]->append(str);
}

double Inventory::get_Int_Value_18O(double depth, QString str){
    double yy=NAN;
    // Create Sublist of isotope data
    // create subset of active Flag only
    // get length
    int active_count=0;
    for (int i=0;i<get_Length();i++) if (get_data_Use_Flag(i)==1) active_count++;

    double *temp_18O;
    double *temp_depth;
    temp_18O=new double[active_count];
    temp_depth=new double[active_count];
    int n=0;
    for (int i=0;i<get_Length();i++){
        if (get_data_Use_Flag(i)==1){
            temp_18O[n]=get_data_d18O_Corr(i);
            temp_depth[n]=get_data_Depth(i);
            n++;
        }
    }
    // Interpolation
    if (depth>=temp_depth[0] && depth<=temp_depth[active_count-1]){

    if (str=="linear"){
        int i=0;
        for (i=0;i<active_count;i++) if (temp_depth[i]>depth) break;
        if (i>0) yy=temp_18O[i-1]+(temp_18O[i]-temp_18O[i-1])/(temp_depth[i]-temp_depth[i-1])*(depth-temp_depth[i-1]);

    }
    } else {
        yy=NAN;
    }
    delete[] temp_18O;
    delete[] temp_depth;

    return yy;
}

QString Inventory::get_data_Comments(int j){
    return data_Comment[j]->toLatin1();
}

QString Inventory::get_att_Core(){
    return att_Core;
}

void Inventory::set_att_Core(QString str){
    att_Core=str;

}

double Inventory::get_att_Latitude(){
    return att_Latitude;
}

void Inventory::set_att_Latitude(double v){
    att_Latitude=v;

}

double Inventory::get_att_Longitude(){
    return att_Longitude;
}

void Inventory::set_att_Longitude(double v){
    att_Longitude=v;

}

QString Inventory::get_att_Device(){
    return att_Device;
}

void Inventory::set_att_Device(QString str){
    att_Device=str;

}

double Inventory::get_att_Water_Depth(){
    return att_Water_Depth;
}

void Inventory::set_att_Water_Depth(double v){
    att_Water_Depth=v;

}

QString Inventory::get_att_Species(){
    return att_Species;
}

void Inventory::set_att_Species(QString str){
    att_Species=str;

}

QString Inventory::get_att_Laboratory(){
    return att_Laboratory;
}

void Inventory::set_att_Laboratory(QString str){
    att_Laboratory=str;

}

QString Inventory::get_att_Reference(){
    return att_Reference;
}

void Inventory::set_att_Reference(QString str){
    att_Reference=str;

}

QString Inventory::get_att_Comment(){
    return att_Comment;
}

void Inventory::set_att_Comment(QString str){
    att_Comment=str;

}

QString Inventory::get_att_EPaper(){
    return att_EPaper;
}

void Inventory::set_att_EPaper(QString s){
    att_EPaper=s;

    //qDebug() << "set E-Paper: "+att_EPaper;

}

double Inventory::get_att_Oxygen_Use_Flag(){
    return att_Oxygen_Use_Flag;
}

void Inventory::set_att_O_Use_Flag(int n){
    att_Oxygen_Use_Flag=n;
}

double Inventory::get_att_Carbon_Use_Flag(){
    return att_Carbon_Use_Flag;
}

void Inventory::set_att_C_Use_Flag(int n){
    att_Carbon_Use_Flag=n;
}

double Inventory::get_att_O_Correction(){
    return att_O_Correction;
}

void Inventory::set_att_O_Correction(double v){
    att_O_Correction=v;
    for (int i=0;i<get_Length();i++){
        data_d18O_Corr.at(i)=data_d18O.at(i)+att_O_Correction;
    }
}

QString Inventory::get_att_O_Justification(){
    return att_O_Justification;
}

void Inventory::set_att_O_Justification(QString str){
    att_O_Justification=str;
}

double Inventory::get_att_C_Correction(){
    return att_C_Correction;
}

void Inventory::set_att_C_Correction(double v){
    att_C_Correction=v;
    for (int i=0;i<get_Length();i++){
        data_d13C_Corr.at(i)=data_d13C.at(i)+att_C_Correction;
    }
}

QString Inventory::get_att_C_Justification(){
    return att_C_Justification;
}

void Inventory::set_att_C_Justification(QString str){
    att_C_Justification=str;
}

QString Inventory::get_att_Data_Source(){
    return att_Data_Source;
}

void Inventory::set_att_Data_Source(QString str){
    att_Data_Source=str;

}

QString Inventory::get_att_Record_Type(){
    return att_Record_Type;
}

void Inventory::set_att_Record_Type(QString str){
    att_Record_Type=str;

}

unsigned int Inventory::get_Length(){
    return length;
}

void Inventory::invert_O_Flag(int n){
    readData(n);
    if (att_Oxygen_Use_Flag==1){
        att_Oxygen_Use_Flag=0;
        var_Oxygen_Use_Flag[n]=0;
    } else {
        att_Oxygen_Use_Flag=1;
        var_Oxygen_Use_Flag[n]=1;
    }
    saveData();
}

void Inventory::invert_C_Flag(int n){
    readData(n);
    if (att_Carbon_Use_Flag==1){
        att_Carbon_Use_Flag=0;
        var_Carbon_Use_Flag[n]=0;
    } else {
        att_Carbon_Use_Flag=1;
        var_Carbon_Use_Flag[n]=1;
    }
    saveData();

}

QString Inventory::get_att_Importer(){
    return att_Importer;
}

void Inventory::set_att_Importer(QString str){
    att_Importer=str;
}

QString Inventory::get_att_Optional(){
    return att_Optional;
}

void Inventory::set_att_Optiona(QString str){
    att_Optional=str;
}

QString Inventory::get_att_Category(){
    return att_Category;
}

void Inventory::set_att_Category(QString str){
    att_Category=str;
}


void Inventory::saveData(){
    int n=current_Core;
    if (n>=0){
        // get file name
        QString QFilename=this->get_Filename(n);
        saveData(QFilename);
    }
}

void Inventory::saveData(QString Filename){
    // get file name
    QString QFilename=resources.path_data+Filename;
    char* filename;
    string fname=QFilename.toStdString();
    filename=new char[fname.size()+1];
    strcpy(filename,fname.c_str());
   //qDebug()<< "Save to :"+QFilename;


    // Initialize ids and meta
    int ncid;
    int retval;// for Errors

    // Create the file
    if ((retval = nc_create(filename, NC_WRITE,&ncid)))
       ERR(retval);

    //---------------- Define Attributes ---------------------

    // --------------- Must Have -----------------------------
    // 1:save att_Core
    if ((retval = nc_put_att(ncid,NC_GLOBAL,"Core",NC_CHAR,att_Core.length(),att_Core.toLatin1().data())))
        ERR(retval);
   //qDebug()<< att_Core;

    // 2:save att_Latitude
    if ((retval = nc_put_att_double(ncid,NC_GLOBAL,"Latitude",NC_DOUBLE,1,&att_Latitude)))
        ERR(retval);
   //qDebug()<< QString::number(att_Latitude);

    // 3:save att_Longitude
    if ((retval = nc_put_att_double(ncid,NC_GLOBAL,"Longitude",NC_DOUBLE,1,&att_Longitude)))
        ERR(retval);
   //qDebug()<< QString::number(att_Longitude);

    // 4:save att_Water_Depth
    if ((retval = nc_put_att_double(ncid,NC_GLOBAL,"Water Depth",NC_DOUBLE,1,&att_Water_Depth)))
        ERR(retval);
   //qDebug()<< QString::number(att_Water_Depth);

    // 5:save att_Species
    if ((retval = nc_put_att(ncid,NC_GLOBAL,"Species",NC_CHAR,att_Species.length(),att_Species.toLatin1().data())))
        ERR(retval);
   //qDebug()<< att_Species;

    // 6:save att_Record_Type
    if ((retval = nc_put_att(ncid,NC_GLOBAL,"Record Type",NC_CHAR,att_Record_Type.length(),att_Record_Type.toLatin1().data())))
        ERR(retval);
   //qDebug()<< att_Record_Type;

    // --------------- Proxy Specific ------------------------------

    // 7:save att_Device
    if ((retval = nc_put_att(ncid,NC_GLOBAL,"Device",NC_CHAR,att_Device.length(),att_Device.toLatin1().data())))
        ERR(retval);
   //qDebug()<< att_Device;

    // 8:save att_Laboratory
    if ((retval = nc_put_att(ncid,NC_GLOBAL,"Laboratory",NC_CHAR,att_Laboratory.length(),att_Laboratory.toLatin1().data())))
        ERR(retval);
   //qDebug()<< att_Laboratory;

    // 9:save att_Instrumentation
    if ((retval = nc_put_att(ncid,NC_GLOBAL,"Instrumentation",NC_CHAR,att_Instrumentation.length(),att_Instrumentation.toLatin1().data())))
        ERR(retval);
   //qDebug()<< att_Instrumentation;

    // 10:save att_Data_Source
    if ((retval = nc_put_att(ncid,NC_GLOBAL,"Data Source",NC_CHAR,att_Data_Source.length(),att_Data_Source.toLatin1().data())))
        ERR(retval);
   //qDebug()<< att_Data_Source;

    // 11:save att_Comment
    if ((retval = nc_put_att(ncid,NC_GLOBAL,"Comment",NC_CHAR,att_Comment.length(),att_Comment.toLatin1().data())))
        ERR(retval);
   //qDebug()<< att_Comment;

    // 12:save att_Proxy_Category
    if ((retval = nc_put_att(ncid,NC_GLOBAL,"Proxy Category",NC_CHAR,att_Category.length(),att_Category.toLatin1().data())))
        ERR(retval);
   //qDebug()<< att_Category;

    // 13:save att_Reference
    if ((retval = nc_put_att(ncid,NC_GLOBAL,"Reference",NC_CHAR,att_Reference.length(),att_Reference.toLatin1().data())))
        ERR(retval);
   //qDebug()<< att_Reference;

    // 14:save att_Importer
    if ((retval = nc_put_att(ncid,NC_GLOBAL,"Importer",NC_CHAR,att_Importer.length(),att_Importer.toLatin1().data())))
        ERR(retval);
   //qDebug()<< att_Importer;

    // -------------------------- Optional -------------------------------

    // 15:save att_EPaper
    if ((retval = nc_put_att(ncid,NC_GLOBAL,"E-Paper",NC_CHAR,att_EPaper.length(),att_EPaper.toLatin1().data())))
        ERR(retval);
   //qDebug()<< att_EPaper;

    // 16:save att_Oxygen_Use_Flag
    if ((retval = nc_put_att_double(ncid,NC_GLOBAL,"Oxygen Use Flag",NC_DOUBLE,1,&att_Oxygen_Use_Flag)))
        ERR(retval);
   //qDebug()<< QString::number(att_Oxygen_Use_Flag);

    // 17:save att_Carbon_Use_Flag
    if ((retval = nc_put_att_double(ncid,NC_GLOBAL,"Carbon Use Flag",NC_DOUBLE,1,&att_Carbon_Use_Flag)))
        ERR(retval);
   //qDebug()<< QString::number(att_Carbon_Use_Flag);

    // 18:save att_O_Correction
    if ((retval = nc_put_att_double(ncid,NC_GLOBAL,"O-Correction",NC_DOUBLE,1,&att_O_Correction)))
        ERR(retval);
   //qDebug()<< QString::number(att_O_Correction);

    // 19:save att_O_Correction_Justification
    if ((retval = nc_put_att_text(ncid,NC_GLOBAL,"O-Correction Justification",att_O_Justification.length(),att_O_Justification.toLatin1().data())))
        ERR(retval);
   //qDebug()<< att_O_Justification;

    // 20:save att_C_Correction
    if ((retval = nc_put_att_double(ncid,NC_GLOBAL,"C-Correction",NC_DOUBLE,1,&att_C_Correction)))
        ERR(retval);
   //qDebug()<< QString::number(att_C_Correction);

    // 21:save att_C_Correction_Justification
    if ((retval = nc_put_att_text(ncid,NC_GLOBAL,"C-Correction Justification",att_C_Justification.length(),att_C_Justification.toLatin1().data())))
        ERR(retval);
   //qDebug()<< att_C_Justification;

    // 22:save att_Optional
    if ((retval = nc_put_att_text(ncid,NC_GLOBAL,"Optional",att_Optional.length(),att_Optional.toLatin1().data())))
        ERR(retval);
   //qDebug()<< att_Optional;

    //----------- Data Length & Variables ----------------------------

    // Add length of record
    int dimidlength=0;
    if ((retval = nc_def_dim(ncid,"Length",length,&dimidlength)))
       ERR(retval);
   //qDebug()<<"Length of Record:"+QString::number(length);

    // Define each data variable
    int dimm[1];
    dimm[0]=dimidlength;

    // Depth
    int depth;
    if ((retval = nc_def_var(ncid,"Depth",NC_DOUBLE,1,dimm,&depth)))
        ERR(retval);
   //qDebug()<< depth;

    // Sample Thickness
    int sample_thickness;
    if ((retval = nc_def_var(ncid,"Sample Thickness",NC_DOUBLE,1,dimm,&sample_thickness)))
        ERR(retval);
   //qDebug()<< sample_thickness;

    // Age
    int age;
    if ((retval = nc_def_var(ncid,"Age",NC_DOUBLE,1,dimm,&age)))
        ERR(retval);
   //qDebug()<< age;

    // d13C
    int d13C;
    if ((retval = nc_def_var(ncid,"d13C",NC_DOUBLE,1,dimm,&d13C)))
        ERR(retval);
   //qDebug()<< d13C;

    // d18O
    int d18O;
    if ((retval = nc_def_var(ncid,"d18O",NC_DOUBLE,1,dimm,&d18O)))
        ERR(retval);
   //qDebug()<< d18O;

    // d13C_Corr
    int d13C_Corr;
    if ((retval = nc_def_var(ncid,"d13C Corr",NC_DOUBLE,1,dimm,&d13C_Corr)))
        ERR(retval);
   //qDebug()<< d13C_Corr;

    // d18O_Corr
    int d18O_Corr;
    if ((retval = nc_def_var(ncid,"d18O Corr",NC_DOUBLE,1,dimm,&d18O_Corr)))
        ERR(retval);
   //qDebug()<< d18O_Corr;

    // d13C_Err
    int d13C_Err;
    if ((retval = nc_def_var(ncid,"d13C Err",NC_DOUBLE,1,dimm,&d13C_Err)))
        ERR(retval);
   //qDebug()<< d13C_Err;

    // d18O_Err
    int d18O_Err;
    if ((retval = nc_def_var(ncid,"d18O Err",NC_DOUBLE,1,dimm,&d18O_Err)))
        ERR(retval);
   //qDebug()<< d18O_Err;

    // Use Flag
    int Use_Flag;
    if ((retval = nc_def_var(ncid,"Use Flag",NC_INT,1,dimm,&Use_Flag)))
        ERR(retval);
   //qDebug()<< Use_Flag;

    // Comments
    // get maximum length of Comment

    int comment_length=0;
    for (int i=0;i<length;i++) if (comment_length<data_Comment[i]->length()) comment_length=data_Comment[i]->length();



    int dim2=0;
    if ((retval = nc_def_dim(ncid,"Character",comment_length,&dim2)))
        ERR(retval);

    int dim_com[2];
    dim_com[0]=dimidlength;
    dim_com[1]=dim2;

    int Comment;
    if ((retval = nc_def_var(ncid,"Comment",NC_CHAR,2,dim_com,&Comment)))
        ERR(retval);
   //qDebug()<< Comment;

    // end definition mode to start writing data
    if ((retval = nc_enddef(ncid)))
        ERR(retval);

    //-------------- Write Data ---------------------------
    // depth
    if ((retval = nc_put_var(ncid,depth,&data_Depth[0])))
        ERR(retval);

    // sample thickness
    if ((retval = nc_put_var(ncid,sample_thickness,&data_Sample_Thickness[0])))
        ERR(retval);

    // age
    if ((retval = nc_put_var(ncid,age,&data_Age[0])))
        ERR(retval);

    // d13C
    if ((retval = nc_put_var(ncid,d13C,&data_d13C[0])))
        ERR(retval);

    // d18O
    if ((retval = nc_put_var(ncid,d18O,&data_d18O[0])))
        ERR(retval);

    // d13C_Corr
    if ((retval = nc_put_var(ncid,d13C_Corr,&data_d13C_Corr[0])))
        ERR(retval);

    // d18O_Corr
    if ((retval = nc_put_var(ncid,d18O_Corr,&data_d18O_Corr[0])))
        ERR(retval);

    // d13C_Err
    if ((retval = nc_put_var(ncid,d13C_Err,&data_d13C_Err[0])))
        ERR(retval);

    // d18O_Err
    if ((retval = nc_put_var(ncid,d18O_Err,&data_d18O_Err[0])))
        ERR(retval);

    // Use Flag
    if ((retval = nc_put_var(ncid,Use_Flag,&data_Use_Flag[0])))
        ERR(retval);

    // Comment
    // create unsigned char field for comments
    unsigned char com[comment_length][length];
    for (int ii=0;ii<comment_length;ii++) for (int i=0;i<length;i++) com[ii][i]=' ';
    for (int i=0;i<length;i++){
        for (int j=0;j<data_Comment[i]->length();j++) com[j][i]=data_Comment[i]->toLatin1().at(j);
    }
    if ((retval = nc_put_var(ncid,Comment,&com[0][0])))
        ERR(retval);


    // Close the file, freeing all resources.
    if ((retval = nc_close(ncid)))
        ERR(retval);
   //qDebug()<<"OK";
    flag_Data_OK=1;

/*
    int dimidcol=0;
    if ((retval = nc_def_dim(ncid,"length",7,&dimidcol)))
       ERR(retval);





    // get maximum length of Comment
    int dim1=0;
    int comment_length=0;
    for (int i=0;i<length;i++) if (comment_length<data_Comments[i].length()) comment_length=data_Comments[i].length();

    if ((retval = nc_def_dim(ncid,"nochar",length,&dim1)))//WARNING nochar and rowst are switched!!!! Row and Colum vectors switched in MATLAB?
        ERR(retval);

    int dim2=0;
    if ((retval = nc_def_dim(ncid,"rowst",comment_length,&dim2)))
        ERR(retval);



    // define variables
    int varid[2];

    int dim[2];
    dim[0]=dimidrow;
    dim[1]=dimidcol;
    if ((retval = nc_def_var(ncid,"Isotopes",NC_DOUBLE,2,dim,&varid[0])))
        ERR(retval);

    int dimm[2];
    dimm[0]=dim1;
    dimm[1]=dim2;
    if ((retval = nc_def_var(ncid,"Specific Comment",NC_CHAR,2,dimm,&varid[1])))
        ERR(retval);




    // write data
    if ((retval = nc_put_var(ncid,varid[0],data_Isotopes)))
        ERR(retval);

   // create unsigned char field for comments
   unsigned char com[comment_length][length];
   for (int ii=0;ii<comment_length;ii++) for (int i=0;i<length;i++) com[ii][i]=' ';
    for (int i=0;i<length;i++){
        for (int j=0;j<data_Comments[i].length();j++) com[j][i]=data_Comments[i].toLatin1().at(j);
    }
    if ((retval = nc_put_var(ncid,varid[1],&com[0][0])))
        ERR(retval);

*/
    delete[] filename;
}

int Inventory::get_currentCore(){
    return current_Core;
}

void Inventory::set_currentCore(QString name,QString proxy){
    int found=0;
    for (int i=0;i<get_Entries();i++){
        if (name==get_Core(i) && proxy==get_Species(i)){
            current_Core=i;
            found=1;
            break;
        }
    }
    if (found==0) {
        //qDebug() << "Entry not found";
        current_Core=-1;
    }

}

void Inventory::set_currentCore(int i){
    if (i<this->get_Entries() && i>=0){
        current_Core=i;
        //qDebug()<< "Current Core:"+QString::number(current_Core);
    }else{
        //qDebug()<<"entry not existent";
    }
}

/*
//***************** Agemodel *********************************************************
void Inventory::new_Age_Model(){
    age_Model_Length=0;
    age_Model_Age=new double[0];
    age_Model_Depth=new double[0];
}

void Inventory::read_Age_Model(){
    int n=current_Core;
    if (n>=0){
    // get file name
    QString QFilename=resources.path_age+this->get_Filename(n);
    QFilename.replace(QString(".nc"),QString(".age"));
    char* filename;
    string fname=QFilename.toStdString();
    filename=new char[fname.size()+1];
    strcpy(filename,fname.c_str());
    //qDebug() << "Read from :"+QFilename;


    // Initialize ids and meta
    int ncid;
    int varid[2];
    int retval;// for Errors

    // Open the file
    if (!(retval = nc_open(filename, NC_NOWRITE, &ncid))){




    // get varid for each variable
    if ((retval = nc_inq_varid(ncid, "Age", &varid[0])))
       ERR(retval);
    if ((retval = nc_inq_varid(ncid, "Depth", &varid[1])))
       ERR(retval);


    // Get number of entires
    age_Model_Length=0;
    nc_inq_dimlen(ncid,varid[0],&age_Model_Length);
    //qDebug() << "Model Size : "+QString::number( age_Model_Length);



    // start reading ....
    // read age
    age_Model_Age=new double [age_Model_Length];
    if ((retval = nc_get_var_double(ncid,varid[0],&age_Model_Age[0]))) ERR(retval);

    // read depth
    age_Model_Depth=new double [age_Model_Length];
    if ((retval = nc_get_var_double(ncid,varid[1],&age_Model_Depth[0]))) ERR(retval);

    // Close the file, freeing all resources.
    if ((retval = nc_close(ncid)))
       ERR(retval);
    } else {

        if (nc_strerror(retval)=="No such file or directory") {
            //qDebug() << "Start generating new File...";
        } else {

           // ERR(retval);
        }
    }
    }
}

void Inventory::save_Age_Model(){
    int n=current_Core;
    if (n>=0){
    // get file name
    QString QFilename=resources.path_age+this->get_Filename(n);
    QFilename.replace(QString(".nc"),QString(".age"));
    char* filename;
    string fname=QFilename.toStdString();
    filename=new char[fname.size()+1];
    strcpy(filename,fname.c_str());
    //qDebug() << "Save to :"+QFilename;


    // Initialize ids and meta
    int ncid;
    int retval;// for Errors

    // Create the file
    if ((retval = nc_create(filename, NC_WRITE,&ncid)))
       ERR(retval);
    // length of AgeModel
    int drows=0;
    if ((retval = nc_def_dim(ncid,"record",age_Model_Length,&drows)))
       ERR(retval);
    //qDebug() << "Age Model Size"+QString::number(drows);

    // Define
    // Age
    int dimm[1];
    dimm[0]=drows;
    int age;
    if ((retval = nc_def_var(ncid,"Age",NC_DOUBLE,1,dimm,&age)))
        ERR(retval);
    //qDebug() << age;
    // Depth
    int depth;
    if ((retval = nc_def_var(ncid,"Depth",NC_DOUBLE,1,dimm,&depth)))
        ERR(retval);
    //qDebug() << depth;

    // end definition mode
    if ((retval = nc_enddef(ncid)))
        ERR(retval);

    // age
    if ((retval = nc_put_var(ncid,age,age_Model_Age)))
        ERR(retval);
    //qDebug() << "age written";

    // depth
    if ((retval = nc_put_var(ncid,depth,age_Model_Depth)))
        ERR(retval);
    //qDebug() << "depth written";

    // Close the file, freeing all resources.
    if ((retval = nc_close(ncid)))
        ERR(retval);
    }
}

void Inventory::add_Point(double depth,double age){
    // check if valid
    int ok=0;
    int pos =0;
    for (int i=0;i<age_Model_Length;i++){
        if (age_Model_Age[i]<age){
            pos++;
        } else {
            break;
        }
    }
    if (age_Model_Length==0) ok=1; // first element always ok

    if (pos>0){//if not first element
        // check previous element
        if (age_Model_Age[pos-1]<age && age_Model_Depth[pos-1]<depth){
            // check next element
            if (pos<age_Model_Length){// if not last element
                if (age_Model_Age[pos]>age && age_Model_Depth[pos]>depth) ok=1;
            } else { // if last element
                ok=1;
            }
        }
    } else {// if first element
        // check next element
        if (pos<age_Model_Length){// if not last element
            if (age_Model_Age[pos]>age && age_Model_Depth[pos]>depth) ok=1;
        } else { // if last element
            ok=1;
        }
    }


    if (ok){
        // save data
        double temp_age[age_Model_Length];
        double temp_depth[age_Model_Length];
        for (int i=0;i<age_Model_Length;i++){
            temp_age[i]=age_Model_Age[i];
            temp_depth[i]=age_Model_Depth[i];
        }
        // new Model with new length
        age_Model_Age=new double[age_Model_Length+1];
        age_Model_Depth=new double[age_Model_Length+1];
        int count=0;
        // first copy smaller elements
        for (int i=0;i<age_Model_Length;i++){
            if (temp_age[i]<age && temp_depth[i]<depth){
                age_Model_Age[count]=temp_age[i];
                age_Model_Depth[count]=temp_depth[i];
                count++;
            } else {
                break;
            }
        }
        // copy new element
        age_Model_Age[count]=age;
        age_Model_Depth[count]=depth;
        count++;
        // copy larger elements
        for (int i=0;i<age_Model_Length;i++){
            if (temp_age[i]>age && temp_depth[i]>depth){
                age_Model_Age[count]=temp_age[i];
                age_Model_Depth[count]=temp_depth[i];
                count++;
            }
        }
        age_Model_Length++;
    }
}

void Inventory::remove_Point(int n){
    if (age_Model_Length>0){
        // save data
        double temp_age[age_Model_Length-1];
        double temp_depth[age_Model_Length-1];
        int count=0;
        for (int i=0;i<age_Model_Length;i++){
            if (i!=n){
                temp_age[count]=age_Model_Age[i];
                temp_depth[count]=age_Model_Depth[i];
                count++;
            }
        }
        // new Model with new length
        age_Model_Age=new double[age_Model_Length-1];
        age_Model_Depth=new double[age_Model_Length-1];
        for (int i=0;i<age_Model_Length-1;i++){
            age_Model_Age[i]=temp_age[i];
            age_Model_Depth[i]=temp_depth[i];
        }
        age_Model_Length--;
    } else {
        new_Age_Model();
    }
}

double Inventory::get_Point_Depth(int n){
    return age_Model_Depth[n];
}

double Inventory::get_Point_Age(int n){
    return age_Model_Age[n];
}

int Inventory::get_Age_Model_Size(){
    return age_Model_Length;
}
*/
//***************** Target Data
// Data Format Triplets of: Age(kyr):Value:Error
void Inventory::readTarget(){
    // get file name
    QString QFilename=resources.path_target+"targets.nc";

    char* filename;
    string fname=QFilename.toStdString();
    filename=new char[fname.size()+1];
    strcpy(filename,fname.c_str());
    //qDebug() << QFilename;

    // Initialize ids and meta
    int ncid;
    int varid[2];
    int dimid[2]={0};
    size_t dimlen[2]={0};
    int retval;// for Errors

    // Open the file
    if ((retval = nc_open(filename, NC_NOWRITE, &ncid)))
       ERR(retval);

    // Get Number of Variables
    int ndimsp,nvarsp,nattsp,unlimdimidp;
    if ((retval = nc_inq(ncid,&ndimsp,&nvarsp,&nattsp,&unlimdimidp)))
       ERR(retval);
    //qDebug()<<QString::number(ndimsp)+":"+QString::number(nvarsp)+":"+QString::number(nattsp)+":"+QString::number(unlimdimidp);
    // read header and data
    header.clear();
    target.clear();
    header.reserve(nvarsp/2);
    target.reserve((nvarsp/2)*4);
    for (int i=0;i<nvarsp;i++){
        // read header
        // get length of header
        unsigned int len[2];
        if ((retval =nc_inq_dimlen(ncid,i*2+0,&len[0])))
            ERR(retval);
        if ((retval =nc_inq_dimlen(ncid,i*2+1,&len[1])))
            ERR(retval);
        //qDebug()<<QString::number(len[0])+":"+QString::number(len[1]);
        // read header
        unsigned char text[len[0]*len[1]];
        if ((retval = nc_get_var(ncid,i,&text[0]))) ERR(retval);
        for (unsigned int j=0;j<len[0];j++){
            QString str="";
            for (unsigned int k=0;k<len[1];k++){
                str.append(text[j+len[0]*k]);
            }

            header<<str.simplified();
            //qDebug()<<str.simplified();
        }
        // finished reading header
        i++;
        // read data
        // get length of data
        if ((retval =nc_inq_dimlen(ncid,i*2+0,&len[0])))
            ERR(retval);
        if ((retval =nc_inq_dimlen(ncid,i*2+1,&len[1])))
            ERR(retval);

        //qDebug()<<QString::number(len[0])+":"+QString::number(len[1]);
        // read data
        double d[len[0]*len[1]];
        if ((retval = nc_get_var(ncid,i,&d))) ERR(retval);
        QList<double> x1;
        x1.clear();
        x1.reserve(4*len[0]);
        for (int j=0;j<len[0];j++){
            x1.append(d[j*4+0]);
            x1.append(d[j*4+1]);
            x1.append(d[j*4+2]);
            x1.append(d[j*4+3]);
        }
        target.append(x1);

        //qDebug()<<QString::number(target[0][0])+":"+QString::number(target[0][1])+":"+QString::number(target[0][2]);
    }

    // Close the file, freeing all resources.
    if ((retval = nc_close(ncid)))
       ERR(retval);
    delete[] filename;
}

int Inventory::get_Target_Length(int i){
    return target[i].size()/4;
}

int Inventory::get_Target_Vari(){
    return target.size();
}

QString Inventory::get_Target_Name(int i){
    return header[i*4+2];
}

double Inventory::get_Target_Age(int n,int i){
    return target[i][n*4];
}

double Inventory::get_Target_Value(int n,int i){
    return target[i][n*4+2];
}

double Inventory::get_Target_Error(int n,int i){
    return target[i][n*4+3];
}

double Inventory::get_Target_Age_Error(int n,int i){
    return target[i][n*4+1];
}
/*
// Interpolation for Age Model
double Inventory::get_Int_Value_Age(double depth,QString str){
    double yy=NULL;
    if (depth>=age_Model_Depth[0] && depth<=age_Model_Depth[age_Model_Length-1]){
    if (str=="linear"){
        int i=0;
        for (i=0;i<age_Model_Length;i++) if (age_Model_Depth[i]>depth) break;
        if (i>0) yy=age_Model_Age[i-1]+(age_Model_Age[i]-age_Model_Age[i-1])/(age_Model_Depth[i]-age_Model_Depth[i-1])*(depth-age_Model_Depth[i-1]);
    }

    }
    return yy;
}

double Inventory::get_Int_Value_Depth(double age,QString str){
    double yy=NULL;
    if (age>=age_Model_Age[0] && age<=age_Model_Age[age_Model_Length-1]){

        if (str=="linear"){
            int i=0;
            for (i=0;i<age_Model_Length;i++) if (age_Model_Age[i]>age) break;
            if (i>0) yy=age_Model_Depth[i-1]+(age_Model_Depth[i]-age_Model_Depth[i-1])/(age_Model_Age[i]-age_Model_Age[i-1])*(age-age_Model_Age[i-1]);
        }


    }
    return yy;
}


void Inventory::apply_Age_Model(QString str){
    for (int i=0;i<length;i++){
        double v=get_Int_Value_Age(get_data_Isotopes(0,i),str);
        set_data_Isotopes(1,i,v);
    }
    saveData();
    save_Age_Model();
}

*/
void Inventory::read_Basin(){

    // get file name
    QString QFilename=resources.path_hydro+"basin.nc";

    char* filename;
    string fname=QFilename.toStdString();
    filename=new char[fname.size()+1];
    strcpy(filename,fname.c_str());
    //qDebug() << QFilename;


    // Initialize ids and meta
    int ncid;
    int varid;
    size_t dimlen[2]={0};
    int dimid[2]={0};
    int retval;// for Errors

    // Open the file
    if ((retval = nc_open(filename, NC_NOWRITE, &ncid)))
       ERR(retval);

    // ********  read basin dimension
    if ((retval = nc_inq_varid(ncid, "Ocean Basin", &varid)))
       ERR(retval);
    // get info for sizes
    if ((retval = nc_inq_dimid(ncid, "Latitude", &dimid[0])))
       ERR(retval);
    if ((retval = nc_inq_dimlen(ncid, dimid[0], &dimlen[0])))
       ERR(retval);
    if ((retval = nc_inq_dimid(ncid, "Longitude", &dimid[1])))
       ERR(retval);
    if ((retval = nc_inq_dimlen(ncid, dimid[1], &dimlen[1])))
       ERR(retval);
    basin_lat=dimlen[0];
    basin_lon=dimlen[1];
    // read basin
    basin_data=new double[(basin_lon)*(basin_lat)];
    if ((retval = nc_get_var_double(ncid,varid,&basin_data[0]))) ERR(retval);


    // Close the file, freeing all resources.
    if ((retval = nc_close(ncid)))
       ERR(retval);
    delete[] filename;
}

int Inventory::get_Basin(float lon,float lat){
    int basin=0;
    if (lon<0) lon=360+lon;

    lat=lat+90;
    int x=(int)lon;
    int y=(int)lat;
    basin=basin_data[x+y*basin_lon];
    // if on land look for sourondings
    if (basin==-100 && x+1<360) basin=basin_data[(x+1)+y*basin_lon];
    if (basin==-100 && x-1>=0) basin=basin_data[(x-1)+y*basin_lon];
    if (basin==-100 && y+1<180) basin=basin_data[x+(y+1)*basin_lon];
    if (basin==-100 && y-1>=0) basin=basin_data[x+(y-1)*basin_lon];
    return basin;
}

QString Inventory::get_Basinname(float lon,float lat){
    int basin=0;
    if(lon<0) lon=360+lon;
    lat=lat+90;
    int x=(int)lon;
    int y=(int)lat;
    basin=basin_data[x+y*basin_lon];
    QString basinname="NA";
    if (basin==1) basinname="Atlantic Ocean";
    if (basin==2) basinname="Pacific Ocean";
    if (basin==3) basinname="Indic Ocean";
    if (basin==4) basinname="Mediteranian Sea";
    if (basin==5) basinname="Baltic Sea";
    if (basin==6) basinname="Black Sea";
    if (basin==7) basinname="Red Sea";
    if (basin==8) basinname="Persian Gulf";
    if (basin==9) basinname="Hudson Bay";
    if (basin==10) basinname="Antarctic Ocean";
    if (basin==11) basinname="Arctic Ocean";
    if (basin==53) basinname="Caspian Sea";
    if (basin==56) basinname="Bay of Bengal";
    if (basin==-100) basinname="On Land!";
    return basinname;
}

QString Inventory::get_Basinname(int basin){
    QString basinname="NA";
    if (basin==1) basinname="Atlantic Ocean";
    if (basin==2) basinname="Pacific Ocean";
    if (basin==3) basinname="Indic Ocean";
    if (basin==4) basinname="Mediteranian Sea";
    if (basin==5) basinname="Baltic Sea";
    if (basin==6) basinname="Black Sea";
    if (basin==7) basinname="Red Sea";
    if (basin==8) basinname="Persian Gulf";
    if (basin==9) basinname="Hudson Bay";
    if (basin==10) basinname="Antarctic Ocean";
    if (basin==11) basinname="Arctic Ocean";
    if (basin==53) basinname="Caspian Sea";
    if (basin==56) basinname="Bay of Bengal";
    if (basin==-100) basinname="On Land!";
    return basinname;
}
