#ifndef AMSALL_H
#define AMSALL_H

#include <QDialog>
#include <QDebug>
#include <QMainWindow>
#include <QStandardItemModel>
#include "General/inventory.h"
#include "amsdata.h"
#include "calibplot.h"
#include "General/resources.h"
#include <QFileDialog>
#include "Dialog/attdialog.h"
#include "amsedit.h"
#include "Editor/graph.h"
#include "Bacon/bacon.h"
#include <QApplication>

namespace Ui {
class AMSAll;
}

class AMSAll : public QDialog
{
    Q_OBJECT

public:
    explicit AMSAll(QMainWindow *mainWindow,Inventory *inventory);
    ~AMSAll();
    void checkReversals();
    void calibrateAll();

private slots:
    void set_CalibData();
    void start();
signals:
    void refresh();

private:
    Ui::AMSAll *ui;
    QMainWindow *mainW;
    Inventory *inv;
    AMSData *amsdata;

    Resources *resources;

};

#endif // AMSALL_H
