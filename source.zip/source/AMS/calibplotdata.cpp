/********************************************************************************/
/*    This file is part of PaleoDataViewer.                       					*/
/*                                                                      		*/
/*    PaleoDataViewer is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoDataViewer is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoDataViewer.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#include "calibplotdata.h"

CalibPlotData::CalibPlotData(QGraphicsScene *graphScene)
    : graph(graphScene)
{
    plot_Size_X=100;
    plot_Size_Y=100;
    textsize=10;
    titelsize=0;
    margin=5;
    x_min=-1;
    x_max=1;
    y_min=-1;
    y_max=1;
    x_axis=0;
    y_axis=1;
    selected=-1;
    select_Rect=0;
    sel_x1=0;
    sel_x2=0;
    sel_y1=0;
    sel_y2=0;
    factor_x=1;
    factor_y=-1;
    valid=false;
}

CalibPlotData::~CalibPlotData(){

}

void CalibPlotData::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget){
if (amsdata->get_Length()>0){
    {
        // draw dated Age lines
        int oldx = 0, oldy = 0;
        double linex = 0, liney = 0, oldlinex = 0, oldliney = 0;
        bool nofirst=1;
        for (int i=0;i<amsdata->get_Calib_Length();i++){



            // get x and y cooridinates
            int x = (int) (-plot_Size_X/2+4*textsize+margin + (double) (plot_Size_X-2*margin-4*textsize) * (double) (((amsdata->get_cage(i)*factor_x) - x_min) / (x_max - x_min)));
            int y = (int) (-plot_Size_Y/2+titelsize+margin + (double) (plot_Size_Y-2*margin-4*textsize-titelsize) * (double) ((y_max - (amsdata->get_dage(i)*factor_y)) / (y_max - y_min)));
            if (nofirst){
                oldx=x;
                oldy=y;
                nofirst=false;
            }
           // draw line
               if (i > 0) {
                       linex = x;
                       liney = y;
                       oldlinex = oldx;
                       oldliney = oldy;
                       double slope = 0;
                       if (linex - oldlinex != 0 && liney - oldliney != 0) {
                           slope = (liney - oldliney) / (linex - oldlinex);
                       } else {
                           if (linex - oldlinex == 0) {
                               slope = 999999999;
                           }
                           if (liney - oldliney == 0) {
                               slope = 0;
                           }
                       }
                       double offset = (liney - (linex * slope));

                       int c = 0;
                       while ((((linex < -plot_Size_X/2+4*textsize+margin)
                               || (liney < -plot_Size_Y/2+titelsize+margin)
                               || (linex > plot_Size_X/2-margin)
                               || (liney > plot_Size_Y/2-margin-4*textsize))
                               || ((oldlinex < -plot_Size_X/2+4*textsize+margin)
                               || (oldliney < -plot_Size_Y/2+titelsize+margin)
                               || (oldlinex > plot_Size_X/2-margin)
                               || (oldliney > plot_Size_Y/2-margin-4*textsize)))
                               && c < 3) {
                           if (linex < -plot_Size_X/2+4*textsize+margin) {
                               linex = -plot_Size_X/2+4*textsize+margin + 1;
                               liney = ((linex * slope) + offset);
                           }
                           if (linex >  plot_Size_X/2-margin) {
                               linex = plot_Size_X/2-margin - 1;
                               liney = ((linex * slope) + offset);
                           }
                           if (liney < -plot_Size_Y/2+titelsize+margin) {
                               liney = -plot_Size_Y/2+titelsize+margin + 1;
                               linex = ((liney - offset) / slope);
                           }
                           if (liney > plot_Size_Y/2-margin-4*textsize) {
                               liney = plot_Size_Y/2-margin-4*textsize - 1;
                               linex = ((liney - offset) / slope);
                           }
                           if (oldlinex < -plot_Size_X/2+4*textsize+margin) {
                               oldlinex = -plot_Size_X/2+4*textsize+margin + 1;
                               oldliney = ((oldlinex * slope) + offset);
                           }
                           if (oldlinex > plot_Size_X/2-margin) {
                               oldlinex = plot_Size_X/2-margin - 1;
                               oldliney = ((oldlinex * slope) + offset);
                           }
                           if (oldliney < -plot_Size_Y/2+titelsize+margin) {
                               oldliney = -plot_Size_Y/2+titelsize+margin + 1;
                               oldlinex = ((oldliney - offset) / slope);
                           }
                           if (oldliney > plot_Size_Y/2-margin-4*textsize) {
                               oldliney = plot_Size_Y/2-margin-4*textsize - 1;
                               oldlinex = ((oldliney - offset) / slope);
                           }
                           c++;
                       }
                       if (linex != oldlinex || liney != oldliney) {
                           if ((linex >= -plot_Size_X/2+4*textsize+margin)
                                   && (liney >= -plot_Size_Y/2+titelsize+margin)
                                   && (linex <= plot_Size_X/2-margin)
                                   && (liney <= plot_Size_Y/2-4*textsize-margin)
                                   && (oldlinex >= -plot_Size_X/2+4*textsize+margin)
                                   && (oldliney >= -plot_Size_Y/2+titelsize+margin)
                                   && (oldlinex <= plot_Size_X/2-margin)
                                   && (oldliney <= plot_Size_Y/2-4*textsize-margin)) {

                               QPen pen;
                               pen.setWidth(1);
                               pen.setColor(Qt::black);
                               pen.setStyle(Qt::SolidLine);
                               painter->setPen(pen);
                               painter->setRenderHint(QPainter::Antialiasing,true);
                               if (valid) painter->drawLine((int) linex, (int) liney, (int) oldlinex, (int) oldliney);
                               painter->setRenderHint(QPainter::Antialiasing,false);
                           }
                       }
               }
           oldx = x;
           oldy = y;

        }
    }

    {
        // draw dated Age+error lines
        int oldx = 0, oldy = 0;
        double linex = 0, liney = 0, oldlinex = 0, oldliney = 0;
        bool nofirst=1;
        for (int i=0;i<amsdata->get_Calib_Length();i++){



            // get x and y cooridinates
            int x = (int) (-plot_Size_X/2+4*textsize+margin + (double) (plot_Size_X-2*margin-4*textsize) * (double) (((amsdata->get_cage(i)*factor_x) - x_min) / (x_max - x_min)));
            int y = (int) (-plot_Size_Y/2+titelsize+margin + (double) (plot_Size_Y-2*margin-4*textsize-titelsize) * (double) ((y_max - (amsdata->get_dage(i)+amsdata->get_uage(i)*factor_y)) / (y_max - y_min)));
            if (nofirst){
                oldx=x;
                oldy=y;
                nofirst=false;
            }
           // draw line
               if (i > 0) {
                       linex = x;
                       liney = y;
                       oldlinex = oldx;
                       oldliney = oldy;
                       double slope = 0;
                       if (linex - oldlinex != 0 && liney - oldliney != 0) {
                           slope = (liney - oldliney) / (linex - oldlinex);
                       } else {
                           if (linex - oldlinex == 0) {
                               slope = 999999999;
                           }
                           if (liney - oldliney == 0) {
                               slope = 0;
                           }
                       }
                       double offset = (liney - (linex * slope));

                       int c = 0;
                       while ((((linex < -plot_Size_X/2+4*textsize+margin)
                               || (liney < -plot_Size_Y/2+titelsize+margin)
                               || (linex > plot_Size_X/2-margin)
                               || (liney > plot_Size_Y/2-margin-4*textsize))
                               || ((oldlinex < -plot_Size_X/2+4*textsize+margin)
                               || (oldliney < -plot_Size_Y/2+titelsize+margin)
                               || (oldlinex > plot_Size_X/2-margin)
                               || (oldliney > plot_Size_Y/2-margin-4*textsize)))
                               && c < 3) {
                           if (linex < -plot_Size_X/2+4*textsize+margin) {
                               linex = -plot_Size_X/2+4*textsize+margin + 1;
                               liney = ((linex * slope) + offset);
                           }
                           if (linex >  plot_Size_X/2-margin) {
                               linex = plot_Size_X/2-margin - 1;
                               liney = ((linex * slope) + offset);
                           }
                           if (liney < -plot_Size_Y/2+titelsize+margin) {
                               liney = -plot_Size_Y/2+titelsize+margin + 1;
                               linex = ((liney - offset) / slope);
                           }
                           if (liney > plot_Size_Y/2-margin-4*textsize) {
                               liney = plot_Size_Y/2-margin-4*textsize - 1;
                               linex = ((liney - offset) / slope);
                           }
                           if (oldlinex < -plot_Size_X/2+4*textsize+margin) {
                               oldlinex = -plot_Size_X/2+4*textsize+margin + 1;
                               oldliney = ((oldlinex * slope) + offset);
                           }
                           if (oldlinex > plot_Size_X/2-margin) {
                               oldlinex = plot_Size_X/2-margin - 1;
                               oldliney = ((oldlinex * slope) + offset);
                           }
                           if (oldliney < -plot_Size_Y/2+titelsize+margin) {
                               oldliney = -plot_Size_Y/2+titelsize+margin + 1;
                               oldlinex = ((oldliney - offset) / slope);
                           }
                           if (oldliney > plot_Size_Y/2-margin-4*textsize) {
                               oldliney = plot_Size_Y/2-margin-4*textsize - 1;
                               oldlinex = ((oldliney - offset) / slope);
                           }
                           c++;
                       }
                       if (linex != oldlinex || liney != oldliney) {
                           if ((linex >= -plot_Size_X/2+4*textsize+margin)
                                   && (liney >= -plot_Size_Y/2+titelsize+margin)
                                   && (linex <= plot_Size_X/2-margin)
                                   && (liney <= plot_Size_Y/2-4*textsize-margin)
                                   && (oldlinex >= -plot_Size_X/2+4*textsize+margin)
                                   && (oldliney >= -plot_Size_Y/2+titelsize+margin)
                                   && (oldlinex <= plot_Size_X/2-margin)
                                   && (oldliney <= plot_Size_Y/2-4*textsize-margin)) {

                               QPen pen;
                               pen.setWidth(1);
                               pen.setColor(Qt::gray);
                               pen.setStyle(Qt::DashLine);
                               painter->setPen(pen);
                               painter->setRenderHint(QPainter::Antialiasing,true);
                               if (valid) painter->drawLine((int) linex, (int) liney, (int) oldlinex, (int) oldliney);
                               painter->setRenderHint(QPainter::Antialiasing,false);
                           }
                       }
               }
           oldx = x;
           oldy = y;

        }
    }

    {
        // draw dated Age-error lines
        int oldx = 0, oldy = 0;
        double linex = 0, liney = 0, oldlinex = 0, oldliney = 0;
        bool nofirst=1;
        for (int i=0;i<amsdata->get_Calib_Length();i++){



            // get x and y cooridinates
            int x = (int) (-plot_Size_X/2+4*textsize+margin + (double) (plot_Size_X-2*margin-4*textsize) * (double) (((amsdata->get_cage(i)*factor_x) - x_min) / (x_max - x_min)));
            int y = (int) (-plot_Size_Y/2+titelsize+margin + (double) (plot_Size_Y-2*margin-4*textsize-titelsize) * (double) ((y_max - (amsdata->get_dage(i)-amsdata->get_uage(i)*factor_y)) / (y_max - y_min)));
            if (nofirst){
                oldx=x;
                oldy=y;
                nofirst=false;
            }
           // draw line
               if (i > 0) {
                       linex = x;
                       liney = y;
                       oldlinex = oldx;
                       oldliney = oldy;
                       double slope = 0;
                       if (linex - oldlinex != 0 && liney - oldliney != 0) {
                           slope = (liney - oldliney) / (linex - oldlinex);
                       } else {
                           if (linex - oldlinex == 0) {
                               slope = 999999999;
                           }
                           if (liney - oldliney == 0) {
                               slope = 0;
                           }
                       }
                       double offset = (liney - (linex * slope));

                       int c = 0;
                       while ((((linex < -plot_Size_X/2+4*textsize+margin)
                               || (liney < -plot_Size_Y/2+titelsize+margin)
                               || (linex > plot_Size_X/2-margin)
                               || (liney > plot_Size_Y/2-margin-4*textsize))
                               || ((oldlinex < -plot_Size_X/2+4*textsize+margin)
                               || (oldliney < -plot_Size_Y/2+titelsize+margin)
                               || (oldlinex > plot_Size_X/2-margin)
                               || (oldliney > plot_Size_Y/2-margin-4*textsize)))
                               && c < 3) {
                           if (linex < -plot_Size_X/2+4*textsize+margin) {
                               linex = -plot_Size_X/2+4*textsize+margin + 1;
                               liney = ((linex * slope) + offset);
                           }
                           if (linex >  plot_Size_X/2-margin) {
                               linex = plot_Size_X/2-margin - 1;
                               liney = ((linex * slope) + offset);
                           }
                           if (liney < -plot_Size_Y/2+titelsize+margin) {
                               liney = -plot_Size_Y/2+titelsize+margin + 1;
                               linex = ((liney - offset) / slope);
                           }
                           if (liney > plot_Size_Y/2-margin-4*textsize) {
                               liney = plot_Size_Y/2-margin-4*textsize - 1;
                               linex = ((liney - offset) / slope);
                           }
                           if (oldlinex < -plot_Size_X/2+4*textsize+margin) {
                               oldlinex = -plot_Size_X/2+4*textsize+margin + 1;
                               oldliney = ((oldlinex * slope) + offset);
                           }
                           if (oldlinex > plot_Size_X/2-margin) {
                               oldlinex = plot_Size_X/2-margin - 1;
                               oldliney = ((oldlinex * slope) + offset);
                           }
                           if (oldliney < -plot_Size_Y/2+titelsize+margin) {
                               oldliney = -plot_Size_Y/2+titelsize+margin + 1;
                               oldlinex = ((oldliney - offset) / slope);
                           }
                           if (oldliney > plot_Size_Y/2-margin-4*textsize) {
                               oldliney = plot_Size_Y/2-margin-4*textsize - 1;
                               oldlinex = ((oldliney - offset) / slope);
                           }
                           c++;
                       }
                       if (linex != oldlinex || liney != oldliney) {
                           if ((linex >= -plot_Size_X/2+4*textsize+margin)
                                   && (liney >= -plot_Size_Y/2+titelsize+margin)
                                   && (linex <= plot_Size_X/2-margin)
                                   && (liney <= plot_Size_Y/2-4*textsize-margin)
                                   && (oldlinex >= -plot_Size_X/2+4*textsize+margin)
                                   && (oldliney >= -plot_Size_Y/2+titelsize+margin)
                                   && (oldlinex <= plot_Size_X/2-margin)
                                   && (oldliney <= plot_Size_Y/2-4*textsize-margin)) {

                               QPen pen;
                               pen.setWidth(1);
                               pen.setColor(Qt::gray);
                               pen.setStyle(Qt::DashLine);
                               painter->setPen(pen);
                               painter->setRenderHint(QPainter::Antialiasing,true);
                               if (valid) painter->drawLine((int) linex, (int) liney, (int) oldlinex, (int) oldliney);
                               painter->setRenderHint(QPainter::Antialiasing,false);
                           }
                       }
               }
           oldx = x;
           oldy = y;

        }
    }



    // draw lines for data
    for (int i=0;i<amsdata->get_Calib_Length();i++){
        // get x and y cooridinates
       int x = (int) (-plot_Size_X/2+4*textsize+margin + (double) (plot_Size_X-2*margin-4*textsize) * (double) (((amsdata->get_cage(i)*factor_x) - x_min) / (x_max - x_min)));
       int y = (int) (-plot_Size_Y/2+titelsize+margin + (double) (plot_Size_Y-2*margin-4*textsize-titelsize) * (double) ((y_max - (amsdata->get_dage(i)*factor_y)) / (y_max - y_min)));

       // draw error range
       int y1=(int) (-plot_Size_Y/2+titelsize+margin + (double) (plot_Size_Y-2*margin-4*textsize-titelsize) * (double) ((y_max - (amsdata->get_dage(i)+amsdata->get_uage(i)*factor_y)) / (y_max - y_min)));
       int y2=(int) (-plot_Size_Y/2+titelsize+margin + (double) (plot_Size_Y-2*margin-4*textsize-titelsize) * (double) ((y_max - (amsdata->get_dage(i)-amsdata->get_uage(i)*factor_y)) / (y_max - y_min)));
       if (x>=-plot_Size_X/2+4*textsize+margin && x<=plot_Size_X/2-margin && y1<=plot_Size_Y/2-4*textsize-margin && y2>=-plot_Size_Y/2+titelsize+margin){
           if (y1<=-plot_Size_Y/2+titelsize+margin) y1=-plot_Size_Y/2+titelsize+margin;
           if (y2>=plot_Size_Y/2-4*textsize-margin) y2=plot_Size_Y/2-4*textsize-margin;
           if (valid) painter->drawLine(x,y1,x,y2);
       }
    }

    // draw dated values
    // for mean only
    {
    int y_value=(int) (-plot_Size_Y/2+titelsize+margin + (double) (plot_Size_Y-2*margin-4*textsize-titelsize) * (double) ((y_max - (value*factor_y)) / (y_max - y_min)));
    int c=0;
    for (c=0;c<amsdata->get_Calib_Length();c++) if (amsdata->get_dage(c)>value) break;

    cvalue=amsdata->get_cage(c-1)+((amsdata->get_cage(c)-amsdata->get_cage(c-1))/(amsdata->get_dage(c)-amsdata->get_dage(c-1)))*(value-amsdata->get_dage(c-1));

    int x_value=(int) (-plot_Size_X/2+4*textsize+margin + (double) (plot_Size_X-2*margin-4*textsize) * (double) (((cvalue*factor_x) - x_min) / (x_max - x_min)));

    QPen pen;
    pen.setWidth(2);
    pen.setColor(Qt::red);
    pen.setStyle(Qt::DashLine);
    painter->setPen(pen);
    if (valid) painter->drawLine(-plot_Size_X/2+4*textsize+margin,y_value,x_value,y_value);
    if (valid) painter->drawLine(x_value,y_value,x_value,plot_Size_Y/2-4*textsize-margin);
    }
    // for UCL only
    {
    int y_value=(int) (-plot_Size_Y/2+titelsize+margin + (double) (plot_Size_Y-2*margin-4*textsize-titelsize) * (double) ((y_max - ((value+valuep*3)*factor_y)) / (y_max - y_min)));
    int c=amsdata->get_Calib_Length()-1;
    for (c=amsdata->get_Calib_Length()-1;c>=0;c--) if (amsdata->get_dage(c)<(value+valuep*3)) break;

    cvaluep=amsdata->get_cage(c)+((amsdata->get_cage(c+1)-amsdata->get_cage(c))/(amsdata->get_dage(c+1)-amsdata->get_dage(c)))*((value+valuep*3)-amsdata->get_dage(c));
    int x_value=(int) (-plot_Size_X/2+4*textsize+margin + (double) (plot_Size_X-2*margin-4*textsize) * (double) (((cvaluep*factor_x) - x_min) / (x_max - x_min)));

    QPen pen;
    pen.setWidth(2);
    pen.setColor(Qt::red);
    pen.setStyle(Qt::DashDotLine);
    painter->setPen(pen);
    if (valid) painter->drawLine(-plot_Size_X/2+4*textsize+margin,y_value,x_value,y_value);
    if (valid) painter->drawLine(x_value,y_value,x_value,plot_Size_Y/2-4*textsize-margin);
    }
    // for LCL only
    {
    int y_value=(int) (-plot_Size_Y/2+titelsize+margin + (double) (plot_Size_Y-2*margin-4*textsize-titelsize) * (double) ((y_max - ((value-valuem*3)*factor_y)) / (y_max - y_min)));
    int c=0;
    for (c=0;c<amsdata->get_Calib_Length();c++) if (amsdata->get_dage(c)>(value-valuem*3)) break;

    cvaluem=amsdata->get_cage(c-1)+((amsdata->get_cage(c)-amsdata->get_cage(c-1))/(amsdata->get_dage(c)-amsdata->get_dage(c-1)))*((value-valuem*3)-amsdata->get_dage(c-1));
    int x_value=(int) (-plot_Size_X/2+4*textsize+margin + (double) (plot_Size_X-2*margin-4*textsize) * (double) (((cvaluem*factor_x) - x_min) / (x_max - x_min)));

    QPen pen;
    pen.setWidth(2);
    pen.setColor(Qt::red);
    pen.setStyle(Qt::DashDotLine);
    painter->setPen(pen);
    if (valid) painter->drawLine(-plot_Size_X/2+4*textsize+margin,y_value,x_value,y_value);
    if (valid) painter->drawLine(x_value,y_value,x_value,plot_Size_Y/2-4*textsize-margin);
    }




    // Calculate/Draw PDFs

    {
        // draw dated Age PDF
        int oldx = 0, oldy = 0;
        double linex = 0, liney = 0, oldlinex = 0, oldliney = 0;
        bool nofirst=1;
        float pdf_max=amsdata->get_DPDF(value,valuep,value);

        for (double i=y_min;i<y_max;i=i+(y_max-y_min)/(plot_Size_Y-2*margin-4*textsize-titelsize)){



            // get x and y cooridinates

            float v=amsdata->get_DPDF(value,valuep,i)/pdf_max*(x_max-x_min)*0.2;
            int x = (int) (-plot_Size_X/2+4*textsize+margin + (double) (plot_Size_X-2*margin-4*textsize) * (double) ((((x_min+v)*factor_x) - x_min) / (x_max - x_min)));
            int y = (int) (-plot_Size_Y/2+titelsize+margin + (double) (plot_Size_Y-2*margin-4*textsize-titelsize) * (double) ((y_max - (i*factor_y)) / (y_max - y_min)));
            if (nofirst){
                oldx=x;
                oldy=y;
                nofirst=false;
            }
           // draw line
               if (i > 0) {
                       linex = x;
                       liney = y;
                       oldlinex = oldx;
                       oldliney = oldy;
                       double slope = 0;
                       if (linex - oldlinex != 0 && liney - oldliney != 0) {
                           slope = (liney - oldliney) / (linex - oldlinex);
                       } else {
                           if (linex - oldlinex == 0) {
                               slope = 999999999;
                           }
                           if (liney - oldliney == 0) {
                               slope = 0;
                           }
                       }
                       double offset = (liney - (linex * slope));

                       int c = 0;
                       while ((((linex < -plot_Size_X/2+4*textsize+margin)
                               || (liney < -plot_Size_Y/2+titelsize+margin)
                               || (linex > plot_Size_X/2-margin)
                               || (liney > plot_Size_Y/2-margin-4*textsize))
                               || ((oldlinex < -plot_Size_X/2+4*textsize+margin)
                               || (oldliney < -plot_Size_Y/2+titelsize+margin)
                               || (oldlinex > plot_Size_X/2-margin)
                               || (oldliney > plot_Size_Y/2-margin-4*textsize)))
                               && c < 3) {
                           if (linex < -plot_Size_X/2+4*textsize+margin) {
                               linex = -plot_Size_X/2+4*textsize+margin + 1;
                               liney = ((linex * slope) + offset);
                           }
                           if (linex >  plot_Size_X/2-margin) {
                               linex = plot_Size_X/2-margin - 1;
                               liney = ((linex * slope) + offset);
                           }
                           if (liney < -plot_Size_Y/2+titelsize+margin) {
                               liney = -plot_Size_Y/2+titelsize+margin + 1;
                               linex = ((liney - offset) / slope);
                           }
                           if (liney > plot_Size_Y/2-margin-4*textsize) {
                               liney = plot_Size_Y/2-margin-4*textsize - 1;
                               linex = ((liney - offset) / slope);
                           }
                           if (oldlinex < -plot_Size_X/2+4*textsize+margin) {
                               oldlinex = -plot_Size_X/2+4*textsize+margin + 1;
                               oldliney = ((oldlinex * slope) + offset);
                           }
                           if (oldlinex > plot_Size_X/2-margin) {
                               oldlinex = plot_Size_X/2-margin - 1;
                               oldliney = ((oldlinex * slope) + offset);
                           }
                           if (oldliney < -plot_Size_Y/2+titelsize+margin) {
                               oldliney = -plot_Size_Y/2+titelsize+margin + 1;
                               oldlinex = ((oldliney - offset) / slope);
                           }
                           if (oldliney > plot_Size_Y/2-margin-4*textsize) {
                               oldliney = plot_Size_Y/2-margin-4*textsize - 1;
                               oldlinex = ((oldliney - offset) / slope);
                           }
                           c++;
                       }
                       if (linex != oldlinex || liney != oldliney) {
                           if ((linex >= -plot_Size_X/2+4*textsize+margin)
                                   && (liney >= -plot_Size_Y/2+titelsize+margin)
                                   && (linex <= plot_Size_X/2-margin)
                                   && (liney <= plot_Size_Y/2-4*textsize-margin)
                                   && (oldlinex >= -plot_Size_X/2+4*textsize+margin)
                                   && (oldliney >= -plot_Size_Y/2+titelsize+margin)
                                   && (oldlinex <= plot_Size_X/2-margin)
                                   && (oldliney <= plot_Size_Y/2-4*textsize-margin)) {

                               QPen pen;
                               pen.setWidth(1);
                               pen.setColor(Qt::blue);
                               pen.setStyle(Qt::SolidLine);
                               painter->setPen(pen);
                               painter->setRenderHint(QPainter::Antialiasing,true);
                               if (valid) painter->drawLine((int) linex, (int) liney, (int) oldlinex, (int) oldliney);
                               painter->setRenderHint(QPainter::Antialiasing,false);
                           }
                       }
               }
           oldx = x;
           oldy = y;

        }
    }

    {
        // draw calender Age PDF
        int oldx = 0, oldy = 0;
        double linex = 0, liney = 0, oldlinex = 0, oldliney = 0;
        bool nofirst=1;

        amsdata->calc_CalPDF(value,valuep);

        for (double i=0;i<amsdata->get_Calib_Length();i++){



            // get x and y cooridinates

            float v=amsdata->get_CalPDF(i)/amsdata->get_CalPDF_max()*(y_max-y_min)*0.2;
            int x = (int) (-plot_Size_X/2+4*textsize+margin + (double) (plot_Size_X-2*margin-4*textsize) * (double) (((amsdata->get_cage(i)*factor_x) - x_min) / (x_max - x_min)));
            int y = (int) (-plot_Size_Y/2+titelsize+margin + (double) (plot_Size_Y-2*margin-4*textsize-titelsize) * (double) ((y_max - ((y_min+v)*factor_y)) / (y_max - y_min)));
            if (nofirst){
                oldx=x;
                oldy=y;
                nofirst=false;
            }
           // draw line
               if (i > 0) {
                       linex = x;
                       liney = y;
                       oldlinex = oldx;
                       oldliney = oldy;
                       double slope = 0;
                       if (linex - oldlinex != 0 && liney - oldliney != 0) {
                           slope = (liney - oldliney) / (linex - oldlinex);
                       } else {
                           if (linex - oldlinex == 0) {
                               slope = 999999999;
                           }
                           if (liney - oldliney == 0) {
                               slope = 0;
                           }
                       }
                       double offset = (liney - (linex * slope));

                       int c = 0;
                       while ((((linex < -plot_Size_X/2+4*textsize+margin)
                               || (liney < -plot_Size_Y/2+titelsize+margin)
                               || (linex > plot_Size_X/2-margin)
                               || (liney > plot_Size_Y/2-margin-4*textsize))
                               || ((oldlinex < -plot_Size_X/2+4*textsize+margin)
                               || (oldliney < -plot_Size_Y/2+titelsize+margin)
                               || (oldlinex > plot_Size_X/2-margin)
                               || (oldliney > plot_Size_Y/2-margin-4*textsize)))
                               && c < 3) {
                           if (linex < -plot_Size_X/2+4*textsize+margin) {
                               linex = -plot_Size_X/2+4*textsize+margin + 1;
                               liney = ((linex * slope) + offset);
                           }
                           if (linex >  plot_Size_X/2-margin) {
                               linex = plot_Size_X/2-margin - 1;
                               liney = ((linex * slope) + offset);
                           }
                           if (liney < -plot_Size_Y/2+titelsize+margin) {
                               liney = -plot_Size_Y/2+titelsize+margin + 1;
                               linex = ((liney - offset) / slope);
                           }
                           if (liney > plot_Size_Y/2-margin-4*textsize) {
                               liney = plot_Size_Y/2-margin-4*textsize - 1;
                               linex = ((liney - offset) / slope);
                           }
                           if (oldlinex < -plot_Size_X/2+4*textsize+margin) {
                               oldlinex = -plot_Size_X/2+4*textsize+margin + 1;
                               oldliney = ((oldlinex * slope) + offset);
                           }
                           if (oldlinex > plot_Size_X/2-margin) {
                               oldlinex = plot_Size_X/2-margin - 1;
                               oldliney = ((oldlinex * slope) + offset);
                           }
                           if (oldliney < -plot_Size_Y/2+titelsize+margin) {
                               oldliney = -plot_Size_Y/2+titelsize+margin + 1;
                               oldlinex = ((oldliney - offset) / slope);
                           }
                           if (oldliney > plot_Size_Y/2-margin-4*textsize) {
                               oldliney = plot_Size_Y/2-margin-4*textsize - 1;
                               oldlinex = ((oldliney - offset) / slope);
                           }
                           c++;
                       }
                       if (linex != oldlinex || liney != oldliney) {
                           if ((linex >= -plot_Size_X/2+4*textsize+margin)
                                   && (liney >= -plot_Size_Y/2+titelsize+margin)
                                   && (linex <= plot_Size_X/2-margin)
                                   && (liney <= plot_Size_Y/2-4*textsize-margin)
                                   && (oldlinex >= -plot_Size_X/2+4*textsize+margin)
                                   && (oldliney >= -plot_Size_Y/2+titelsize+margin)
                                   && (oldlinex <= plot_Size_X/2-margin)
                                   && (oldliney <= plot_Size_Y/2-4*textsize-margin)) {

                               QPen pen;
                               pen.setWidth(1);
                               pen.setColor(Qt::blue);
                               pen.setStyle(Qt::SolidLine);
                               painter->setPen(pen);
                               painter->setRenderHint(QPainter::Antialiasing,true);
                               if (valid) painter->drawLine((int) linex, (int) liney, (int) oldlinex, (int) oldliney);
                               painter->setRenderHint(QPainter::Antialiasing,false);
                           }
                       }
               }
           oldx = x;
           oldy = y;

        }
    }
    //More Statistical Values
    amsdata->calc_intPDF();
    amsdata->sortInt();

    // draw calibrated values
    float v=(y_max-y_min)*0.2;
    int y_value = (int) (-plot_Size_Y/2+titelsize+margin + (double) (plot_Size_Y-2*margin-4*textsize-titelsize) * (double) ((y_max - ((y_min+v)*factor_y)) / (y_max - y_min)));
    // for wmean only
    {
    int x_value=(int) (-plot_Size_X/2+4*textsize+margin + (double) (plot_Size_X-2*margin-4*textsize) * (double) (((amsdata->get_CalWMean()*factor_x) - x_min) / (x_max - x_min)));

    QPen pen;
    pen.setWidth(2);
    pen.setColor(Qt::green);
    pen.setStyle(Qt::DashLine);
    painter->setPen(pen);

    if (valid) painter->drawLine(x_value,y_value,x_value,plot_Size_Y/2-4*textsize-margin);
    }
    // for UCL only
    {
    int x_value=(int) (-plot_Size_X/2+4*textsize+margin + (double) (plot_Size_X-2*margin-4*textsize) * (double) (((amsdata->get_Cal95U()*factor_x) - x_min) / (x_max - x_min)));

    QPen pen;
    pen.setWidth(2);
    pen.setColor(Qt::green);
    pen.setStyle(Qt::DashDotLine);
    painter->setPen(pen);

    if (valid) painter->drawLine(x_value,y_value,x_value,plot_Size_Y/2-4*textsize-margin);
    }
    // for LCL only
    {
    int x_value=(int) (-plot_Size_X/2+4*textsize+margin + (double) (plot_Size_X-2*margin-4*textsize) * (double) (((amsdata->get_Cal95L()*factor_x) - x_min) / (x_max - x_min)));

    QPen pen;
    pen.setWidth(2);
    pen.setColor(Qt::green);
    pen.setStyle(Qt::DashDotLine);
    painter->setPen(pen);

    if (valid) painter->drawLine(x_value,y_value,x_value,plot_Size_Y/2-4*textsize-margin);
    }



    if (select_Rect==1){
        QPen pen;
        pen.setWidth(1);
        pen.setColor(Qt::red);
        painter->setBrush(Qt::NoBrush);
        painter->setPen(pen);
        if (valid) painter->drawRect(QRect(sel_x1,sel_y1,(sel_x2-sel_x1),(sel_y2-sel_y1)));
    }


}

    // Draw message
    QPen pen;
    pen.setColor(Qt::black);
    painter->setPen(pen);
    if (amsdata->get_Length()==0 ) painter->drawText(0,0,"No Age Model");
    if (valid==false)  painter->drawText(0,0,"No valid data");


}

void CalibPlotData::setSize(int x,int y){
    plot_Size_X=x;
    plot_Size_Y=y;
}

void CalibPlotData::setAMSData(AMSData *i){
    amsdata=i;
}

void CalibPlotData::setPlot(int x,int y,int fx,int fy,QString inter){
    x_axis=x;
    y_axis=y;
    factor_x=fx;
    factor_y=fy;
    int_style=inter;
}

QRectF CalibPlotData::boundingRect() const
{
}

QPainterPath CalibPlotData::shape() const
{
}

double CalibPlotData::get_x_max(){
    return x_max;
}

double CalibPlotData::get_x_min(){
    return x_min;
}
double CalibPlotData::get_y_min(){
    return y_min;
}

double CalibPlotData::get_y_max(){
    return y_max;
}

void CalibPlotData::setSelected(int n){
    selected=n;
}

void CalibPlotData::setView(double x1,double x2,double y1,double y2){
    x_min=x1;
    x_max=x2;
    y_min=y1;
    y_max=y2;
}

void CalibPlotData::setRect(int x1,int x2, int y1, int y2, int mode){
    select_Rect=mode;
    sel_x1=x1;
    sel_x2=x2;
    sel_y1=y1;
    sel_y2=y2;
}

 int CalibPlotData::getSelected(){
     if (selected>amsdata->get_Length()) selected=-1;
     return selected;
 }

void CalibPlotData::setValue(float v, float vm, float vp){
    value=v;
    valuem=vm;
    valuep=vp;
}

double CalibPlotData::get_Calender(){
    return cvalue;
}
double CalibPlotData::get_Calender_UCL(){
    return cvaluep;
}

double CalibPlotData::get_Calender_LCL(){
    return cvaluem;
}

double CalibPlotData::get_Calender_Median(){
    return amsdata->get_CalMedian();
}

double CalibPlotData::get_Calender_WMean(){
    return amsdata->get_CalWMean();
}

double CalibPlotData::get_Calender_MidAge(){
    return amsdata->get_CalMidAge();
}

double CalibPlotData::get_Calender_U95(){
    return amsdata->get_Cal95U();
}

double CalibPlotData::get_Calender_L95(){
    return amsdata->get_Cal95L();
}


void CalibPlotData::setValid(bool i){
    valid=i;
}

