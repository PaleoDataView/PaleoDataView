/********************************************************************************/
/*    This file is part of PaleoDataViewer.                       					*/
/*                                                                      		*/
/*    PaleoDataViewer is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoDataViewer is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoDataViewer.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#include "calibaxis.h"

CalibAxis::CalibAxis(QGraphicsScene *graphScene)
    : graph(graphScene)
{
    titel="Plot";
    titel_x="X(Y)";
    titel_y="Y(X)";
    plot_Size_X=100;
    plot_Size_Y=100;
    textsize=10;
    titelsize=0;
    margin=5;
    x_min=-1;
    x_max=1;
    y_min=-1;
    y_max=1;
    ticks_x=10;
    ticks_y=5;
    grid_flag=1;
    x_axis=0;
    y_axis=1;
    factor_x=1;
    factor_y=-1;
    valid=false;
}

CalibAxis::~CalibAxis(){

}

void CalibAxis::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget){
    if (amsdata->get_Length()>=1 && valid==true){



    // draw titel
    QFont font_titel("times", 0.75*titelsize,QFont::Bold);
    QFontMetrics fm_titel(font_titel);
    int str_len=fm_titel.width(titel);
    painter->setFont(font_titel);
    if (titelsize!=0)painter->drawText(-str_len/2,-plot_Size_Y/2+titelsize*0.75+margin,titel);

    // draw titel x-axis
    QFont font_titel_xy("times", textsize);
    QFontMetrics fm_titel_xy(font_titel_xy);
    str_len=fm_titel_xy.width(titel_x);
    painter->setFont(font_titel_xy);
    painter->drawText(-str_len/2,plot_Size_Y/2-margin,titel_x);

    // draw titel y-axis
    str_len=fm_titel_xy.width(titel_x);
    painter->setFont(font_titel_xy);
    painter->rotate(-90);
    painter->drawText(-str_len/2,-plot_Size_X/2+textsize+margin,titel_y);
    painter->rotate(90);

    // draw Frame of Plot
    painter->drawRect(QRect(-plot_Size_X/2+4*textsize+margin,-plot_Size_Y/2+titelsize+margin,plot_Size_X-2*margin-4*textsize,plot_Size_Y-2*margin-4*textsize-titelsize));

    // draw x-Axis

    QFont font_axis("times", textsize);
    QFontMetrics fm_axis(font_axis);
    painter->setFont(font_axis);

    // estimate resolution
    double dx = (x_max - x_min) / ticks_x;
    if (dx == 0) {
         dx = x_max;
    }

    if (fabs(dx) > 1) {
        dx = (int) (dx / pow(10, (int) ((1 / log(10)) * log(dx)))) * pow(10, (int) ((1 / log(10)) * log(dx)));
    } else {
        int i = 0;
        while ((int) dx == 0) {
            dx = dx * 10;
            i = i + 1;
        }
        dx = (int) dx;
        dx = dx / (pow(10, i));
    }
    if (dx == 0) {
        dx = (x_max - x_min) / ticks_x;
    }

    // draw lines and numbers
    double view_x_min = (ceil(x_min / dx)) * dx;
    double view_x_max = (floor(x_max / dx)) * dx;
    int len = plot_Size_X;

    for (int i = 0; view_x_min + dx * i <= x_max; i++) {
        int x = (int) (-plot_Size_X/2+4*textsize+margin + (double) (plot_Size_X-2*margin-4*textsize) * (double) ((view_x_min + dx * i) - x_min) / (x_max - x_min));
        painter->drawLine(x, plot_Size_Y/2-margin-4*textsize, x,plot_Size_Y/2-margin-4*textsize + 3);

        QString val = QString::number(floor((view_x_min + dx * i) * 1000000000) / 1000000000*factor_x);

        // prevent overlaping numbers
        str_len=fm_axis.width(val);
        len = len + (int) ((double) (plot_Size_X-2*margin-4*textsize) * (double) (dx / (view_x_max - view_x_min)));
        if (str_len < len - 32 && view_x_min + dx * i < 0) {
            len = 0;
            painter->drawText(x - str_len / 2, plot_Size_Y/2-margin-2*textsize,val);
        }
        if (str_len + 5 < len - 32 && view_x_min + dx * i > 0) {
            len = 0;
            painter->drawText(x - str_len / 2, plot_Size_Y/2-margin-2*textsize,val);
        }
        if (str_len + 18 < len - 32 && view_x_min + dx * i == 0) {
            len = 0;
            painter->drawText(x - str_len / 2, plot_Size_Y/2-margin-2*textsize,val);
        }

        // draw Grid
        if (grid_flag && (x > -plot_Size_X/2+4*textsize+margin + 1) && (x < plot_Size_X/2-margin - 1)) {
            painter->setPen(QColor(Qt::gray));
            painter->drawLine(x, -plot_Size_Y/2+margin+titelsize+1, x, plot_Size_Y/2-margin-4*textsize-1);
            painter->setPen(QColor(Qt::black));
        }
    }

    // draw y-Axis

    // estimate resolution
    double dy = (y_max - y_min) / ticks_y;
    if (dy == 0) {
        dy = y_max;
    }

    if (fabs(dy) > 1) {
        dy = (int) (dy / pow(10, (int) ((1 / log(10)) * log(dy)))) * pow(10, (int) ((1 / log(10)) * log(dy)));
    } else {
        int i = 0;
        while ((int) dy == 0) {
            dy = dy * 10;
            i = i + 1;
        }
        dy = (int) dy;
        dy = dy / (pow(10, i));
    }
    if (dy == 0) {
        dy = (y_max - y_min) / ticks_y;
    }

    // draw lines and numbers
    double view_min_y = (ceil(y_min / dy)) * dy;
    double view_max_y = (floor(y_max / dy)) * dy;
    len = plot_Size_Y;

    for (int i = 0; view_max_y - dy * i >= y_min; i++) {
        int y = (int) (-plot_Size_Y/2+titelsize+margin+ (double) (plot_Size_Y-2*margin-4*textsize-titelsize) * (double) ((y_max - (view_max_y - dy * i)) / (y_max - y_min)));
        if (grid_flag && y > (-plot_Size_Y/2+titelsize+margin + 1) && y < (plot_Size_Y-margin - 1)) {
            painter->setPen(QColor(Qt::gray));
            painter->drawLine(-plot_Size_X/2+margin+4*textsize + 1, y, plot_Size_X/2-margin -1, y);
            painter->setPen(QColor(Qt::black));
        }
        painter->drawLine(-plot_Size_X/2+margin+4*textsize, y, -plot_Size_X/2+margin+4*textsize - 3, y);


        QString val = QString::number(floor((view_max_y - dy * i) * 1000000000) / 1000000000*factor_y);

        // prevent overlaping numbers
        str_len=fm_axis.width(val);

        len = len + (int) ((double) (plot_Size_Y-2*margin-4*textsize-titelsize) * (double) (dy / (view_max_y - view_min_y)));
        painter->rotate(-90);
        if (str_len < len - 32 && view_max_y - dy * i < 0) {
            len = 0;
            painter->drawText( (int) -y - str_len / 2,-plot_Size_X/2+margin+3*textsize,val);
        }
        if (str_len + 5 < len - 32 && view_max_y - dy * i >= 0) {
            len = 0;
            painter->drawText( (int) -y - str_len / 2,-plot_Size_X/2+margin+3*textsize,val);
        }
        if (str_len + 18 < len - 32 && view_max_y - dy * i == 0) {
            len = 0;
            painter->drawText( (int) -y - str_len / 2,-plot_Size_X/2+margin+3*textsize,val);
        }
        painter->rotate(90);
    }
}

}

void CalibAxis::setSize(int x,int y){
    plot_Size_X=x;
    plot_Size_Y=y;
}

void CalibAxis::setAMSData(AMSData *i){
    amsdata=i;

}

void CalibAxis::setPlot(int x,int y,QString t,QString tx,QString ty,int fx,int fy){
    x_axis=x;
    y_axis=y;
    titel=t;
    titel_x=tx;
    titel_y=ty;
    factor_x=fx;
    factor_y=fy;
}

void CalibAxis::setView(double x1,double x2,double y1,double y2){
    x_min=x1;
    x_max=x2;
    y_min=y1;
    y_max=y2;
}

QRectF CalibAxis::boundingRect() const
{
}

QPainterPath CalibAxis::shape() const
{
}

void CalibAxis::setValid(bool i){
    valid=i;
}
