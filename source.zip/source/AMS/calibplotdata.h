/********************************************************************************/
/*    This file is part of PaleoDataViewer.                       					*/
/*                                                                      		*/
/*    PaleoDataViewer is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoDataViewer is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoDataViewer.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#ifndef CALIBPLOTDATA_H
#define CALIBPLOTDATA_H


#include <QGraphicsScene>
#include <QPainter>
#include <QFont>
#include <QGraphicsItem>
#include "General/inventory.h"
#include "amsdata.h"

class CalibPlotData : public QGraphicsItem
{

public:
    CalibPlotData(QGraphicsScene *graphScene);
    ~CalibPlotData();
    void setSize(int x,int y);
    void setAMSData(AMSData *i);
    void setPlot(int x,int y,int fx,int fy,QString inter);
    QRectF boundingRect() const Q_DECL_OVERRIDE;
    QPainterPath shape() const Q_DECL_OVERRIDE;
    void paint(QPainter *painter,const QStyleOptionGraphicsItem *option, QWidget *widget) Q_DECL_OVERRIDE;
    double get_x_min();
    double get_x_max();
    double get_y_min();
    double get_y_max();
    void setSelected(int n);
    int getSelected();
    void setView(double x1,double x2,double y1,double y2);
    void setRect(int x1,int x2, int y1, int y2, int mode);
    void setValue(float v, float vm, float vp);
    double get_Calender();
    double get_Calender_UCL();
    double get_Calender_LCL();
    double get_Calender_Median();
    double get_Calender_MidAge();
    double get_Calender_WMean();
    double get_Calender_U95();
    double get_Calender_L95();

    void setValid(bool i);
private:
    QGraphicsScene *graph;
    int plot_Size_X;
    int plot_Size_Y;
    AMSData *amsdata;
    int textsize;
    int titelsize;
    int margin;
    double x_min,y_min,x_max,y_max;
    int x_axis,y_axis;
    int selected;
    int select_Rect;
    int sel_x1,sel_x2,sel_y1,sel_y2;
    int factor_x,factor_y;
    QString int_style="linear";
    float value,valuem,valuep,cvalue,cvaluep,cvaluem;
    bool valid;
};

#endif // CALIBPLOTDATA_H
