/********************************************************************************/
/*    This file is part of PaleoDataViewer.                       					*/
/*                                                                      		*/
/*    PaleoDataViewer is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoDataViewer is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoDataViewer.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#ifndef AMS_H
#define AMS_H

#include <QDialog>
#include <QDebug>
#include <QMainWindow>
#include <QStandardItemModel>
#include "General/inventory.h"
#include "amsdata.h"
#include "calibplot.h"
#include "General/resources.h"
#include <QFileDialog>
#include "Dialog/attdialog.h"
#include "amsedit.h"
#include "Editor/graph.h"
#include "Bacon/bacon.h"
#include <QApplication>
namespace Ui {
class AMS;
}

class AMS : public QDialog
{
    Q_OBJECT

public:
    explicit AMS(QMainWindow *mainWindow,Inventory *inventory);
    ~AMS();
    void reject();

private:
    void paintEvent(QPaintEvent*);
    void setupTable();
    void createAMSPlot();
    void checkReversals();

protected:
    bool eventFilter(QObject *obj, QEvent *event);

private slots:
    void selected(QModelIndex mi);
    void set_CalibData();
    void attChanged(QString s1, QString s2);
    void refresh();
    void save_AMS();
    void reload();
    void calibrate();
    void calibrateAll();
    void EditEntry();
    void NewEntry();
    void DeleteEntry();
    void applyAM();

private:
    Ui::AMS *ui;

    QMainWindow *mainW;
    Inventory *inv;
    AMSData *amsdata;
    QStandardItemModel *modelData;
    Graph *amsplot;
    float *amsplot_data;
    bool *data_use;
    float *data_error;
    float *data_error2;
    QColor *col;
    int *mark;
    QString *comment;

    CalibPlot *calibplot;
    Resources *resources;
    AMSEdit *edit;
    int select;
    QByteArray sp,sp_2,sp_3;
    bool changes;

    attDialog *attd;


};

#endif // AMS_H
