/********************************************************************************/
/*    This file is part of PaleoDataViewer.                       					*/
/*                                                                      		*/
/*    PaleoDataViewer is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoDataViewer is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoDataViewer.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#ifndef CALIBAXIS_H
#define CALIBAXIS_H


#include <QGraphicsScene>
#include <QPainter>
#include <QFont>
#include <QGraphicsItem>
#include <math.h>
#include "General/inventory.h"
#include "amsdata.h"

class CalibAxis : public QGraphicsItem
{
public:
    CalibAxis(QGraphicsScene *graphScene);
    ~CalibAxis();
    void setSize(int x,int y);
    void setAMSData(AMSData *i);
    void setPlot(int x,int y,QString t,QString tx,QString ty,int fx,int fy);
    void setView(double x1,double x2,double y1,double y2);
    QRectF boundingRect() const Q_DECL_OVERRIDE;
    QPainterPath shape() const Q_DECL_OVERRIDE;
    void paint(QPainter *painter,const QStyleOptionGraphicsItem *option, QWidget *widget) Q_DECL_OVERRIDE;
    void setValid(bool i);
private:
    QGraphicsScene *graph;
    int plot_Size_X;
    int plot_Size_Y;
    QString titel;
    QString titel_x;
    QString titel_y;
    int textsize;
    int titelsize;
    int margin;
    double x_min,y_min,x_max,y_max;
    int ticks_x,ticks_y;
    int grid_flag;
    AMSData *amsdata;
    int x_axis,y_axis;
    int factor_x,factor_y;
    bool valid;
};

#endif // CALIBAXIS_H
