/********************************************************************************/
/*    This file is part of PaleoDataViewer.                       					*/
/*                                                                      		*/
/*    PaleoDataViewer is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoDataViewer is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoDataViewer.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#ifndef CALIBPLOT_H
#define CALIBPLOT_H


#include <QDialog>
#include <QGraphicsSceneMouseEvent>
#include <QGraphicsScene>
#include "General/inventory.h"
#include "amsdata.h"
#include "calibaxis.h"
#include "calibplotdata.h"
#include <QToolTip>
#include <QKeyEvent>

class CalibPlot : public QGraphicsScene
{
     Q_OBJECT

public:
    CalibPlot(QDialog *dialogWindow);
    ~CalibPlot();
    void setAMSData(AMSData *amsdata);
    void setSize(int plot_width,int plot_height);
    void setPlot(int x,int y,QString t,QString tx,QString ty,int fx,int fy,QString inter);
    void autoSize();
    void setView(float v,float v_min, float v_max);
    double get_View_Dated();
    double get_View_UCL();
    double get_View_LCL();

    double get_View_Calender();
    double get_View_Calender_UCL();
    double get_View_Calender_LCL();
    double get_View_Calender_Median();
    double get_View_Calender_MidAge();
    double get_View_Calender_WMean();
    double get_View_Calender_U95();
    double get_View_Calender_L95();
    int getSelected();

signals:
    void redraw();

protected:
    void mousePressEvent(QGraphicsSceneMouseEvent* mouseEvent1) Q_DECL_OVERRIDE;
    void mouseReleaseEvent(QGraphicsSceneMouseEvent* mouseEvent2) Q_DECL_OVERRIDE;
    void mouseMoveEvent(QGraphicsSceneMouseEvent* mouseEvent3) Q_DECL_OVERRIDE;
    void wheelEvent(QGraphicsSceneWheelEvent *mouseEvent4) Q_DECL_OVERRIDE;
    void mouseDoubleClickEvent(QGraphicsSceneMouseEvent *mouseEvent5) Q_DECL_OVERRIDE;

    void keyPressEvent(QKeyEvent *event) Q_DECL_OVERRIDE;
    void keyReleaseEvent(QKeyEvent *event) Q_DECL_OVERRIDE;
private:

    QDialog *dialogW;
    AMSData *amsdata;
    CalibAxis *axis;
    CalibPlotData *pdata;

    int plot_Size_X;
    int plot_Size_Y;
    QString titel;
    QString titel_x;
    QString titel_y;
    int textsize;
    int titelsize;
    int margin;
    double x_min,y_min,x_max,y_max;
    int ticks_x,ticks_y;
    int grid_flag;
    int moveFlag;
    int x_axis,y_axis;
    int key_flag;
    int frame_x1,frame_x2,frame_y1,frame_y2;
    int factor_x,factor_y;
    float value,valuem,valuep;

};

#endif // CALIBPLOT_H
