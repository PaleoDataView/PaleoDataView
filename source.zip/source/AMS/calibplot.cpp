/********************************************************************************/
/*    This file is part of PaleoDataViewer.                       					*/
/*                                                                      		*/
/*    PaleoDataViewer is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoDataViewer is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoDataViewer.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#include "calibplot.h"
#include <QDebug>

CalibPlot::CalibPlot(QDialog *dialogWindow)
    : dialogW(dialogWindow)
{
    titel="Plot";
    titel_x="X(Y)";
    titel_y="Y(X)";
    plot_Size_X=100;
    plot_Size_Y=100;
    this->setSceneRect(-plot_Size_X/2+1,-plot_Size_Y/2+1,plot_Size_X-2,plot_Size_Y-2);
    textsize=10;
    titelsize=0;
    margin=5;
    x_min=-1;
    x_max=1;
    y_min=-1;
    y_max=1;
    ticks_x=10;
    ticks_y=5;
    grid_flag=1;
    x_axis=0;
    y_axis=1;
    moveFlag=0;
    // Generate axis
    axis=new CalibAxis(this);
    axis->setAMSData(amsdata);
    this->addItem(axis);
    pdata=new CalibPlotData(this);
    pdata->setAMSData(amsdata);
    this->addItem(pdata);
    key_flag=0;
    frame_x1=0;
    frame_x2=0;
    frame_y1=0;
    frame_y2=0;
    factor_x=1;
    factor_y=-1;

    connect(this,SIGNAL(redraw()),dialogW,SLOT(refresh()));

}

CalibPlot::~CalibPlot(){
    delete axis;
    delete pdata;
}

void CalibPlot::setAMSData(AMSData *i){
    amsdata=i;
    this->autoSize();
    axis->setAMSData(amsdata);
    pdata->setAMSData(amsdata);
    update();
}

void CalibPlot::setSize(int x,int y){
    plot_Size_X=x;
    plot_Size_Y=y;
    this->setSceneRect(-plot_Size_X/2+1,-plot_Size_Y/2+1,plot_Size_X-2,plot_Size_Y-2);
    axis->setSize(x,y);

    pdata->setSize(x,y);
}

void CalibPlot::setPlot(int x,int y,QString t,QString tx,QString ty,int fx,int fy,QString inter){
    axis->setPlot(x,y,t,tx,ty,fx,fy);
    pdata->setPlot(x,y,fx,fy,inter);
    x_axis=x;
    y_axis=y;
    titel=t;
    titel_x=tx;
    titel_y=ty;
    factor_x=fx;
    factor_y=fy;
}

void CalibPlot::autoSize(){
    x_min=9e999;
    x_max=-9e999;
    y_min=9e999;
    y_max=-9e999;
    for (int i=0;i<amsdata->get_Calib_Length();i++){
        if (x_min>amsdata->get_cage(i)*factor_x) x_min=(amsdata->get_cage(i))*factor_x;
        if (x_max<amsdata->get_cage(i)*factor_x) x_max=(amsdata->get_cage(i))*factor_x;
        if (y_min>(amsdata->get_dage(i)-amsdata->get_uage(i))*factor_y) y_min=(amsdata->get_dage(i)-amsdata->get_uage(i))*factor_y;
        if (y_max<((amsdata->get_dage(i))+amsdata->get_uage(i))*factor_y) y_max=(amsdata->get_dage(i)+amsdata->get_uage(i))*factor_y;

    }
    x_min-=(x_max-x_min)*0.01;
    x_max+=(x_max-x_min)*0.01;
    y_min-=(y_max-y_min)*0.01;
    y_max+=(y_max-y_min)*0.01;
    if ((x_max-x_min)==0){
        x_max++;
        x_min--;
    }
    if ((y_max-y_min)==0){
        y_max++;
        y_min--;
    }

    axis->setView(x_min,x_max,y_min,y_max);
    pdata->setView(x_min,x_max,y_min,y_max);
    update();
}

void CalibPlot::setView(float v,float vm,float vp){
    //qDebug() << QString::number(vm);
    value=v;
    valuem=vm;
    valuep=vp;
    if (value-valuem*9>0 && value+valuep*9<amsdata->get_dage(amsdata->get_Calib_Length()-1)) pdata->setValid(true); else pdata->setValid(false);
    if (value-valuem*9>0 && value+valuep*9<amsdata->get_dage(amsdata->get_Calib_Length()-1)) axis->setValid(true); else axis->setValid(false);
    pdata->setValue(value, valuem, valuep);

    y_min=value-valuem*9;
    y_max=value+valuep*9;
    // estimate x_min for vm
    int count=0;

    x_min=99999999999999.;
    x_max=0.0;
    for (int i=0;i<amsdata->get_Calib_Length();i++){
        if (amsdata->get_dage(i)+valuep>=y_min && amsdata->get_dage(i)-valuem<=y_max){
            if (amsdata->get_cage(i)<x_min) x_min=amsdata->get_cage(i);//amsdata->get_cage(i-1)+((amsdata->get_cage(i)-amsdata->get_cage(i-1))/(amsdata->get_dage(i)-amsdata->get_dage(i-1)))*(y_min-amsdata->get_dage(i-1));
        }
        if (amsdata->get_dage(i)+valuep>=y_min && amsdata->get_dage(i)-valuem<=y_max){
            if (amsdata->get_cage(i)>x_max) x_max=amsdata->get_cage(i);//amsdata->get_cage(i-1)+((amsdata->get_cage(i)-amsdata->get_cage(i-1))/(amsdata->get_dage(i)-amsdata->get_dage(i-1)))*(y_max-amsdata->get_dage(i-1));
        }

    }

    // estimate x_max for vp


    //qDebug()<<QString::number(x_min)+":"+QString::number(x_max)+":"+QString::number(y_min)+":"+QString::number(y_max);

    x_min-=(x_max-x_min)*0.01;
    x_max+=(x_max-x_min)*0.01;
    y_min-=(y_max-y_min)*0.01;
    y_max+=(y_max-y_min)*0.01;
    if ((x_max-x_min)==0){
        x_max++;
        x_min--;
    }
    if ((y_max-y_min)==0){
        y_max++;
        y_min--;
    }

    axis->setView(x_min,x_max,y_min,y_max);
    pdata->setView(x_min,x_max,y_min,y_max);
    update();

}

double CalibPlot::get_View_Dated(){
    return value;
}

double CalibPlot::get_View_UCL(){
    return valuep*3.0;
}
double CalibPlot::get_View_LCL(){
    return valuem*3.0;
}

double CalibPlot::get_View_Calender(){
    return pdata->get_Calender();
}

double CalibPlot::get_View_Calender_UCL(){
    return pdata->get_Calender_UCL();
}
double CalibPlot::get_View_Calender_LCL(){
    return pdata->get_Calender_LCL();
}

double CalibPlot::get_View_Calender_Median(){
    return pdata->get_Calender_Median();
}
double CalibPlot::get_View_Calender_MidAge(){
    return pdata->get_Calender_MidAge();
}
double CalibPlot::get_View_Calender_WMean(){
    return pdata->get_Calender_WMean();
}

double CalibPlot::get_View_Calender_U95(){
    return pdata->get_Calender_U95();
}
double CalibPlot::get_View_Calender_L95(){
    return pdata->get_Calender_L95();
}

void CalibPlot::mousePressEvent(QGraphicsSceneMouseEvent* mouseEvent1){


}

void CalibPlot::mouseReleaseEvent(QGraphicsSceneMouseEvent* mouseEvent2){
    if(moveFlag==0 && key_flag==0){
        x_min=pdata->get_x_min();
        x_max=pdata->get_x_max();
        y_min=pdata->get_y_min();
        y_max=pdata->get_y_max();

        double x=(double)mouseEvent2->scenePos().x();
        double y=(double)mouseEvent2->scenePos().y();
        x=x_min+(x+plot_Size_X/2-margin-4*textsize)*(float)((x_max-x_min)/(float)(plot_Size_X-2*margin-4*textsize));
        y=y_max-(y+plot_Size_Y/2-margin-titelsize)*(float)((y_max-y_min)/(float)(plot_Size_Y-2*margin-4*textsize-titelsize));

        // find closest dot
        double rx=999999e999;
        int count=-1;
        for (int i=0;i<amsdata->get_Calib_Length();i++){
            double r=(x-amsdata->get_cage(i)*factor_x)*(x-amsdata->get_cage(i)*factor_x)+(y-amsdata->get_dage(i)*factor_y)*(y-amsdata->get_dage(i)*factor_y);


            if (r<rx){
               count=i;
               rx=r;
            }
        }
        if (rx/4>(float)((x_max-x_min)/(float)(plot_Size_X-2*margin-4*textsize))*(float)((x_max-x_min)/(float)(plot_Size_X-2*margin-4*textsize))+
                (float)((y_max-y_min)/(float)(plot_Size_Y-2*margin-4*textsize-titelsize))*(float)((y_max-y_min)/(float)(plot_Size_Y-2*margin-4*textsize-titelsize))) count=-1;
        int i=pdata->getSelected();
        if (i>=-1 && count==-1) count=i;
        pdata->setSelected(count);


        // Give dot details
        if (count>-1){
            QString str="Age Dated : "+QString::number(amsdata->get_dage(count))+
                    "\nAge Calibrated : "+QString::number(amsdata->get_cage(count))+
                    "\nAge Error : "+QString::number(amsdata->get_uage(count));
            QPoint pos;
            pos.setX(mouseEvent2->screenPos().x());
            pos.setY(mouseEvent2->screenPos().y());
            QToolTip::showText(pos,str,0);
        }
        update();

    }

}

void CalibPlot::mouseMoveEvent(QGraphicsSceneMouseEvent* mouseEvent3){


}

int CalibPlot::getSelected(){
    return pdata->getSelected();
}

void CalibPlot::wheelEvent(QGraphicsSceneWheelEvent *mouseEvent4){


}

void CalibPlot::mouseDoubleClickEvent(QGraphicsSceneMouseEvent *mouseEvent5){

}

void CalibPlot::keyPressEvent(QKeyEvent *event){
    //qDebug() << "Pressed :"+QString::number(event->key());
    if (event->key()==Qt::Key_Up){
        //qDebug() << "UpArrow";
        value=value+10;
        pdata->setValue(value, valuem, valuep);
        setView(value,valuem,valuep);
    }
    if (event->key()==Qt::Key_Down){
        //qDebug() << "UpDown";
        value=value-10;
        pdata->setValue(value, valuem, valuep);
        setView(value,valuem,valuep);
    }
    emit(redraw());
    update();
}
void CalibPlot::keyReleaseEvent(QKeyEvent *event){

}





