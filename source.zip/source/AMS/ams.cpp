/********************************************************************************/
/*    This file is part of PaleoDataViewer.                       					*/
/*                                                                      		*/
/*    PaleoDataViewer is free software: you can redistribute it and/or modify 		*/
/*    it under the terms of the GNU General Public License as published by  	*/
/*    the Free Software Foundation, either version 3 of the License, or     	*/
/*    (at your option) any later version.                                   	*/
/*                                                                          	*/
/*    PaleoDataViewer is distributed in the hope that it will be useful,          	*/
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of        	*/
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         	*/
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with PaleoDataViewer.  If not, see <http://www.gnu.org/licenses/>.        */
/********************************************************************************/

#include "ams.h"
#include "ui_ams.h"

AMS::AMS(QMainWindow *mainWindow,Inventory *inventory) :
    mainW(mainWindow),inv(inventory),
    ui(new Ui::AMS)
{
    resources=new Resources();
    ui->setupUi(this);
    sp=ui->splitter->saveState();
    sp_2=ui->splitter_2->saveState();
    sp_3=ui->splitter_3->saveState();
    qApp->installEventFilter(this);
    this->setWindowTitle("AMS for Core : "+inv->get_Core(inv->get_currentCore())+" : "+inv->get_Species(inv->get_currentCore())+" at "+QString::number(inv->get_Longitude(inv->get_currentCore()))+"° :"+QString::number(inv->get_Latitude(inv->get_currentCore()))+"° in "+QString::number(inv->get_Water_Depth(inv->get_currentCore()))+"m");
    select=0;
    // Read AgeModel
    amsdata=new AMSData(inv);
    amsdata->AMSRead();



    // create Age model plot
    amsplot_data=new float[0];

    data_use=new bool[0];
    data_error=new float[0];
    data_error2=new float[0];
    col=new QColor[0];
    mark=new int[0];
    comment=new QString[0];
    amsplot=new Graph(this,amsplot_data,0,0);
    createAMSPlot();


    // Read Calibration Data
    ui->label->setText(resources->get_filename_C14_Cal());
    amsdata->ReadCalib();
    // Plot Calib Data
    calibplot=new CalibPlot(this);
    calibplot->setAMSData(amsdata);

    calibplot->setPlot(0,1,"","Calender Age in [yr]","Dated Age in [yr]",1,1,"");
    calibplot->setSize(ui->graphicsView_3->width(),ui->graphicsView_3->height());
    calibplot->setView(0,100.0/3.0,100.0/3.0);
    ui->graphicsView_3->setScene(calibplot);

    // Fill Label Data
    ui->label_2->setText("Dated Age : "+QString::number(calibplot->get_View_Dated()));
    ui->label_3->setText("UCL : "+QString::number(calibplot->get_View_UCL()));
    ui->label_4->setText("LCL : "+QString::number(calibplot->get_View_LCL()));
    ui->label_6->setText("Reservoir Age : "+QString::number(amsdata->get_Data(3,0)));
    ui->label_7->setText("Calender Age (youngest mean): "+QString::number(calibplot->get_View_Calender()));
    ui->label_8->setText("Calender UCL : "+QString::number(calibplot->get_View_Calender_UCL()));
    ui->label_9->setText("Calender LCL : "+QString::number(calibplot->get_View_Calender_LCL()));
    ui->label_10->setText("Calender Age (median) :"+QString::number(calibplot->get_View_Calender_Median()));
    ui->label_11->setText("Calender Age (MidAge) :"+QString::number(calibplot->get_View_Calender_MidAge()));
    ui->label_12->setText("Calender Age (weighted mean) :"+QString::number(calibplot->get_View_Calender_WMean()));
    ui->label_13->setText("Calender Upper Limit (95%) :"+QString::number(calibplot->get_View_Calender_U95()));
    ui->label_14->setText("Calender Lower Limit (95%) :"+QString::number(calibplot->get_View_Calender_L95()));

    edit=new AMSEdit(this,amsdata,0);
    attd=new attDialog(this,"","");

    modelData = new QStandardItemModel(0,0,this);

    setupTable();

    connect(ui->tableView,SIGNAL(clicked(QModelIndex)),this,SLOT(selected(QModelIndex)));// entry selected
    connect(ui->pushButton_3,SIGNAL(clicked()),this,SLOT(set_CalibData()));// Change Calib-File
    connect(ui->pushButton_2,SIGNAL(clicked()),this,SLOT(save_AMS()));// save AMS to File
    connect(ui->pushButton_10,SIGNAL(clicked()),this,SLOT(applyAM()));// apply AMS and write to File
    connect(ui->pushButton_6,SIGNAL(clicked()),this,SLOT(reload()));// Reload AMS
    connect(ui->pushButton_4,SIGNAL(clicked()),this,SLOT(calibrate()));// Calibrate selected entry
    connect(ui->pushButton_5,SIGNAL(clicked()),this,SLOT(calibrateAll()));// Calibrate All
    connect(ui->pushButton_7,SIGNAL(clicked()),this,SLOT(NewEntry()));// Add new AMS Entry
    connect(ui->pushButton_8,SIGNAL(clicked()),this,SLOT(DeleteEntry()));// Delete Entry
    connect(ui->pushButton_9,SIGNAL(clicked()),this,SLOT(EditEntry()));// Edit Entry
    //connect(ui->pushButton_11,SIGNAL(clicked()),this,SLOT(RunBacon()));
    update();
    changes=false;
}

AMS::~AMS()
{

    delete ui;
    delete resources;
    delete amsdata;
    delete amsplot;
    delete calibplot;
    delete modelData;
    delete amsplot_data;
    delete[] amsplot_data;
    delete[] data_use;
    delete[] data_error;
    delete[] data_error2;
    delete[] col;
    delete[] mark;
    delete[] comment;
    delete edit;
    delete attd;

}

void AMS::paintEvent(QPaintEvent *)
{
    amsplot->setSize(ui->graphicsView->width(),ui->graphicsView->height());
    calibplot->setSize(ui->graphicsView_3->width(),ui->graphicsView_3->height());
    //calibplot->setView(amsdata->get_Data(0,index)*1000-amsdata->get_Data(3,index)*1000,amsdata->get_Data(1,index)*1000.0/3.0,amsdata->get_Data(2,index)*1000.0/3.0);
    // Fill Label Data
    ui->label_2->setText("Dated Age : "+QString::number(calibplot->get_View_Dated()));
    ui->label_3->setText("UCL : "+QString::number(calibplot->get_View_UCL()));
    ui->label_4->setText("LCL : "+QString::number(calibplot->get_View_LCL()));
    ui->label_6->setText("Reservoir Age : "+QString::number(amsdata->get_Data(3,select)));
    ui->label_7->setText("Calender Age (youngest mean): "+QString::number(calibplot->get_View_Calender()));
    ui->label_8->setText("Calender UCL : "+QString::number(calibplot->get_View_Calender_UCL()));
    ui->label_9->setText("Calender LCL : "+QString::number(calibplot->get_View_Calender_LCL()));
    ui->label_10->setText("Calender Age (median) :"+QString::number(calibplot->get_View_Calender_Median()));
    ui->label_11->setText("Calender Age (MidAge) :"+QString::number(calibplot->get_View_Calender_MidAge()));
    ui->label_12->setText("Calender Age (weighted mean) :"+QString::number(calibplot->get_View_Calender_WMean()));
    ui->label_13->setText("Calender Upper Limit (95%) :"+QString::number(calibplot->get_View_Calender_U95()));
    ui->label_14->setText("Calender Lower Limit (95%) :"+QString::number(calibplot->get_View_Calender_L95()));

}

void AMS::setupTable(){
    // create the model for AMSData
    delete modelData;
    modelData = new QStandardItemModel(amsdata->get_Length(),14,this);
    modelData->setHorizontalHeaderItem(0, new QStandardItem(QString("Index")));
    modelData->setHorizontalHeaderItem(1, new QStandardItem(QString("Depth")));
    modelData->setHorizontalHeaderItem(2, new QStandardItem(QString("Sample\nThickness")));
    modelData->setHorizontalHeaderItem(3, new QStandardItem(QString("Label")));
    modelData->setHorizontalHeaderItem(4, new QStandardItem(QString("Type")));
    modelData->setHorizontalHeaderItem(5, new QStandardItem(QString("Age dated\n[ka]")));
    modelData->setHorizontalHeaderItem(6, new QStandardItem(QString("Age UCL\n[ka+]")));
    modelData->setHorizontalHeaderItem(7, new QStandardItem(QString("Age LCL\n[ka-]")));
    modelData->setHorizontalHeaderItem(8, new QStandardItem(QString("Res. Age\n[ka]")));
    modelData->setHorizontalHeaderItem(9, new QStandardItem(QString("Res. Age\n Error\n[ka]")));
    modelData->setHorizontalHeaderItem(10, new QStandardItem(QString("Cal yrs\n[wm ka BP]")));
    modelData->setHorizontalHeaderItem(11, new QStandardItem(QString("Cal yrs min\n[95%]")));
    modelData->setHorizontalHeaderItem(12, new QStandardItem(QString("Cal yrs max\n[95%]")));
    modelData->setHorizontalHeaderItem(13, new QStandardItem(QString("Use Flag")));
    modelData->setHorizontalHeaderItem(14, new QStandardItem(QString("Comments")));
    ui->tableView->setModel(modelData);
    ui->tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);

    QStandardItem *var_Index = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Depth = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Sample = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Label = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Type = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Age_dated = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Age_UCL = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Age_LCL = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Age_Res = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Age_Res_Err = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Cal = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Cal_Min = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Cal_Max = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Use_Flag = new QStandardItem[amsdata->get_Length()];
    QStandardItem *var_Comment = new QStandardItem[amsdata->get_Length()];

    for (int i=0;i<amsdata->get_Length();i++){
        var_Index[i].setData(i,Qt::EditRole);
        modelData->setItem(i,0,&var_Index[i]);

        var_Depth[i].setData(amsdata->get_Depth(i),Qt::EditRole);
        modelData->setItem(i,1,&var_Depth[i]);

        var_Sample[i].setData(amsdata->get_Sample_Thickness(i),Qt::EditRole);
        modelData->setItem(i,2,&var_Sample[i]);

        var_Label[i].setText(amsdata->get_LabID(i));
        modelData->setItem(i,3,&var_Label[i]);

        var_Type[i].setText(amsdata->get_Type(i));
        modelData->setItem(i,4,&var_Type[i]);

        var_Age_dated[i].setData(amsdata->get_Data(0,i),Qt::EditRole);
        modelData->setItem(i,5,&var_Age_dated[i]);

        var_Age_UCL[i].setData(amsdata->get_Data(1,i),Qt::EditRole);
        modelData->setItem(i,6,&var_Age_UCL[i]);

        var_Age_LCL[i].setData(amsdata->get_Data(2,i),Qt::EditRole);
        modelData->setItem(i,7,&var_Age_LCL[i]);

        var_Age_Res[i].setData(amsdata->get_Data(3,i),Qt::EditRole);
        modelData->setItem(i,8,&var_Age_Res[i]);

        var_Age_Res_Err[i].setData(amsdata->get_Reservoir_Error(i),Qt::EditRole);
        modelData->setItem(i,9,&var_Age_Res_Err[i]);

        var_Cal[i].setData(amsdata->get_Data(4,i),Qt::EditRole);
        modelData->setItem(i,10,&var_Cal[i]);

        var_Cal_Min[i].setData(amsdata->get_Data(5,i),Qt::EditRole);
        modelData->setItem(i,11,&var_Cal_Min[i]);

        var_Cal_Max[i].setData(amsdata->get_Data(6,i),Qt::EditRole);
        modelData->setItem(i,12,&var_Cal_Max[i]);

        var_Use_Flag[i].setData(amsdata->get_Data(7,i),Qt::EditRole);
        var_Use_Flag[i].setCheckable(true);
        var_Use_Flag[i].setText(QString::number(amsdata->get_Data(7,i)));
        if (amsdata->get_Data(7,i)) var_Use_Flag[i].setCheckState(Qt::Checked);
        modelData->setItem(i,13,&var_Use_Flag[i]);
        modelData->setData(modelData->index(i, 13), Qt::AlignCenter,Qt::TextAlignmentRole);

        var_Comment[i].setText(amsdata->get_Age_Comment(i));
        modelData->setItem(i,14,&var_Comment[i]);




        // coloring
        if (amsdata->get_Data(7,i)){
            modelData->setData(modelData->index(i, 13), QColor(Qt::green), Qt::BackgroundRole);
        } else {
            modelData->setData(modelData->index(i, 13), QColor(Qt::red), Qt::BackgroundRole);
        }


    }
    ui->tableView->setSortingEnabled(1);
    ui->tableView->horizontalHeader()->setSortIndicator(0,Qt::AscendingOrder);
    ui->tableView->verticalHeader()->setDefaultSectionSize(ui->tableView->verticalHeader()->minimumSectionSize());
    ui->tableView->resizeColumnsToContents();
    ui->tableView->setHorizontalScrollMode(ui->tableView->ScrollPerPixel);
    ui->tableView->setSelectionMode(QAbstractItemView::NoSelection);
    ui->tableView->scrollTo(modelData->index(amsdata->getSelect(),0));
}

void AMS::selected(QModelIndex mi){
        int sel=mi.row();
        //qDebug() << "Clicked :"+QString::number(sel)+":"+QString::number(mi.column());
        QStandardItemModel* model = qobject_cast<QStandardItemModel*>(ui->tableView->model());
        QString text = model->item(sel,mi.column())->text();
        //qDebug() << text;
        int index=model->item(sel,0)->text().toInt();

        if (mi.column()==13){
            if (amsdata->get_Data(7,sel)==1){
                amsdata->set_Data(7,sel,0);
            } else {
                if (!isnan(amsdata->get_Data(4,sel))) amsdata->set_Data(7,sel,1);
                checkReversals();
            }
        }
        if (mi.column()==14){
            delete attd;
            attd=new attDialog(this,amsdata->get_Age_Comment(index),QString::number(index));
            attd->setModal(true);
            attd->show();
        }

        setupTable();
        for (int i=0;i<15;i++)if (i!=13)modelData->setData(modelData->index(index,i), QColor(Qt::gray), Qt::BackgroundRole);
        select=index;
        // recreate Age model plot
        createAMSPlot();
        // show calib

        if (amsdata->get_Type(index)=="AMS"){
            float error1=sqrt(amsdata->get_Data(1,index)*amsdata->get_Data(1,index)+amsdata->get_Reservoir_Error(index)*amsdata->get_Reservoir_Error(index));
            float error2=sqrt(amsdata->get_Data(2,index)*amsdata->get_Data(2,index)+amsdata->get_Reservoir_Error(index)*amsdata->get_Reservoir_Error(index));
            calibplot->setView(amsdata->get_Data(0,index)*1000-amsdata->get_Data(3,index)*1000,error1*1000.0/3.0,error2*1000.0/3.0);
            // Fill Label Data
            ui->label_2->setText("Dated Age : "+QString::number(calibplot->get_View_Dated()));
            ui->label_3->setText("UCL : "+QString::number(calibplot->get_View_UCL()));
            ui->label_4->setText("LCL : "+QString::number(calibplot->get_View_LCL()));
            ui->label_6->setText("Reservoir Age : "+QString::number(amsdata->get_Data(3,select)));
            ui->label_7->setText("Calender Age (youngest mean): "+QString::number(calibplot->get_View_Calender()));
            ui->label_8->setText("Calender UCL : "+QString::number(calibplot->get_View_Calender_UCL()));
            ui->label_9->setText("Calender LCL : "+QString::number(calibplot->get_View_Calender_LCL()));
            ui->label_10->setText("Calender Age (median) :"+QString::number(calibplot->get_View_Calender_Median()));
            ui->label_11->setText("Calender Age (MidAge) :"+QString::number(calibplot->get_View_Calender_MidAge()));
            ui->label_12->setText("Calender Age (weighted mean) :"+QString::number(calibplot->get_View_Calender_WMean()));
            ui->label_13->setText("Calender Upper Limit (95%) :"+QString::number(calibplot->get_View_Calender_U95()));
            ui->label_14->setText("Calender Lower Limit (95%) :"+QString::number(calibplot->get_View_Calender_L95()));


        }
        update();

}

void AMS::set_CalibData(){
    QString file = QFileDialog::getOpenFileName(this, tr("Select File"),
                                             resources->get_path_target(),
                                             tr("C14 Calibration Data (*.14C)"));


    //qDebug() << "Selected :"+file;
    amsdata->setCalibFile(file);
    ui->label->setText(file);
    amsdata->ReadCalib();
    update();
}


void AMS::attChanged(QString text,QString origin){
        int sel=origin.toInt(0,10);
        //qDebug() << "Text:"+text;
        amsdata->set_Age_Comment(text,sel);
        //inv->saveData();
        setupTable();
        changes=true;
}

void AMS::refresh(){

    setupTable();
    if(select>=0){
    for (int i=0;i<15;i++)if (i!=13)modelData->setData(modelData->index(select,i), QColor(Qt::gray), Qt::BackgroundRole);

    // recreate Age model plot
    createAMSPlot();
    // show calib
    if (amsdata->get_Type(select)=="AMS"){
        //calibplot->setView(amsdata->get_Data(0,select)*1000-amsdata->get_Data(3,select)*1000,amsdata->get_Data(1,select)*1000.0/3.0,amsdata->get_Data(2,select)*1000.0/3.0);
        // Fill Label Data
        ui->label_2->setText("Dated Age : "+QString::number(calibplot->get_View_Dated()));
        ui->label_3->setText("UCL : "+QString::number(calibplot->get_View_UCL()));
        ui->label_4->setText("LCL : "+QString::number(calibplot->get_View_LCL()));
        ui->label_6->setText("Reservoir Age : "+QString::number(amsdata->get_Data(3,select)));
        ui->label_7->setText("Calender Age (youngest mean): "+QString::number(calibplot->get_View_Calender()));
        ui->label_8->setText("Calender UCL : "+QString::number(calibplot->get_View_Calender_UCL()));
        ui->label_9->setText("Calender LCL : "+QString::number(calibplot->get_View_Calender_LCL()));
        ui->label_10->setText("Calender Age (median) :"+QString::number(calibplot->get_View_Calender_Median()));
        ui->label_11->setText("Calender Age (MidAge) :"+QString::number(calibplot->get_View_Calender_MidAge()));
        ui->label_12->setText("Calender Age (weighted mean) :"+QString::number(calibplot->get_View_Calender_WMean()));
        ui->label_13->setText("Calender Upper Limit (95%) :"+QString::number(calibplot->get_View_Calender_U95()));
        ui->label_14->setText("Calender Lower Limit (95%) :"+QString::number(calibplot->get_View_Calender_L95()));


    }
    update();}
}

void AMS::save_AMS(){
    if (amsdata->get_Length()>0) amsdata->AMSSave();
    amsplot->autoSize();
    update();
    changes=false;
}

void AMS::applyAM(){
    //qDebug()<<"Apply Model";
    //amdata->apply_Age_Model("linear");
    for (int i=0;i<inv->get_Length();i++){
        double v=amsdata->get_Int_Value_Age(inv->get_data_Isotopes(0,i),"linear");
        inv->set_data_Isotopes(1,i,v);
    }
    inv->saveData();
}


void AMS::reload(){
    delete amsdata;
    amsdata=new AMSData(inv);
    amsdata->AMSRead();
    setupTable();


    // create Age model plot
    createAMSPlot();

    // Read Calibration Data
    ui->label->setText(resources->get_filename_C14_Cal());
    amsdata->ReadCalib();
    // Plot Calib Data
    delete calibplot;
    calibplot=new CalibPlot(this);
    calibplot->setAMSData(amsdata);

    calibplot->setPlot(0,1,"","Calender Age in [yr]","Dated Age in [yr]",1,1,"");
    calibplot->setSize(ui->graphicsView_3->width(),ui->graphicsView_3->height());
    calibplot->setView(1000,100.0/3.0,100.0/3.0);
    ui->graphicsView_3->setScene(calibplot);

    // Fill Label Data
    ui->label_2->setText("Dated Age : "+QString::number(calibplot->get_View_Dated()));
    ui->label_3->setText("UCL : "+QString::number(calibplot->get_View_UCL()));
    ui->label_4->setText("LCL : "+QString::number(calibplot->get_View_LCL()));
    ui->label_6->setText("Reservoir Age : "+QString::number(amsdata->get_Data(3,select)));
    ui->label_7->setText("Calender Age (youngest mean): "+QString::number(calibplot->get_View_Calender()));
    ui->label_8->setText("Calender UCL : "+QString::number(calibplot->get_View_Calender_UCL()));
    ui->label_9->setText("Calender LCL : "+QString::number(calibplot->get_View_Calender_LCL()));
    ui->label_10->setText("Calender Age (median) :"+QString::number(calibplot->get_View_Calender_Median()));
    ui->label_11->setText("Calender Age (MidAge) :"+QString::number(calibplot->get_View_Calender_MidAge()));
    ui->label_12->setText("Calender Age (weighted mean) :"+QString::number(calibplot->get_View_Calender_WMean()));
    ui->label_13->setText("Calender Upper Limit (95%) :"+QString::number(calibplot->get_View_Calender_U95()));
    ui->label_14->setText("Calender Lower Limit (95%) :"+QString::number(calibplot->get_View_Calender_L95()));
    update();
    changes=false;
}

void AMS::calibrate(){
    if (select!=-1 && amsdata->get_Type(select)=="AMS") {
        amsdata->set_Data(4,select,amsdata->get_CalWMean()/1000.0);
        amsdata->set_Data(5,select,amsdata->get_Cal95L()/1000.0);
        amsdata->set_Data(6,select,amsdata->get_Cal95U()/1000.0);
        amsdata->set_Data(7,select,1);
        checkReversals();
        setupTable();
        changes=true;
    }
}

void AMS::calibrateAll(){
    for (int i=0;i<amsdata->get_Length();i++){
        if ( amsdata->get_Type(i)=="AMS") {
            float error=sqrt(amsdata->get_Data(1,i)*amsdata->get_Data(1,i)+amsdata->get_Reservoir_Error(i)*amsdata->get_Reservoir_Error(i));
            amsdata->calc_CalPDF(amsdata->get_Data(0,i)*1000-amsdata->get_Data(3,i)*1000,error*1000.0/3.0);
            amsdata->calc_intPDF();
            amsdata->sortInt();
            amsdata->set_Data(4,i,amsdata->get_CalWMean()/1000.0);
            amsdata->set_Data(5,i,amsdata->get_Cal95L()/1000.0);
            amsdata->set_Data(6,i,amsdata->get_Cal95U()/1000.0);
            amsdata->set_Data(7,i,1);
            changes=true;
        }
    }
    checkReversals();
    setupTable();
    select=-1;
    // create Age model plot
    createAMSPlot();
    update();
}

void AMS::NewEntry(){
    amsdata->addEntry();
    delete edit;
    edit=new AMSEdit(this,amsdata,0);
    edit->setModal(true);
    edit->show();
    changes=true;
}


void AMS::EditEntry(){
    if (select>=0&&amsdata->get_Length()>select){
        delete edit;
        edit=new AMSEdit(this,amsdata,select);
        edit->setModal(true);
        edit->show();
    }
    changes=true;
}

void AMS::DeleteEntry(){
    if (amsdata->get_Length()>0){
        if (amsdata->get_Length()==1) {

            amsdata->set_Depth(select,NAN);
            amsdata->set_Sample_Thickness(select,NAN);
            amsdata->set_LabID(select,"Unknown");
            amsdata->set_Type(select,"Unknown");
            amsdata->set_Age_Comment("default Entry: Please Edit",select);
            for (int i=0;i<7;i++) amsdata->set_Data(i,select,NAN);
            amsdata->set_Reservoir_Error(select,NAN);
            amsdata->set_Data(7,select,0);
        }
        if (amsdata->get_Length()>1) amsdata->deleteEntry(select);

        if (amsdata->get_Length()>0){
            select=0;
        } else {
            select=-1;
        }

        refresh();
    }
    changes=true;
}

void AMS::createAMSPlot(){
    delete[] amsplot_data;
    delete[] data_use;
    delete[] data_error;
    delete[] data_error2;
    delete[] col;
    delete[] mark;
    delete[] comment;
    amsplot_data=new float[amsdata->get_Length()*4];
    data_use=new bool[amsdata->get_Length()*4];
    data_error=new float[amsdata->get_Length()*4];
    data_error2=new float[amsdata->get_Length()*4];
    col=new QColor[amsdata->get_Length()*4];
    mark=new int[amsdata->get_Length()*4];
    comment=new QString[amsdata->get_Length()*4];
    for (int i=0;i<amsdata->get_Length();i++){
        amsplot_data[i+0*amsdata->get_Length()]=amsdata->get_Depth(i);
        amsplot_data[i+1*amsdata->get_Length()]=amsdata->get_Data(0,i);
        amsplot_data[i+2*amsdata->get_Length()]=amsdata->get_Depth(i);
        amsplot_data[i+3*amsdata->get_Length()]=amsdata->get_Data(4,i);
        data_use[i+0*amsdata->get_Length()]=amsdata->get_Data(7,i);
        data_use[i+1*amsdata->get_Length()]=amsdata->get_Data(7,i);
        data_use[i+2*amsdata->get_Length()]=amsdata->get_Data(7,i);
        data_use[i+3*amsdata->get_Length()]=amsdata->get_Data(7,i);
        data_error[i+0*amsdata->get_Length()]=NAN;
        data_error[i+1*amsdata->get_Length()]=amsdata->get_Data(2,i);
        data_error[i+2*amsdata->get_Length()]=NAN;
        //data_error[i+3*amsdata->get_Length()]=abs(amsdata->get_Data(4,i)-amsdata->get_Data(5,i));
        if (amsdata->get_Data(5,i)!=0) data_error[i+3*amsdata->get_Length()]=abs(amsdata->get_Data(4,i)-amsdata->get_Data(5,i)); else data_error[i+3*amsdata->get_Length()]=NAN;

        data_error2[i+0*amsdata->get_Length()]=NAN;
        data_error2[i+1*amsdata->get_Length()]=amsdata->get_Data(1,i);
        data_error2[i+2*amsdata->get_Length()]=NAN;
        //data_error2[i+3*amsdata->get_Length()]=abs(amsdata->get_Data(4,i)-amsdata->get_Data(6,i));
        if (amsdata->get_Data(6,i)!=0) data_error2[i+3*amsdata->get_Length()]=abs(amsdata->get_Data(4,i)-amsdata->get_Data(6,i)); else data_error2[i+3*amsdata->get_Length()]=NAN;

        col[i+0*amsdata->get_Length()]=QColor(0,0,0);
        col[i+1*amsdata->get_Length()]=QColor(255,255,0);
        col[i+2*amsdata->get_Length()]=QColor(0,0,0);
        col[i+3*amsdata->get_Length()]=QColor(0,0,255);

        //if (amdata->get_Age_Comment(i).simplified()!="NaN") comment[i+2*amdata->get_Length()]=amdata->get_Age_Comment(i);
        mark[i+0*amsdata->get_Length()]=0;
        mark[i+1*amsdata->get_Length()]=0;
        mark[i+2*amsdata->get_Length()]=0;
        mark[i+3*amsdata->get_Length()]=0;
    }
    mark[select+0*amsdata->get_Length()]=1;
    mark[select+1*amsdata->get_Length()]=1;
    mark[select+2*amsdata->get_Length()]=1;
    mark[select+3*amsdata->get_Length()]=1;
    amsplot->setData(amsplot_data,4,amsdata->get_Length());
    amsplot->setUse(data_use,1);
    amsplot->setError(data_error,2);
    amsplot->setError2(data_error2,2);
    amsplot->setColor(col,1);
    amsplot->setMark(mark,1);
    //am_plot->setComment(comment,1);
    amsplot->setTitel("","Depth [m]","Age in [kyr]");
    amsplot->setMultiplicator(1,1);
    amsplot->setTextSize(8,0,8);
    amsplot->setSize(ui->graphicsView->width(),ui->graphicsView->height());
    amsplot->setSymbol(3);
    amsplot->autoSize();
    amsplot->setSettings(resources->get_path_PaleoDataViewer()+"/Resources/Plot/AMS_AgeModel.txt",0);
    ui->graphicsView->setScene(amsplot);
}



bool AMS::eventFilter(QObject *obj, QEvent *event)
{
    if (event->type() == QEvent::KeyPress)
    {
        if (obj==ui->graphicsView||obj==ui->tableView||obj==ui->graphicsView_3){
            QKeyEvent *keyEvent = static_cast<QKeyEvent *>(event);
            if (keyEvent->key()==Qt::Key_F1){
                ui->splitter->restoreState(sp);
                ui->splitter_2->restoreState(sp_2);
                ui->splitter_3->restoreState(sp_3);
                return true;
            }
        }
    }
    return QObject::eventFilter(obj, event);
}

void AMS::reject()
{
    QMessageBox::StandardButton resBtn = QMessageBox::Yes;
    if (changes) {
        resBtn = QMessageBox::question( this,"PaleoDataViewer - AMS",
                                        tr("There are unsaved changes.\nAre you sure?\n"),
                                        QMessageBox::Cancel | QMessageBox::Yes,
                                        QMessageBox::Yes);
    }
    if (resBtn == QMessageBox::Yes) {
        QDialog::reject();
    }
}

void AMS::checkReversals(){
    for(int i=0;i<amsdata->get_Length();i++){
        int ok=1;
        if(amsdata->get_Data(7,i)==1){
            // check previous
            if(i>0){
                for (int j=i-1;j>=0;j--){
                    if (amsdata->get_Data(7,j)==1){
                        if (amsdata->get_Data(4,i)<amsdata->get_Data(4,j)) ok=0;
                    }
                }
            }
            // check followers
            if(i<amsdata->get_Length()-1){
                for(int j=i+1;j<amsdata->get_Length();j++){
                    if (amsdata->get_Data(7,j)==1){
                        if (amsdata->get_Data(4,i)>amsdata->get_Data(4,j)) ok=0;
                    }
                }

            }
            if (ok==0){
                amsdata->set_Data(7,i,0);
            }
        }
    }
}
