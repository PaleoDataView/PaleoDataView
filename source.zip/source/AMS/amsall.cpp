#include "amsall.h"
#include "ui_amsall.h"

AMSAll::AMSAll(QMainWindow *mainWindow,Inventory *inventory) :
    mainW(mainWindow),inv(inventory),
    ui(new Ui::AMSAll)
{
    ui->setupUi(this);
    resources=new Resources();
    amsdata=new AMSData(inv);
    ui->lineEdit->setText(resources->get_filename_C14_Cal());
    amsdata->ReadCalib();

    connect(ui->pushButton_2,SIGNAL(clicked()),this,SLOT(set_CalibData()));// Change Calib-File
    connect(ui->pushButton,SIGNAL(clicked(bool)),this,SLOT(start()));
    connect(this,SIGNAL(refresh()),mainW,SLOT(redraw_score()));
}

AMSAll::~AMSAll()
{
    delete ui;
    delete resources;
    delete amsdata;
}

void AMSAll::set_CalibData(){
    QString file = QFileDialog::getOpenFileName(this, tr("Select File"),
                                             resources->get_path_target(),
                                             tr("C14 Calibration Data (*.14C)"));


    //qDebug() << "Selected :"+file;
    amsdata->setCalibFile(file);
    ui->lineEdit->setText(file);
    amsdata->ReadCalib();
    update();
}

void AMSAll::start(){
    for (int i=0;i<inv->get_Entries();i++) inv->set_Selected(i,0); // deselect all
    for (int i=0;i<inv->get_Entries();i++){
        inv->set_currentCore(i);
        ui->plainTextEdit->appendPlainText("\n"+inv->get_Core(inv->get_currentCore()));
        amsdata->AMSRead();
        calibrateAll();
        amsdata->AMSSave();
    }
    emit(refresh());
    ui->plainTextEdit->appendPlainText("\nChecked and callibrated all agemodels. See list in mainwindow for changed proxy agemodels.");

}

void AMSAll::calibrateAll(){
    for (int i=0;i<amsdata->get_Length();i++){
        if ( amsdata->get_Type(i)=="AMS") {
            if (amsdata->get_Data(4,i)==NAN && ui->radioButton->isChecked()){
                float error=sqrt(amsdata->get_Data(1,i)*amsdata->get_Data(1,i)+amsdata->get_Reservoir_Error(i)*amsdata->get_Reservoir_Error(i));
                amsdata->calc_CalPDF(amsdata->get_Data(0,i)*1000-amsdata->get_Data(3,i)*1000,error*1000.0/3.0);
                amsdata->calc_intPDF();
                amsdata->sortInt();
                amsdata->set_Data(4,i,amsdata->get_CalWMean()/1000.0);
                amsdata->set_Data(5,i,amsdata->get_Cal95L()/1000.0);
                amsdata->set_Data(6,i,amsdata->get_Cal95U()/1000.0);
                amsdata->set_Data(7,i,1);
                inv->set_Selected(inv->get_currentCore(),1);
                ui->plainTextEdit->appendPlainText(QString::number(i)+" of "+QString::number(amsdata->get_Length())+" : found uncalibrated AMS: Calibrated");
            }
            if (amsdata->get_Data(4,i)!=NAN && (!ui->radioButton->isChecked())){
                float error=sqrt(amsdata->get_Data(1,i)*amsdata->get_Data(1,i)+amsdata->get_Reservoir_Error(i)*amsdata->get_Reservoir_Error(i));
                amsdata->calc_CalPDF(amsdata->get_Data(0,i)*1000-amsdata->get_Data(3,i)*1000,error*1000.0/3.0);
                amsdata->calc_intPDF();
                amsdata->sortInt();
                amsdata->set_Data(4,i,amsdata->get_CalWMean()/1000.0);
                amsdata->set_Data(5,i,amsdata->get_Cal95L()/1000.0);
                amsdata->set_Data(6,i,amsdata->get_Cal95U()/1000.0);
                amsdata->set_Data(7,i,1);
                inv->set_Selected(inv->get_currentCore(),1);
                ui->plainTextEdit->appendPlainText(QString::number(i)+" of "+QString::number(amsdata->get_Length())+"found calibrated AMS: Re-Calibrated");
            }
        }
    }
    checkReversals();
}

void AMSAll::checkReversals(){
    for(int i=0;i<amsdata->get_Length();i++){
        int ok=1;
        if(amsdata->get_Data(7,i)==1){
            // check previous
            if(i>0){
                for (int j=i-1;j>=0;j--){
                    if (amsdata->get_Data(7,j)==1){
                        if (amsdata->get_Data(4,i)<amsdata->get_Data(4,j)) ok=0;
                    }
                }
            }
            // check followers
            if(i<amsdata->get_Length()-1){
                for(int j=i+1;j<amsdata->get_Length();j++){
                    if (amsdata->get_Data(7,j)==1){
                        if (amsdata->get_Data(4,i)>amsdata->get_Data(4,j)) ok=0;
                    }
                }

            }
            if (ok==0){
                amsdata->set_Data(7,i,0);
            }
        }
    }
}


